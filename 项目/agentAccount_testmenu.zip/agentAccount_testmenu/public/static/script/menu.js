// 传给外部页面的菜单
window.agentAcountMenu = [
  {
    text: '首页New',
    id: 'homePageNew',
    path: '/homepageNew',
  },
  {
    text: '客户管理',
    id: 'customManage',
    path: '/custom/list',
  },
  {
    text: '客户详情',
    id: 'customEdit',
    path: '/custom/detail/',
  },
  // 合同管理
  {
    text: '合同列表',
    id: 'contractList',
    path: '/contract/list',
  },
  {
    text: '新增合同',
    id: 'contractAdd',
    path: '/contract/add',
  },
  {
    text: '查看合同',
    id: 'contractView',
    path: '/contract/view',
  },
  {
    text: '变更合同',
    id: 'contractEdit',
    path: '/contract/edit',
  },
  {
    text: '续签合同',
    id: 'contractRenewal',
    path: '/contract/renewal',
  },
  {
    text: '查看电子合同',
    id: 'EtcContractView',
    path: '/EtcContract/view',
  },
  {
    text: '合同设置',
    id: 'contractSetting',
    path: '/contract/setting',
  },
  // 收费管理
  {
    text: '应收单',
    id: 'receivable',
    path: '/charge/receivable',
  },
  {
    text: '查看应收单',
    id: 'viewReceivable',
    path: '/charge/viewReceivable',
  },
  {
    text: '查看收款单',
    id: 'viewCollection',
    path: '/charge/viewCollection',
  },
  {
    text: '应收单列表',
    id: 'receivableList',
    path: '/charge/receivableList',
  },
  {
    text: '收款计划汇',
    id: 'collectionPlanList',
    path: '/charge/collectionPlanList',
  },
  {
    text: '收款单',
    id: 'collection',
    path: '/charge/collection',
  },
  {
    text: '收款单列表',
    id: 'collectionList',
    path: '/charge/collectionList',
  },
  {
    text: '核销单',
    id: 'verification',
    path: '/charge/verification',
  },
  {
    text: '查看核销单',
    id: 'viewVerification',
    path: '/charge/viewVerification',
  },
  {
    text: '核销单列表',
    id: 'verificationList',
    path: '/charge/verificationList',
  },
  // 工作台
  {
    text: '记账平台',
    id: 'account',
    path: '/account',
  },
  // 消息管理
  {
    text: '发送消息',
    id: 'messageSend',
    path: '/message/send',
  },
  {
    text: '消息记录',
    id: 'messageRecord',
    path: '/message/record',
  },
  {
    text: '消息设置',
    id: 'messageSetting',
    path: '/message/setting',
  },
  {
    text: '系统消息',
    id: 'systemMsg',
    path: '/message/systemsg',
  },
  {
    text: '登录日志',
    id: 'loginLog',
    path: '/loginLog',
  },
  {
    text: '部门与员工',
    id: 'staff',
    path: '/staff',
  },
  {
    text: '权限中心',
    id: 'authCenter',
    path: '/authCenter',
  },
  {
    text: '权限中心New',
    id: 'authCenterNew',
    path: '/authCenterNew',
  },
  {
    text: '企业信息',
    id: 'companyInfo',
    path: '/companyInfo',
  },
  {
    text: '员工业绩',
    id: 'performance',
    path: '/performance',
  },

  // -------基础设置---------
  {
    text: '业务设置',
    id: 'businessSetting',
    path: '/setting/business',
  },
  {
    text: '服务设置',
    id: 'serviceSetting',
    path: '/setting/service',
  },
  {
    text: '流程设置',
    id: 'processSetting',
    path: '/setting/process',
  },
  {
    text: '档案设置',
    id: 'archivesSetting',
    path: '/setting/archives',
  },
  {
    text: '报税设置',
    id: 'taxSetting',
    path: '/setting/tax',
  },
  {
    text: '代开设置',
    id: 'dkSetting',
    path: '/setting/dkSet',
  },

  // 工商服务
  // 工商任务列表
  {
    text: '参数配置',
    id: 'businessList',
    path: '/businessServe/businessList',
  },
  {
    text: '参数配置',
    id: 'paramConfig',
    path: '/businessServe/paramConfig',
  },
  {
    text: '任务单',
    id: 'businessTask',
    path: '/businessServe/task',
  },
  {
    text: '查看任务单',
    id: 'businessViewTask',
    path: '/businessServe/viewTask',
  },
  {
    text: '任务执行单',
    id: 'taskExecution',
    path: '/businessServe/taskExecution',
  },
  // 权限
  {
    text: '授权查账',
    id: 'checkAccount',
    path: '/auth/checkAccount',
  },
  {
    text: '进项勾选',
    id: 'invoice',
    path: '/invoice',
  },
];
