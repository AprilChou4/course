export default {
  getList() {
    return {
      status: 200,
      data: {
        list: [
          {
            customerId: '123',
            customerName: '北京大来创杰咨询有限责任公司上海公司公司公司公司公asldjhlasjkdlaksjdlkj',
            bookkeepingAccounting: '欧阳计会呵呵哒2…asdlkjadsas',
            grantUsers: [
              { userId: 1, realName: '张数', isInvalid: false },
              { userId: 2, realName: '李青', isInvalid: false },
              { userId: 3, realName: '王明（13509876723）', isInvalid: false },
              { userId: 4, realName: '王明（13709341120）', isInvalid: false },
              { userId: 5, realName: '吴清风', isInvalid: false },
              { userId: 6, realName: '李逍遥（已失效）', isInvalid: true },
            ],
            validityType: 1,
          },
          {
            customerId: 'rrrwe',
            customerName: '北京大来',
            bookkeepingAccounting: '欧阳计会呵呵哒2…asdlkjadsas',
            grantUsers: [
              { userId: 1, realName: '张数', isInvalid: false },
              { userId: 2, realName: '李青', isInvalid: false },
            ],
            validityType: null,
          },
        ],
        total: 100,
      },
    };
  },
  getGrantDetail() {
    return {
      status: 200,
      data: { a: 1 },
    };
  },
  getGrantUser() {
    return {
      status: 200,
      data: {
        phoneNum: '18823131231',
        realName: 'lhz',
        remoteId: 'nuonuo-id1',
        staffId: '1lkjSL:KJDLKJD',
        userId: 'XXXXX',
        username: 'halhjsdljh1',
      },
    };
  },
  getAuthorityList() {
    return {
      status: 200,
      data: {
        appAuthorises: [
          { authorityId: 1, authorityName: '资产负债表' },
          { authorityId: 2, authorityName: '利润表' },
          { authorityId: 3, authorityName: '电子凭证' },
          { authorityId: 4, authorityName: '往来账款' },
        ],
        clientAuthorises: [
          {
            authorityId: 1,
            authorityName: '账簿',
            subClientAuthorises: [
              {
                authorityId: 2,
                authorityName: '固定资产',
              },
            ],
          },
          {
            authorityId: 3,
            authorityName: '报表',
            subClientAuthorises: [
              {
                authorityId: 4,
                authorityName: '存货',
              },
            ],
          },
        ],
      },
    };
  },
};
