import { createServices } from '@utils';
// import mock from './mock';

export default createServices({
  getList: 'instead/v2/customer/grant/list.do::postJSON', // 表格的数据
  grant: '/instead/v2/customer/grant/grant.do::postJSON', // 授权
  getGrantDetail: 'instead/v2/customer/grant/grantInfo.do::postJSON', // 查询客户授权记录
  getGrantUser: 'instead/v2/user/getUserByNameForAuthority.do::get', // 根据用户名/手机号精确匹配用户中心的用户
  getAuthorityList: '/instead/v2/user/authority/grantCustomerAuthority.do::postJSON', // 查询授权查账的权限数据
  getDeptList: 'instead/v2/user/dept/list.do', // 查询部门树
  getBookkeep: 'instead/v2/user/staff/bookkeep/list.do', // 查询记账会计集合
  removeGrantItem: 'instead/v2/customer/grant/delete.do::postJSON', // 删除授权
  // ...mock,
});
