import { message } from 'antd';
import { pick, flatten, omit } from 'lodash';
import services from '../services';
import {
  MODAL_STATUS,
  PREFIX_KEY_APP,
  PREFIX_KEY_CLIENT,
  generateDataSource,
  normalizeParams,
  INIT_FORM,
} from '../utils';

export default {
  // 获取表格数据
  async $getList(changeFields = {}) {
    const { pageSize, customerName, grantUser, deptIds, bookkeepingAccounting } = this.getState();
    console.log(changeFields);
    const params = {
      current: 1,
      pageSize,
      customerName,
      grantUser,
      deptIds,
      bookkeepingAccounting,
      ...changeFields,
    };

    console.log('最终参数:', params);
    const data = await services.getList(params);
    this.updateState({
      dataSource: data.list || [],
      total: data.total,
      ...changeFields,
      selectedRows: [],
    });
    console.log('最终state:', this.getState());
  },

  // 授权查账
  async $grant() {
    const { modalFormValues, clientIdMap } = this.getState();
    const params = normalizeParams(modalFormValues, clientIdMap);
    await services.grant(params);
    message.success('保存成功');
    this.updateState({
      isModalVisible: false,
      modalStatus: MODAL_STATUS.ADD,
      modalFormValues: INIT_FORM,
      grantUserInputVal: '',
    });
    await this.$getList();
  },

  async $getGrantDetail({ record, isEdit }) {
    const { customerId, customerName } = record;
    const data = await services.getGrantDetail({ customerId });
    console.log('getGrantDetail', data);
    const grantList = data.map((item) => ({
      appAuthorises: item.appAuthorises.map((t) => t.authorityId),
      clientAuthorises: flatten(
        item.clientAuthorises.map((t) => t.subClientAuthorises.map((sub) => sub.authorityId)),
      ),
      ...pick(item, [
        'realName',
        'remoteId',
        'validityType',
        'startDate',
        'endDate',
        'phoneNum',
        'isInvalid',
        'grantId',
      ]),
    }));
    this.updateState({
      isModalVisible: true,
      modalStatus: isEdit ? MODAL_STATUS.EDIT : MODAL_STATUS.VIEW,
      modalFormValues: {
        customerList: [{ customerId, customerName }],
        grantList: generateDataSource(grantList),
      },
    });
  },

  // 删除其中一条授权记录
  async $removeGrantItem(grantId) {
    // 未授权时候的删除不需要请求接口
    if (grantId) {
      await services.removeGrantItem({ grantId }, { loading: '正在删除' });
    }
    const { modalFormValues } = this.getState();
    const copyList = modalFormValues.grantList.filter((item) => item.grantId !== grantId);
    console.log('copyList', copyList);
    this.updateState({
      modalFormValues: {
        ...modalFormValues,
        grantList: copyList,
      },
    });
  },

  async $getGrantUser() {
    const { grantUserInputVal, modalFormValues } = this.getState();
    const data = await services.getGrantUser(
      { username: grantUserInputVal },
      {
        status: {
          902: () => {
            message.warn('当前账户未注册诺诺网账号，不支持授权查账');
          },
          901: () => {
            message.warn('如需将账套授权给本公司员工，请直接在客户管理页面进行指派');
          },
        },
      },
    );
    // 重复校验
    const repeatIdIdx = modalFormValues.grantList.findIndex((it) => it.remoteId === data.remoteId);
    if (repeatIdIdx > -1) {
      message.warn('查账人已存在');
      return;
    }
    // 默认查账内容是全部，所以需要遍历拿到所有id
    const { allAppIds, allClientIds } = this.getState();
    this.updateState({
      modalFormValues: {
        ...modalFormValues,
        grantList: generateDataSource(
          modalFormValues.grantList.concat({
            ...pick(data, ['remoteId', 'phoneNum', 'realName']),
            appAuthorises: allAppIds,
            clientAuthorises: allClientIds,
          }),
        ),
      },
      grantUserInputVal: '',
    });
  },

  // 获取部门数据
  async $getDeptList() {
    const data = await services.getDeptList();
    const deptIdMap = {};
    function dig(list) {
      list.forEach((item) => {
        deptIdMap[item.deptId] = item.name;
        if (item.children?.length) {
          dig(item.children);
        }
      });
    }
    dig(data);
    this.updateState({
      deptList: data || [],
      deptIdMap,
    });
  },

  // 获取记账会计数据
  async $getBookkeep() {
    const data = await services.getBookkeep();
    this.updateState({
      bookeepers: data || [],
    });
  },

  // 获取s
  async $getAuthorityList() {
    const data = await services.getAuthorityList();
    const { appAuthorises = [], clientAuthorises = [] } = data || {};
    const allAppIds = [];
    const allClientIds = [];
    // 通过子id找到父
    const clientIdMap = {};
    const appTreeNode = {
      title: 'APP',
      key: PREFIX_KEY_APP,
      children: appAuthorises.map((item) => {
        allAppIds.push(item.authorityId);
        return {
          title: item.authorityName,
          key: `${PREFIX_KEY_APP}${item.authorityId}`,
        };
      }),
    };
    const clientTreeNode = {
      title: '电脑端',
      key: PREFIX_KEY_CLIENT,
      children: clientAuthorises.map((item) => {
        allClientIds.push(item.authorityId);
        const node = {
          title: item.authorityName,
          key: `${PREFIX_KEY_CLIENT}${item.authorityId}`,
          children: item.subClientAuthorises.map((it) => {
            clientIdMap[it.authorityId] = item;
            allClientIds.push(it.authorityId);
            return {
              title: it.authorityName,
              key: `${PREFIX_KEY_CLIENT}${it.authorityId}`,
            };
          }),
        };
        return node;
      }),
    };
    this.updateState({
      authorityList: [appTreeNode, clientTreeNode],
      appAuthoritySize: appTreeNode.children.length,
      clientAuthoritySize: data?.clientAuthoritySize,
      clientIdMap,
      allClientIds,
      allAppIds,
    });
  },

  async initData() {
    this.$getDeptList();
    this.$getBookkeep();
    this.$getAuthorityList();
    await this.$getList();
  },
};
