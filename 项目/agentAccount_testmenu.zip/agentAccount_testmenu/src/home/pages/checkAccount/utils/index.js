import moment from 'moment';

// 初始表单值
export const INIT_FORM = {
  // 授权客户 { customerName, customerId }
  customerList: [],
  // 授权具体列表
  grantList: [
    // appAuthorises APP授权ids,
    // clientAuthorises 客户端授权ids,
    // remoteId 查账人ids
    // validityType 有效期间类型，1任意区间，3自定义期间
    // startDate 自定义期间有效的开始时间
    // endDate: 自定义期间有效的结束时间
  ],
};

// 授权弹窗当前状态
export const MODAL_STATUS = {
  // 编辑 (一定是一个客户，所以不显示“已选择客户”模块，客户名称作为弹窗title)
  EDIT: 1,
  // 新增 (显示“已选择客户”模块)
  ADD: 2,
  // 查看 (一定是一个客户，只显示表格内容，客户名称作为弹窗title)
  VIEW: 3,
};

// 构造树结构用到的前缀key
export const PREFIX_KEY_APP = 'PREFIX_KEY_APP/';
export const PREFIX_KEY_CLIENT = 'PREFIX_KEY_CLIENT/';

// 1. 遍历授权列表，将无名的显示手机号，将重复名字的加上手机号
// 2. validityType 查账期间要默认设置成任意期间
// 3. 自定义期间默认值
export function generateDataSource(list) {
  const map = {};
  const result = [];
  for (let i = 0; i < list.length; i++) {
    const item = list[i];
    // 重复：名字 + 手机号
    if (map[item.realName] !== undefined) {
      item.showName = `${item.realName}（${item.phoneNum}）`;
      const idx = map[item.realName];
      result[idx].showName = `${result[idx].realName}（${result[idx].phoneNum}）`;
    } else {
      // 空字符不存在map
      item.realName && (map[item.realName] = i);
      item.showName = item.realName;
    }
    // 无名字：显示手机号
    if (!item.realName && !item.showName) {
      item.showName = item.phoneNum;
    }
    // 2.validityType 查账期间要默认设置成任意期间1
    item.validityType = item.validityType ?? 1;
    // 3.自定义期间默认值
    item.startDate = item.startDate ? moment(item.startDate, 'X') : moment();
    item.endDate = item.endDate ? moment(item.endDate, 'X') : moment().add(1, 'years');
    result.push(item);
  }

  return result;
}

// 通过id数组，带出父级的id
function withParentId(list, map) {
  const parentIds = list
    .map((item) => (map[item] ? map[item].authorityId : undefined))
    .filter((_) => _);
  return [...new Set([...list, ...parentIds])];
}

// 整理后端需要的数据
export function normalizeParams(values, map) {
  const { customerList, grantList: list } = values;

  const customerIdList = customerList.map((t) => t.customerId);
  const customerNameList = customerList.map((t) => t.customerName);
  const grantList = list.map((t) => ({
    appAuthorityIdList: t.appAuthorises,
    clientAuthorityIdList: withParentId(t.clientAuthorises, map),
    remoteId: t.remoteId,
    validityType: t.validityType,
    startDate: t.validityType === 3 ? t.startDate.unix() : null,
    endDate: t.validityType === 3 ? t.endDate.unix() : null,
  }));

  return { customerIdList, customerNameList, grantList };
}

export default {};
