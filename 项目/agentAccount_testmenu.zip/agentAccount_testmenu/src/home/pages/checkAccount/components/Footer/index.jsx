import React from 'react';
import { Pagination } from 'antd';
import { connect } from 'nuomi';

const Footer = ({ pageSize, current, total, dispatch }) => {
  // 页码改变
  function handlePageChange(page) {
    dispatch({
      type: '$getList',
      payload: {
        current: page,
      },
    });
  }

  // pageSize变化
  function handlePageSizeChange(_, size) {
    dispatch({
      type: '$getList',
      payload: {
        current: 1,
        pageSize: size,
      },
    });
  }
  return (
    <div style={{ textAlign: 'right' }}>
      <Pagination
        pageSize={pageSize}
        current={current}
        total={total}
        showSizeChanger
        onChange={handlePageChange}
        pageSizeOptions={['20', '50', '100']}
        onShowSizeChange={handlePageSizeChange}
      />
    </div>
  );
};

export default connect(({ pageSize, current, total }) => ({ pageSize, current, total }))(Footer);
