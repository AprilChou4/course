import React from 'react';
import LinkButton from '@components/buttons/LinkButton';
import AntdTable from '@components/table/AntdTable';
import { connect } from 'nuomi';
import { MODAL_STATUS } from '../../utils';

const Content = ({ dataSource, selectedRows, loading, dispatch }) => {
  // 授权查账
  const handleGrant = ({ customerId, customerName }) => {
    dispatch({
      type: 'updateState',
      payload: {
        isModalVisible: true,
        modalStatus: MODAL_STATUS.ADD,
        modalFormValues: {
          customerList: [{ customerId, customerName }],
          grantList: [],
        },
      },
    });
  };

  // 查看、编辑授权
  const handleEditGrant = (record, isEdit) => {
    dispatch({
      type: '$getGrantDetail',
      payload: { record, isEdit },
    });
  };

  const columns = [
    {
      title: '客户名称',
      dataIndex: 'customerName',
      className: 'th-center',
      width: 360,
      ellipsis: true,
    },
    {
      title: '记账会计',
      dataIndex: 'bookkeepingAccounting',
      align: 'center',
      ellipsis: true,
      width: 130,
    },
    {
      title: '查账人',
      dataIndex: 'grantUsers',
      className: 'th-center',
      render: (userList) => {
        if (!userList.length) return '-';
        return userList.map((user, idx) => (
          <span
            key={user.userId}
            style={{ color: user.isInvalid ? '#f5222d' : '#323232 ', display: 'inline-block' }}
          >
            {user.realName}
            {user.isInvalid && ' (已失效)'}
            {idx !== userList.length - 1 ? '，' : ''}
          </span>
        ));
      },
    },
    {
      title: '操作',
      dataIndex: 'opt',
      align: 'center',
      width: 90,
      render: (_, record) => {
        if (record.grant) {
          return (
            <>
              <LinkButton className="e-mr12" onClick={() => handleEditGrant(record, false)}>
                查看
              </LinkButton>
              <LinkButton onClick={() => handleEditGrant(record, true)}>编辑</LinkButton>
            </>
          );
        }
        return <LinkButton onClick={() => handleGrant(record)}>授权查账</LinkButton>;
      },
    },
  ];

  // 选择/取消选择某行
  function handleRowsChange(selectedKeys) {
    dispatch({
      type: 'updateState',
      payload: {
        selectedRows: selectedKeys,
      },
    });
  }

  return (
    <div style={{ height: '100%', paddingBottom: 20 }}>
      <AntdTable
        bordered
        rowKey="customerId"
        columns={columns}
        dataSource={dataSource}
        loading={loading}
        scroll={{ y: true }}
        rowSelection={{
          columnWidth: 40,
          selectedRowKeys: selectedRows,
          onChange: handleRowsChange,
        }}
        locale={{ emptyText: '未找到与“诺诺网”相关的授权' }}
      />
    </div>
  );
};

export default connect(({ dataSource, selectedRows, loadings }) => ({
  dataSource,
  selectedRows,
  loading: loadings.$getList,
}))(Content);
