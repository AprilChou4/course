import React from 'react';
import Layout from '@components/Layout';
import ContentWrapper from '@components/ContentWrapper';
import Left from '../Left';
import Right from '../Right';
import Content from '../Content';
import Footer from '../Footer';
import GrantModal from '../GrantModal';

const Main = () => {
  return (
    <Layout.PageWrapper>
      <ContentWrapper
        header={{
          left: <Left />,
          right: <Right />,
        }}
        content={<Content />}
        footer={<Footer />}
      />
      <GrantModal />
    </Layout.PageWrapper>
  );
};

export default Main;
