import React, { useMemo, useState } from 'react';
import { Modal, Icon, Input, Button, message } from 'antd';
import { connect } from 'nuomi';
import classNames from 'classnames';
import Table from './Table';
import { MODAL_STATUS, INIT_FORM } from '../../utils';

import './style.less';

const GrantModal = ({
  isModalVisible,
  modalStatus,
  grantUserInputVal,
  modalFormValues,
  searchUserLoading,
  confirmLoading,
  dispatch,
}) => {
  // 客户大于一个客户的时候用的上
  const [expand, setExpand] = useState(false);

  // 关闭弹窗
  const handleCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        isModalVisible: false,
        modalFormValues: INIT_FORM,
        selectedRows: [],
        grantUserInputVal: '',
      },
    });
    setExpand(false);
    dispatch({
      type: '$getList',
    });
  };

  // 查账人搜索关键词输入
  const handleInputChange = (e) => {
    dispatch({
      type: 'updateState',
      payload: {
        grantUserInputVal: e.target.value,
      },
    });
  };

  // 查账人搜索
  const handleSearchGrantUser = () => {
    dispatch({
      type: '$getGrantUser',
    });
  };

  // 删除其中一个授权客户
  const remove = (idx) => {
    const copyCustomerList = [...modalFormValues.customerList];
    copyCustomerList.splice(idx, 1);
    dispatch({
      type: 'updateState',
      payload: {
        modalFormValues: {
          ...modalFormValues,
          customerList: copyCustomerList,
        },
      },
    });
  };

  // 提交
  const onSubmit = () => {
    // 查看时，直接变成编辑
    if (modalStatus === MODAL_STATUS.VIEW) {
      dispatch({
        type: 'updateState',
        payload: {
          modalStatus: MODAL_STATUS.EDIT,
        },
      });
      return;
    }
    // 检查查账列表是否是空的
    if (!modalFormValues.grantList.length) {
      message.warn('请添加查账人');
      return;
    }
    // 校验每一项是否都有查账内容
    const everyHasAuthList = modalFormValues.grantList.every(
      (item) =>
        item.appAuthorises && Boolean(item.appAuthorises.length + item.clientAuthorises.length),
    );
    if (!everyHasAuthList) {
      message.warn('查账内容不能为空');
      return;
    }
    dispatch({
      type: '$grant',
    });
  };

  // 弹窗标题
  const modalTitle = useMemo(() => {
    if (modalStatus === MODAL_STATUS.ADD) return '授权查账';
    return modalFormValues.customerList[0]?.customerName;
  }, [modalFormValues.customerList, modalStatus]);

  return (
    <Modal
      className="withForm"
      width="890px"
      title={modalTitle}
      visible={isModalVisible}
      onOk={onSubmit}
      onCancel={handleCancel}
      maskClosable={false}
      okText={modalStatus === MODAL_STATUS.VIEW ? '编辑' : '确认授权'}
      confirmLoading={confirmLoading}
    >
      {modalStatus === MODAL_STATUS.ADD && (
        <>
          <div className="title-mark">已选择客户</div>
          <div styleName={classNames('customer-block', { expand })}>
            {modalFormValues.customerList.length > 1 ? (
              <>
                <p styleName="expand-row">
                  <span className="customer-count">
                    共选择{modalFormValues.customerList.length}个客户
                  </span>
                  <span
                    className={classNames('expand-icon', { open: expand })}
                    onClick={() => setExpand((prev) => !prev)}
                  >
                    {expand ? '收起' : '详情'}
                    <Icon type="double-right" />
                  </span>
                </p>
                <div styleName="customer-tags">
                  {modalFormValues.customerList.map((customer, index) => (
                    <div key={customer.customerId} className="customer-tag">
                      {customer.customerName}
                      <Icon type="close-circle" theme="filled" onClick={() => remove(index)} />
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <span style={{ color: '#000' }}>{modalFormValues.customerList[0]?.customerName}</span>
            )}
          </div>
        </>
      )}
      {modalStatus === MODAL_STATUS.ADD && <div className="title-mark">查账人</div>}
      {modalStatus !== MODAL_STATUS.VIEW && (
        <div styleName="grant-user-row">
          <Input
            placeholder="请输入查账人手机号或用户名"
            value={grantUserInputVal}
            onChange={handleInputChange}
            allowClear
          />
          <Button type="primary" onClick={handleSearchGrantUser} loading={searchUserLoading}>
            添加
          </Button>
        </div>
      )}
      <Table />
    </Modal>
  );
};

export default connect(
  ({ isModalVisible, grantUserInputVal, modalStatus, modalFormValues, loadings }) => ({
    isModalVisible,
    grantUserInputVal,
    modalStatus,
    modalFormValues,
    searchUserLoading: loadings.$getGrantUser,
    confirmLoading: loadings.$grant,
  }),
)(GrantModal);
