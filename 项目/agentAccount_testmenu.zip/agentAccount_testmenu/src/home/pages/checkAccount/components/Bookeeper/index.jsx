// 记账会计
import React from 'react';
import { connect } from 'nuomi';
import { Select } from 'antd';

const Bookeeper = ({ bookeepers, allEmployeeList, value, ...rest }) => {
  return (
    <Select
      placeholder="请选择记账会计"
      value={value}
      {...rest}
      showArrow
      showSearch
      filterOption={(input, option) =>
        option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
      // getPopupContainer={(triggerNode) => triggerNode.parentNode}
    >
      {bookeepers.map(({ staffId, realName }) => (
        <Select.Option
          key={staffId}
          value={staffId}
          style={{ ...(staffId === value ? { display: 'none' } : {}) }}
        >
          {realName}
        </Select.Option>
      ))}
    </Select>
  );
};
export default connect(({ bookeepers }) => ({ bookeepers }))(Bookeeper);
