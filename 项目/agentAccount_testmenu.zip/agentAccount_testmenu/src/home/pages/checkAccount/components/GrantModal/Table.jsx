import React from 'react';
import AntdTable from '@components/table/AntdTable';
import LinkButton from '@components/buttons/LinkButton';
import ShowConfirm from '@components/ShowConfirm';
import { connect } from 'nuomi';
import { Select, DatePicker, Tooltip } from 'antd';
import TreeSelect from '../TreeSelect';
import { PREFIX_KEY_APP, PREFIX_KEY_CLIENT, MODAL_STATUS } from '../../utils';

import './style.less';

const { Option } = Select;
const { RangePicker } = DatePicker;

const Table = ({
  grantList,
  authorityList,
  clientAuthoritySize,
  appAuthoritySize,
  modalFormValues,
  modalStatus,
  dispatch,
}) => {
  // 授权节点check
  const hanldeCheck = (record, index, keys) => {
    const copyList = [...grantList];
    copyList[index].appAuthorises = [];
    copyList[index].clientAuthorises = [];
    keys.forEach((k) => {
      // APP、客户端分别统计
      if (k.indexOf(PREFIX_KEY_APP) > -1) {
        const truthKey = k.replace(PREFIX_KEY_APP, '');
        // 过滤掉自定义的节点(APP、客户端)
        truthKey && copyList[index].appAuthorises.push(+truthKey);
      } else {
        const truthKey = k.replace(PREFIX_KEY_CLIENT, '');
        truthKey && copyList[index].clientAuthorises.push(+truthKey);
      }
    });
    dispatch({
      type: 'updateState',
      payload: {
        modalFormValues: {
          ...modalFormValues,
          grantList: copyList,
        },
      },
    });
  };

  // 期限类型改变
  const handleTypeChange = (record, index, v) => {
    const copyList = [...grantList];
    copyList[index].validityType = v;
    dispatch({
      type: 'updateState',
      payload: {
        modalFormValues: {
          ...modalFormValues,
          grantList: copyList,
        },
      },
    });
  };

  // 日期区间改变
  const handleDateChange = (record, index, v) => {
    const copyList = [...grantList];
    const [start, end] = v;
    copyList[index].startDate = start;
    copyList[index].endDate = end;
    dispatch({
      type: 'updateState',
      payload: {
        modalFormValues: {
          ...modalFormValues,
          grantList: copyList,
        },
      },
    });
  };

  // 删除一项
  const handleRemove = (record) => {
    const remove = () => {
      dispatch({
        type: '$removeGrantItem',
        payload: record.grantId,
      });
    };
    if (modalStatus === MODAL_STATUS.ADD) {
      remove();
      return;
    }
    ShowConfirm({
      title: '你确定要删除所选查账人吗？',
      onOk: () => {
        remove();
      },
    });
  };

  const columns = [
    {
      title: '查账人',
      dataIndex: 'remoteId',
      key: 'remoteId',
      align: 'center',
      render: (remoteId, record) => {
        return (
          <>
            {record.isInvalid && (
              <Tooltip title="已失效" overlayClassName="white-tooltip" placement="bottomRight">
                <i className="iconfont iconjian" styleName="invalid-icon" />
              </Tooltip>
            )}
            <span style={{ verticalAlign: 'middle' }}> {record.showName}</span>
          </>
        );
      },
    },
    {
      title: '查账内容',
      dataIndex: 'authorityList',
      key: 'authorityList',
      align: 'center',
      width: 300,
      render: (list, record, index) => {
        const { appAuthorises = [], clientAuthorises = [] } = record;

        const appKeys = appAuthorises.map((t) => `${PREFIX_KEY_APP}${t}`);
        const clientKeys = clientAuthorises.map((t) => `${PREFIX_KEY_CLIENT}${t}`);

        let inputValue = '';
        if (appKeys.length) {
          inputValue += `App: ${appKeys.length === appAuthoritySize ? '全部' : '部分'}         `;
        }
        if (clientKeys.length) {
          // todo 统计客户端授权的总数
          inputValue += `电脑端: ${clientKeys.length === clientAuthoritySize ? '全部' : '部分'}`;
        }
        if (modalStatus === MODAL_STATUS.VIEW) {
          // 展示的时候缩短间隔
          return <pre styleName="authority-prev">{inputValue.replace(/\s+/, '    ')}</pre>;
        }
        return (
          <TreeSelect
            treeData={authorityList}
            inputValue={inputValue}
            checkedKeys={[...appKeys, ...clientKeys]}
            onChange={(keys) => hanldeCheck(record, index, keys)}
          />
        );
      },
    },
    {
      title: '查账期间',
      dataIndex: 'validityType',
      key: 'validityType',
      align: 'center',
      width: 250,
      render: (type, record, index) => {
        if (modalStatus === MODAL_STATUS.VIEW) {
          return type === 1
            ? '任意区间'
            : `${record.startDate.format('YYYY-MM-DD')} ~ ${record.endDate.format('YYYY-MM-DD')}`;
        }
        return (
          <div>
            <Select
              value={type}
              style={{ width: '100%' }}
              onChange={(v) => handleTypeChange(record, index, v)}
              placeholder=""
            >
              <Option value={1}>任意区间</Option>
              <Option value={3}>自定义期间</Option>
            </Select>
            {type === 3 && (
              <RangePicker
                style={{ marginTop: 5 }}
                value={[record.startDate, record.endDate]}
                onChange={(v) => handleDateChange(record, index, v)}
              />
            )}
          </div>
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'operate',
      key: 'operate',
      width: 50,
      align: 'center',
      render: (type, record, index) => (
        <LinkButton onClick={() => handleRemove(record, index)}>删除</LinkButton>
      ),
    },
  ];

  if (modalStatus === MODAL_STATUS.VIEW) {
    columns.pop();
  }

  return (
    <AntdTable
      bordered
      rowKey="remoteId"
      dataSource={grantList}
      columns={columns}
      scroll={{ y: modalStatus === MODAL_STATUS.ADD ? 300 : 150 }}
      locale={{
        emptyText: '添加查账人，授权APP查账',
      }}
    />
  );
};

export default connect(
  ({ modalFormValues, modalStatus, authorityList, appAuthoritySize, clientAuthoritySize }) => ({
    modalFormValues,
    modalStatus,
    grantList: modalFormValues.grantList,
    appAuthoritySize,
    clientAuthoritySize,
    authorityList,
  }),
)(Table);
