import React from 'react';
import { Button, Popover, message } from 'antd';
import { connect } from 'nuomi';
import { MODAL_STATUS } from '../../utils';
/* eslint-disable react/no-danger */

import './style.less';

const TipInfo = () => {
  const textArr = [
    '支持授权给非公司员工进行查账，例如企业老板、出纳等人员',
    '支持授权app查账和电脑端查账，内容、期间和自定义',
    'app查账为下载【诺言app】进入云代账中进行查账',
    '客户端查账为登录【诺诺云代账】进行查账，<br>网址：https：cloud.jss.com.cn',
    '若贵公司已申请公众号，可以将云代账查账链接放至公众号中哦~ 云代账链接: https://cloud.jss.com.cn/app/index.html',
  ];

  return (
    <>
      <h2 className="title">授权查账说明</h2>
      {textArr.map((text, index) => (
        <div className="text-wrap" key={text}>
          <span className="index">{index + 1}、</span>
          <span className="text" dangerouslySetInnerHTML={{ __html: text }} />
        </div>
      ))}
    </>
  );
};

const Right = ({ selectedRows, dataSource, dispatch }) => {
  // 授权
  const handleGrant = () => {
    if (!selectedRows.length) {
      message.warn('请选择需要授权查账的客户');
      return;
    }
    const customerList = selectedRows.map((key) => {
      const matched = dataSource.find((item) => item.customerId === key);
      const { customerId, customerName } = matched;
      return { customerId, customerName };
    });
    dispatch({
      type: 'updateState',
      payload: {
        isModalVisible: true,
        modalStatus: MODAL_STATUS.ADD,
        modalFormValues: {
          customerList,
          grantList: [],
        },
      },
    });
  };
  return (
    <>
      <Popover
        content={<TipInfo />}
        placement="topRight"
        overlayClassName="check-account-popover-info"
      >
        <i className="iconfont iconbangzhu" styleName="checkaccount-tip-icon" />
      </Popover>
      <Button type="primary" onClick={handleGrant}>
        授权查账
      </Button>
    </>
  );
};

export default connect(({ selectedRows, dataSource }) => ({ selectedRows, dataSource }))(Right);
