import React from 'react';
// import SearchInput from '@components/SearchInput';
import MultiTreeSelect from '@components/MultiTreeSelect';
import { Form, Input } from 'antd';
import { connect } from 'nuomi';
import SearchInput from '@components/input/MoreSearchInput';
import Bookeeper from '../Bookeeper';

import './style.less';

const formItemLayout = {
  labelCol: {
    sm: { span: 5 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};

const Left = ({ bookeepers, deptList, deptIdMap, dispatch }) => {
  // 更多条件的内容
  function getContent({ getFieldDecorator }) {
    return (
      <div styleName="search-container">
        <Form.Item label="查账人" {...formItemLayout}>
          {getFieldDecorator('grantUser')(<Input placeholder="请输入查账人" autoComplete="off" />)}
        </Form.Item>
        <Form.Item label="按照部门" {...formItemLayout}>
          {getFieldDecorator('deptIds')(
            <MultiTreeSelect
              dropdownStyle={{ maxHeight: 260, maxWidth: 288 }}
              treeData={deptList}
              val="deptId"
              showMode={false}
              searchPlaceholder="请选择部门"
            />,
          )}
        </Form.Item>
        <Form.Item label="记账会计" {...formItemLayout}>
          {getFieldDecorator('bookkeepingAccounting', {})(<Bookeeper mode="multiple" />)}
        </Form.Item>
      </div>
    );
  }

  // 处理数据
  function getSearchData(data) {
    const searchData = [];
    /* eslint-disable  guard-for-in */
    for (const i in data) {
      const value = data[i];
      if (value && value.length) {
        switch (i) {
          case 'grantUser':
            searchData.push({
              title: '查账人',
              text: [].concat(value),
            });
            break;
          case 'deptIds':
            searchData.push({
              title: '部门',
              text: [].concat(value).map((k) => deptIdMap[k]),
            });
            break;
          case 'bookkeepingAccounting':
            searchData.push({
              title: '记账会计',
              text: []
                .concat(value)
                .map((staffId) => bookeepers.find((item) => item.staffId === staffId).realName),
            });
            break;
          default:
            break;
        }
      }
    }
    return searchData;
  }

  // 搜索时
  function onSearch(formValues, inputValue) {
    let data = {};
    if (!formValues) {
      data.customerName = inputValue;
    } else {
      data = formValues;
    }
    console.log('onSearch', data);
    dispatch({
      type: '$getList',
      payload: data,
    });
  }

  function getValue(formValues) {
    const searchData = getSearchData(formValues);
    const values = [];
    if (searchData.length) {
      searchData.forEach((ele) => {
        const text = Array.isArray(ele.text) ? ele.text.join('、') : ele.text;
        if (text) {
          values.push(`${ele.title}：${text}`);
        }
      });
      return values.join('；');
    }
    return '';
  }

  return (
    <SearchInput
      autoComplete="off"
      style={{ width: 320 }}
      placeholder="请输入客户名称搜索"
      getValue={getValue}
      getContent={getContent}
      onSearch={onSearch}
    />
  );
};

export default connect(({ bookeepers, deptList, deptIdMap }) => ({
  bookeepers,
  deptList,
  deptIdMap,
}))(Left);
