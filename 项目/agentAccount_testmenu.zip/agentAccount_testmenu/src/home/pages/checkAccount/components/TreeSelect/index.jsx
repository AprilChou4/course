// 单选树结构带查询
import React, { forwardRef, useCallback, useState } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import { Input, Popover, Tree, Icon } from 'antd';
import { useMeasure } from 'react-use';
import { useControllableValue } from '@umijs/hooks';

import './style.less';

const TreeSelect = forwardRef((props, ref) => {
  const { treeData, disabled, onChange, dropdownStyle, inputValue, placeholder, ...rest } = props;

  // 控制poppver展开关闭
  const [visible, setVisible] = useState(false);
  // check选中
  const [checkedKeys, setCheckedKeys] = useControllableValue({
    value: rest.checkedKeys,
    onChange,
  });
  // 触发target的宽度
  const [targetRef, { width }] = useMeasure();

  // 节点选择
  const onCheck = useCallback(
    (keys) => {
      setCheckedKeys(keys);
      if (typeof onChange === 'function') {
        onChange(keys);
      }
    },
    [onChange, setCheckedKeys],
  );

  const handleVisibleChange = useCallback((v) => {
    setVisible(v);
  }, []);

  // 渲染树结构
  const renderTree = useCallback(
    (data) => {
      return data.length ? (
        <Tree
          checkable
          checkedKeys={checkedKeys}
          selectable={false}
          className="tree-select-inner-tree"
          treeData={data}
          defaultExpandAll
          onCheck={onCheck}
          style={{ ...dropdownStyle }}
        />
      ) : (
        <div className="filter-no-result">
          <svg width="64" height="41" viewBox="0 0 64 41" xmlns="http://www.w3.org/2000/svg">
            <g transform="translate(0 1)" fill="none" fillRule="evenodd">
              <ellipse fill="#F5F5F5" cx="32" cy="33" rx="32" ry="7" />
              <g fillRule="nonzero" stroke="#D9D9D9">
                <path d="M55 12.76L44.854 1.258C44.367.474 43.656 0 42.907 0H21.093c-.749 0-1.46.474-1.947 1.257L9 12.761V22h46v-9.24z" />
                <path
                  d="M41.613 15.931c0-1.605.994-2.93 2.227-2.931H55v18.137C55 33.26 53.68 35 52.05 35h-40.1C10.32 35 9 33.259 9 31.137V13h11.16c1.233 0 2.227 1.323 2.227 2.928v.022c0 1.605 1.005 2.901 2.237 2.901h14.752c1.232 0 2.237-1.308 2.237-2.913v-.007z"
                  fill="#FAFAFA"
                />
              </g>
            </g>
          </svg>
          <p>暂无数据</p>
        </div>
      );
    },
    [checkedKeys, dropdownStyle, onCheck],
  );

  // classes
  const prefix = 'check-account-select';
  const classess = classNames(prefix, {
    [`${prefix}-open`]: visible,
  });

  // check-account

  return (
    <div className={classess} ref={targetRef}>
      <Popover
        placement="bottom"
        content={renderTree(treeData)}
        trigger="click"
        overlayClassName="check-account-grant-popover"
        overlayStyle={{ width }}
        visible={visible}
        onVisibleChange={handleVisibleChange}
      >
        <Input
          ref={ref}
          placeholder={placeholder}
          value={inputValue}
          disabled={disabled}
          readOnly
          suffix={<Icon type="down" className="select-arrow" />}
        />
      </Popover>
    </div>
  );
});

TreeSelect.propTypes = {
  // 树结构数据 { title, value, selectable, disabled, children }
  treeData: PropTypes.arrayOf(PropTypes.object),
  // 变化回调
  onChange: PropTypes.func,
  // dropdown样式
  dropdownStyle: PropTypes.shape(),
  // 选中复选框的树节点
  checkedKeys: PropTypes.arrayOf(PropTypes.string),
  // inputVal显示的内容
  inputValue: PropTypes.string.isRequired,
  // 占位符显示
  placeholder: PropTypes.string,
};

TreeSelect.defaultProps = {
  treeData: [],
  onChange() {},
  dropdownStyle: { minHeight: 200, maxHeight: 300 },
  checkedKeys: [],
  placeholder: '请选择',
};

// 原输入框支持输入筛选的树选择器，antd3.x不支持，升级4可以移除该组件
export default TreeSelect;
