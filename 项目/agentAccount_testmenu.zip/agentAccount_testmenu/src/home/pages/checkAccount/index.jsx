// 授权查账

import React from 'react';
import effects from './effects';
import Main from './components/Main';
import { INIT_FORM, MODAL_STATUS } from './utils';

export default {
  state: {
    // 表格数据
    dataSource: [],
    // 表格选中的keys
    selectedRows: [],
    // ----------------------------------表格搜索的条件
    // 当前页
    current: 1,
    // 每页查询条数
    pageSize: 20,
    // 客户名称
    customerName: '',
    // 查账人
    grantUser: '',
    // 部门id数组
    deptIds: [],
    // 部门id对应的名字Map
    deptIdMap: {},
    // 记账会计id数组
    bookkeepingAccounting: [],
    // ----------------------------------
    // 总条数
    total: 1000,
    // 部门数据
    deptList: [],
    // 记账会计
    bookeepers: [],
    // 授权弹窗显示状态
    isModalVisible: false,
    // 授权弹窗表单值
    modalFormValues: INIT_FORM,
    // 授权弹窗当前状态
    modalStatus: MODAL_STATUS.ADD,
    // 搜索查账人的inputval
    grantUserInputVal: '',
    // 授权查账的权限数据，整理后的树结构
    authorityList: [],
    // 授权查账app端权限总数
    appAuthoritySize: Infinity,
    // 授权查账客户端权限总数
    clientAuthoritySize: Infinity,
    // 客户端权限通过id找到父级
    clientIdMap: Infinity,
    // 全部授权id
    allClientIds: [],
    allAppIds: [],
  },
  effects,
  render() {
    return <Main />;
  },
  onInit() {
    this.store.dispatch({
      type: 'initData',
    });
  },
};
