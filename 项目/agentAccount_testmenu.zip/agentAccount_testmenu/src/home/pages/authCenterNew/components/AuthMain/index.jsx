// 权限公共布局
import React from 'react';
import Layout from '@components/Layout';
import ContentWrapper from '@components/ContentWrapper';

import './style.less';

const { Left, BFCContent } = Layout;

const AuthMain = ({ leftSider, rightSider }) => {
  const { topContent, mainContent, bottomContent } = rightSider;
  return (
    <ContentWrapper
      header={null}
      content={
        <>
          <Left styleName="m-sider">{leftSider}</Left>
          <BFCContent styleName="m-main">
            <div styleName="m-mainTop">{topContent}</div>
            <div styleName="m-mainContent">{mainContent}</div>
            <div styleName="m-mainBottom">{bottomContent}</div>
          </BFCContent>
        </>
      }
    />
  );
};
AuthMain.defaultProps = {
  // 左侧
  leftSider: null,
  rightSider: {
    // 头部内容
    topContent: null,
    // 主体内容
    mainContent: null,
    // 底部内容
    bottomContent: null,
  },
};
export default AuthMain;
