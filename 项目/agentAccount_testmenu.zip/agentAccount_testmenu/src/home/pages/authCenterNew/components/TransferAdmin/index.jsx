// 移交管理员
import React from 'react';
import { Button } from 'antd';
import { connect } from 'nuomi';
import pubData from 'data';
import TransferModal from './TransferModal';
import './style.less';

const TransferAdmin = ({ dispatch, transferAdminVisible }) => {
  const isSystemManage = pubData.get('userInfo_isSystemManage');
  const tansfer = () => {
    dispatch({
      type: 'updateState',
      payload: {
        transferAdminVisible: true,
      },
    });
  };
  return (
    <>
      {isSystemManage && (
        <>
          <Button type="primary" styleName="m-transferBtn" onClick={tansfer}>
            移交超级管理员权限
          </Button>
          {transferAdminVisible && <TransferModal />}
        </>
      )}
    </>
  );
};
export default connect(({ transferAdminVisible }) => ({ transferAdminVisible }))(TransferAdmin);
