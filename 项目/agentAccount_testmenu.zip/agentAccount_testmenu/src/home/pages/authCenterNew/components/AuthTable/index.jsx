// 权限表格模块 组件
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Checkbox, Table, message } from 'antd';
import { connect } from 'nuomi';
import pubData from 'data';
import Style from './style.less';

const AuthTable = React.memo(
  ({ dispatch, authData, defaultCheckedList, nuomiName, type, authValue }) => {
    const userInfo = pubData.get('userInfo') || {};
    const userAuthArr = userInfo.authorities?.split('#');
    // 显示菜单是否选中
    const [isShowMenuChecked, setIsShowMenuChecked] = useState(false);
    // 选中的值全表
    const [currTableCheckList, setCurrTableCheckList] = useState([]);
    // 全选效果，只负责样式控制
    const [indeterminate, setIndeterminate] = useState(false);
    // 全选
    const [checkAll, setCheckedAll] = useState(false);

    /**
     * childrenMenuList 子菜单权限，如合同管理子菜单
     * menuName 表格th名称，如客户管理
     * authorityList 表格checkbox 显示菜单
     */
    const { childrenMenuList = [], menuName, authorityList } = authData;

    // 当前table所有权限选项 plainList=['1','2','3']
    const plainList = useMemo(() => {
      let arr = [...authorityList];
      childrenMenuList.forEach((item) => {
        arr = [...arr, ...item.authorityList];
      });
      const plainArr = arr.map((item) => String(item.authorityId));
      // 当前table选中项
      let checkedArr = [];
      plainArr.forEach((val) => {
        if (defaultCheckedList.includes(val)) {
          checkedArr = [...checkedArr, val];
        }
      });
      setCurrTableCheckList(checkedArr);
      setIsShowMenuChecked(!!checkedArr.length);
      // 是否全选
      setIndeterminate(!!checkedArr.length && checkedArr.length < plainArr.length);
      setCheckedAll(checkedArr.length === plainArr.length);

      return plainArr;
    }, [childrenMenuList, authorityList, defaultCheckedList]);

    // 改变显示菜单按钮
    const changeShowMenu = useCallback(
      (e) => {
        const { checked, value } = e.target;
        if (currTableCheckList.length > 1) {
          message.warning('抱歉，您已选择该菜单权限，不能取消“显示菜单”');
          return false;
        }
        // 选中的值
        let newSelectedList = [];
        if (checked) {
          newSelectedList = [...currTableCheckList, value];
        } else {
          newSelectedList = currTableCheckList.filter((item) => item !== value);
        }
        dispatch({
          type: 'authCenterNew/getSetAuth',
          payload: {
            newSelectedList,
            type,
            nuomiName,
          },
        });
        setCurrTableCheckList(newSelectedList);
        setIsShowMenuChecked(e.target.checked);
        // eslint
        return true;
      },
      [dispatch, currTableCheckList, type, nuomiName],
    );

    // 改变复选框
    const onChange = useCallback(
      (checkedValue) => {
        const { checked, value } = checkedValue.target;
        const [showMenuId] = authorityList && authorityList.map((item) => item.authorityId);
        // 选中的值
        let newSelectedList = [];
        if (checked) {
          newSelectedList = showMenuId
            ? [...currTableCheckList, String(showMenuId), value]
            : [...currTableCheckList, value];
          newSelectedList = Array.from(new Set(newSelectedList));
        } else {
          newSelectedList = currTableCheckList.filter((item) => item !== value);
        }
        console.log(newSelectedList, '--------newSelectedList---------newSelectedList');
        dispatch({
          type: 'authCenterNew/getSetAuth',
          payload: {
            newSelectedList,
            type,
            nuomiName,
          },
        });
        setCurrTableCheckList(newSelectedList);
      },
      [dispatch, authorityList, currTableCheckList, type, nuomiName],
    );
    // 全选
    const onCheckAllChange = useCallback(
      (e) => {
        const { checked } = e.target;
        setIsShowMenuChecked(checked);
        let newSelectedList = [];
        if (checked) {
          const hasAuthList = plainList.filter((v) => userAuthArr.includes(v));
          newSelectedList = [...hasAuthList];
        } else {
          const hasAuthList = currTableCheckList.filter((v) => !userAuthArr.includes(v));
          newSelectedList = hasAuthList;
        }
        dispatch({
          type: 'authCenterNew/getSetAuth',
          payload: {
            newSelectedList,
            type,
            nuomiName,
          },
        });
        setCurrTableCheckList(newSelectedList);
        setIndeterminate(!checked);
        setCheckedAll(checked);
      },
      [dispatch, currTableCheckList, userAuthArr, plainList, type, nuomiName],
    );
    // if (type === '40') {
    //   console.log(currTableCheckList, `-currTableCheckList------${type}`);
    // }

    // 获取表格列
    const columns = useMemo(() => {
      return [
        {
          title: menuName,
          dataIndex: 'menuName',
          key: 'menuName',
          align: 'center',
          width: 120,
        },
        {
          title: () => {
            return (
              authorityList &&
              authorityList.map((item) => (
                <Checkbox
                  key={item.authorityId}
                  checked={isShowMenuChecked}
                  onChange={changeShowMenu}
                  value={String(item.authorityId)}
                  disabled={!userAuthArr.includes(String(item.authorityId)) || !authValue}
                >
                  {item.authorityName}
                  {item.authorityId}
                </Checkbox>
              ))
            );
          },
          className: Style['m-authItem'],
          dataIndex: 'authorityList',
          key: 'authorityList',
          render: (text) =>
            text &&
            text.map((item) => (
              <Checkbox
                key={item.authorityId}
                disabled={!userAuthArr.includes(String(item.authorityId)) || !authValue}
                value={String(item.authorityId)}
                onChange={onChange}
                checked={currTableCheckList.includes(String(item.authorityId))}
              >
                {item.authorityName}
                {item.authorityId}
              </Checkbox>
            )),
        },
        {
          title: (
            <Checkbox
              indeterminate={indeterminate}
              onChange={onCheckAllChange}
              checked={checkAll}
              className="f-fr"
              disabled={!authValue}
            >
              全选
            </Checkbox>
          ),
          className: Style['m-all'],
          dataIndex: 'all',
          key: 'all',
          width: 70,
        },
      ];
    }, [
      authValue,
      userAuthArr,
      isShowMenuChecked,
      authorityList,
      menuName,
      currTableCheckList,
      indeterminate,
      checkAll,
      changeShowMenu,
      onChange,
      onCheckAllChange,
    ]);

    return (
      <Table
        columns={columns}
        dataSource={childrenMenuList}
        rowKey={(record, index) => index + 1}
        bordered
        pagination={false}
        styleName="m-authTable"
      />
    );
  },
);
AuthTable.defaultProps = {
  // 单个表格权限数据
  authData: {},
  // 默认选中的权限值
  defaultCheckedList: [],
  // nuomi名称
  nuomiName: '',
  // 权限值 没有权限则不能编辑
  authValue: true,
};
export default connect()(AuthTable);
