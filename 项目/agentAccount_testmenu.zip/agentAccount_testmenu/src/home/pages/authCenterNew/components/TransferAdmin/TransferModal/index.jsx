// 移交管理员弹窗
import React, { useEffect, useCallback } from 'react';
import { Modal, Form, Spin, Input } from 'antd';
import { connect } from 'nuomi';
import pubData from 'data';
import SearchTreeSelect from '@components/select/SearchTreeSelect';
import GenFormItem from '@components/form/GenFormItem';
import './style.less';

const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 16 },
  },
};
const TransferModal = ({ dispatch, form, transferLoading, transferAdminVisible, staffTree }) => {
  const isSystemManage = pubData.get('userInfo_isSystemManage');
  const realName = pubData.get('userInfo_realName');
  const topStaffId = pubData.get('userInfo_staffId');

  // 获取员工树
  useEffect(() => {
    dispatch({
      type: 'getStaffTree',
    });
    /* eslint-disable-next-line */
  }, []);

  const changeTreeSelect = (value, label) => {
    form.setFieldsValue({ name: label?.node?.props?.title });
  };

  // 确定提交
  const handleOk = () => {
    form.validateFields((err, values) => {
      if (err) {
        return false;
      }
      dispatch({
        type: '$transferManage',
        payload: {
          ...values,
        },
      });
      // eslint
      return true;
    });
  };

  // 取消
  const handleCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        transferAdminVisible: false,
      },
    });
  };

  const transferValidator = useCallback((rule, value, callback) => {
    if (value === topStaffId) {
      callback('移交人员不能为超级管理员');
      return;
    }
    callback();
    /* eslint-disable-next-line */
  }, []);
  return (
    <Modal
      title="移交超级管理员权限"
      visible={transferAdminVisible}
      onOk={handleOk}
      onCancel={handleCancel}
      centered
      styleName="m-transferModal"
      width={420}
      getContainer={false}
      maskClosable={false}
    >
      <Spin spinning={!!transferLoading}>
        <div styleName="m-hint">
          注：超级管理员移交后，将成为普通员工，同时岗位角色需要重新设
          置，可联系新超级管理员设置岗位角色
        </div>
        <Form {...formItemLayout}>
          {form.getFieldDecorator('name')(<Input type="hidden" />)}
          <GenFormItem
            form={form}
            label="移交人员"
            name="transferStaffId"
            initialValue={undefined}
            placeholder="请选择要移交的人员"
            rules={[
              {
                required: true,
                message: '请选择移交人员',
              },
              {
                validator: transferValidator,
              },
            ]}
          >
            <SearchTreeSelect
              treeData={staffTree}
              placeholder="请选择要移交的人员"
              style={{ width: '100%' }}
              onChange={changeTreeSelect}
              treeDefaultExpandAll
              dropdownStyle={{ maxHeight: 300 }}
            />
          </GenFormItem>
          {isSystemManage && realName === 'admin' && (
            <GenFormItem
              form={form}
              label="新用户名"
              name="realName"
              initialValue=""
              extra={<div>移交超级管理员后，需要您输入新的用户名</div>}
              styleName="m-realnameItem"
              rules={[
                {
                  required: true,
                  message: '新用户名不能为空',
                },
              ]}
            >
              <Input placeholder="请输入姓名" autoComplete="off" />
            </GenFormItem>
          )}
        </Form>
      </Spin>
    </Modal>
  );
};
const TransferForm = Form.create()(TransferModal);
export default connect(({ transferAdminVisible, loadings, staffTree }) => ({
  transferAdminVisible,
  transferLoading: loadings.$transferManage,
  staffTree,
}))(TransferForm);
