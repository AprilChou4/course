// 权限右侧公共导航菜单
import React from 'react';
import { Menu } from 'antd';
import './style.less';

const AuthMenu = ({ menuList, name, keyName }) => {
  const scrollToAnchor = (anchorName) => {
    if (anchorName) {
      // 找到锚点
      const anchorElement = document.getElementById(anchorName);
      // 如果对应id的锚点存在，就跳转到锚点
      if (anchorElement) {
        anchorElement.scrollIntoView({ block: 'start', behavior: 'smooth' });
      }
    }
  };
  // const clickMenu = (e) => {

  // };
  return (
    <Menu
      style={{ width: 96 }}
      defaultSelectedKeys={['1']}
      defaultOpenKeys={['sub1']}
      inlineIndent={0}
      styleName="m-menu"
      mode="inline"
      theme="light"
      // onClick={clickMenu}
    >
      {menuList.map((item) => (
        <Menu.Item key={item[keyName]}>
          <a onClick={() => scrollToAnchor(item[keyName])}>
            {item[keyName]} {item[name]}
          </a>
        </Menu.Item>
      ))}
    </Menu>
  );
};

AuthMenu.defaultProps = {
  // 菜单列表
  menuList: [],
  // name字段
  name: '',
  // key字段
  keyName: '',
};

export default AuthMenu;
