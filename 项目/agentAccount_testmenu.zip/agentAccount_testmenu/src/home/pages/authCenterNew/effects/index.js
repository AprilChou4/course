import { message } from 'antd';
import { store, router } from 'nuomi';
import globalServices from '@home/services';
import getAuthData from '@pages/authCenterNew/utils';
import services from '../services';

export default {
  /**
   *   权限中心-权限树查询
   */
  async $queryAuthority(payload = {}) {
    const { nuomiName } = payload;
    const { allAuthorityList, authorityTypeList } =
      (await services.queryAuthority(payload, {
        loading: '正在加载...',
      })) || {};
    const { allAuthData, noAuthData } =
      getAuthData(allAuthorityList.join('#'), authorityTypeList) || {};
    this.dispatch({
      type: `${nuomiName}/updateState`,
      payload: {
        allAuthList: authorityTypeList || [],
        allAuthValueList: allAuthorityList || [],
        allAuthValueData: allAuthData,
        noAuthValueData: noAuthData,
      },
    });
  },
  /**
   *   查询公司员工树
   */
  async getStaffTree() {
    const data = await globalServices.getStaffTree();
    const helper = (list) => {
      return list.map((item) => {
        if (item.isParent) {
          return {
            title: item.name,
            value: item.value,
            key: item.value,
            code: item.code,
            parentId: item.id,
            selectable: false,
            disabled: !item.children.length,
            children: helper(item.children),
            isParent: item.isParent,
          };
        }
        return {
          title: item.name,
          value: item.value,
          key: item.value,
          parentId: item.id,
          code: item.code,
          selectable: true,
          isParent: item.isParent,
        };
      });
    };
    this.updateState({
      staffTree: helper(data) || [],
    });
    return helper(data) || [];
  },

  /**
   *  移交超级管理员
   * @param {*} realName 真实姓名
   * @param {*} transferStaffId 被移交员工id
   */
  async $transferManage(payload = {}) {
    const { name, ...rest } = payload;
    await services.transferManage(rest);
    message.success(`超级管理员权限已经移交给${payload.realName || name}`);
    /* eslint-disable-next-line */
    top.location.reload();
    this.updateState({
      transferAdminVisible: false,
    });
  },

  /**
   *  获取所有权限值
   */
  async $checkAllAuth(payload = {}) {
    const { checked, allAuthValueData, noAuthValueData, nuomiName } = payload;
    let authData = {};
    if (checked) {
      authData = allAuthValueData;
    } else {
      authData = noAuthValueData;
    }
    this.dispatch({
      type: `${nuomiName}/updateState`,
      payload: {
        defaultSelecedAuthData: authData,
      },
    });
  },

  /**
   *   权限中心-权限树查询 用于authTable
   */
  async getSetAuth(payload = {}) {
    const { newSelectedList, type, nuomiName } = payload;
    const storeData = store.getState();
    const { defaultSelecedAuthData } = storeData[nuomiName];

    const newAuth = {};
    newAuth[type] = newSelectedList;

    this.dispatch({
      type: `${nuomiName}/updateState`,
      payload: {
        defaultSelecedAuthData: {
          ...defaultSelecedAuthData,
          ...newAuth,
        },
      },
    });
  },

  async initData() {
    const { query } = router.location();
    const mainTabActiveKey = query.tab || '1';
    this.updateState({
      mainTabActiveKey: query.tab || '1',
    });
    if (mainTabActiveKey) {
      const url = ['jobRoleNuomiNew', 'functionRoleNuomi', 'staffAuthNuomiNew'][
        Number(mainTabActiveKey) - 1
      ];
      // 等nuomi子组件渲染后
      setTimeout(() => {
        this.dispatch({
          type: `${url}/initData`,
        });
      });
    }
  },
};
