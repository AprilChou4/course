// 权限中心
import React from 'react';
import NoAuthPage from '@components/NoAuthPage';
import { router } from 'nuomi';
import pubData from 'data';
import { get } from '@utils';
import Layout from './components/Layout';
import effects from './effects';

export default {
  id: 'authCenterNew',
  state: {
    // 主页面Tab的activeKey
    // 1=岗位角色 2=职能角色 3=职员权限
    mainTabActiveKey: '1',
    // 公司员工树
    staffTree: [],
    // 移交超级管理员弹窗是否显示
    transferAdminVisible: false,
  },
  effects,
  render() {
    const userAuth = pubData.get('authority');
    return userAuth[48] ? <Layout /> : <NoAuthPage />;
  },
  onChange: {
    query() {},
  },
  onInit() {
    this.store.dispatch({
      type: 'initData',
    });
  },
};
