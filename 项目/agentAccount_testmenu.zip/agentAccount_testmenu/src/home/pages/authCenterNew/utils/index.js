import getAuthData from './getAuthData';

export default getAuthData;
