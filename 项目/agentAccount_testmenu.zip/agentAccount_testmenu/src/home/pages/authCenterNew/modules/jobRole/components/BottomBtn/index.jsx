import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import pubData from 'data';

const BottomBtn = ({
  dispatch,
  allAuthList,
  form,
  selectedMenu,
  roleList,
  defaultSelecedAuthData,
}) => {
  const userAuth = pubData.get('authority');
  const { roleId, roleName } = selectedMenu || {};

  // 恢复默认
  const onReset = () => {
    dispatch({
      type: '$queryDefaultAuthority',
      payload: {
        roleId,
        allAuthList,
      },
    });
  };
  // 取消
  const onCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 0,
        selectedMenu: roleId ? selectedMenu : roleList[0],
      },
    });
  };
  // 保存
  const save = () => {
    form.validateFields((err, values) => {
      if (err) {
        return false;
      }
      const url = roleId ? '$updateRole' : '$addRole';
      let authList = [];
      Object.keys(defaultSelecedAuthData).forEach((key) => {
        authList = [...authList, ...defaultSelecedAuthData[key]];
      });
      dispatch({
        type: url,
        payload: {
          roleId,
          roleName,
          authorities: authList.join('#'),
          ...values,
        },
      });
      // eslint
      return true;
    });
  };

  return (
    !!userAuth[49] && (
      <>
        <Button className="f-fl" onClick={onReset}>
          恢复默认
        </Button>
        <Button style={{ marginRight: 12 }} onClick={onCancel}>
          取消
        </Button>
        <Button type="primary" onClick={save}>
          保存
        </Button>
      </>
    )
  );
};

export default connect(
  ({ form, editStatus, selectedMenu, roleList, defaultSelecedAuthData }, { authCenterNew }) => ({
    form,
    editStatus,
    selectedMenu,
    roleList,
    defaultSelecedAuthData,
    allAuthList: authCenterNew.allAuthList,
  }),
)(BottomBtn);
