import { createServices } from '@utils';

export default createServices({
  queryAuthority: 'instead/v2/user/authority/query::post', // 权限中心-权限树查询
  getStaffAuthority: 'instead/v2/user/authority/getStaffAuthority::post', // 查询员工权限
  updateStaffAuthority: 'instead/v2/user/authority/updateStaffAuthority::postJSON', // 权限中心- 修改员工权限
});
