// 新增职能按钮
import React from 'react';
import { Button, message } from 'antd';
import Iconfont from '@components/Iconfont';
import { connect } from 'nuomi';
import pubData from 'data';
import './style.less';

const AddFuncRoleBtn = ({ dispatch, functionRoleList }) => {
  const userAuth = pubData.get('authority');
  // 新增
  const add = () => {
    if (functionRoleList.length >= 10) {
      message.warning('您新增的职能数量已超出10个');
      return false;
    }

    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 1,
        selectedMenu: {
          dataAuthorityType: 3,
          empFunctionId: '',
          empFunctionName: '',
          isSystem: false,
        },
      },
    });
    // eslint
    return true;
  };
  return (
    !!userAuth[50] && (
      <Button type="primary" onClick={add}>
        <Iconfont code="&#xe68c;" styleName="m-icon" />
        新增职能
      </Button>
    )
  );
};
export default connect(({ functionRoleList }) => ({ functionRoleList }))(AddFuncRoleBtn);
