import React from 'react';
import { connect } from 'nuomi';
import { AuthMain, AllAuth } from '@pages/authCenterNew/components';
import pubData from 'data';
import StaffTree from '../StaffTree';
import TopContent from '../TopContent';
import BottomBtn from '../BottomBtn';

const Main = ({ allAuthList, defaultSelecedAuthData }) => {
  const userAuth = pubData.get('authority');
  return (
    <AuthMain
      leftSider={<StaffTree />}
      rightSider={{
        topContent: <TopContent />,
        mainContent: (
          <AllAuth
            allAuthList={allAuthList}
            defaultCheckedData={defaultSelecedAuthData}
            nuomiName="staffAuthNuomiNew"
            authValue={!!userAuth[490]}
          />
        ),
        bottomContent: <BottomBtn />,
      }}
    />
  );
};

// authCenter为上层存储state
export default connect(({ defaultSelecedAuthData, allAuthList }, { authCenterNew }) => ({
  staffTree: authCenterNew.staffTree,
  allAuthList,
  defaultSelecedAuthData,
}))(Main);
