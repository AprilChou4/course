import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import pubData from 'data';

const BottomBtn = ({ dispatch, form, selectedMenu }) => {
  const userAuth = pubData.get('authority');
  const { dataAuthorityType, empFunctionId, empFunctionName, isSystem } = selectedMenu || {};
  // 保存
  const save = () => {
    form.validateFields((err, values) => {
      if (err) {
        return false;
      }
      const url = empFunctionId ? '$updateFunction' : '$addFunction';
      dispatch({
        type: url,
        payload: {
          dataAuthorityType,
          empFunctionId,
          empFunctionName,
          isSystem,
          ...values,
        },
      });
      // eslint
      return true;
    });
  };
  const onCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 0,
      },
    });
  };

  return (
    !!userAuth[50] && (
      <>
        <Button
          style={{
            marginRight: 12,
          }}
          onClick={onCancel}
        >
          取消
        </Button>
        <Button type="primary" onClick={save}>
          保存
        </Button>
      </>
    )
  );
};
export default connect(({ form, selectedMenu, editStatus }) => ({
  form,
  selectedMenu,
  editStatus,
}))(BottomBtn);
