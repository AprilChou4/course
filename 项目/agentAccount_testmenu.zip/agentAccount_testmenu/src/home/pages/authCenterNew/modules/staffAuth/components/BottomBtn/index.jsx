import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import pubData from 'data';

const BottomBtn = ({ dispatch, form, selectedKey, defaultSelecedAuthData, dataAuthorityType }) => {
  const userAuth = pubData.get('authority');
  const [staffId] = selectedKey;

  // 取消
  const onCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 0,
      },
    });
  };
  // 保存
  const save = () => {
    form.validateFields((err, values) => {
      if (err) {
        return false;
      }
      let authList = [];
      Object.keys(defaultSelecedAuthData).forEach((key) => {
        authList = [...authList, ...defaultSelecedAuthData[key]];
      });
      dispatch({
        type: '$updateStaffAuthority',
        payload: {
          staffId,
          dataAuthorityType,
          authorities: authList.join('#'),
          ...values,
        },
      });
      // eslint
      return true;
    });
  };

  return (
    !!userAuth[490] && (
      <>
        <Button style={{ marginRight: 12 }} onClick={onCancel}>
          取消
        </Button>
        <Button type="primary" onClick={save}>
          保存
        </Button>
      </>
    )
  );
};

export default connect(
  ({ form, editStatus, selectedKey, defaultSelecedAuthData, dataAuthorityType }) => ({
    form,
    editStatus,
    selectedKey,
    defaultSelecedAuthData,
    dataAuthorityType,
  }),
)(BottomBtn);
