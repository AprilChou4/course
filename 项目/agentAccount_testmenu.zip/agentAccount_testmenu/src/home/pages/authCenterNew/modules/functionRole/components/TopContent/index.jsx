// 头部
import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import { Input, Form } from 'antd';
import GenFormItem from '@components/form/GenFormItem';
import { useDebouncedCallback } from 'use-debounce';
import services from '../../services';

import './style.less';

const TopContent = ({ dispatch, editStatus, selectedMenu, form }) => {
  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        form,
      },
    });
  }, [dispatch, editStatus, form]);
  // 加防抖
  const [checkSameNameValidator] = useDebouncedCallback(async (rule, value, callback) => {
    await services.checkFunctionSameName(
      {
        empFunctionName: value,
      },
      {
        status: {
          300: (res) => {
            callback(res.message);
          },
        },
      },
    );
    callback();
  });
  return (
    <div styleName="m-functionTop">
      {editStatus === 0 && <h3>{selectedMenu.empFunctionName}职能权限</h3>}
      {editStatus === 1 && (
        <Form layout="inline">
          <GenFormItem
            form={form}
            label="职能名称"
            name="empFunctionName"
            initialValue={selectedMenu.empFunctionName || ''}
            rules={[
              {
                required: true,
                message: '职能名称不能为空',
              },
              {
                validator: checkSameNameValidator,
              },
            ]}
          >
            <Input
              placeholder="最多10个字，不能为空"
              style={{ width: 300 }}
              allowClear
              autoComplete="off"
              maxLength={10}
            />
          </GenFormItem>
        </Form>
      )}
    </div>
  );
};
const TopContentForm = Form.create()(TopContent);
export default connect(({ selectedMenu, editStatus }) => ({ selectedMenu, editStatus }))(
  TopContentForm,
);
