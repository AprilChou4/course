/**
 * 权限中心-岗位角色
 */
import React from 'react';
import Main from './components/Layout';
import effects from './effects';

export default {
  id: 'functionRoleNuomi',
  state: {
    // 职能角色列表
    functionRoleList: [],
    //
    form: null,
    // 0=默认 1=新增
    editStatus: 0,
    // 选中菜单 {value: 14, name: "老板", isSystem: true,defaultAuth:1}
    selectedMenu: {},
  },
  effects,
  render() {
    return <Main />;
  },
  onInit() {
    // this.store.dispatch({
    //   type: 'initData',
    // });
  },
};
