import { message } from 'antd';
import getAuthData from '@pages/authCenterNew/utils';
import ShowConfirm from '@components/ShowConfirm';
import pubData from 'data';
import services from '../services';

export default {
  /**
   * 权限中心-查询员工权限
   * @param {*} staffId 员工id
   */
  async $getStaffAuthority(payload = {}) {
    const { allAuthList } = this.getState();
    const { staffId } = payload;

    const { authorities, dataAuthorityType } =
      (await services.getStaffAuthority(
        { staffId },
        {
          loading: '正在加载...',
        },
      )) || {};
    const { allAuthData } = getAuthData(authorities, allAuthList);
    this.updateState({
      selectedKey: [staffId],
      defaultSelecedAuthData: allAuthData || {},
      staffAuthorityType: dataAuthorityType,
    });
  },

  /**
   * 权限中心-修改员工权限
   * @param {*} authorities 权限id集合#隔开
   * @param {*} dataAuthorityType 员工数据权限
   * @param {*} staffId 员工id
   *
   */
  async $updateStaffAuthority(payload = {}) {
    const update = async () => {
      await services.updateStaffAuthority(payload, {
        loading: '正在加载...',
      });
      message.success('职员权限修改成功');
    };
    if (payload.authorities === '') {
      ShowConfirm({
        title: '此岗位权限为空，确定保存？',
        onOk: async () => {
          update();
        },
      });
      return false;
    }
    update();
    return true;
  },
  // 获取员工树 方法在外层nuomi
  async getStaffTree() {
    const toAuthId = window.authParams && window.authParams.toAuthId; // 来源于职员授权页面
    // const toAuthId = 'fe58d6cf26404e8abfcb13fc771588f9';
    const staffTree = await this.dispatch({
      type: 'authCenterNew/getStaffTree',
    });
    let defaultSelectedKey = [];
    let defaultExpandedKey = [];
    if (toAuthId) {
      defaultSelectedKey = [toAuthId];
      // 获取展开的节点
      const getKey = (data, arr = []) => {
        data.every((item) => {
          if (item.children && item.children.length) {
            arr = [...arr, item.parentId];
            getKey(item.children, arr);
            return true;
          }
          if (item.value === toAuthId) {
            defaultExpandedKey = Array.from(new Set([...arr, staffTree[0].value, item.parentId]));
            return true;
          }
          return true;
        });
      };
      getKey(staffTree);
    } else {
      const getTree = (data) => {
        data.every((item) => {
          if (item.children && item.children.length) {
            defaultExpandedKey = [item.parentId];
            return getTree(item.children);
          }
          if (!item.isParent) {
            defaultSelectedKey = [item.value];
            defaultExpandedKey = Array.from(
              new Set([...defaultExpandedKey, staffTree[0].value, item.parentId]),
            );
            return false;
          }
          defaultExpandedKey = [];
          return true;
        });
      };
      getTree(staffTree);
    }
    this.$getStaffAuthority({
      staffId: defaultSelectedKey[0],
    });
    this.updateState({
      expandedKeys: defaultExpandedKey,
      staffTree,
    });
  },
  async initData() {
    await this.dispatch({
      type: 'authCenterNew/$queryAuthority',
      payload: {
        nuomiName: 'staffAuthNuomiNew',
      },
    });
    await this.getStaffTree();
  },
};
