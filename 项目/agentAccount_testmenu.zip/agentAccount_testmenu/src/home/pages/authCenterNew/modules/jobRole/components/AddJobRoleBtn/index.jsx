// 新增岗位按钮
import React from 'react';
import { Button, message } from 'antd';
import { connect } from 'nuomi';
import Iconfont from '@components/Iconfont';
import pubData from 'data';
import './style.less';

const AddJobRoleBtn = ({ dispatch, roleList, noAuthValueData }) => {
  const userAuth = pubData.get('authority');
  // 新增
  const add = () => {
    if (roleList.length >= 99) {
      message.warning('您新增的岗位数量已超出99个');
      return false;
    }
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 1,
        selectedMenu: {
          roleId: '',
          roleName: '',
          isDefault: false,
        },
        defaultSelecedAuthData: noAuthValueData,
      },
    });
    // eslint
    return true;
  };
  return (
    !!userAuth[490] && (
      <Button type="primary" onClick={add}>
        <Iconfont code="&#xe68c;" styleName="m-icon" />
        新增岗位
      </Button>
    )
  );
};
export default connect(({ roleList, noAuthValueData }) => ({ roleList, noAuthValueData }))(
  AddJobRoleBtn,
);
