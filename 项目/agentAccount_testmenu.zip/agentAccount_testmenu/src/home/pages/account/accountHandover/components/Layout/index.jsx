import React from 'react';
import { Drawer } from 'antd';
import { connect } from 'nuomi';
import If from '@components/If';
import Content from '../Content';
import './style.less';

const Index = ({ visible, dispatch }) => {
  const handleClose = () => {
    dispatch({
      type: 'updateState',
      payload: {
        visible: false,
      },
    });
  };

  return (
    <If condition={visible}>
      <Drawer
        destroyOnClose
        title="账套交接"
        width={798}
        getContainer={false}
        visible={visible}
        onClose={handleClose}
        styleName="drawer"
      >
        <Content />
      </Drawer>
    </If>
  );
};

export default connect(({ visible }) => ({ visible }))(Index);
