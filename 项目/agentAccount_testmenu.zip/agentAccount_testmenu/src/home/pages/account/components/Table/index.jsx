import React from 'react';
import { useSize } from '@umijs/hooks';
import Title from './Title';
import DataGride from './DataGride';
import styles from './style.less';

const Table = () => {
  const [titleSize, titleRef] = useSize();

  return (
    <>
      <div className={styles.title} ref={titleRef}>
        <Title />
      </div>
      <div style={{ height: `calc(100% - 5px - ${titleSize.height || 38}px)` }}>
        <DataGride />
      </div>
    </>
  );
};

export default Table;
