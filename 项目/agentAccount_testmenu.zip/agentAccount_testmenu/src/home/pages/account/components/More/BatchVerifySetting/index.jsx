/**
 * 批量审核设置
 */
import React from 'react';
import { connect } from 'nuomi';

const BatchVerifySetting = ({ dispatch }) => {
  const handleClick = () => {
    dispatch({
      type: 'handleBatchVerifySetting',
    });
  };

  return <div onClick={handleClick}>批量审核设置</div>;
};

export default connect()(BatchVerifySetting);
