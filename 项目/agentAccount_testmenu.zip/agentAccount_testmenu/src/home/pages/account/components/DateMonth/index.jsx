import React from 'react';
import { connect } from 'nuomi';
import Calendar from '@components/Calendar';

const DateMonth = ({ startDate, maxDate, minDate, dispatch }) => {
  const handleChange = (date) => {
    // FIXME: 待优化
    dispatch({
      type: 'updateState',
      payload: {
        startDate: date,
      },
    });
    dispatch({
      type: 'updateMainDatas',
      payload: true,
    });
  };

  return <Calendar onChange={handleChange} value={startDate} max={maxDate} min={minDate} />;
};

export default connect(({ startDate, maxDate, minDate }) => ({
  startDate,
  maxDate,
  minDate,
}))(DateMonth);
