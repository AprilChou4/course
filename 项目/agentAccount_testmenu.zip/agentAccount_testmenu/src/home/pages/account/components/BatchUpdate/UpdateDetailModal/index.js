/* eslint-disable react/jsx-filename-extension */
import React, { useState } from 'react';
import { Modal, Button, Checkbox, Icon, Popover } from 'antd';

import './style.less';

const UpdateDetailModal = ({ onCancel, onOk, data }) => {
  const [checked, setChecked] = useState(false);

  const { upgradePlanTime, total, oldNum } = data;

  return (
    <Modal
      visible
      maskClosable={false}
      width={480}
      title="批量升级"
      onCancel={onCancel}
      footer={null}
      wrapClassName="update-detail-xxs"
    >
      <div styleName="top">
        可升级账套数量：{oldNum} 个（共 {total} 个账套，已升级 {total - oldNum} 个）
      </div>
      <div styleName="top">
        预约升级时间：{upgradePlanTime}
        <span style={{ marginLeft: 8 }}>
          <Popover
            content={
              <div style={{ width: 312 }}>
                为错开做账高峰时间，若 21:00 前预约，系统将于当天晚上10点对账套进行批量升级；21:00
                后预约将于次日晚上10点升级。
              </div>
            }
            title={null}
            placement="bottom"
          >
            <Icon type="exclamation-circle" theme="filled" style={{ color: '#008CFF' }} />
          </Popover>
        </span>
      </div>
      <div styleName="content">
        <div styleName="content-title">请仔细阅读以下事项：</div>
        <div styleName="content-item">1.批量升级时（{upgradePlanTime} 开始）请勿操作账套!</div>
        <div styleName="content-item">
          2.根据账套和数据量，所需时间可能不同。升级完成后将通过系统消息提 示管理员！
        </div>
        <div styleName="content-item">
          3.升级账套后，新版账套将无法切换回旧版，旧版账套备份也将无法兼容!
        </div>
      </div>
      <div>
        <Checkbox checked={checked} onChange={(e) => setChecked(e.target.checked)}>
          我已阅读以上内容
        </Checkbox>
      </div>
      <div styleName="footer">
        <Button type="primary" disabled={!checked} onClick={onOk}>
          提交预约
        </Button>
      </div>
    </Modal>
  );
};

export default UpdateDetailModal;
