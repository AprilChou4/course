import React from 'react';
import SuperTable from '@components/SuperTable';

const Table = () => {
  return <SuperTable />;
};

export default Table;
