import React, { useMemo, useCallback } from 'react';
import { connect } from 'nuomi';
import CustomColModals from '@components/modal/CustomColModals';

const CustomColModal = ({ visible, columnSource, dispatch }) => {
  const handleCancel = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        customColModal: { visible: false },
      },
    });
  }, [dispatch]);

  const handleOk = useCallback(
    ({ dataSource }) => {
      dispatch({
        type: 'updateCustomCols',
        payload: {
          customizeColumns: dataSource,
        },
      });
    },
    [dispatch],
  );

  // 查询初始的自定义列数据
  const getInitDataSource = useCallback(async () => {
    const data = await dispatch({
      type: 'getCustomCols',
      payload: { isInit: 1 },
    });
    return data || [];
  }, [dispatch]);

  const tableProps = useMemo(
    () => ({
      dataSource: columnSource,
      disabledRowKeys: ['accountName'],
      getInitDataSource,
    }),
    [columnSource, getInitDataSource],
  );

  return (
    <CustomColModals
      visible={visible}
      tableProps={tableProps}
      onCancel={handleCancel}
      onOk={handleOk}
    />
  );
};

export default connect(({ columnSource, customColModal: { visible } }) => ({
  visible,
  columnSource,
}))(CustomColModal);
