/**
 * @func 数据字典
 */

const getData = (data) => {
  const datas = data;
  datas.map = {};
  datas.list.forEach((ele) => {
    datas.map[ele.value] = ele.name;
  });
  return datas;
};

// 收款单-源单类型
const sourceBillType = {
  title: '源单类型',
  list: [
    {
      name: '应收单',
      value: 1,
    },
    {
      name: '无',
      value: 0,
    },
  ],
};

// 应收单-源单类型
const receiveSourceBillType = {
  title: '源单类型',
  list: [
    {
      name: '合同',
      value: 1,
    },
    {
      name: '无',
      value: 0,
    },
  ],
};
// 核销状态 0-未核销 1-核销完成 2-部分核销
const reviewStatus = {
  title: '核销状态',
  list: [
    {
      name: '未核销',
      value: 0,
    },
    {
      name: '核销完成',
      value: 1,
    },
    {
      name: '部分核销',
      value: 2,
    },
  ],
};

export default {
  sourceBillType: getData(sourceBillType),
  receiveSourceBillType: getData(receiveSourceBillType),
  reviewStatus: getData(reviewStatus),
};
