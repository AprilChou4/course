import React, { useCallback, useMemo, useEffect, useState } from 'react';
import { connect } from 'nuomi';
import moment from 'moment';
import { postMessageRouter } from '@utils';
import TaxTable from '@components/TaxTable';
import { useScrollBar } from '@hooks';
import { useSize } from '@umijs/hooks';
import CustomColumn from '../CustomColumn';
import Style from './style.less';

const dateFormat = 'YYYY-MM-DD';
const CollectionTable = ({
  tableHeight,
  tableList,
  total,
  totalMoney,
  selectedRowKeys,
  pageSizeOptions,
  current,
  pageSize,
  columnSource,
  dispatch,
}) => {
  const { receiveMoneyTotal, reviewMoneyTotal } = totalMoney;
  const [scrollBarWidth] = useScrollBar();
  const [containerSize, containerRef] = useSize();
  const contentWidth = useMemo(() => containerSize.width || 0, [containerSize.width]);

  // 点击单据编号
  const handleShowReceivable = useCallback(({ shouldReceiveId }) => {
    shouldReceiveId &&
      postMessageRouter({
        type: 'agentAccount/routerLocation',
        payload: {
          url: '/charge/viewReceivable',
          query: {
            id: shouldReceiveId,
          },
        },
      });
  }, []);

  // 列配置
  const columnsConfig = {
    // 制单日期
    createBillDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
    // 单据编号
    srbNo: {
      width: 160,
      render: (text, record) => (
        <a className={Style['m-srbNo']} onClick={() => handleShowReceivable(record)}>
          {text}
        </a>
      ),
    },
    // 制单人
    createBillStaffName: {
      width: 120,
    },
    // 客户名称
    customerName: {
      width: 220, // 18个汉字换行
      render: (text) => (
        <div className="f-tal f-ellipsis" title={text}>
          {text || '-'}
        </div>
      ),
    },
    // 源单类型  0-手动创建 1-合同
    sourceBillType: {
      width: 90,
      render: (text) => {
        return [0, 1].includes(text) ? ['手动创建', '合同'][text] : '-';
      },
    },
    // 应收金额
    shouldReceiveMoney: {
      width: 140,
      render: (text) => <div className="f-tar">{text}</div>,
    },
    // 核销金额
    reviewMoney: {
      width: 140,
      render: (text) => <div className="f-tar">{text}</div>,
    },

    // 核销状态  0-未核销 1-核销完成 2-部分核销
    reviewStatus: {
      width: 90,
      render: (text) => {
        return [0, 1, 2].includes(text) ? ['未核销', '核销完成', '部分核销'][text] : '-';
      },
    },
    // 单据日期
    billDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
    // 开始日期
    startDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
    // 结束日期
    endDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
    // 部门
    deptName: {
      width: 170,
    },
    // 业务员
    businessStaffName: {
      width: 130,
    },
    // 摘要
    remark: {
      width: 180,
    },
    // 收款方式 0-预付 1-后付
    payType: {
      render: (text) => (text || text === 0) && ['预付', '后付'][text],
    },
    // 结算方式 0-一次结清 1-月结 2-季结 3- 4-年结
    settlementMethod: {
      width: 100,
      render: (text) => (text ? ['一次结清', '月结', '季结', '半年结', '年结'][text - 1] : ''),
    },
    // 最新修改人
    modifyStaffName: {
      width: 130,
    },
    // 修改日期
    modifyDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
  };

  // 显示的列 及 显示列的fieldKey
  const showColumns = columnSource.filter((item) => item.selected);

  // 获取列columns(array) 和列宽x(number)
  const { columns, x } = useMemo(() => {
    let columWidth = 170 + 50;
    const customColum = showColumns.map((item, index) => {
      const option = {
        ...item,
        title: item.fieldName,
        dataIndex: item.fieldKey,
        align: 'center',
        width: 130,
        className: 'f-ellipsis',
        render: (text) => (
          <div className="f-ellipsis" title={text}>
            {text}
          </div>
        ),
        ...(columnsConfig[item.fieldKey] || {}),
      };

      // 非固定列要固定宽度,最后一列宽度自适应(不然会有间隙)
      if (index === showColumns.length - 1) {
        delete option.width;
      }
      columWidth += option.width || 0;
      return option;
    });

    const newColumns = [
      {
        // 返回数据中没有这一栏，自己手动加上
        title: '序号',
        dataIndex: 'index',
        align: 'center',
        className: 'operate-cell',
        width: 50,
        render: (text, record, index) => index + 1,
      },
    ].concat(customColum);
    columWidth += 50;
    return {
      columns: newColumns,
      x: columWidth,
    };
  }, [columnsConfig, showColumns]);

  // 获取统计列 totalColumns (array)
  const totalColumns = useMemo(() => {
    let totalColumnArr = [
      {
        title: '合计',
        key: 'total',
        align: 'left',
        width: 60,
      },
    ];
    // 为当x>屏幕宽度，则最后一列为auto;否则计算剩余宽度为最后一列
    let leftWidth = x - 60;
    console.log(x, contentWidth, x - contentWidth, leftWidth);

    // 应收金额(shouldReceiveMoney) | 核销金额(reviewMoney)
    const moneyArr = ['shouldReceiveMoney', 'reviewMoney'];
    columns.forEach((item, index) => {
      const { fieldKey, width } = item;
      if (index < columns.length - 1) {
        leftWidth -= width;
      }
      if (moneyArr.includes(fieldKey)) {
        totalColumnArr = [
          ...totalColumnArr,
          {
            title:
              {
                shouldReceiveMoney: receiveMoneyTotal,
                reviewMoney: reviewMoneyTotal,
              }[fieldKey] || 0,
            dataIndex: fieldKey,
            align: 'right',
            width:
              index === columns.length - 1
                ? { width: x < contentWidth ? 'auto' : leftWidth }
                : width,
          },
        ];
      } else {
        totalColumnArr = [
          ...totalColumnArr,
          {
            title: '',
            key: index + 100000,
            align: 'left',
            ...(index === columns.length - 1
              ? { width: x < contentWidth ? 'auto' : leftWidth }
              : { width }),
          },
        ];
      }
    });
    return totalColumnArr;
  }, [columns, contentWidth, receiveMoneyTotal, reviewMoneyTotal, x]);

  // 是否显示合计
  const isShowTotal = useMemo(() => {
    const showFieldKeyArr = showColumns.map((item) => item.fieldKey);
    return (
      tableList.length > 0 &&
      (showFieldKeyArr.includes('shouldReceiveMoney') || showFieldKeyArr.includes('reviewMoney'))
    );
  }, [showColumns, tableList]);

  // 页码改变
  const handlePageChange = (page) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        current: page,
      },
    });
  };

  // pageSize 变化
  const handlePageSizeChange = (page, size) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        pageSize: size,
      },
    });
  };

  // 改变复选框
  const changeSelection = (selectedRowKey, selectedRow) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedRowKeys: selectedRowKey,
        selectedRows: selectedRow,
      },
    });
  };

  // 自定义点击
  const customizeClick = () => {
    dispatch({
      type: 'updateState',
      payload: {
        receivaleCustomizeColumVisible: true,
      },
    });
  };
  return (
    <div ref={containerRef}>
      <TaxTable
        rowKey="shouldReceiveId"
        className={Style['m-shouldReceiveBillTable']}
        columns={columns}
        totalColumns={totalColumns}
        total={isShowTotal}
        bordered
        rowSelection={{
          columnWidth: '60px',
          selectedRowKeys,
          onChange: changeSelection,
        }}
        locale={{
          emptyText: '暂无数据',
        }}
        // 减去头40/合计40/分页48/滚动条scrollBarWidth
        tableBodyHeight={
          isShowTotal ? tableHeight - 128 - scrollBarWidth : tableHeight - 88 - scrollBarWidth
        }
        tableName="charge-receiveTable"
        pagination={{
          showSizeChanger: true,
          pageSizeOptions,
          current,
          total,
          pageSize,
          showTotal: (count) => `共${count}条`,
          onChange: handlePageChange,
          onShowSizeChange: handlePageSizeChange,
        }}
        tableBodyMinWidth={x}
        dataSource={tableList}
        isCustomiseIcon
        customizeClick={customizeClick}
      />
      <CustomColumn />
    </div>
  );
};

export default connect(
  ({
    tableList,
    columnSource,
    total,
    totalMoney,
    selectedRowKeys,
    selectedRows,
    pageSizeOptions,
    tableConditions,
    loadings,
  }) => ({
    tableList,
    columnSource,
    total,
    totalMoney,
    selectedRowKeys,
    selectedRows,
    pageSizeOptions,
    current: tableConditions.current,
    pageSize: tableConditions.pageSize,
    tableLoading: loadings.$getShouldReceiveBillList,
  }),
)(CollectionTable);
