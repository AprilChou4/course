import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import { Checkbox } from 'antd';
import If from '@components/If';
import GenFormItem from '@components/form/GenFormItem';
import MainContent from '../MainContent';
import DataGride from '../DataGride';
import styles from './style.less';

const Content = ({ form, tableData, shouldCreateTask }) => {
  // 当表格中有服务类型属于“工商服务”时，上方显示“生成工商任务单”
  const isShowCreateTask = useMemo(() => tableData.some((item) => item.serviceClassId === '2'), [
    tableData,
  ]);

  return (
    <div className={styles.container}>
      <div>
        <MainContent />
        <div style={{ paddingBottom: 1 }}>
          <div className="title-mark f-dib">服务项目</div>
          <If condition={isShowCreateTask}>
            <div className="f-fr f-dib">
              <GenFormItem
                form={form}
                name="createTask"
                valuePropName="checked"
                className={styles.createTask}
                initialValue={shouldCreateTask}
              >
                <Checkbox>生成工商任务单</Checkbox>
              </GenFormItem>
            </div>
          </If>
        </div>
      </div>
      <div>
        <DataGride />
      </div>
    </div>
  );
};

export default connect(({ form, tableData, shouldCreateTask }) => ({
  form,
  tableData,
  shouldCreateTask,
}))(Content);
