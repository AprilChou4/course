/**
 * 核销列表
 */
import React, { useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import AntdTable from '@components/table/AntdTable';
import { postMessageRouter } from '@utils';
import getColumns from './columns';

const Receivable = ({
  rowKey,
  dataSource,
  columnSource,
  selectedRowKeys,
  pagination,
  dispatch,
}) => {
  const handleBillNoClick = useCallback((record) => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/viewVerification',
        query: { id: record.reviewBillId },
      },
    });
  }, []);

  const columns = useMemo(
    () =>
      getColumns({
        columnSource,
        currentPage: pagination.current,
        pageSize: pagination.pageSize,
        handleBillNoClick,
      }),
    [columnSource, handleBillNoClick, pagination],
  );

  const rowSelection = useMemo(
    () => ({
      columnWidth: 38,
      selectedRowKeys,
      onChange(sRowKeys) {
        dispatch({
          type: 'updateVerificationTable',
          payload: {
            selectedRowKeys: sRowKeys,
          },
        });
      },
    }),
    [dispatch, selectedRowKeys],
  );

  const handleTableChange = useCallback(
    ({ current, pageSize }) => {
      dispatch({
        type: 'query',
        payload: {
          current,
          pageSize,
        },
      });
    },
    [dispatch],
  );

  const handleSettingClick = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        customColModal: { visible: true },
      },
    });
  }, [dispatch]);

  return (
    <AntdTable
      bordered
      showSettingIcon
      scroll={{ y: true }}
      rowKey={rowKey}
      columns={columns}
      rowSelection={rowSelection}
      pagination={pagination}
      dataSource={dataSource}
      onChange={handleTableChange}
      onSettingClick={handleSettingClick}
    />
  );
};

export default connect(
  ({ verificationTable: { rowKey, dataSource, columnSource, selectedRowKeys, pagination } }) => ({
    rowKey,
    dataSource,
    columnSource,
    selectedRowKeys,
    pagination,
  }),
)(Receivable);
