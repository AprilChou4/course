import moment from 'moment';
import { store } from 'nuomi';
import { message } from 'antd';
import ShowConfirm from '@components/ShowConfirm';
import { get, trim, validateArrayLength, postMessageRouter } from '@utils';
import services from '../services';

export default {
  // 初始化
  async initData() {
    this.query();
  },

  // 查询
  async query(payload) {
    this.getCustomCols();
    await this.$query(payload);
  },

  // 查询
  async $query(args = {}) {
    const { query, inputSearchValue, createBillDate } = this.getState();
    const { init, ...payload } = args;
    const params = {
      ...query,
      customerName: trim(inputSearchValue) || undefined,
      createBillDateMin:
        createBillDate && createBillDate[0]
          ? moment(createBillDate[0]).startOf('day').format('X')
          : undefined,
      createBillDateMax:
        createBillDate && createBillDate[1]
          ? moment(createBillDate[1]).endOf('day').format('X')
          : undefined,
      ...payload,
      ...(init ? { current: 1 } : {}),
    };

    const data = await services
      .getVerificationList(params, { loading: '正在获取核销单列表...' })
      .catch(() => {});

    const list = get(data, 'list', []);
    const total = get(data, 'count', 0);
    this.updateState({
      query: params,
    });
    this.updateVerificationTable({
      dataSource: list,
      pagination: {
        total,
        current: params.current,
        pageSize: params.pageSize,
      },
    });
  },

  // 更新核销表格
  updateVerificationTable(payload = {}) {
    const { verificationTable } = this.getState();
    this.updateState({
      verificationTable: {
        ...verificationTable,
        ...payload,
      },
    });
  },

  // 更新核销日期
  updateStateAndQuery(payload = {}) {
    this.updateState(payload);
    this.$query();
  },

  // 处理删除核销单逻辑
  deleteVerification() {
    const that = this;
    const {
      verificationTable: { selectedRowKeys },
    } = this.getState();

    if (!validateArrayLength(selectedRowKeys)) {
      message.warning('请选择要删除的信息');
      return;
    }

    ShowConfirm({
      title: '你确定要删除所选核销单吗？',
      onOk() {
        that.$deleteVerification({
          reviewBillIds: selectedRowKeys,
        });
      },
    });
  },

  // 删除核销单
  async $deleteVerification(payload = {}) {
    await services.deleteVerification(payload, {
      loading: '正在删除核销单...',
      successMsg: '核销单已删除',
    });
    this.updateVerificationTable({
      selectedRowKeys: [],
    });
    this.query();

    // 如果删除的核销单已经在核销单新增页面打开了，重置核销单新增页面
    const verificationStore = store.getStore('verification');
    const reviewBillId = get(
      verificationStore && verificationStore.getState(),
      'formInitialValues.reviewBillId',
    );
    if (reviewBillId && get(payload, 'reviewBillIds', []).includes(reviewBillId)) {
      verificationStore.dispatch({
        type: 'handleNewVerification',
      });
    }

    // 如果删除的核销单已经在核销单查看页面打开了，关闭“查看核销单”标签页
    const viewVerificationStore = store.getStore('viewVerification');
    const viewReviewBillId = get(
      viewVerificationStore && viewVerificationStore.getState(),
      'formInitialValues.reviewBillId',
    );
    if (viewReviewBillId && get(payload, 'reviewBillIds', []).includes(viewReviewBillId)) {
      postMessageRouter({
        type: 'agentAccount/closeTab',
        payload: {
          path: '/charge/viewVerification',
        },
      });
    }
  },

  // 查询自定义列
  async getCustomCols(payload = {}) {
    const data = await services.getCustomCols(payload);
    !payload.isInit &&
      this.updateVerificationTable({
        columnSource: data || [],
      });
    return data;
  },

  // 更新自定义列
  async updateCustomCols(payload = {}) {
    await services.updateCustomCols(payload, { loading: '正在保存...', successMsg: '保存成功' });
    this.updateState({
      customColModal: { visible: false },
    });
    this.getCustomCols();
  },
};
