/**
 * 核销单列表
 */
import React from 'react';
import pubData from 'data';
import NoAuthPage from '@components/NoAuthPage';
import Main from './components/Main';
import effects from './effects';

const userAuth = pubData.get('authority');
const defaultCurrent = 1;
const defaultPageSize = 20;

export default {
  id: 'verificationList',
  state: {
    title: '核销单列表',
    inputSearchValue: '',
    // 核销日期
    createBillDate: undefined,
    // 核销表格查询参数
    query: {
      current: defaultCurrent,
      pageSize: defaultPageSize,
    },
    // 核销表格相关数据
    verificationTable: {
      rowKey: 'reviewBillId',
      columnSource: [],
      dataSource: [],
      selectedRowKeys: [],
      pagination: {
        total: 0, // 数据总数
        current: defaultCurrent, // 当前页
        pageSize: defaultPageSize, // 每页条数
      },
    },
    // 自定义列弹窗
    customColModal: {
      visible: false,
    },
  },
  effects,
  render() {
    // 控制查看权限
    return <>{userAuth[591] ? <Main /> : <NoAuthPage />}</>;
  },
  onChange: {
    // 这里加上$让它在初始化的时候不执行，initData里再手动的去执行 query，否则 initData中无法拿到 query中请求得到的数据
    $query() {
      // 控制查看权限
      if (!userAuth[591]) {
        return;
      }
      this.store.dispatch({
        type: 'query',
      });
    },
  },
  onInit() {
    // 控制查看权限
    if (!userAuth[591]) {
      return;
    }
    this.store.dispatch({
      type: 'initData',
    });
  },
};
