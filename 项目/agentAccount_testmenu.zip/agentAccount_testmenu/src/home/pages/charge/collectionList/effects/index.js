import { message } from 'antd';
import { store } from 'nuomi';
import { get } from '@utils';
import postMessage from '@utils/postMessage';
import services from '../services';

export default {
  // 查询应收单自定义列
  async $getCollectCustomizeColumn() {
    const data = await services.getCollectCustomizeColumn();
    const { tableConditions } = this.getState();
    // let data =
    //   (await services.getReceiveBillList(tableConditions, {
    //     loading: '正在获取收款单列表...',
    //   })) || {};
    // data = [
    //   {
    //     columnKey: 'unix_timestamp(create_bill_date) create_bill_date',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'createBillDate',
    //     fieldName: '制单日期',
    //     id: 37,
    //     selected: true,
    //     sort: 1,
    //   },
    //   {
    //     columnKey: 'user_pre_receipt_money',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'userPreReceiptMoney',
    //     fieldName: '使用预收',
    //     id: 48,
    //     selected: true,
    //     sort: 12,
    //   },
    //   {
    //     columnKey: 'rb_no',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'receiptNo',
    //     fieldName: '单据编号',
    //     id: 38,
    //     selected: true,
    //     sort: 2,
    //   },
    //   {
    //     columnKey: 'customer_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'customerName',
    //     fieldName: '客户名称',
    //     id: 39,
    //     selected: true,
    //     sort: 3,
    //   },
    //   {
    //     columnKey: 'unix_timestamp(receipt_date) receipt_date',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'receiptDate',
    //     fieldName: '收款时间',
    //     id: 40,
    //     selected: true,
    //     sort: 4,
    //   },
    //   {
    //     columnKey: 'receipt_staff_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'receiptStaffName',
    //     fieldName: '收款人',
    //     id: 41,
    //     selected: true,
    //     sort: 5,
    //   },
    //   {
    //     columnKey: 'receipt_type_account_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'receiptType',
    //     fieldName: '收款方式',
    //     id: 42,
    //     selected: true,
    //     sort: 6,
    //   },
    //   {
    //     columnKey: 'source_bill_type',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'sourceBillType',
    //     fieldName: '源单类型',
    //     id: 43,
    //     selected: true,
    //     sort: 7,
    //   },
    //   {
    //     columnKey: 'source_bill_no',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'sourceBillNo',
    //     fieldName: '源单据号',
    //     id: 44,
    //     selected: true,
    //     sort: 8,
    //   },
    //   {
    //     columnKey: 'total_receipt_money',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'totalReceiptMoney',
    //     fieldName: '实收金额',
    //     id: 45,
    //     selected: true,
    //     sort: 9,
    //   },
    //   {
    //     columnKey: 'pre_receipt_money',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'preReceiptMoney',
    //     fieldName: '本次预收',
    //     id: 46,
    //     selected: true,
    //     sort: 10,
    //   },
    //   {
    //     columnKey: 'free_money',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'freeMoney',
    //     fieldName: '优惠金额',
    //     id: 47,
    //     selected: true,
    //     sort: 11,
    //   },

    //   {
    //     columnKey: 'remark',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'remark',
    //     fieldName: '摘要',
    //     id: 49,
    //     selected: false,
    //     sort: 13,
    //   },
    //   {
    //     columnKey: 'receipt_type_account_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'receiptTypeAccount',
    //     fieldName: '收款账号',
    //     id: 50,
    //     selected: false,
    //     sort: 14,
    //   },
    //   {
    //     columnKey: 'dept_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'deptName',
    //     fieldName: '部门',
    //     id: 51,
    //     selected: false,
    //     sort: 15,
    //   },
    //   {
    //     columnKey: 'business_staff_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'businessStaffName',
    //     fieldName: '业务员',
    //     id: 52,
    //     selected: false,
    //     sort: 16,
    //   },
    //   {
    //     columnKey: 'modify_staff_id',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'modifyStaffName',
    //     fieldName: '最新修改人',
    //     id: 53,
    //     selected: false,
    //     sort: 17,
    //   },
    //   {
    //     columnKey: 'modify_date',
    //     entity: 'RECEIVE_ENTITY',
    //     fieldKey: 'modifyDate',
    //     fieldName: '修改日期',
    //     id: 54,
    //     selected: false,
    //     sort: 18,
    //   },
    // ];
    this.updateState({
      columnSource: data,
    });
    return data;
  },

  /**
   * 更新应收单自定义列
   * @param {*array}  customizeColumns 表头列表
   */
  async $updateCollectCustomizeColumn(payload = {}) {
    const { customizeColumns } = payload;
    await services.updateCollectCustomizeColumn(payload);
    message.success('自定义列表已保存');
    this.updateState({
      columnSource: customizeColumns,
    });
    this.$getReceiveBillList();
  },

  // 请求收款单列表
  async $getReceiveBillList() {
    const { tableConditions } = this.getState();
    const data =
      (await services.getReceiveBillList(tableConditions, {
        loading: '正在获取收款单列表...',
      })) || {};
    this.updateState({
      tableList: data.list || [],
      total: data.count || 0,
      totalMoney: data.totalMoney || {},
    });
  },

  // 修改筛选条件
  async updateCondition(payload = {}) {
    const { tableConditions } = this.getState();
    const lastConditions = {
      ...tableConditions,
      current: 1,
      ...payload,
    };
    this.updateState({
      tableConditions: lastConditions,
      selectedRowKeys: [],
      selectedRows: [],
    });
    await this.$getReceiveBillList();
  },

  // 根据部门id查询员工集合
  async $getStaffList() {
    const aList = await services.getStaffList();
    return aList || [];
  },

  // 查询部门树
  async $getDeptList() {
    const aList = await services.getDeptList();
    return aList || [];
  },

  // 获取服务项目
  async $getChargingItem() {
    const data = await services.getChargingItem();
    let aList = [];
    data.forEach(({ serviceProductVOList }) => {
      aList = [...aList, ...serviceProductVOList];
    });
    return aList || [];
  },

  // 列表初始化查询：服务类型、部门、
  async $getTreeData() {
    const [deptList, staffList, chargeItemList] = await Promise.all([
      this.$getDeptList(),
      this.$getStaffList(),
      this.$getChargingItem(),
    ]);

    this.updateState({
      deptList,
      staffList,
      chargeItemList,
    });
  },
  /**
   * 删除收款单
   * @param {*} receiveBillIds 收款单id
   */
  async $deleteReceiveBill(payload) {
    await services.deleteReceiveBill(payload, {
      status: {
        300: (res) => {
          message.warning(res.message);
          this.updateCondition();
          // if (payload.receiveBillIds.length === 1) {
          //   message.warning('该收款单对应的应收单已完成收款，无法删除');
          //   this.updateCondition();
          // } else {
          //   this.updateState({
          //     delFailData: res.data,
          //     delFailVisible: true,
          //   });
          // }
        },
      },
    });
    message.success('收款单已删除');
    this.updateCondition();

    /* 处理列表中删除可能牵扯到新增收款单页面、查看收款单页面 */
    const receiveBillIds = get(payload, 'receiveBillIds', []);

    // 如果删除的收款单已经在收款单新增页面打开了，清空收款单页面
    const collectionStore = store.getStore('charge_collection');
    const collectionId = get(collectionStore && collectionStore.getState(), 'receiveBillId');
    if (collectionId && receiveBillIds.includes(collectionId)) {
      // console.log('---------新增');
      collectionStore.dispatch({
        type: '$initForm',
        payload: true,
      });
    }
    // 如果删除的收款单已经在收款单查看页面打开了，关闭标签页
    const viewCollectionStore = store.getStore('charge_viewCollection');
    const viewCollectionId = get(
      viewCollectionStore && viewCollectionStore.getState(),
      'receiveBillId',
    );
    if (viewCollectionId && receiveBillIds.includes(+viewCollectionId)) {
      // console.log('---------查看');
      postMessage({
        type: 'agentAccount/closeTab',
        payload: {
          path: '/charge/viewCollection',
        },
      });
    }
  },

  async initData() {
    this.$getCollectCustomizeColumn();
    this.$getReceiveBillList();
    this.$getTreeData();
  },
};
