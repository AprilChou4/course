import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import moment from 'moment';
import { useSize } from '@umijs/hooks';
import { postMessageRouter } from '@utils';
import TaxTable from '@components/TaxTable';
import { useScrollBar } from '@hooks';
import CustomColumn from '../CustomColumn';
import Style from './style.less';

const dateFormat = 'YYYY-MM-DD';
const CollectionTable = ({
  tableHeight,
  tableList,
  columnSource,
  total,
  totalMoney,
  selectedRowKeys,
  pageSizeOptions,
  current,
  pageSize,
  dispatch,
}) => {
  const { receiveMoneyTotal, preReceiptMoneyTotal, freeMoneyTotal, userPreReceiptMoneyTotal } =
    totalMoney || {};
  const [scrollBarWidth] = useScrollBar();
  const [containerSize, containerRef] = useSize();
  const contentWidth = useMemo(() => containerSize.width || 0, [containerSize.width]);

  // 跳转收款单列表
  const toDetail = (id) => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/viewCollection',
        query: {
          id,
        },
      },
    });
  };

  // 列配置
  const columnsConfig = {
    // 制单日期
    createBillDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
    // 单据编号
    receiptNo: {
      width: 160,
      render: (text, { receiveBillId }) => (
        <a className={`f-ellipsis ${Style['m-receiptNo']}`} onClick={() => toDetail(receiveBillId)}>
          {text || '-'}
        </a>
      ),
    },
    // 客户名称
    customerName: {
      width: 220, // 18个汉字换行
      render: (text) => (
        <div className="f-tal f-ellipsis" title={text}>
          {text || '-'}
        </div>
      ),
    },
    // 收款时间
    receiptDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
    // 收款人
    receiptStaffName: {
      width: 140,
    },

    // 源单类型   0-单独创建  1-应收单
    sourceBillType: {
      width: 90,
      render: (text) => {
        return [0, 1].includes(text) ? ['-', '应收单'][text] : '-';
      },
    },
    // 源单据号
    sourceBillNo: {
      width: 140,
    },
    // 实收金额
    totalReceiptMoney: {
      width: 120,
      render: (text) => <div className="f-tar">{text}</div>,
    },
    // 本次预收
    preReceiptMoney: {
      width: 120,
      render: (text) => <div className="f-tar">{text}</div>,
    },
    // 优惠金额
    freeMoney: {
      width: 120,
      render: (text) => <div className="f-tar">{text}</div>,
    },
    // 使用预收
    userPreReceiptMoney: {
      width: 120,
      render: (text) => <div className="f-tar">{text}</div>,
    },
    // 摘要
    remark: {
      width: 180,
    },
    // 收款方式 0-预付 1-后付
    receiptType: {
      width: 120,
    },
    // 收款账号
    receiptTypeAccount: {
      width: 160,
    },
    // 部门
    deptName: {
      width: 170,
    },
    // 业务员
    businessStaffName: {
      width: 130,
    },
    // 最新修改人
    modifyStaffName: {
      width: 130,
    },
    // 修改日期
    modifyDate: {
      width: 110,
      render: (text) => <span>{text && moment(text, 'X').format(dateFormat)}</span>,
    },
  };
  // 显示的列 及 显示列的fieldKey
  const showColumns = columnSource.filter((item) => item.selected);

  // 获取列columns 和列宽x
  const { columns, x } = useMemo(() => {
    let columWidth = 170 + 50;
    const customColum = showColumns.map((item, index) => {
      const option = {
        ...item,
        title: item.fieldName,
        dataIndex: item.fieldKey,
        align: 'center',
        width: 130,
        className: 'f-ellipsis',
        render: (text) => (
          <div className="f-ellipsis" title={text}>
            {text}
          </div>
        ),
        ...(columnsConfig[item.fieldKey] || {}),
      };

      // 非固定列要固定宽度,最后一列宽度自适应(不然会有间隙)
      if (index === showColumns.length - 1) {
        delete option.width;
      }
      columWidth += option.width || 0;
      return option;
    });

    const newColumns = [
      {
        // 返回数据中没有这一栏，自己手动加上
        title: '序号',
        dataIndex: 'index',
        align: 'center',
        className: 'operate-cell',
        width: 50,
        render: (text, record, index) => index + 1,
      },
    ].concat(customColum);
    columWidth += 50;
    return {
      columns: newColumns,
      x: columWidth,
    };
  }, [columnsConfig, showColumns]);

  // 获取统计列 totalColumns (array)
  const totalColumns = useMemo(() => {
    let totalColumnArr = [
      {
        title: '合计',
        key: 'total',
        align: 'left',
        width: 60,
      },
    ];
    // 为当x>屏幕宽度，则最后一列为auto;否则计算剩余宽度为最后一列
    let leftWidth = x - 60;
    const moneyArr = ['totalReceiptMoney', 'preReceiptMoney', 'freeMoney', 'userPreReceiptMoney'];
    // 实收金额(receiveMoneyTotal) | 本次预收(preReceiptMoneyTotal) | 优惠金额合计(freeMoneyTotal) | 使用预收合计(userPreReceiptMoneyTotal)
    columns.forEach((item, index) => {
      const { fieldKey, width } = item;
      if (index < columns.length - 1) {
        leftWidth -= width;
      }
      if (moneyArr.includes(fieldKey)) {
        totalColumnArr = [
          ...totalColumnArr,
          {
            title:
              {
                totalReceiptMoney: receiveMoneyTotal,
                preReceiptMoney: preReceiptMoneyTotal,
                freeMoney: freeMoneyTotal,
                userPreReceiptMoney: userPreReceiptMoneyTotal,
              }[fieldKey] || 0,
            dataIndex: fieldKey + index,
            align: 'right',
            ...(index === columns.length - 1
              ? { width: x < contentWidth ? 'auto' : leftWidth }
              : { width }),
          },
        ];
      } else {
        totalColumnArr = [
          ...totalColumnArr,
          {
            title: '',
            key: index + 100000,
            align: 'left',
            ...(index === columns.length - 1
              ? { width: x < contentWidth ? 'auto' : leftWidth }
              : { width }),
          },
        ];
      }
    });
    return totalColumnArr;
  }, [
    columns,
    contentWidth,
    freeMoneyTotal,
    preReceiptMoneyTotal,
    receiveMoneyTotal,
    userPreReceiptMoneyTotal,
    x,
  ]);
  const showFieldKeyArr = showColumns.map((item) => item.fieldKey);
  // 是否显示合计
  const isShowTotal =
    tableList.length > 0 &&
    (showFieldKeyArr.includes('totalReceiptMoney') ||
      showFieldKeyArr.includes('preReceiptMoney') ||
      showFieldKeyArr.includes('freeMoney') ||
      showFieldKeyArr.includes('userPreReceiptMoney'));

  // 页码改变
  const handlePageChange = (page) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        current: page,
      },
    });
  };

  // pageSize 变化
  const handlePageSizeChange = (page, size) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        pageSize: size,
      },
    });
  };

  // 改变复选框
  const changeSelection = (selectedRowKey, selectedRow) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedRowKeys: selectedRowKey,
        selectedRows: selectedRow,
      },
    });
  };

  // 自定义列点击
  const customizeClick = () => {
    dispatch({
      type: 'updateState',
      payload: {
        collectCustomizeColumVisible: true,
      },
    });
  };
  return (
    <div ref={containerRef}>
      <TaxTable
        // loading={tableLoading}
        rowKey="receiveBillId"
        className={Style['m-receiveBillTable']}
        columns={columns}
        totalColumns={totalColumns}
        total={isShowTotal}
        bordered
        rowSelection={{
          columnWidth: 60,
          selectedRowKeys,
          onChange: changeSelection,
        }}
        locale={{
          emptyText: '暂无数据',
        }}
        // 减去头40/合计40/分页48/滚动条scrollBarWidth
        tableBodyHeight={
          isShowTotal ? tableHeight - 128 - scrollBarWidth : tableHeight - 88 - scrollBarWidth
        }
        tableName="charge-collectTable"
        pagination={{
          showSizeChanger: true,
          pageSizeOptions,
          current,
          total,
          pageSize,
          showTotal: (count) => `共${count}条`,
          onChange: handlePageChange,
          onShowSizeChange: handlePageSizeChange,
        }}
        tableBodyMinWidth={x}
        dataSource={tableList}
        isCustomiseIcon
        customizeClick={customizeClick}
      />
      <CustomColumn />
    </div>
  );
};

export default connect(
  ({
    tableList,
    columnSource,
    total,
    totalMoney,
    selectedRowKeys,
    pageSizeOptions,
    tableConditions,
    loadings,
  }) => ({
    tableList,
    columnSource,
    total,
    totalMoney,
    selectedRowKeys,
    pageSizeOptions,
    current: tableConditions.current,
    pageSize: tableConditions.pageSize,
    tableLoading: loadings.$getReceiveBillList,
  }),
)(CollectionTable);
