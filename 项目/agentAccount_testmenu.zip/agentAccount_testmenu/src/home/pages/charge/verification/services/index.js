import { createServices } from '@utils';

export default createServices({
  getReceivableAddCollectionList:
    'instead/v2/customer/receipt/reviewBill/querySrbAndRbBill::postJSON', // 查询需要核销的应收单和收款单
  getVerificationInfo: 'instead/v2/customer/receipt/reviewBill/get', // 查看核销单信息
  addVerification: 'instead/v2/customer/receipt/reviewBill/add::postJSON', // 添加核销单
});
