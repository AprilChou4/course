/**
 * 核销单-收款表格
 */
import React, { useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import AntdTable from '@components/table/AntdTable';
import { moneyFormat, getRows, validateArrayLength } from '@utils';
import getColumns from './columns';
import styles from '../style.less';

const Receivable = ({ status, form, rowKey, dataSource, selectedRowKeys, dispatch }) => {
  const isView = status === 1;

  const { matchType } = useMemo(() => (form ? form.getFieldsValue() : {}), [form]);

  const columns = useMemo(() => getColumns({ matchType }), [matchType]);

  const rowSelection = useMemo(
    () => ({
      columnWidth: 30,
      selectedRowKeys,
      getCheckboxProps: () =>
        isView
          ? {
              disabled: true,
            }
          : {},
      onChange(sRowKeys) {
        dispatch({
          type: 'updateCollectionTable',
          payload: {
            selectedRowKeys: sRowKeys,
            dataSource: dataSource.map((item) => ({
              ...item,
              currentReviewedMoney: sRowKeys.includes(item[rowKey]) ? item.unReviewMoney : 0,
            })),
          },
        });
      },
    }),
    [dataSource, dispatch, isView, rowKey, selectedRowKeys],
  );

  const footer = useCallback(
    (currentPageData) => {
      const sum = (a, b) => Number(a || 0) + Number(b || 0);
      const { currentReviewedMoney, receivedMoney, reviewedMoney } = getRows(
        currentPageData,
        selectedRowKeys,
        rowKey,
      ).reduce(
        (acc, cur) => ({
          currentReviewedMoney: sum(acc.currentReviewedMoney, cur.currentReviewedMoney),
          receivedMoney: sum(acc.receivedMoney, cur.receivedMoney),
          reviewedMoney: sum(acc.reviewedMoney, cur.reviewedMoney),
        }),
        {},
      );
      return (
        <div className={styles['table-footer']}>
          <span className={styles['footer-title']}>本次核销合计：</span>
          {moneyFormat(currentReviewedMoney)}
          <span className={styles['footer-title']}>收款合计：</span>
          {moneyFormat(receivedMoney)}
          <span className={styles['footer-title']}>已核销合计：</span>
          {moneyFormat(reviewedMoney)}
        </div>
      );
    },
    [rowKey, selectedRowKeys],
  );

  return (
    <AntdTable
      bordered
      emptyType="default"
      locale={{
        emptyText: <div className={styles['table-placeholder']}>请设置过滤项添加收款数据</div>,
      }}
      pagination={false}
      rowKey={rowKey}
      columns={columns}
      rowSelection={rowSelection}
      dataSource={dataSource}
      footer={validateArrayLength(selectedRowKeys) ? footer : null}
    />
  );
};

export default connect(
  ({ status, form, collectionTable: { rowKey, dataSource, selectedRowKeys } }) => ({
    status,
    form,
    rowKey,
    dataSource,
    selectedRowKeys,
  }),
)(Receivable);
