/**
 * 核销单
 */
import React from 'react';
import { router } from 'nuomi';
import moment from 'moment';
import pubData from 'data';
import NoAuthPage from '@components/NoAuthPage';
import Main from './components/Main';
import effects from './effects';

const userName = pubData.get('userInfo_realName');
const getAuth = () => {
  const userAuth = pubData.get('authority');
  const { pathname } = router.location();
  const isViewPage = pathname === '/charge/viewVerification';
  return isViewPage ? userAuth[591] : userAuth[589];
};

const initialPageState = {
  status: 0, // 页面状态：0是新增，1是查看
  // 头部form初始值
  formInitialValues: {
    matchType: 0, // 核销条件，默认按单据
    reviewStaffName: userName || '', // 核销人，默认当前登录用户
    reviewDate: moment().format('X'), // 核销日期，默认当前日期
  },
  // 应收单制单日期
  receivableBillDate: undefined,
  // 应收表格
  receivableTable: {
    rowKey: 'srbId',
    dataSource: [],
    selectedRowKeys: [],
  },
  // 收款单制单日期
  collectionBillDate: undefined,
  // 收款表格
  collectionTable: {
    rowKey: 'rbId',
    dataSource: [],
    selectedRowKeys: [],
  },
  // 核销结果
  verificationResult: {
    visible: false,
  },
};

export default {
  id: 'verification',
  state: {
    title: '核销单',
    // 客户列表
    customerList: [],
    initialPageState,
    ...initialPageState,
  },
  effects,
  render() {
    // 控制查看权限
    return <>{getAuth() ? <Main /> : <NoAuthPage />}</>;
  },
  onChange: {
    // 这里加上$让它在初始化的时候不执行，initData里再手动的去执行 query，否则 initData中无法拿到 query中请求得到的数据
    $query() {
      // 控制查看权限
      if (!getAuth()) {
        return;
      }
      this.store.dispatch({
        type: 'initData',
      });
    },
  },
  onInit() {
    // 控制查看权限
    if (!getAuth()) {
      return;
    }
    this.store.dispatch({
      type: 'initData',
      payload: true,
    });
  },
};
