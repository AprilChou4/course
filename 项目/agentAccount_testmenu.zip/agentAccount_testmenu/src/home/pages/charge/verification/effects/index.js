import { router } from 'nuomi';
import moment from 'moment';
import { message } from 'antd';
import pubData from 'data';
import { get, validateArrayLength } from '@utils';
import globalServices from '@home/services';
import services from '../services';

export default {
  // 初始化
  async initData(init) {
    const { id } = router.location().query || {};
    const params = pubData.get('verification-query') || {};
    pubData.set('verification-query', undefined);
    if (id) {
      // 查看
      this.updateFormInitialValues({ reviewBillId: id });
    } else {
      // 新增
      // 由于新项目经过路由跳转时只能把参数附在url上，url长度有限制，所以有的查询参数就放到了pubData
      const isNew = pubData.get('verification-new');
      pubData.set('verification-new', undefined);
      if (init || isNew) {
        this.initAddVerification(params);
      }
    }
    // 等待form的value重置
    setTimeout(() => {
      this.query(params);
    });
  },

  // 查询相关依赖项
  queryDependence() {
    this.getCustomerList();
  },

  // 查询
  async query(payload = {}) {
    const { status } = this.getState();
    // 获取页面其他依赖信息
    this.queryDependence();
    if (status === 0) {
      // 代表是新增
      await Promise.all([this.$query(payload)]);
    } else {
      // 代表是查看
      await Promise.all([this.initViewVerification()]);
    }
  },

  // 查询需要核销的应收单和收款单
  async $query(payload = {}) {
    const { customerId, srbIds } = payload;
    const { form, receivableBillDate, collectionBillDate } = this.getState();
    const cId = customerId || (form ? form.getFieldValue('customerId') : undefined);
    const sIds = srbIds || (form ? form.getFieldValue('srbIds') : undefined);
    if (!cId) {
      return;
    }

    const data = await services.getReceivableAddCollectionList(
      {
        srbIds: sIds,
        customerId: cId,
        srbCreateBillDateMin:
          receivableBillDate && receivableBillDate[0]
            ? moment(receivableBillDate[0]).startOf('day').format('X')
            : undefined,
        srbCreateBillDateMax:
          receivableBillDate && receivableBillDate[1]
            ? moment(receivableBillDate[1]).endOf('day').format('X')
            : undefined,
        rbCreateBillDateMin:
          collectionBillDate && collectionBillDate[0]
            ? moment(collectionBillDate[0]).startOf('day').format('X')
            : undefined,
        rbCreateBillDateMax:
          collectionBillDate && collectionBillDate[1]
            ? moment(collectionBillDate[1]).endOf('day').format('X')
            : undefined,
      },
      { loading: '正在查询应收和收款信息...' },
    );

    // 更新表格
    this.updateReceivableTable({
      dataSource: get(data, 'shouldReceiveBills', []),
      selectedRowKeys: [],
    });
    this.updateCollectionTable({
      dataSource: get(data, 'receiveBills', []),
      selectedRowKeys: [],
    });
  },

  // 获取客户列表
  async getCustomerList() {
    const data = await globalServices.getCustomerBillNO({
      isShouldReceiveBill: 0,
    });
    this.updateState({
      customerList: data || [],
    });
  },

  // 新增核销单初始化
  async initAddVerification(payload = {}) {
    console.log('initAddVerification', payload);
    const { form, initialPageState } = this.getState();
    this.updateState(initialPageState);
    // 重置form
    form && form.resetFields();
    // form重新设置初始值
    this.getFormInitialValues(payload);
  },

  // 点新增时重置页面
  handleNewVerification(payload = {}) {
    console.log('handleNewVerification', payload);
    this.initAddVerification(payload);
  },

  // 获取form初始值
  async getFormInitialValues(payload = {}) {
    this.updateFormInitialValues(payload);
    if (!payload.reviewBillNo) {
      await this.getVerificationNo();
    }
  },

  // 获取单据编号
  async getVerificationNo() {
    const data = await globalServices.getReceiptNo({ receiveType: 2 });
    this.updateFormInitialValues({
      reviewBillNo: data,
    });
  },

  // 更新form初始值
  updateFormInitialValues(payload = {}) {
    const { init, ...rest } = payload;
    const { form, formInitialValues = {} } = this.getState();
    init && form && form.resetFields();
    this.updateState({
      formInitialValues: {
        ...(init ? {} : formInitialValues),
        ...rest,
      },
    });
  },

  // 查看核销单初始化
  async initViewVerification(payload = {}) {
    const { id } = payload;
    const {
      formInitialValues: { reviewBillId },
    } = this.getState();
    this.updateState({
      status: 1,
    });
    await this.$getVerificationInfo({ id: id || reviewBillId });
  },

  // 查看核销单信息
  async $getVerificationInfo(payload = {}) {
    const { id } = payload;
    const { receivableTable, collectionTable } = this.getState();
    const data = await services.getVerificationInfo(
      { reviewBillId: id },
      {
        loading: '正在查询核销单信息...',
      },
    );

    const { customerId, reviewBillId, matchType, reviewBillNo, reviewStaffName, reviewDate } =
      data || {};

    // 更新form
    this.updateFormInitialValues({
      init: true,
      reviewBillId,
      customerId,
      matchType,
      reviewBillNo,
      reviewStaffName,
      reviewDate,
    });

    const shouldReceiveBills = get(data, 'shouldReceiveBills', []);
    const receiveBills = get(data, 'receiveBills', []);
    // 更新表格
    this.updateReceivableTable({
      dataSource: shouldReceiveBills,
      selectedRowKeys: shouldReceiveBills.map((item) => item[receivableTable.rowKey]),
    });
    this.updateCollectionTable({
      dataSource: receiveBills,
      selectedRowKeys: receiveBills.map((item) => item[collectionTable.rowKey]),
    });
  },

  // 更新应收单和收款单的制单日期
  updateBillDate(payload = {}) {
    this.updateState(payload);
    this.$query();
  },

  // 更新应收表格
  updateReceivableTable(payload = {}) {
    const { receivableTable } = this.getState();
    this.updateState({
      receivableTable: {
        ...receivableTable,
        ...payload,
      },
    });
  },

  // 更新收款表格
  updateCollectionTable(payload = {}) {
    const { collectionTable } = this.getState();
    this.updateState({
      collectionTable: {
        ...collectionTable,
        ...payload,
      },
    });
  },

  // 更新头部form
  updateForm(payload = {}) {
    const { form } = payload;
    this.updateState({
      form,
    });
  },

  // 添加核销单
  async $addVerification() {
    const { form, receivableTable, collectionTable } = this.getState();
    form &&
      form.validateFields(async (err, values) => {
        console.log('values', values);
        if (err) {
          message.warning('请先填充信息！');
          return;
        }
        const validateReceivableTable = validateArrayLength(receivableTable.selectedRowKeys);
        const validateCollectionTable = validateArrayLength(collectionTable.selectedRowKeys);
        if (!validateReceivableTable && !validateCollectionTable) {
          message.warning('请勾选您要审核的单据');
          return;
        }
        if (!validateReceivableTable && validateCollectionTable) {
          message.warning('请勾选相应的应收单据进行核销');
          return;
        }
        if (validateReceivableTable && !validateCollectionTable) {
          message.warning('请勾选相应的收款单据进行核销');
          return;
        }

        const { customerId, matchType, reviewBillNo } = values;
        const data = await services.addVerification(
          {
            customerId,
            matchType,
            reviewBillNo,
            srbIds: receivableTable.selectedRowKeys,
            rbIds: collectionTable.selectedRowKeys,
          },
          { loading: '正在新增核销单...' },
        );

        const { status, srbSuccessCount, rbSuccessCount, reviewBillId } = data || {};
        if (status === 2) {
          message.warning('您勾选的应收和收款数据不匹配，无法核销');
          return;
        }

        if (status === 1) {
          message.success('核销完成');
          this.afterAdd({
            id: reviewBillId,
          });
          return;
        }

        if (status === 0) {
          // 显示核销结果弹窗
          const failedSrbNos = get(data, 'failedSrbNos', []);
          const failedRbNos = get(data, 'failedRbNos', []);
          this.updateVerificationResult({
            visible: true,
            data: {
              srbSuccessCount,
              rbSuccessCount,
              failedSrbNos,
              failedRbNos,
            },
          });
          this.afterAdd({
            id: reviewBillId,
          });
        }
      });
  },

  afterAdd(payload = {}) {
    const { id } = payload;
    // 更新form
    this.initViewVerification({ id });
  },

  // 更新核销结果弹窗
  updateVerificationResult(payload = {}) {
    const { verificationResult } = this.getState();
    const { init } = payload;
    this.updateState({
      verificationResult: init ? payload : { ...verificationResult, ...payload },
    });
  },
};
