import React from 'react';
import moment from 'moment';
import LinkButton from '@components/buttons/LinkButton';
import Iconfont from '@components/Iconfont';
import { moneyFormat } from '@utils';
import PopoverTable from '../../PopoverTable';
import UnReviewMoneyDetails from '../UnReviewMoneyDetails';

const dateFormat = 'YYYY-MM-DD';

export default ({ isView, matchType }) => {
  return [
    {
      title: '应收单单据编号',
      dataIndex: 'srbNo',
      align: 'center',
      width: 200,
      render: (value, record) => (
        <>
          <span>{value}</span>
          {isView && (
            <PopoverTable
              placement="rightTop"
              overlayStyle={{ width: 340 }}
              tableProps={{
                rowKey: 'rbId',
                columns: [
                  {
                    title: '被核销收款单',
                    dataIndex: 'rbNo',
                    align: 'center',
                  },
                  {
                    title: '本次核销金额',
                    dataIndex: 'reviewMoney',
                    className: 'th-center td-right',
                    render: (val) => moneyFormat(val),
                  },
                ],
                dataSource: record.rbRelBills,
              }}
            >
              <LinkButton className="f-fr">
                <Iconfont code="&#xee80;" />
              </LinkButton>
            </PopoverTable>
          )}
        </>
      ),
    },
    {
      title: '制单日期',
      dataIndex: 'createBillDate',
      align: 'center',
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
    {
      title: '本次核销金额',
      dataIndex: 'currentReviewedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '应收金额',
      dataIndex: 'shouldReceiveMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '已核销金额',
      dataIndex: 'reviewedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '未核销金额',
      dataIndex: 'unReviewMoney',
      align: 'center',
      render: (value, record) => (
        <>
          {matchType !== 0 && (
            <UnReviewMoneyDetails tableType={0} matchType={matchType} record={record} />
          )}
          <span className="f-fr">{moneyFormat(value)}</span>
        </>
      ),
    },
  ];
};
