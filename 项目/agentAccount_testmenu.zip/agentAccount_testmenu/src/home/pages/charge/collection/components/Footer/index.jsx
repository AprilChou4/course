import React from 'react';
import { Descriptions } from 'antd';
import moment from 'moment';
import { connect } from 'nuomi';
import styles from './style.less';

const { Item: DescriptionsItem } = Descriptions;

const Footer = ({ formValues }) => {
  return (
    <Descriptions column={6} className={styles.descriptions}>
      <DescriptionsItem label="制单人">{formValues.createBillStaffName || ''}</DescriptionsItem>
      <DescriptionsItem label="制单日期" span={2}>
        {formValues.createBillDate
          ? moment(formValues.createBillDate, 'X').format('YYYY-MM-DD')
          : ''}
      </DescriptionsItem>
      <DescriptionsItem label="修改人">{formValues.modifyStaffName || ''}</DescriptionsItem>
      <DescriptionsItem label="修改日期">
        {formValues.modifyDate ? moment(formValues.modifyDate, 'X').format('YYYY-MM-DD') : ''}
      </DescriptionsItem>
    </Descriptions>
  );
};

export default connect(({ formValues }) => ({ formValues }))(Footer);
