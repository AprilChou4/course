import React from 'react';
import { isNumber } from 'lodash';
import { connect } from 'nuomi';

const FormTableFooter = ({ isReference, dataSource, columns }) => {
  // console.log(columns);
  // 是否有服务项目明细
  const hasServiceItems = isReference || dataSource.some((it) => it.serviceItemId);

  const renderText = (num) => {
    if (!hasServiceItems && num !== '合计') return '';
    return isNumber(num) ? num.toFixed(2) : num;
  };
  return (
    <table>
      <tbody>
        <tr>
          <td width="30" />
          {columns.map((it, index) => (
            <td
              key={it.dataIndex}
              width={it.width}
              align={index === 0 ? 'left' : 'right'}
              style={{ paddingRight: 19 }}
            >
              {renderText(it.total)}
            </td>
          ))}
        </tr>
      </tbody>
    </table>
  );
};

export default connect(({ isReference, dataSource }) => ({ isReference, dataSource }))(
  FormTableFooter,
);
