const Layout = () => {
  return null;
};

export default Layout;
