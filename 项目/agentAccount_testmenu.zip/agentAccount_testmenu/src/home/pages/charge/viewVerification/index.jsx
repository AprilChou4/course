/**
 * 查看核销单
 */
import { nuomi } from 'nuomi';
import verification from '../verification';

export default nuomi.extend(verification, {
  id: 'viewVerification',
  state: {
    title: '核销单',
    status: 1,
  },
});
