/* eslint-disable react/no-array-index-key */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import moment from 'moment';
import { connect } from 'nuomi';
import { Timeline, Typography } from 'antd';
import { isNil, validateArrayLength } from '@utils';
import styles from './style.less';

const { Item: TimelineItem } = Timeline;
const { Paragraph, Text } = Typography;
const operateTypeMap = {
  0: '添加',
  1: '更新',
  2: '续签',
  3: '终止',
};

const Content = ({ visible, dispatch }) => {
  const [logs, setLogs] = useState([]);

  const getLogs = useCallback(async () => {
    const data = await dispatch({
      type: 'getContractOperateLog',
    });
    setLogs(data || []);
  }, [dispatch]);

  useEffect(() => {
    visible && getLogs();
  }, [getLogs, visible]);

  const logsContent = useMemo(
    () =>
      logs.map(({ operateDate, operateStaffName, operateType, content }, index) => (
        <TimelineItem key={index}>
          <div className={styles.title}>
            <span>{moment(operateDate, 'X').format('YYYY-MM-DD HH:mm')}</span>
            <Text ellipsis title={operateStaffName} className={styles.name}>
              {operateStaffName}
            </Text>
            <span>{!isNil(operateType) ? `${operateTypeMap[operateType]}了合同` : ''}</span>
          </div>
          <Paragraph ellipsis title={content} className={styles.details}>
            {content}
          </Paragraph>
        </TimelineItem>
      )),
    [logs],
  );

  return validateArrayLength(logs) ? <Timeline>{logsContent}</Timeline> : '无';
};

export default connect()(Content);
