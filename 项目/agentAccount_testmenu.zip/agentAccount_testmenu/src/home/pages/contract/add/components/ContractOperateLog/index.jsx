/**
 * 合同操作记录
 */
import React, { useState, useCallback, useMemo } from 'react';
import { Popover } from 'antd';
import LinkButton from '@components/buttons/LinkButton';
import Iconfont from '@components/Iconfont';
import Content from './Content';
import styles from './style.less';

const ContractOperateLog = () => {
  const [visible, setVisible] = useState(false);

  const handleVisibleChange = useCallback((vis) => {
    setVisible(vis);
  }, []);

  const content = useMemo(() => <Content visible={visible} />, [visible]);

  return (
    <Popover
      title="操作记录"
      placement="bottomRight"
      onVisibleChange={handleVisibleChange}
      content={content}
      overlayStyle={{ width: 394 }}
      overlayClassName={styles.overlay}
    >
      <LinkButton className="f-fr">
        <Iconfont type="iconjilu" className={styles.icon} />
        操作记录
      </LinkButton>
    </Popover>
  );
};

export default ContractOperateLog;
