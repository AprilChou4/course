import React from 'react';
import MainContent from '../MainContent';
import TableHeader from '../TableHeader';
import DataGride from '../DataGride';
import styles from './style.less';

const Content = () => {
  return (
    <div className={styles.container}>
      <MainContent />
      <div className={styles.header}>
        <div className="title-mark f-dib">服务项目</div>
        <TableHeader />
      </div>
      <div>
        <DataGride />
      </div>
    </div>
  );
};

export default Content;
