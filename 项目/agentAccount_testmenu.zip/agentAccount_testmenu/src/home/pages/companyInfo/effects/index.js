import { message } from 'antd';
import ShowConfirm from '@components/ShowConfirm';
import services from '../services';

export default {
  /**
   * 获取企业信息
   * @param {*} param0
   */
  async $getCompanyInfo(payload = {}) {
    const res = await services.getCompanyInfo(payload);
    const { companyId, certifyStatus, rejectReason, ...rest } = res; // result、status没有用
    this.updateState({
      companyId,
      certificationStatus: certifyStatus,
      rejectReason,
      formValues: {
        companyType: 1, // 默认是企业
        ...rest,
      },
    });
  },

  /**
   *
   * @param {*} areaCode  区域Code
   * @param {*} businessPlace  经营场所
   * @param {*} businessScope  经营范围
   * @param {*} companyId  公司id
   * @param {*} companyLicenseName  公司营业执照文件名
   * @param {*} companyLicenseUrl  公司营业执照url
   * @param {*} companyPrincipal  法定代表人/企业负责人
   * @param {*} companyType  企业类型(1企业版，2个人版)
   * @param {*} idNumber  身份证号码
   * @param {*} unifiedSocialCreditCode  统一社会信用代码
   */
  async updateCompanyInfo(payload) {
    const { formRef, companyId } = this.getState();
    const formValues = formRef.getFieldsValue();
    const { area = {}, companyLicense, createTime, ...restFormValues } = formValues;
    const data = await services.updateCompanyInfo(
      {
        areaCode: area.areaCode,
        areaName: area.areaName,
        ...companyLicense,
        ...restFormValues,
        ...payload,
        companyId,
      },
      {
        status: {
          300: (res) => {
            ShowConfirm({
              width: 400,
              type: 'warning',
              title: res.message,
            });
          },
        },
      },
    );
    if (data && data.certify) {
      ShowConfirm({
        width: 300,
        type: 'success',
        title: '已为您提交企业信息至后台审核认证',
        onOk() {
          window.location.reload();
        },
      });
      return;
    }
    message.success('保存成功');
    setTimeout(() => {
      window.location.reload();
    }, 500);
    this.$getCompanyInfo();
    this.updateState({
      editStatus: 0,
    });
  },

  async initData() {
    await this.$getCompanyInfo();
  },
};
