import { createServices } from '@utils';

export default createServices({
  getCompanyInfo: 'instead/v2/user/company/get::post',
  updateCompanyInfo: 'instead/v2/user/company/update::postJSON',
});
