// 企业信息
import React from 'react';
import Layout from './components/Layout';
import effects from './effects';

export default {
  state: {
    companyId: '',
    // 编辑状态 0: 未编辑，1: 部分编辑，2: 全部编辑
    editStatus: 0,
    // 认证状态 -1: 未认证，0: 认证中，1: 已认证，2: 认证失败。
    certificationStatus: 0,
    // 失败原因
    rejectReason: '',
    formRef: null,
    formValues: {
      companyType: 1,
    },
    // 认证状态选项
    certificationOptions: {
      '-1': {
        text: '未认证',
        type: 'primary',
        color: '#008cff',
      },
      '0': {
        text: '认证中',
        type: 'warning',
        color: '#f6a327',
      },
      '1': {
        text: '已认证',
        type: 'success',
        color: '#19d86c',
      },
      '2': {
        text: '认证失败',
        type: 'danger',
        color: '#D83919',
      },
    },
  },
  effects,
  render() {
    return <Layout />;
  },
  onChange: {
    query() {
      this.store.dispatch({
        type: 'initData',
      });
    },
  },
};
