import React, { forwardRef, useMemo } from 'react';
import { Upload, Button, message, Icon } from 'antd';
import _ from 'lodash';
import ViewImg from '../ViewImg';
import './style.less';

const UploadInfo = () => (
  <div styleName="m-hint">
    <p>请上传贵司加盖红色公章的营业执照复印件/扫描件；</p>
    <p>支持jpg/bmp/png格式；大小不超过1mb。</p>
  </div>
);

const UploadImg = ({ value, onChange }) => {
  const url = useMemo(() => _.get(value, 'companyLicenseUrl', ''), [value]);
  const fileName = useMemo(() => _.get(value, 'companyLicenseName', ''), [value]);

  // 上传图片前
  const beforeUpload = ({ type, size }) => {
    // 'application/pdf'
    const isValidFormat = ['image/jpeg', 'image/bmp', 'image/png'].includes(type);
    if (!isValidFormat) {
      message.warn('上传文件格式错误，仅支持图片(jpg、png、bmp)');
    }
    const isValidSize = size / 1024 / 1024 < 1;
    if (!isValidSize) {
      message.warn('图片大小不能超过1M');
    }
    return isValidFormat && isValidSize;
  };

  // 上传图片
  const handleChange = ({ file }) => {
    if (file.status === 'uploading') {
      // nui loading
    } else if (file.status === 'done') {
      console.log(file, '----------file');
      if (_.get(file, 'response.status') === 300) {
        message.error(_.get(file, 'response.message') || '上传失败!');
        return;
      }
      const companyLicenseUrl = _.get(file, 'response.data.filePath', '');
      const companyLicenseName = _.get(file, 'response.data.fileName', '');
      onChange({
        companyLicenseUrl,
        companyLicenseName,
      });
    } else if (file.status === 'error') {
      message.error('上传失败!');
    }
  };

  const handleRemove = () => {
    onChange();
  };

  return (
    <div styleName="m-uploadImg">
      {url && (
        <>
          <div styleName="m-upload">
            <ViewImg alt="营业执照" src={url} fileName={fileName} />
            <i className="iconfont" styleName="m-del" onClick={handleRemove}>
              &#xeb2f;
            </i>
          </div>
          <UploadInfo />
        </>
      )}
      <Upload
        accept="image/jpeg,image/png,image/bmp,application/pdf"
        name="file"
        listType={url ? 'text' : 'picture-card'}
        showUploadList={false}
        action={`${basePath}instead/v2/user/company/uploadFile.do`}
        // action="http://192.168.206.92:3000/mock/516/instead/v2/user/company/uploadFile.do"
        beforeUpload={beforeUpload}
        onChange={handleChange}
      >
        {url ? (
          <Button type="highlight">重新上传</Button>
        ) : (
          // <div className="components-uploadImg-upload">
          <Icon type="plus" style={{ fontSize: 32 }} />
          // </div>
        )}
      </Upload>
      {!url && <UploadInfo />}
    </div>
  );
};

export default forwardRef(UploadImg);
