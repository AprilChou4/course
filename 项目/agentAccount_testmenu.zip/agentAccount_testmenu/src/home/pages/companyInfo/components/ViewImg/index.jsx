import React, { forwardRef, useState } from 'react';
import Carousel from '@components/Carousel';
import { Modal } from 'antd';
import './style.less';

const ViewImg = ({ src, fileName }) => {
  const [visible, setVisible] = useState(false);

  // 点击图片
  const handleImgClick = () => {
    setVisible(true);
  };

  // 取消
  const onCancel = () => {
    setVisible(false);
  };
  return (
    Boolean(src) && (
      <>
        <div style={{ display: 'inline-block' }} onClick={handleImgClick}>
          <img alt="营业执照" src={src} styleName="m-img" />
        </div>
        {/* <ViewImg
          src={src}
          fileName={fileName}
          visible={visible}
          onVisibleChange={handleVisibleChange}
        /> */}
        <Modal
          title="营业执照"
          footer={null}
          width={800}
          height={500}
          centered
          visible={visible}
          destroyOnClose
          onCancel={onCancel}
          styleName="m-viewImgModal"
          getContainer={false}
          maskClosable={false}
        >
          <div styleName="m-imgWrap">
            <Carousel
              imageUrl={src}
              getContent={() => (
                <a
                  href={`${basePath}instead/CustomerArchive/downloadAttachment.do?urlString=${src}&fileName=${fileName}`}
                  className="iconfont"
                  title="下载"
                >
                  &#xea34;
                </a>
              )}
            />
          </div>
        </Modal>
      </>
    )
  );
};
export default forwardRef(ViewImg);
