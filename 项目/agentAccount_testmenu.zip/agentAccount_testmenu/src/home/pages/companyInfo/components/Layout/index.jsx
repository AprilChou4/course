import React from 'react';
import { Layout } from 'antd';
import HeaderBtn from '../HeaderBtn';
import Form from '../Form';
import SiderImg from '../SiderImg';
import './style.less';

const { Sider, Content } = Layout;
const Main = () => (
  <div styleName="companyInfo-layout">
    <HeaderBtn />
    <Layout>
      <Sider theme="light" width={260}>
        <SiderImg />
      </Sider>
      <Content style={{ background: '#fff' }}>
        <Form />
      </Content>
    </Layout>
  </div>
);

export default Main;
