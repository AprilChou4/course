import dictionary from './dictionary';

export default dictionary;
