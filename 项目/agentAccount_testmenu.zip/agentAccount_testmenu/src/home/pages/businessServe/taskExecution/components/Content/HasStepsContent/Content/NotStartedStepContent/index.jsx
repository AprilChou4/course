/**
 * 未开始的步骤内容
 */
import React from 'react';
import { Descriptions } from 'antd';
import styles from '../style.less';

const DescriptionsItem = Descriptions.Item;

const NotStartedStepContent = ({ index, data }) => {
  const { stepName, stepDescribe, stepData, stepOutput } = data;

  return (
    <Descriptions
      column={1}
      title={`步骤${index + 1}：${stepName}`}
      className={styles.descriptions}
    >
      <DescriptionsItem label="描述">{stepDescribe}</DescriptionsItem>
      <DescriptionsItem label="资料">{stepData}</DescriptionsItem>
      <DescriptionsItem label="交付件">{stepOutput}</DescriptionsItem>
    </Descriptions>
  );
};

export default NotStartedStepContent;
