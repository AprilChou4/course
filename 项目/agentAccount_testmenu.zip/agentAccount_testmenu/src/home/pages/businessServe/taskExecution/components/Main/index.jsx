import React from 'react';
import Layout from '@components/Layout';
import ContentWrapper from '@components/ContentWrapper';
import Title from '../Title';
import Header from '../Header';
import Content from '../Content';

const Main = () => {
  return (
    <Layout.Container>
      <ContentWrapper
        title={<Title />}
        header={<Header />}
        headerStyle={{ borderBottom: '1px solid #E2E2E2', padding: '9px 0' }}
        content={<Content />}
        contentStyle={{ padding: '16px 0 16px 16px' }}
        style={{ overflow: 'hidden' }}
      />
    </Layout.Container>
  );
};

export default Main;
