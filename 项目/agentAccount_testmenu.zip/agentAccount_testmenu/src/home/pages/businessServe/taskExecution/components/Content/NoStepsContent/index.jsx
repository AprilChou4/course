/**
 * 任务单没有步骤的内容
 */
import React from 'react';
import { connect } from 'nuomi';
import Complete from './Complete';
import UnComplete from './UnComplete';

const NoStepsContent = ({ taskStatus }) => {
  const isCompleted = taskStatus === 2;
  return isCompleted ? <Complete /> : <UnComplete />;
};

export default connect(({ taskInfo: { taskStatus } }) => ({ taskStatus }))(NoStepsContent);
