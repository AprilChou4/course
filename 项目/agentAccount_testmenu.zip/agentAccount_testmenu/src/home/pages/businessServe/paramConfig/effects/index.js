import globalServices from '@home/services';
import services from '../services';

export default {
  // 获取工商服务参数设置
  async $getParamSetting(payload) {
    const data = await globalServices.getBusinessServeSetting(payload);
    this.updateState({
      companySetData: data,
    });
  },
  // 是否必须上传附件
  async $updateTaskFileUpload(payload) {
    await services.updateTaskFileUpload(payload);
    this.$getParamSetting();
  },

  // 任务是否严格执行
  async $updateTaskRule(payload) {
    await services.updateTaskRule(payload);
    this.$getParamSetting();
  },
  $initData() {
    this.$getParamSetting();
  },
};
