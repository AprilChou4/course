import { createServices } from '@utils';

export default createServices({
  updateTaskFileUpload: 'instead/v2/customer/task/business/set/updateTaskFileUpload::post', // 是否必须上传附件
  updateTaskRule: 'instead/v2/customer/task/business/set/updateTaskRule::post', // 任务是否严格执行
});
