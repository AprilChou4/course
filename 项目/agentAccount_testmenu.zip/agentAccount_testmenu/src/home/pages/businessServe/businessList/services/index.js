import { createServices } from '@utils';

export default createServices({
  getRoletypeList: 'instead/v2/user/staff/role/list.do', // 查询派工角色信息(树结构)，包括开票员等

  getTaskList: 'instead/v2/customer/task/business/list.do::postJSON', // 获取工商任务单列表
  getProductList: 'instead/v2/user/basicSetting/service/process/list.do::post', // 获取服务产品/流程列表接口
  deleteBusiness: 'instead/v2/customer/task/business/delete.do::postJSON', // 任务-删除
  assignBusiness: 'instead/v2/customer/task/business/assign.do::postJSON', // 派工
  getTaskAssign: 'instead/v2/customer/task/business/get.do::post', // 派工-查看任务详情
  getCustomCols: 'instead/v2/customer/account/customizeColumn/get', // 查询记账平台自定义列数据
  updateCustomCols: 'instead/v2/customer/account/customizeColumn/update::postJSON', // 更新记账平台自定义列
});
