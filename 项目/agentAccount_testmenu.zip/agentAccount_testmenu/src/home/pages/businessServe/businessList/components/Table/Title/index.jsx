import React from 'react';
import { connect } from 'nuomi';
import Iconfont from '@components/Iconfont';
import './style.less';

const Title = ({ taskAuth }) => {
  return (
    <>
      <Iconfont code="&#xea3d;" />
      {
        [
          <span>当前存在未开始任务 x1 个、进行中任务 x2 个</span>,
          <span>您有 x 个待执行的工商任务，请及时处理！</span>,
          <span>当前存在未开始任务 x1 个，进行中任务 x2 个，待执行任务 z 个，请及时处理！</span>,
        ][taskAuth - 1]
      }
    </>
  );
};
export default connect(({ taskAuth }) => ({ taskAuth }))(Title);
