/* eslint-disable no-param-reassign */
/**
 * 工商任务派工
 */
import React from 'react';
import { Button, message } from 'antd';
import { connect } from 'nuomi';
import TaskAssignModal from './TaskAssignModal';
import services from '../../services';

const TaskAssign = ({
  dispatch,
  selectedRowKeys,
  selectedRows,
  taskAssignVisible,
  executorList,
}) => {
  // 点击派工
  const assign = async () => {
    if (!selectedRowKeys.length) {
      message.warning('请选择要派工的任务');
      return false;
    }
    if (selectedRowKeys.length === 1) {
      const data = await services.getTaskAssign({
        taskId: selectedRowKeys[0],
      });

      if (data.taskStatus === 2 && !data.assign) {
        message.warning('所选任务已完成/无权限，无法派工');
        return false;
      }
      if (data.taskStatus === 2) {
        message.warning('所选任务已完成，无法派工');
        return false;
      }
      if (!data.assign) {
        message.warning('您暂无所选任务的派工权限');
        return false;
      }
      dispatch({
        type: 'updateState',
        payload: {
          taskAssignData: data,
          selectedRows: [data],
        },
      });
    } else {
      // 过滤已完成、无权限的任务
      const hasCompleteArr = selectedRows.filter((item) => item.taskStatus === 2);
      const noAuthArr = selectedRows.filter((item) => !item.edit);
      // 既有已完成、又有无权限
      const bothCompleteAuth = hasCompleteArr.length + noAuthArr.length > selectedRowKeys.length;
      // 只有已完成
      const onlyComplete = hasCompleteArr.length === selectedRowKeys.length && !noAuthArr.length;
      // 只有无权限
      const onlyNoAuth = noAuthArr.length === selectedRowKeys.length && !hasCompleteArr.length;
      if (bothCompleteAuth || onlyComplete || onlyNoAuth) {
        let msg = '';
        if (bothCompleteAuth) {
          msg = '所选任务已完成/无权限，无法派工';
        } else if (onlyComplete) {
          msg = '所选任务已完成，无法派工';
        } else {
          msg = '您暂无所选任务的派工权限';
        }
        message.warning(msg);
        return false;
      }
    }
    dispatch({
      type: 'updateState',
      payload: {
        taskAssignVisible: true,
        isSingleAssign: selectedRowKeys.length === 1,
      },
    });
    // eslint
    return true;
  };
  return (
    <div style={{ display: 'inline-block' }}>
      <Button type="primary" onClick={assign}>
        派工
      </Button>
      {taskAssignVisible && <TaskAssignModal executorList={executorList} type={1} />}
    </div>
  );
};

export default connect(({ selectedRowKeys, selectedRows, taskAssignVisible, executorList }) => ({
  selectedRowKeys,
  selectedRows,
  taskAssignVisible,
  executorList,
}))(TaskAssign);
