// 工商任务派工> 步骤表格
import React from 'react';
import { connect } from 'nuomi';
import { Tooltip, Form, Input } from 'antd';
import SuperTable from '@components/SuperTable';
import SearchTreeSelect from '@components/select/SearchTreeSelect';
import PropTypes from 'prop-types';

import Style from './style.less';

const FormItem = Form.Item;
const formItemLayout = {
  labelCol: {
    sm: { span: 0 },
  },
  wrapperCol: {
    sm: { span: 24 },
  },
};
const StepTable = ({ form, taskAssignData, executorList }) => {
  const { getFieldDecorator } = form;
  const { taskStepVOList } = taskAssignData || {};
  const columns = [
    {
      title: '步骤',
      dataIndex: 'stepOrder',
      align: 'center',
      width: 60,
    },
    {
      title: '名称',
      dataIndex: 'stepName',
      align: 'center',
      width: 340,
      render: (text) => (
        <div className="f-tal f-ellipsis" title={text}>
          {text}
        </div>
      ),
    },
    {
      title: '经办人',
      dataIndex: 'operator',
      align: 'center',
      render: (text, record, index) => {
        // stepStatus 步骤状态（0未开始，1进行中，2已完成）
        return (
          <>
            {/* 任务id */}
            {getFieldDecorator(`taskStepRequest[${index}].taskId`, {
              initialValue: record.taskId,
            })(<Input type="hidden" />)}
            {/* 步骤id */}
            {getFieldDecorator(`taskStepRequest[${index}].taskStepId`, {
              initialValue: record.taskStepId,
            })(<Input type="hidden" />)}

            {record.stepStatus === 2 ? (
              <>
                {getFieldDecorator(`taskStepRequest[${index}].operator`, {
                  initialValue: record.operator,
                })(<Input type="hidden" />)}
                <Tooltip
                  title={record.stepStatus === 2 ? '任务已完成' : '无派工权限'}
                  overlayClassName={Style['m-tooltip']}
                  placement="bottom"
                >
                  <span>{record.operatorName}</span>
                </Tooltip>
              </>
            ) : (
              <>
                <FormItem label="" {...formItemLayout}>
                  {getFieldDecorator(`taskStepRequest[${index}].operator`, {
                    initialValue: record.operator || undefined,
                  })(
                    <SearchTreeSelect
                      placeholder="请选择经办人"
                      style={{ width: '100%' }}
                      treeData={executorList}
                      treeDefaultExpandAll
                      dropdownStyle={{ maxHeight: 300 }}
                    />,
                  )}
                </FormItem>
              </>
            )}
          </>
        );
      },
    },
  ];

  return (
    <div className={Style['m-customBody']}>
      <SuperTable
        rowKey="taskStepId"
        className={Style['m-stepTable']}
        columns={columns}
        bordered
        locale={{
          emptyText: '当前任务未设置步骤',
        }}
        pagination={false}
        dataSource={taskStepVOList}
        scroll={{ y: 240 }}
      />
    </div>
  );
};
StepTable.defaultProps = {
  // 经办人列表
  executorList: [],
};
StepTable.propTypes = {
  executorList: PropTypes.arrayOf(PropTypes.any),
};
export default connect(({ taskAssignData }) => ({
  taskAssignData,
}))(StepTable);
