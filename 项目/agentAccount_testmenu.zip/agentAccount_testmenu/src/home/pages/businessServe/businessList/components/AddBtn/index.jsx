/* eslint-disable no-param-reassign */
/**
 * 新增任务单
 */
import React from 'react';
import { Button } from 'antd';
import { connect } from 'nuomi';
import { postMessageRouter } from '@utils';

const AddBtn = () => {
  // 点击新增
  const add = () => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/businessServe/task',
        query: {},
      },
    });
  };
  return (
    <>
      <Button className="e-ml12" type="primary" onClick={add}>
        新增任务单
      </Button>
    </>
  );
};

export default connect()(AddBtn);
