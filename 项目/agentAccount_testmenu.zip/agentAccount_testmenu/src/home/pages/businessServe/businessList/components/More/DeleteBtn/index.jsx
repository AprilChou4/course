/**
 * 点击删除
 */
import React from 'react';
import { message } from 'antd';
import CollapseItem from '@components/CollapseItem';
import ShowConfirm from '@components/ShowConfirm';
import { connect } from 'nuomi';

const DeleteBtn = ({ dispatch, selectedRowKeys, selectedRows }) => {
  // 删除收缩框
  const getCollapseItem = (selectList) => (
    <CollapseItem
      getContent={() => (
        <div>
          {selectedRows &&
            selectedRows.length &&
            selectList.map((item) => <span key={item.taskNumber}>“{item.taskNumber}”,</span>)}
          无权限删除
        </div>
      )}
      header="详细原因"
    />
  );
  // 点击删除
  const del = () => {
    if (!selectedRowKeys.length) {
      message.warning('请选择要删除的任务');
      return false;
    }
    if (selectedRowKeys.length === 1 && !selectedRows[0].edit) {
      message.warning('您无权限删除该任务');
      return false;
    }

    ShowConfirm({
      title: '你确定要删除所选任务信息吗？',
      onOk: () => {
        dispatch({
          type: '$deleteBusiness',
          payload: {
            taskIds: selectedRowKeys,
            selectedRows,
            getCollapseItem,
          },
        });
      },
    });
    // eslint
    return true;
  };
  return (
    <>
      <div onClick={del}>删除</div>
    </>
  );
};

export default connect(({ selectedRowKeys, selectedRows }) => ({
  selectedRowKeys,
  selectedRows,
}))(DeleteBtn);
