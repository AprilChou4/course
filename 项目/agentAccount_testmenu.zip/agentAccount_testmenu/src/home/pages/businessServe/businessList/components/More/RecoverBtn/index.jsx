/**
 * 恢复按钮
 */
import React from 'react';
import { message } from 'antd';
import CollapseItem from '@components/CollapseItem';
import ShowConfirm from '@components/ShowConfirm';
import { connect } from 'nuomi';

const RecoverBtn = ({ dispatch, selectedRowKeys, selectedRows }) => {
  // 收缩框
  const getCollapseItem = (selectList) => (
    <CollapseItem
      getContent={() => (
        <div>
          {selectList &&
            selectList.map((item) => <span key={item.taskNumber}>“{item.taskNumber}”，</span>)}
          等任务状态为【未开始 / 进行中 / 已完成】，无需恢复
        </div>
      )}
      header="详细原因"
    />
  );
  // 点击恢复
  const recover = () => {
    if (!selectedRowKeys.length) {
      message.warning('请选择要恢复的任务');
      return false;
    }
    // 非已终止（未开始，进行中，已完成）的提示：
    const notStopList = selectedRows.filter((item) => ![0, 1, 2].includes(item.taskStatus));
    if (notStopList.length === 'selectedRows') {
      message.warning('所选任务状态为【未开始/进行中/已完成】，无需恢复');
      return false;
    }

    // 勾选多条，包含无权限恢复的任务 / 非已终止（未开始，进行中，已完成）的任务时，进行提示：点击知道了，自动过滤不能恢复的，能恢复的就直接恢复
    const noAuthAndNoStopList = selectedRows.filter(
      (item) => [0, 1, 2].includes(item.taskStatus) || !item.edit,
    );
    // const canRecoverList = selectedRows.filter(
    //   (item) => ![0, 1, 2].includes(item.taskStatus) && item.edit,
    // );
    ShowConfirm({
      title: `“${noAuthAndNoStopList[0].taskNumber}”等${noAuthAndNoStopList.length}个任务不支持恢复`,
      type: 'warning',
      width: 420,
      content: getCollapseItem(noAuthAndNoStopList),
      onOk: () => {
        dispatch({
          type: '$recoverBusiness',
          payload: {
            taskIds: selectedRowKeys,
          },
        });
      },
    });
    // eslint
    return true;
  };
  return (
    <>
      <div onClick={recover}>恢复</div>
    </>
  );
};

export default connect(({ selectedRowKeys, selectedRows }) => ({
  selectedRowKeys,
  selectedRows,
}))(RecoverBtn);
