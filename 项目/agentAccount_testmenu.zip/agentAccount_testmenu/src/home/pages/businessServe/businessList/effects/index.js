import { message } from 'antd';
import ShowConfirm from '@components/ShowConfirm';
import globalServices from '@home/services';
import services from '../services';

export default {
  getQueryParam() {
    const { tableConditions } = this.getState();
    // 部门员工跳转工商服务的查询参数
    if (!window.businessListParams) {
      return false;
    }
    const { staffId } = window.businessListParams || {};
    this.updateState({
      tableConditions: {
        ...tableConditions,
        executorOperator: staffId,
      },
    });
    // eslint
    return true;
  },

  // 请求任务单列表
  async $getTaskList() {
    const { tableConditions } = this.getState();
    const data =
      (await services.getTaskList(tableConditions, {
        loading: '正在获取任务单列表...',
      })) || {};
    this.updateState({
      tableList: data.list || [],
      total: data.total || 0,
      taskAuth: data.authority,
    });
  },

  // 修改筛选条件
  async updateCondition(payload = {}) {
    const { tableConditions } = this.getState();
    const lastConditions = {
      ...tableConditions,
      current: 1,
      ...payload,
    };
    this.updateState({
      tableConditions: lastConditions,
      selectedRowKeys: [],
      selectedRows: [],
      isSingleAssign: false,
    });
    await this.$getTaskList();
  },
  // 查询自定义列
  async getCustomCols(payload = {}) {
    const data = await services.getCustomCols(payload);
    !payload.isInit &&
      this.updateState({
        columnSource: data || [],
      });
    return data;
  },
  // 更新自定义列
  async updateCustomCols(payload = {}) {
    await services.updateCustomCols(payload, { loading: '正在保存...', successMsg: '保存成功' });
    this.updateState({
      businessCustomColVisible: false,
    });
    this.getCustomCols();
  },

  // 查询所有员工集合
  async getAllEmployeeList(payload) {
    const data = await globalServices.getAllEmployeeList(payload);
    this.updateState({
      allEmployeeList: data,
    });
  },
  // 任务-终止
  async $stopBusiness(payload) {
    const { taskIds } = payload;
    await services.deleteBusiness(taskIds);
    message.success('终止成功');
    this.updateState({
      selectedRowKeys: [],
      selectedRows: [],
    });
    this.updateCondition();
  },

  // 任务-恢复
  async $recoverBusiness() {
    // const { selectedRows, taskIds, getCollapseItem } = payload;
    // const data = await services.deleteBusiness(taskIds);
    // message.success('恢复成功');
    // this.updateState({
    //   selectedRowKeys: [],
    //   selectedRows: [],
    // });
    // this.updateCondition();
  },
  // 任务-删除
  async $deleteBusiness(payload) {
    const { selectedRows, taskIds, getCollapseItem } = payload;
    const data = await services.deleteBusiness(taskIds);
    const noAuthArr = selectedRows.filter((item) => data.includes(item.taskId));
    if (data.length) {
      ShowConfirm({
        title: `“${noAuthArr[0].taskNumber}”等${data.length}个任务不支持删除`,
        type: 'warning',
        width: 420,
        content: getCollapseItem(noAuthArr),
        onOk: () => {
          this.updateState({
            selectedRowKeys: [],
            selectedRows: [],
          });
          this.updateCondition();
        },
      });
    } else {
      message.success('删除成功');
      this.updateState({
        selectedRowKeys: [],
        selectedRows: [],
      });
      this.updateCondition();
    }
  },

  /**
   * 派工
   * @param {*string} deptId 执行人部门id
   * @param {*string} staffId 执行人id
   * @param {*array} taskIdList 执行人id	任务id集合
   * @param {*array} taskStepRequest 执行步骤信息
   */
  async $assignBusiness(payload) {
    await services.assignBusiness(payload);
    message.success('派工成功');
    this.updateState({
      taskAssignVisible: false,
      selectedRowKeys: [],
      selectedRows: [],
    });
    this.updateCondition();
  },

  /**
   * 派工-查看任务详情
   * @param {*string} taskId 执行人id
   */
  async $getTaskAssign(payload) {
    const data = await services.getTaskAssign(payload);

    this.updateState({
      taskAssignData: data,
    });
  },

  // 获取服务产品列表
  async $getProductList() {
    const data = await services.getProductList();
    const businessList = (data || []).filter((it) => it.serviceClassId === 2);
    const productList = []; // 服务产品树结构  服务类型0-服务产品
    businessList.forEach((classType) => {
      classType.serviceTypeVOList.forEach((serviceType) => {
        productList.push(serviceType);
      });
    });
    this.updateState({
      productList,
    });
  },

  // 查询执行人--获取公司所有部门员工树
  async $queryEmpTree() {
    const data = await globalServices.getStaffTree();
    const helper = (list) => {
      return list.map((item) => {
        if (item.isParent) {
          return {
            title: item.name,
            value: item.value,
            key: item.value,
            code: item.code,
            selectable: false,
            disabled: !item.children.length,
            children: helper(item.children),
          };
        }
        return {
          title: item.name,
          value: item.value,
          key: item.value,
          code: item.code,
          selectable: true,
        };
      });
    };
    this.updateState({
      executorList: helper(data),
    });
  },

  async initData() {
    this.getQueryParam();
    this.getCustomCols();
    await this.$getTaskList();
    // 获取执行人列表
    this.$queryEmpTree();
    this.getAllEmployeeList();
    // 获取服务产品列表
    this.$getProductList();
  },

  // 判断执行权限
  async taskCheckAuthority(payload) {
    const data = await globalServices.taskCheckAuthority(payload);
    return data;
  },
};
