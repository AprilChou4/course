/* eslint-disable no-param-reassign */
/**
 * 执行按钮
 */
import React from 'react';
import { Button, message } from 'antd';
import { connect } from 'nuomi';
import pubData from 'data';
import { validateArrayLength, postMessageRouter } from '@utils';

const ExecuteBtn = ({ dispatch, type, selectedRowKeys }) => {
  // 点击执行
  const execute = async () => {
    if (!selectedRowKeys.length) {
      message.warning('请选择要执行的任务');
      return;
    }

    // 过滤无权限和未派工的任务
    const data = await dispatch({
      type: 'taskCheckAuthority',
      payload: {
        execute: true,
        taskIdList: selectedRowKeys,
      },
    });
    if (!data) {
      return;
    }
    const { taskIdList, notAssign, notAuthority } = data || {};
    if (!validateArrayLength(taskIdList)) {
      if (notAssign && notAuthority) {
        message.warning('所选任务未派工或无权限，无法执行');
      } else if (notAssign) {
        message.warning('所选任务未派工，无法执行');
      } else {
        message.warning('您无权限执行该任务');
      }
      return;
    }

    // 由于新项目经过路由跳转时只能把参数附在url上，url长度有限制，所以有的查询参数就放到了pubData
    pubData.set('taskExecution-query', { taskIds: taskIdList });
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/businessServe/taskExecution',
      },
    });
  };

  return (
    <Button className="e-ml12" type={type || 'primary'} onClick={execute}>
      执行
    </Button>
  );
};

export default connect(({ selectedRowKeys }) => ({
  selectedRowKeys,
}))(ExecuteBtn);
