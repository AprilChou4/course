// 管理者列
import React from 'react';
import ColumnsManage from './ColumnsManage';

const ColumnsAll = [
  ...ColumnsManage,
  {
    title: '步骤状态',
    dataIndex: 'stepProcess',
    align: 'center',
    width: 145,
    render: (text) => (
      <div className="f-tal f-ellipsis" title={text}>
        {text || '-'}
      </div>
    ),
  },
];
export default ColumnsAll;
