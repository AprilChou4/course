// 工商任务派工弹窗 1=列表派工 2=新增任务单派工
import React, { useEffect } from 'react';
import { Modal, Form, Input, message } from 'antd';
import { connect } from 'nuomi';
import Title from '@components/Title';
import SearchTreeSelect from '@components/select/SearchTreeSelect';
import PropTypes from 'prop-types';
import Collapse from '../Collapse';
import StepTable from '../StepTable';
import Style from './style.less';
import services from '../../../services';

const FormItem = Form.Item;
const formItemLayout = {
  labelCol: {
    sm: { span: 3 },
  },
  wrapperCol: {
    sm: { span: 21 },
  },
};
const TaskAssignModal = ({
  dispatch,
  form,
  selectedRows,
  selectedRowKeys,
  taskAssignVisible,
  executorList,
  taskAssignData,
  isSingleAssign,
  type,
}) => {
  const { getFieldDecorator, setFieldsValue, validateFields } = form;
  const { executorName, executorId, executorDeptId, edit, taskStepVOList } = taskAssignData || {};
  useEffect(() => {
    const getData = async () => {
      // 列表派工在点击按钮就请求了
      if (isSingleAssign && type === 2) {
        const data = await services.getTaskAssign({
          taskId: selectedRowKeys[0],
        });
        dispatch({
          type: 'updateState',
          payload: {
            taskAssignData: data,
          },
        });
      }
    };
    getData();
  }, [dispatch, isSingleAssign, selectedRowKeys, selectedRows, type]);
  // 确定
  const onOk = () => {
    validateFields(async (err, values) => {
      if (!err) {
        // type=1 使用selectedRows; type=2 使用taskAssignData
        const assignArr = type === 1 ? selectedRows : [taskAssignData];
        // 可以派工的数组
        const filterAsignArr = assignArr.filter((item) => item.taskStatus !== 2 && item.edit);
        // 不能派工的数组
        const noAsignArr = assignArr.filter((item) => item.taskStatus === 2 || !item.edit);
        const taskIdList = filterAsignArr.map((item) => item.taskId);
        if (noAsignArr.length && taskIdList.length === 0) {
          message.warning('所选任务已完成/无权限，无法派工');
          return false;
        }
        await services.assignBusiness({
          ...values,
          taskIdList,
        });
        message.success('派工成功');
        if (type === 1) {
          // 刷新列表
          dispatch({
            type: 'updateCondition',
          });
        } else {
          dispatch({
            type: '$getDetail',
            payload: selectedRowKeys[0],
          });
        }
        dispatch({
          type: 'updateState',
          payload: {
            taskAssignVisible: false,
            selectedRowKeys: [],
            selectedRows: [],
          },
        });

        // dispatch({
        //   type: 'businessServe_businessList/$assignBusiness',
        //   payload: {
        //     ...values,
        //     taskIdList,
        //   },
        // });
      }
      // eslint
      return true;
    });
  };

  // 取消
  const onCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        taskAssignVisible: false,
        selectedRowKeys: [],
        selectedRows: [],
      },
    });
  };

  // code 为deptId +staffId
  const executorChange = (value, e) => {
    // 获取部门id
    const staffDeptId = e.node.props && e.node.props.code.replace(value, '');

    // 单个派工处理start========
    taskStepVOList &&
      taskStepVOList.forEach((item, index) => {
        // 经办人id
        const operatorData = {};
        operatorData[`taskStepRequest[${index}].operator`] = value;
        setFieldsValue(operatorData);
      });
    // 单个派工处理end========
    setFieldsValue({
      deptId: staffDeptId,
    });
  };
  return (
    <>
      {taskAssignVisible && (
        <Modal
          title="派工"
          visible={taskAssignVisible}
          width={680}
          maskClosable={false}
          centered
          onOk={onOk}
          onCancel={onCancel}
          okText="确认派工"
          getContainer={false}
          destroyOnClose
          className={Style['m-taskAssignModal']}
        >
          <Form {...formItemLayout}>
            <Title title="已选择任务" />
            <Collapse />
            <Title title="派工信息" />
            {getFieldDecorator('deptId', {
              initialValue: executorDeptId || '',
            })(<Input type="hidden" />)}
            <FormItem
              label="执行人"
              {...(isSingleAssign ? { extra: <div>(原执行人：{executorName || '--'})</div> } : {})}
              className={Style['executor-item']}
            >
              {getFieldDecorator('staffId', {
                initialValue: executorId || undefined,
                rules: [
                  {
                    required: true,
                    message: '请选择执行人',
                  },
                ],
              })(
                <SearchTreeSelect
                  disabled={isSingleAssign && !edit}
                  treeData={executorList}
                  placeholder="请选择执行人"
                  style={{ width: '100%' }}
                  onChange={executorChange}
                  treeDefaultExpandAll
                  dropdownStyle={{ maxHeight: 300 }}
                />,
              )}
            </FormItem>
            {isSingleAssign && <StepTable form={form} executorList={executorList} />}
          </Form>
        </Modal>
      )}
    </>
  );
};
TaskAssignModal.defaultProps = {
  // 经办人列表
  executorList: [],
  // 派工- 1=列表派工 2=新增任务单派工
  type: 1,
};
TaskAssignModal.propTypes = {
  executorList: PropTypes.arrayOf(PropTypes.any),
  type: PropTypes.number,
};
export default connect(
  ({ taskAssignVisible, selectedRows, selectedRowKeys, taskAssignData, isSingleAssign }) => ({
    taskAssignVisible,
    selectedRows,
    selectedRowKeys,
    taskAssignData,
    isSingleAssign,
  }),
)(Form.create()(TaskAssignModal));
