// 工商任务表格
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import AntdTable from '@components/table/AntdTable';
import { ColumnsManage, ColumnsExecutor, ColumnsAll } from '../Columns';

const ManageTable = ({
  tableList,
  total,
  selectedRowKeys,
  pageSizeOptions,
  current,
  pageSize,
  taskAuth,
  columnSource,
  dispatch,
  ...rest
}) => {
  // 页码改变
  const handlePageChange = (page) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        current: page,
      },
    });
  };

  // pageSize 变化
  const handlePageSizeChange = (page, size) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        pageSize: size,
      },
    });
  };

  // 改变复选框
  const changeSelection = (selectedRowKey, selectedRow) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedRowKeys: selectedRowKey,
        selectedRows: selectedRow,
      },
    });
  };
  // const columnsConfig = {
  //   customerName: {
  //     // 客户名称
  //     width: 272, // 18个汉字换行
  //     fixed: 'left',
  //     align: 'left',
  //     className: `f-ellipsis`,
  //     render: (text, record) => (
  //       <>
  //         {record.new ? <span /> : null}
  //         <span title={text}>{text}</span>
  //       </>
  //     ),
  //   },
  //   // 是否办理CA证书 1是0否
  //   isOpenCaCertificate: {
  //     width: 170,
  //     render: (text) => (text || text === 0) && ['否', '是'][text],
  //   },
  // };
  /**
   * 根据自定义列获取列
   * @param {*} customColumnSource
   */
  // const getColumns = (customColumnSource) => {
  //   const showColumns = customColumnSource.filter((item) => item.selected);
  //   let x = 170 + 50;
  //   const customColum = showColumns.map((item, index) => {
  //     const option = {
  //       ...item,
  //       title: item.fieldName,
  //       dataIndex: item.fieldKey,
  //       align: 'center',
  //       width: 130,
  //       className: 'f-ellipsis',
  //       render: (text) => (
  //         <div className="f-ellipsis" title={text}>
  //           {text}
  //         </div>
  //       ),
  //       ...(columnsConfig[item.fieldKey] || {}),
  //     };
  //     // 固定列固定宽度,只有客户名称一列的时候，不固定列
  //     if (showColumns.length === 1) {
  //       delete option.fixed;
  //     }
  //     // 非固定列要固定宽度,最后一列宽度自适应(不然会有间隙)
  //     if (index === showColumns.length - 1) {
  //       delete option.width;
  //     }
  //     x += option.width || 0;
  //     return option;
  //   });
  //   const columns = [
  //     {
  //       // 返回数据中没有这一栏，自己手动加上
  //       title: '序号',
  //       dataIndex: 'index',
  //       fixed: 'left',
  //       align: 'center',
  //       className: 'operate-cell',
  //       width: 60,
  //       render: (text, record, index) => index + 1,
  //     },
  //   ].concat(customColum);
  //   x = x + 60 + 170;
  //   return {
  //     columns,
  //     x,
  //   };
  // };

  // 点击自定义列
  const handleSettingClick = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        businessCustomColVisible: true,
      },
    });
  }, [dispatch]);

  return (
    <AntdTable
      rowKey="taskId"
      bordered
      showSettingIcon
      rowSelection={{
        columnWidth: 40,
        selectedRowKeys,
        onChange: changeSelection,
      }}
      locale={{
        emptyText: '暂无数据',
      }}
      pagination={{
        showSizeChanger: true,
        pageSizeOptions,
        current,
        total,
        pageSize,
        showTotal: (count) => `共${count}条`,
        onChange: handlePageChange,
        onShowSizeChange: handlePageSizeChange,
      }}
      scroll={{ y: true }}
      dataSource={tableList}
      {...rest}
      columns={[ColumnsManage, ColumnsExecutor, ColumnsAll][taskAuth - 1]}
      onSettingClick={handleSettingClick}
    />
  );
};

export default connect(
  ({
    tableList,
    total,
    selectedRowKeys,
    pageSizeOptions,
    tableConditions,
    taskAuth,
    columnSource,
  }) => ({
    tableList,
    total,
    selectedRowKeys,
    pageSizeOptions,
    current: tableConditions.current,
    pageSize: tableConditions.pageSize,
    taskAuth,
    columnSource,
  }),
)(ManageTable);
