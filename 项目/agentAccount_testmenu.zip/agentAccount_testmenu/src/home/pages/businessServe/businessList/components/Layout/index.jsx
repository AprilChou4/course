// 布局-管理者
import React from 'react';
import ContentWrapper from '@components/ContentWrapper';
import Layout from '@components/Layout';
import Authority from '@components/Authority';
import { connect } from 'nuomi';
import Search from '../Search';
import BusinessTable from '../Table';
import './style.less';
import AddBtn from '../AddBtn';
import ExecuteBtn from '../ExecuteBtn';
import TaskAssign from '../TaskAssign';
import More from '../More';

const Main = () => {
  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title="工商任务单列表"
        header={{
          left: <Search />,
          right: (
            <>
              <Authority code="602">
                <AddBtn />
              </Authority>
              <Authority code="604">
                <TaskAssign />
              </Authority>
              <Authority code="605">
                <ExecuteBtn type="default" />
              </Authority>
              <More />
            </>
          ),
        }}
        content={<BusinessTable />}
      />
    </Layout.PageWrapper>
  );
};

export default connect(({ key }) => ({
  key,
}))(Main);
