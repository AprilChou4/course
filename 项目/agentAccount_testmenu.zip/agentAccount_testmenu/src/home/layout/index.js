import React from 'react';
import Layout from './components/Layout';
import effects from './effects';

export default {
  id: 'agentAccount',
  state: {
    // 用户数据
    user: {},
    // 企业状态
    companyStatusInfo: {},
    // 菜单数据
    menuList: [],
    // 有权限的路由列表（一维数组）
    routerList: [],
    // 菜单是否收起
    collapsed: false,
    // 当前展开的 SubMenu 菜单项 key 数组
    openKeys: [],
    // 存储打开的菜单，用于收起展开后打开菜单
    openKeysTemp: [],
    // 当前选中的菜单项 key 数组
    selectedKeys: [],
    // 选择企业弹窗是否显示
    chooseCompanyVisible: false,
  },
  reducers: {
    // 更新user状态
    updateUser: (state, { payload }) => ({ ...state, user: { ...state.user, ...payload } }),
    // 更新系统消息状态
    updateMsg: (state, { payload }) => ({ ...state, message: { ...state.message, ...payload } }),
  },
  effects,
  render() {
    return <Layout>{this.children}</Layout>;
  },
  onInit() {
    this.store.dispatch({
      type: '$initData',
    });
  },
};
