import { message } from 'antd';
import { util } from '@utils';
import globalServices from '@home/services';
import services from '../services';
import { createAuth, createMenus } from '../utils';

export default {
  // 获取菜单
  $initMenus() {
    const { menuList, routerList } = createMenus(this.getState(), this.dispatch);
    this.dispatch({
      type: 'updateState',
      payload: {
        menuList,
        routerList,
      },
    });
  },
  // 退出
  async logout() {
    await services.logout();
    if (typeof ExternService === 'object') {
      // clientAPI.resScreen();
      // util???
      util.location('/client.html');
    } else {
      util.location('/agent.html');
    }
  },

  // 获取用户信息
  async getUser() {
    const user = await globalServices.getUserInfo({}, { errorMsg: '获取用户信息失败！' });
    this.updateState({ user });
  },
  // 获取企业状态
  async getCompanyStatus() {
    const companyStatusInfo = await services.getCompanyStatus(
      {},
      { errorMsg: '获取用户信息失败！' },
    );
    this.updateState({ companyStatusInfo });
  },

  $initData() {
    // 存储权限
    // createAuth(authorities ? authorities.split('#') : null);
    this.$initMenus();
    this.getUser();
    this.getCompanyStatus();
  },
};
