import { createServices } from '@utils';

export default createServices({
  logout: 'instead/v2/user/exit::post',
  getCompanyStatus: 'instead/v2/user/company/companyStatus', // 获取企业状态
});
