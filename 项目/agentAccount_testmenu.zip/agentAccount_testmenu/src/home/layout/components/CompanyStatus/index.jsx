// 公司状态
import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import moment from 'moment';
import { Popover } from 'antd';
import './style.less';

const CompanyStatus = ({ companyStatusInfo }) => {
  const {
    companyStatus,
    openAccountNum = 0,
    stopAccountNum = 0,
    usedAccountNum = 0,
    delAccountNum = 0,
    endTime,
  } = companyStatusInfo;
  const isShowAccountStatus = openAccountNum !== null;
  const currAccountNum = usedAccountNum + stopAccountNum + delAccountNum; // 已使用
  const content = (
    <div styleName="m-accountHint">
      <h3>{['试用', '正式', '过期'][companyStatus - 1]}</h3>
      <p>开通账套数：{openAccountNum || 0}</p>
      <p>已使用账套：{currAccountNum}</p>
      <p>
        (在用账套：{usedAccountNum || 0}；停用账套：{stopAccountNum || 0}；回收站账套：
        {delAccountNum || 0})
      </p>
      <p>到期时间：{endTime ? moment(endTime).format('YYYY-MM-DD') : '-'}</p>
    </div>
  );

  // 客户端
  const isClient = typeof ExternService === 'object';
  if (isClient) {
    CppSetAccountStatus &&
      CppSetAccountStatus(
        ['试用', '正式', '过期'][companyStatus - 1] || '500',
        String(openAccountNum),
        String(currAccountNum),
        String(usedAccountNum),
        String(stopAccountNum),
        String(delAccountNum),
        endTime,
        isShowAccountStatus,
      );
  }
  console.log(companyStatus, '-----companyStatus');
  return (
    <Popover placement="bottomLeft" content={content}>
      <span styleName={`m-status m-status${companyStatus || 1}`} />
    </Popover>
  );
};
CompanyStatus.defaultProps = {
  companyStatusInfo: {},
};

CompanyStatus.propTypes = {
  companyStatusInfo: PropTypes.objectOf(PropTypes.any),
};

export default connect(({ companyStatusInfo }) => ({ companyStatusInfo }))(CompanyStatus);
