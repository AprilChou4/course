// 企业服务
import React from 'react';
import { connect } from 'nuomi';
import { Popover, List } from 'antd';
import Iconfont from '@components/Iconfont';
import Style from './style.less';

const CompanyService = () => {
  const data = [
    {
      title: '诺诺课堂',
      code: '\uef8b',
      color: '#E7B85D',
      url: 'https://ny.nuonuo.com/zhibo/#/index',
    },
    {
      title: '诺通付',
      code: '\uef92',
      color: '#1890FF',
      url: 'https://jhpay.jss.com.cn/nuotongfupc/#/apply',
    },
    {
      title: '开票桌牌',
      code: '\uef8c',
      color: '#2E69DA',
      url: 'https://jskp.jss.com.cn/jskp/jskpHome/index.html#/CloudGuide',
    },
  ];
  return (
    <Popover
      placement="bottomRight"
      // trigger="click"
      overlayClassName={Style['m-serviceCard']}
      content={
        <List
          grid={{ gutter: 0, column: 3 }}
          dataSource={data}
          styleName="m-list"
          renderItem={(item) => (
            <List.Item>
              <a href={item.url} target="_blank" rel="noreferrer" styleName="m-serviceItem">
                <Iconfont code={item.code} style={{ color: item.color }} />
                <div>{item.title}</div>
              </a>
            </List.Item>
          )}
        />
      }
    >
      <a styleName="m-companyService">
        <Iconfont code="&#xef8e;" name="qiyefuwu" />
        <span>企业服务</span>
        <Iconfont code="&#xe614;" name="xiala" styleName="m-arrow" />
        <Iconfont code="&#xef89;" name="fire" styleName="m-fire" />
      </a>
    </Popover>
  );
};

export default connect()(CompanyService);
