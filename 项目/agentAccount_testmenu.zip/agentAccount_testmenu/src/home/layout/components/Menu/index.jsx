import React from 'react';
import { connect, Link } from 'nuomi';
import { Menu as AntMenu } from 'antd';
import PropTypes from 'prop-types';
import './style.less';

const { SubMenu } = AntMenu;
const MenuItem = AntMenu.Item;

// 菜单名称
const Title = ({ icon, title }) => {
  return (
    <>
      {icon && (
        <i className="iconfont" styleName="icon">
          {icon}
        </i>
      )}
      <span>{title}</span>
    </>
  );
};

Title.propTypes = {
  icon: PropTypes.string,
  title: PropTypes.string.isRequired,
};

Title.defaultProps = {
  icon: '',
};

const Menu = ({ menuList, collapsed, openKeys, selectedKeys, dispatch }) => {
  // 渲染menuItem
  const getMenus = (meuns = []) => {
    const resultList = [];
    meuns.forEach((menuItem) => {
      const { children, title, icon, reload } = menuItem;
      if (children) {
        resultList.push(
          // eslint-disable-next-line react/jsx-props-no-spreading
          <SubMenu title={<Title icon={icon} title={title} />} key={title}>
            {getMenus(children)}
          </SubMenu>,
        );
      } else {
        resultList.push(
          <MenuItem key={menuItem.path}>
            {/* this.updateSta key 会死循环  */}
            <Link to={menuItem.path} reload={reload !== false}>
              <Title icon={icon} title={title} />
            </Link>
          </MenuItem>,
        );
      }
    });
    return resultList;
  };

  // SubMenu 展开/关闭的回调
  const onOpenChange = (keys) => {
    console.log(keys);
    dispatch({
      type: 'updateState',
      payload: {
        openKeys: keys,
      },
    });
  };

  return (
    <div className="antd-menu-wrapper" styleName="menu">
      <AntMenu
        mode="inline"
        inlineCollapsed={collapsed}
        inlineIndent={20}
        openKeys={openKeys}
        selectedKeys={selectedKeys}
        onOpenChange={onOpenChange}
      >
        {getMenus(menuList)}
      </AntMenu>
    </div>
  );
};

Menu.propTypes = {
  collapsed: PropTypes.bool.isRequired,
  menuList: PropTypes.arrayOf(PropTypes.any).isRequired,
  openKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ collapsed, openKeys, selectedKeys, menuList }) => ({
  menuList,
  collapsed,
  openKeys,
  selectedKeys,
}))(Menu);
