import React from 'react';
import { Route, connect, Redirect } from 'nuomi';
import routeList from '@home/public/router';

const Content = ({ routerList, $initMenus }) => {
  return (
    // <Router hashPrefix="!">
    <div id="container">
      {routerList.map(({ path, ...rest }) => {
        return <Route key={path} path={path} {...rest} />;
      })}
      {/* 因为路由通过接口动态配置的，不控制则会导致刷新页面时跳转到首页 */}
      {$initMenus === false && Boolean(routerList.length) && <Redirect to={routerList[0].path} />}
    </div>
    // </Router>
  );
};

export default connect(({ routerList, loadings: { $initMenus } }) => ({ routerList, $initMenus }))(
  Content,
);
