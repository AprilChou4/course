import React from 'react';
import { connect } from 'nuomi';
import { Divider } from 'antd';
import NuomiTabs from '../NuomiTabs';
import HeaderTitle from '../HeaderTitle';
import CompanyStatus from '../CompanyStatus';
import CollapseButton from '../Buttons/CollapseButton';
import HelperButton from '../Buttons/HelperButton';
import MessageButton from '../Buttons/MessageButton';
import UserButton from '../Buttons/UserButton';
import CompanyService from '../CompanyService';
import './style.less';

const Header = () => {
  return (
    <div>
      <div styleName="header-top">
        <div styleName="header-left">
          <CollapseButton />
          <HeaderTitle />
          <CompanyStatus />
        </div>
        <div styleName="header-right">
          <CompanyService />
          <HelperButton />
          <MessageButton />
          <Divider type="vertical" />
          <UserButton />
        </div>
      </div>
      <div styleName="header-nav">
        <NuomiTabs />
      </div>
    </div>
  );
};

export default connect()(Header);
