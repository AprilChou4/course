// 切换企业
import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import ChooseCompany from '@components/ChooseCompany';
import './style.less';

const ChangeCompany = ({ dispatch, chooseCompanyVisible }) => {
  const switchCompany = () => {
    dispatch({
      type: 'updateState',
      payload: {
        chooseCompanyVisible: true,
      },
    });
  };
  return (
    <>
      <Button onClick={switchCompany} type="primary" styleName="m-changeBtn">
        切换企业
      </Button>
      <ChooseCompany
        chooseCompanyVisible={chooseCompanyVisible}
        dispatch={dispatch}
        loginInfo={{ a: '11' }}
        companyList={[]}
      />
    </>
  );
};

export default connect(({ chooseCompanyVisible }) => ({ chooseCompanyVisible }))(ChangeCompany);
