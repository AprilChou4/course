// 系统消息按钮
import React from 'react';
import { Iconfont } from '@components';
import { router } from 'nuomi';
import './style.less';

const style = {
  fontSize: '14px',
  marginRight: '4px',
};
const MessageButton = () => {
  const goMsg = () => {
    console.log('dadasdas');
    router.location('/message/systemsg');
  };

  return (
    <a onClick={goMsg} styleName="btn-link">
      <Iconfont type="xitongxiaoxi" style={style} />
      系统消息
    </a>
  );
};

export default MessageButton;
