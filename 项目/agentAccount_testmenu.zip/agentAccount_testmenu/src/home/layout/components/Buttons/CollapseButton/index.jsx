// 展开收缩
import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import { Iconfont } from '@components';
import './style.less';

const CollapseButton = ({ collapsed, openKeysTemp, dispatch }) => {
  const onClick = () => {
    dispatch({
      type: 'updateMenus',
      payload: {
        openKeys: !collapsed ? [] : openKeysTemp,
        collapsed: !collapsed,
      },
    });
  };
  return (
    <span id="collapsedId" styleName="button" onClick={onClick}>
      <Iconfont type={collapsed ? 'zhankai' : 'shouqi'} />
    </span>
  );
};

CollapseButton.propTypes = {
  dispatch: PropTypes.func.isRequired,
  collapsed: PropTypes.bool.isRequired,
  openKeysTemp: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect(({ collapsed, openKeysTemp }) => ({ collapsed, openKeysTemp }))(
  CollapseButton,
);
