// 客户端下载
import React from 'react';
import { Iconfont } from '@components';
import './style.less';

const ClientDown = () => {
  return (
    <a styleName="m-down" href="http://v.jss.com.cn/cszs/诺诺云代账.exe">
      <Iconfont type="kehuduanxiazai" />
      客户端下载
    </a>
  );
};

export default ClientDown;
