// 帮助中心按钮
import React from 'react';
import { Iconfont } from '@components';
import './style.less';

const HelperButton = () => {
  return (
    <a href="/help.html#/index" styleName="btn-link" rel="noopener noreferrer" target="_blank">
      <Iconfont type="bangzhuzhongxin" styleName="m-help" />
      帮助中心
    </a>
  );
};

export default HelperButton;
