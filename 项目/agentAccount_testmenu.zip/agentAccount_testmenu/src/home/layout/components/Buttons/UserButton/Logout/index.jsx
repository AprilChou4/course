// 退出
import React from 'react';
import { connect } from 'nuomi';
import Iconfont from '@components/Iconfont';

// import './style.less';

const Logout = ({ dispatch }) => {
  const exit = () => {
    dispatch({
      type: 'logout',
    });
  };
  return (
    <a onClick={exit}>
      <Iconfont code="&#xef93;" style={{ marginRight: 12 }} />
      退出
    </a>
  );
};
export default connect()(Logout);
