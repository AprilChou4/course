// 我的订单
import React from 'react';
// import './style.less';
import Iconfont from '@components/Iconfont';

const MyOrder = () => {
  const goMyOrder = () => {};
  return (
    <a onClick={goMyOrder}>
      <Iconfont code="&#xef8f;" />
      我的订单
    </a>
  );
};
export default MyOrder;
