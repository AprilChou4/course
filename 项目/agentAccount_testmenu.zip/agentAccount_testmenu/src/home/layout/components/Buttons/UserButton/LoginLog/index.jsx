// 退出
import React from 'react';
import { router } from 'nuomi';
import Iconfont from '@components/Iconfont';

const LoginLog = () => {
  const goLoginLog = () => {
    router.location('/loginLog');
  };

  return (
    <a onClick={goLoginLog}>
      <Iconfont code="&#xef8a;" />
      登录日志
    </a>
  );
};
export default LoginLog;
