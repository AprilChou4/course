// 版本检测
import React, { useState } from 'react';
import { Modal, Button } from 'antd';
import Iconfont from '@components/Iconfont';

import './style.less';

const VersionDetection = () => {
  const [visible, setVisible] = useState(false);
  const [currVersion, setVersion] = useState('');
  const [isNew, setIsNew] = useState('1');
  const detection = () => {
    setVisible(true);
    checkVersion((data) => {
      // isnew==='1' 云代账不是最新版本！
      const { isnew, version } = JSON.parse(data);
      setVersion(version);
      setIsNew(isnew);
    });
  };
  const onCancel = () => {
    setVisible(false);
  };
  const onOk = () => {
    upgrade();
    return true;
  };
  return (
    <>
      <a onClick={detection}>
        <Iconfont code="&#xef9a;" />
        版本检测
      </a>
      <Modal
        visible={visible}
        title={null}
        centered
        width={280}
        onCancel={onCancel}
        footer={
          isNew === '1' ? (
            <>
              <Button onClick={onCancel}>暂不更新</Button>
              <Button type="primary" onClick={onOk}>
                立即更新
              </Button>
            </>
          ) : (
            <Button onClick={onCancel}>取消</Button>
          )
        }
        styleName="m-updateModal"
      >
        {isNew === '1' ? (
          <div>
            <div>
              <div styleName="m-img" />
              <h2>发现新版本</h2>
              <div>
                当前版本：{currVersion}
                <br />
                您的云代账不是最新版本！
              </div>
            </div>
          </div>
        ) : (
          <div>
            <h3>
              <Iconfont type="logo" styleName="m-logoIcon" />
            </h3>
            <h2>当前版本：{currVersion}</h2>
            <div>当前已是最新版本！</div>
          </div>
        )}
      </Modal>
    </>
  );
};
export default VersionDetection;
