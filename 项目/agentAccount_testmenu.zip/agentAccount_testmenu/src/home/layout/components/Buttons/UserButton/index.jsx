import React, { useState } from 'react';
import { connect } from 'nuomi';
import { Menu, Dropdown } from 'antd';
// import { util } from 'nuijs';
import { Iconfont } from '@components';
import ClientDown from './ClientDown';
import MyOrder from './MyOrder';
import ForgetPassword from './ForgetPassword';
import ChangeCompany from './ChangeCompany';
import VersionDetection from './VersionDetection';
import LoginLog from './LoginLog';
import Logout from './Logout';
import Style from './style.less';
// import entlist from './entList/index';

const UserButton = ({ user }) => {
  console.log(user, '---------realName');
  const { realName, company } = user;
  const { companyName } = company || {};
  const menu = (
    <>
      <div styleName="m-companyInfo" className="f-clearfix">
        <Iconfont code="&#xef96;" styleName="m-icon" />
        <div styleName="m-detail">
          <h3>{realName}</h3>
          <em>{companyName}</em>
        </div>
        <ChangeCompany />
      </div>
      <Menu>
        <Menu.Item>
          <ClientDown />
        </Menu.Item>
        <Menu.Item>
          <MyOrder />
        </Menu.Item>
        <Menu.Divider />
        <Menu.Item>
          <ForgetPassword />
        </Menu.Item>
        <Menu.Item>
          <LoginLog />
        </Menu.Item>
        {typeof ExternService === 'object' && (
          <Menu.Item>
            <VersionDetection />
          </Menu.Item>
        )}
        <Menu.Item>
          <Logout />
        </Menu.Item>
      </Menu>
    </>
  );
  return (
    <Dropdown overlay={menu} trigger={['click']} overlayClassName={Style['m-userDropdown']}>
      <a styleName="m-user" onClick={(e) => e.preventDefault()}>
        <Iconfont name="user" code="&#xef96;" styleName="m-userIcon" />
        <Iconfont name="xialafuben" code="&#xef90;" styleName="m-arrow" />
      </a>
    </Dropdown>
  );
};

export default connect(({ user }) => ({
  user,
}))(UserButton);
