// 智能客服按钮
import React from 'react';
import { Button } from 'antd';
import { Iconfont } from '@components';

const style = {
  fontSize: '13px',
  marginRight: '4px',
};
const SmartButton = () => {
  return (
    <a
      href="https://robot.jss.com.cn/pc.do?newKey=kwy6d386c7566304a685742516c67636e6651755a454b773d3d"
      className="btn-link"
      rel="noopener noreferrer"
      target="_blank"
    >
      <Button type="primary" size="small">
        <Iconfont type="zhinengkefu" style={style} />
        智能客服
      </Button>
    </a>
  );
};

export default SmartButton;
