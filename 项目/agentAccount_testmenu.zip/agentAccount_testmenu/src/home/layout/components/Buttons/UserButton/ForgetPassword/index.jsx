// 修改密码
import React from 'react';
import { util } from '@utils';
import Iconfont from '@components/Iconfont';

// import './style.less';

const ForgetPassword = () => {
  const forget = () => {
    if (typeof ExternService === 'object') {
      // forget();
    } else {
      util.location('http://u.jss.com.cn/usercenter/user/loadAccountMagPage.do', '_blank');
    }
  };
  return (
    <a onClick={forget}>
      <Iconfont code="&#xef95;" />
      修改密码
    </a>
  );
};
export default ForgetPassword;
