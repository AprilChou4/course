import React, { useRef, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { Tabs as AntdTabs, Dropdown, Menu } from 'antd';
import { connect, router } from 'nuomi';
import { util } from 'nuijs';
import PropTypes from 'prop-types';
import { Iconfont } from '@components';
// import { SuperModal } from '@/modal';
import style from './style.less';

const { TabPane } = AntdTabs;
const MINWIDTH = 38;
let $tabs;
let $scroll;
let $inner;
let modal = null;
const closeModal = () => {
  util.storeForUser('CLOSE_MORE_TABS_TIPS', '1');
  modal = null;
};

const Tabs = ({ activeKey, panes, dispatch }) => {
  const tabsRef = useRef();

  const onTabClick = (path) => {
    if (path !== activeKey) {
      router.location(path);
    }
  };

  const onEdit = (path, action) => {
    if (action === 'remove') {
      dispatch({ type: 'remove', payload: path });
    }
  };

  const onChange = () => {};

  const menuClick = ({ key }, { path }) => {
    switch (key) {
      // 关闭当前
      case '2':
        dispatch({ type: 'remove', payload: path });
        break;
      // 关闭其它
      case '3':
        dispatch({ type: 'removeOther', payload: path });
        break;
      // 全部关闭
      case '4':
        dispatch({ type: 'removeAll' });
        break;
      // 刷新
      default:
        router.location(path, true);
    }
  };

  const countTabWidth = (showTips) => {
    if (!$tabs) {
      return;
    }
    const width = $scroll.width();
    const innerWidth = $inner.width();
    let diff = innerWidth - width;
    const elems = [];
    $inner.find('.ant-dropdown-trigger').each((i, elem) => {
      const $elem = $(elem);
      const eleWidth = $elem.width() + 1;
      let maxWidth = parseFloat(elem.style.maxWidth || 0);
      if (!maxWidth) {
        $elem.css('max-width', (maxWidth = eleWidth));
      }
      elems.push({
        maxWidth,
        width: eleWidth,
        $elem,
      });
    });

    // 当容器不足以展示全部页签时
    if (diff > 0) {
      let temp = [];
      elems.forEach((v) => {
        // 检测页签是否可以再减小
        if (v.width > MINWIDTH) {
          temp.push(v);
        }
      });
      const count = () => {
        const size = temp.length;
        if (diff > 0 && size) {
          // 将差值均分，分配到可以变小的页签上
          const splitWidth = Math.ceil(diff / size);
          temp = temp.filter((v) => {
            // 如果页签宽度减去差值小于最小值，直接设置为最小值，并且更新差值
            if (v.width - splitWidth <= MINWIDTH) {
              diff -= v.width - MINWIDTH;
              v.$elem.width(MINWIDTH);
              return false;
            }
            return true;
          });
          // 剩余的页签有不满足均分的（宽度-均值<=24）,递归处理
          if (size !== temp.length) {
            count();
          }
          // 剩余的页签全部满足均分，则减去均值
          else {
            temp.forEach((v) => {
              v.$elem.width(v.width - splitWidth);
            });
          }
        }
      };
      count();

      // 当全部菜单只有一个字时，给出提示
      if (
        showTips &&
        !util.storeForUser('CLOSE_MORE_TABS_TIPS') &&
        !modal &&
        $inner.width() > $scroll.width()
      ) {
        // modal = SuperModal({
        //   content: (
        //     <p style={{ padding: 20, textAlign: 'center' }}>
        //       当前页签开启过多，将会影响页签显示操作
        //     </p>
        //   ),
        //   cancelText: '关闭',
        //   okText: '知道了',
        //   onOk: closeModal,
        //   onCancel: closeModal,
        // });
      }
    } else {
      diff = Math.abs(diff);
      const temp = [];
      elems.forEach((v) => {
        if (v.width < v.maxWidth) {
          temp.push(v);
        }
      });
      const size = temp.length;
      if (size) {
        const splitWidth = Math.ceil(diff / size);
        temp.forEach((v) => {
          v.$elem.width(v.width + splitWidth);
        });
      }
    }
  };

  useEffect(() => {
    /* eslint-disable react/no-find-dom-node */
    $tabs = $(ReactDOM.findDOMNode(tabsRef.current));
    $scroll = $tabs.find('.ant-tabs-nav-scroll');
    $inner = $scroll.children('.ant-tabs-nav').children('div');
    const resize = () => {
      countTabWidth();
    };
    window.addEventListener('resize', resize);
    return () => {
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    countTabWidth(true);
  }, [panes]);

  return (
    <AntdTabs
      className={style.tabs}
      hideAdd
      ref={tabsRef}
      type="editable-card"
      activeKey={activeKey}
      onTabClick={onTabClick}
      onEdit={onEdit}
      onChange={onChange}
    >
      {panes.map((pane) => {
        return (
          <TabPane
            tab={
              <>
                {pane.title === '首页' ? (
                  <span title={pane.title}>{pane.title}</span>
                ) : (
                  <Dropdown
                    overlay={
                      <Menu onClick={(data) => menuClick(data, pane)}>
                        <Menu.Item key="1">刷新</Menu.Item>
                        {pane.path !== '/' ? <Menu.Item key="2">关闭当前</Menu.Item> : ''}
                        <Menu.Item key="3">关闭其它</Menu.Item>
                        <Menu.Item key="4">全部关闭</Menu.Item>
                      </Menu>
                    }
                    key={pane.path}
                    trigger={['contextMenu']}
                  >
                    <span title={pane.title} style={{ marginRight: 8 }}>
                      {pane.title}
                    </span>
                  </Dropdown>
                )}

                {activeKey === pane.path && pane.title !== '初始化' && (
                  <Iconfont type="yeqianshuaxin" onClick={() => router.reload()} />
                )}
                {pane.closable !== false && (
                  <Iconfont
                    type="yeqianguanbi"
                    onClick={(e) => {
                      e.stopPropagation();
                      menuClick({ key: '2' }, { path: pane.path });
                    }}
                  />
                )}
              </>
            }
            key={pane.path}
            // closable={pane.closable}
            closable={false}
          />
        );
      })}
    </AntdTabs>
  );
};

Tabs.propTypes = {
  dispatch: PropTypes.func.isRequired,
  activeKey: PropTypes.string.isRequired,
  panes: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect((state) => ({ ...state }))(Tabs);
