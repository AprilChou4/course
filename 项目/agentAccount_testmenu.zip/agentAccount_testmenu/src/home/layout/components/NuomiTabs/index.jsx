import React from 'react';
import { Nuomi, router } from 'nuomi';
import Tabs from './Tabs';

const props = {
  id: 'tabs',
  state: {
    activeKey: '/home',
    panes: [
      {
        path: '/home',
        title: '首页',
        closable: false,
      },
    ],
  },
  effects: {
    removeOther(activePath) {
      const { panes } = this.getState();
      this.dispatch({
        type: 'updateState',
        payload: {
          panes: panes.filter(({ path }, i) => i === 0 || path === activePath),
        },
      });
      router.location(activePath);
    },
    // onInitSubject({ title }) {
    //   const { panes } = this.getState();
    //   const panesList = [{ ...panes[0], title }];
    //   this.dispatch({
    //     type: 'updateState',
    //     payload: {
    //       panes: panesList,
    //     },
    //   });
    // },
    removeAll() {
      const { panes } = this.getState();
      this.dispatch({
        type: 'updateState',
        payload: {
          panes: [panes[0]],
        },
      });
      router.location(panes[0].path);
    },
    remove(removePath) {
      const removePaths = [].concat(removePath);
      const { panes, activeKey } = this.getState();
      const newPanes = panes.filter(({ path }) => !removePaths.includes(path));
      this.dispatch({
        type: 'updateState',
        payload: {
          panes: newPanes,
        },
      });
      if (removePaths.includes(activeKey)) {
        router.location(newPanes[newPanes.length - 1].path);
      }
    },
    add({ pathname, title }) {
      // debugger;
      const { panes } = this.getState();
      let newPanes = panes;
      // 不存在新增，存在直接展示
      if (!panes.find(({ path }) => path === pathname)) {
        newPanes = newPanes.concat({ path: pathname, title });
      }
      this.dispatch({
        type: 'updateState',
        payload: {
          panes: newPanes,
          activeKey: pathname,
        },
      });
    },
    insert({ pathname, title }) {
      // debugger;
      const { panes, activeKey } = this.getState();
      if (pathname !== activeKey) {
        const index = panes.findIndex(({ path }) => path === activeKey);
        this.dispatch({
          type: 'updateState',
          payload: {
            panes: [...panes.slice(0, index), { path: pathname, title }, ...panes.slice(index)],
            activeKey: pathname,
          },
        });
      }
    },
  },
  render() {
    return <Tabs />;
  },
};

export default () => {
  return <Nuomi {...props} />;
};
