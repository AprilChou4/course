import React from 'react';
import { connect } from 'nuomi';
import Logo from '../Logo';
import Menu from '../Menu';
import './style.less';

const Side = ({ collapsed }) => {
  return (
    <div styleName={`sidebar${collapsed ? ' collapsed' : ''}`}>
      <Logo />
      <Menu />
    </div>
  );
};

export default connect(({ collapsed }) => ({
  collapsed,
}))(Side);
