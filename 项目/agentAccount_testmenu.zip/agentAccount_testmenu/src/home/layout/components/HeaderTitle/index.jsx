import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import './style.less';

const HeaderTitle = ({ user }) => {
  const { company } = user;
  const { companyName } = company || {};
  return <span styleName="m-title">{companyName}</span>;
};

HeaderTitle.defaultProps = {
  user: {},
};

HeaderTitle.propTypes = {
  user: PropTypes.objectOf(PropTypes.any),
};

export default connect(({ user }) => ({ user }))(HeaderTitle);
