import React from 'react';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/es/locale/zh_CN';
import { connect } from 'nuomi';
import Side from '../Side';
import Main from '../Main';
import Loading, { LoadData } from '../Loading';

const Layout = (props) => {
  const {
    children,
    loadings: { $initData, loading },
  } = props;

  return (
    <ConfigProvider locale={zhCN}>
      <>
        {$initData === true && <Loading />}
        {!!loading && <LoadData loading={loading} />}
        <Main />
        <Side />
      </>
    </ConfigProvider>
  );
};

export default connect(({ loadings }) => ({ loadings }))(Layout);
