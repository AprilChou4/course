import React from 'react';
import { router, connect } from 'nuomi';
// import Icon from '@/Icon';
import logo from './logo.png';
import './style.less';

const Logo = ({ versionType }) => {
  const onClick = () => {
    router.location('/');
  };
  return <div styleName="logo" onClick={onClick} />;
};

export default connect(({ versionType }) => ({ versionType }))(Logo);
