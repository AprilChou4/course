// import { Component } from 'react';

export { default as createMenus } from './createMenus';

export default {};
