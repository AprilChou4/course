import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Route, HashRouter } from 'react-router-dom';
import Footer from '../Footer';

import Top from './top';

import Contents from './Content';

class Content extends Component {
  render() {
    // search頁面不需要50的tab距离
    const height = window.location.hash.indexOf('search') > -1 ? 0 : 50;
    return (
      <div
        className="docs-main-body"
        style={{
          height: `calc(100% - 166px)`,
          position: 'relative',
        }}
      >
        <Top />
        <HashRouter>
          <div
            style={{
              height: `calc(100% - ${height}px)`,
              overflow: 'auto',
            }}
            ref={(e) => {
              this.scrollDiv = e;
            }}
          >
            <Route path="/index" component={Contents} />
            <Route path="/list/core/:id" component={Contents} />
            <Route path="/list/common/:id" component={Contents} />
            <Route path="/list/guide/:id" component={Contents} />
            <Route path="/details/:id" component={Contents} />
            <Route path="/video/index" component={Contents} />
            <Route path="/download/index" component={Contents} />
            <Route path="/search/:id" component={Contents} />
            <Footer />
          </div>
        </HashRouter>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  topshow: state.topshow,
});
const mapDispatchToProps = (dispatch) => {
  return {
    SetTopShow: (account) => {
      dispatch({
        type: 'SET_TOPSHOW',
        data: account,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Content);
