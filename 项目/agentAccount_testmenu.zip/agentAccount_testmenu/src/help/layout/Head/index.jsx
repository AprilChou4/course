import React, { Component } from 'react';
import { Popover, Icon, Button, Input } from 'antd';
import { util } from 'nuijs';
import { connect } from 'react-redux';
import '../../public/function.less';
import './index.less';
import Iconfont from '@components/Iconfont';
import dataList from '../../public/list';
import AutoCop from './autoCop';

class Header extends Component {
  logout() {
    util.logout();
  }

  back = () => {
    window.location.href = window.localStorage.getItem('REFERRER') || '/platform.html';
  };

  render() {
    const { Search } = Input;
    const { realName, versionType, topshow } = this.props;
    const _dataList = dataList(versionType);

    const { searchList, bagNavigation } = _dataList;

    const content = (
      <div className="w80 ">
        {typeof ExternService !== 'object' && (
          <div>
            <a href="//u.jss.com.cn" target="_blank" className="quit">
              修改密码
            </a>
          </div>
        )}
        <div className="e-mt5">
          <a className="quit" onClick={this.logout}>
            退出
          </a>
        </div>
      </div>
    );
    const _style = {};
    // console.log('topshow', topshow)
    if (!topshow.topshow) {
      // _style.display = 'none';
      _style.height = '0px';
    }
    return (
      <>
        <div className="header f-clearfix">
          <div className="m-head">
            <div className="utop-left f-fl">
              <a className="help-head-logo">
                <Iconfont type="yundaizhang" />
                <span>诺诺云代账</span>
              </a>
              <a className="help-head-logo" href="#/index">
                <em>帮助中心</em>
              </a>
            </div>
            {typeof ExternService !== 'object' && (
              <div className="utop-right f-fr" style={{ marginTop: '13px' }}>
                <a href="https://www.jss.com.cn" target="_blank">
                  诺诺服务
                </a>
                <span className="e-ml15 e-mr15">|</span>
                <a href="https://www.axnsc.com" target="_blank">
                  诺诺商城
                </a>
                <span className="e-ml15 e-mr15">|</span>
                <Popover placement="bottomRight" content={content} trigger="click">
                  <a className="font4">
                    <Iconfont style={{ paddingRight: '10px' }} type="user" />
                    {realName}
                    <Icon style={{ paddingLeft: '5px' }} type="down" />
                  </a>
                </Popover>
              </div>
            )}
          </div>
        </div>
        <div className="docs-search" style={_style}>
          <div className="docs-search-bj" />
          <div className="docs-search-div">
            <AutoCop searchList={searchList} />
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    versionType: state.account.versionType,
    realName: state.account.realName,
    dhselecteds: state.dhselecteds,
    topshow: state.topshow,
  };
};
export default connect(mapStateToProps)(Header);
