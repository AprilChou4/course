import React, { Component } from 'react';
import { Card } from 'antd';
import { connect } from 'react-redux';
import { request } from 'nuijs';
import moment from 'moment';
import Iconfont from '@components/Iconfont';
import Modal from '../public/component/ModalVideo/index';
import style from './style.less';

class Indexs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      modalUrl: {
        videoUrl: '',
        msgUrl: '',
        videoId: '',
      },
      list: [],
    };
  }

  componentDidMount() {
    this.goList();
  }

  onClick = (data) => {
    const { videoPath, videoThumbnailPath, videoId } = data;
    this.setState({
      visible: true,
      modalUrl: {
        videoUrl: videoPath,
        msgUrl: videoThumbnailPath,
        videoId,
      },
    });
  };

  onCancel = () => {
    this.setState({
      visible: false,
    });
  };

  goList = () => {
    const { match, location } = this.props;
    request.post(
      //   'helpcenter/menu/getVideolList',
      'instead/v2/user/helpercenter/getVideoList',
      {
        type: 2, // 1记账   2代账
      },
      {
        200: (res) => {
          const setData = {
            list: res.data,
          };
          if (location.pathname !== match.url) {
            const _location = location.pathname.split('/');
            const id = _location[_location.length - 1];
            let videoUrl = '';
            let msgUrl = '';
            let record_id = '';
            res.data.map((item) => {
              item.videoList &&
                item.videoList.forEach((val) => {
                  if (val.record_id === id) {
                    videoUrl = val.video_path;
                    msgUrl = val.video_thumbnail_path;
                    record_id = val.record_id;
                  }
                });
            });
            setData.modalUrl = {
              videoUrl,
              msgUrl,
              record_id,
            };
            setData.visible = true;
          }
          this.setState(setData);
        },
      },
      '正在加载数据',
    );
  };

  renderList = () => {
    const { list } = this.state;
    const videoListFilter = list.filter((item) => item.videoList);
    return videoListFilter.map(({ groupName, videoList }, index) => (
      <React.Fragment key={index}>
        <h3 className="video-group-name">{groupName}</h3>
        {videoList &&
          videoList.map((val, key) => {
            const imgUrl = val.videoThumbnailPath || '/static/images/videoimg.jpg';
            const myTitle =
              val.videoName.length > 25 ? `${val.videoName.substring(0, 25)}...` : val.name;
            return (
              <Card key={key} bordered={false}>
                <div className="videoList-imgp" onClick={() => this.onClick(val)}>
                  <img src={imgUrl} alt="图片" />
                  <a>
                    <Iconfont className="i-point" code="&#xeb2d;" />
                    <span />
                  </a>
                </div>
                <p className="videoList-name">
                  <span title={myTitle}>{myTitle}</span>
                  <i>{val.addDate ? moment(val.addDate).format('YYYY-MM-DD') : ''}</i>
                </p>
              </Card>
            );
          })}
      </React.Fragment>
    ));
  };

  render() {
    const { visible, modalUrl } = this.state;
    return (
      <div
        className="docs-main"
        style={{
          background: '#F2F2F2',
          width: '1240px',
          margin: '0 auto',
          paddingTop: '28px',
          overflow: 'hidden',
        }}
      >
        <div className={style['ui-docs-videoList']}>
          <div className="ui-media-div">
            {this.renderList()}
            <Modal visible={visible} modalUrl={modalUrl} onCancel={this.onCancel} />
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  dhselecteds: state.dhselecteds,
});
const mapDispatchToProps = (dispatch) => {
  return {
    changeMenus: (menus) => {
      dispatch({
        type: 'SET_SELECTED',
        selected: menus,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Indexs);
