import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import zhCN from 'antd/es/locale/zh_CN';
import { ConfigProvider } from 'antd';
import trackEvent from 'trackEvent';
import Layout from './layout';
import store from './public/store';
import './public/config'; // 待补充

Component.prototype.trackEvent = trackEvent;

ReactDOM.render(
  <ConfigProvider locale={zhCN}>
    <Provider store={store}>
      <Layout />
    </Provider>
  </ConfigProvider>,
  document.getElementById('app'),
);
