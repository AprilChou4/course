import React, { Component } from 'react';
import { connect } from 'react-redux';
import Iconfont from '@components/Iconfont';
import { request } from 'nuijs';

import { Menu, Modal } from 'antd';
import { Link } from 'react-router-dom';
import './style/index.less';

import Rights from './list';
import Details from './details';
import dataList from '../public/list';

const { SubMenu } = Menu;
const { Item } = Menu;

class Doc extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
      listUrl: '',
      classify: '',
      selectedKeys: [],
      openKeys: [],
      rightList: {},
      detailsList: {},
    };
  }

  componentDidMount() {
    this.goList();
  }

  componentWillUnmount() {}

  getOnOpenKeys = (data) => {
    const { openKeys } = this.state;
    const ids = data.split('-');
    const myOpenKeys = openKeys;
    let openIds = '';
    if (ids.length > 1) {
      ids.map((val, key) => {
        openIds = key === 0 ? val : `${openIds}-${val}`;
        if (key > 0 && key < ids.length - 1) {
          if (myOpenKeys.indexOf(openIds) === -1) {
            myOpenKeys.push(openIds);
          }
        }
        return myOpenKeys;
      });
    }
    return myOpenKeys;
  };

  last = (data, type) => {
    if (data.child.length) {
      return type ? this.last(data.child[0], `${type}-${data.menuId}`) : this.last(data.child[0]);
    }
    return type ? `${type}-${data.menuId}` : data.menuId;
  };

  goList = () => {
    const { match } = this.props;
    const { url, params } = match;
    const urlId = params.id.split('-');
    // const gourls = url.split('/');
    request.postJSON(
      // 'helpcenter/menu/getMenuTree.do',
      'instead/v2/user/helpercenter/getMenuList.do',
      {
        type: 2, // 1记账   2代账
        classify: urlId[0], // 1=新手引导页面
      },
      {
        200: (res) => {
          if (res.data.length <= 0) {
            return false;
          }
          let id = '';
          if (urlId.length > 1) {
            id = urlId[urlId.length - 1];
          } else {
            id = this.last(res.data[0]);
          }
          this.setState(
            {
              list: res.data,
              classify: urlId[0],
            },
            () => {
              this.gorightUrl(id);
              // if(gourls[1] === 'list'){
              //     this.gorightUrl( id );
              // }else{
              //     this.goDetailsUrl( params.id );
              // }
            },
          );
        },
      },
      '正在加载数据',
    );
  };

  gorightUrl = (id) => {
    // 加载列表
    const that = this;
    const { match } = this.props;
    const { url, params } = match;
    const { list, classify } = this.state;
    const urlId = params.id.split('-');
    let newSelectedKeys = [];
    if (urlId.length > 1) {
      newSelectedKeys = [params.id];
    } else {
      newSelectedKeys = [this.last(list[0], classify)];
    }
    const newOnOpenKeys = this.getOnOpenKeys(newSelectedKeys[0]);
    this.setState(
      {
        listUrl: url,
        selectedKeys: newSelectedKeys,
        openKeys: newOnOpenKeys,
      },
      () => {
        request.postJSON(
          // 'helpcenter/menu/getMenuDetailList',
          'instead/v2/user/helpercenter/getDetailList.do',
          {
            type: 2, // 1记账   2代账
            classify, // 1=新手引导页面
            menuId: id,
          },
          {
            200: (res) => {
              that.setState({
                rightList: res.data,
              });
              const { content } = res.data;
              if (content.length === 1) {
                this.goDetailsUrl(`/${content[0].detailId}`);
              }
            },
          },
          '正在加载数据',
        );
      },
    );
  };

  childMenu = (data, classify) => {
    // 下级
    const that = this;
    const { match } = this.props;
    const { path } = match;
    const newPath = path.replace(':id', '');
    return data.map((val) => {
      if (val.child.length) {
        return (
          <SubMenu
            key={`${classify}-${val.menuId}`}
            title={
              val.pid === 0 ? (
                <span>
                  <Iconfont style={{ padding: '0 7px 0 0' }} type="caidanicon" />
                  {val.menuName}
                </span>
              ) : (
                <span>{val.menuName}</span>
              )
            }
          >
            {that.childMenu(val.child, `${classify}-${val.menuId}`)}
          </SubMenu>
        );
      }
      return (
        <Item key={`${classify}-${val.menuId}`}>
          {val.pid === 0 ? (
            <Link to={`${newPath + classify}-${val.menuId}`}>
              <Iconfont style={{ padding: '0 7px 0 0' }} type="caidanicon" />
              {val.menuName}
            </Link>
          ) : (
            <Link to={`${newPath + classify}-${val.menuId}`}>{val.menuName}</Link>
          )}
        </Item>
      );
    });
  };

  onSelect = (data) => {
    this.setState(
      {
        selectedKeys: data.selectedKeys,
      },
      () => {
        const idArr = data.selectedKeys[0].split('-');
        this.gorightUrl(idArr[idArr.length - 1]);
      },
    );
  };

  onOpenChange = (data) => {
    this.setState({
      openKeys: data,
    });
  };

  goDetailsUrl = (id) => {
    const { selectedKeys, versionType, location } = this.props;
    // 详情接口
    const { pathname } = location;
    const detailsId = id.split('/');
    request.post(
      // 'helpcenter/menu/getMenuContentDetail',
      'instead/v2/user/helpercenter/getDetail.do',
      {
        detailId: detailsId[1],
      },
      {
        200: (res) => {
          this.setState({
            detailsList: res.data,
            listUrl: pathname,
          });
        },
        300: (res) => {
          Modal.info({
            title: '温馨提示',
            content: (
              <div>
                <p>{res.message}</p>
              </div>
            ),
            okText: '去看看',
            onOk() {
              const { bagNavigation } = dataList(versionType);
              const currentTab = bagNavigation.find(
                (item) => selectedKeys.indexOf(item.url) !== -1,
              );
              window.location.href = `#${currentTab ? currentTab.url : '#/index'}`;
            },
          });
        },
      },
      '正在加载数据',
    );
  };

  render() {
    const { list, listUrl, classify, selectedKeys, openKeys, rightList, detailsList } = this.state;
    const { location, match, topshow, history } = this.props;
    const { pathname } = location;
    const { url, params } = match;
    const detailsId = pathname.replace(url, '');
    if (listUrl !== url && listUrl !== '' && !selectedKeys.includes(params.id)) {
      // 列表
      const idsArr = params.id.split('-');
      const id = idsArr.length === 1 ? this.last(list[0]) : idsArr[idsArr.length - 1];
      setTimeout(() => {
        this.gorightUrl(id);
      });
    }
    if (
      pathname !== listUrl &&
      pathname !== url &&
      pathname.indexOf(url) !== -1 &&
      list.length > 0 &&
      rightList.content &&
      rightList.content.length > 0
    ) {
      // 详情
      this.goDetailsUrl(detailsId);
    }
    if (
      pathname !== listUrl &&
      pathname.indexOf(url) !== -1 &&
      list.length > 0 &&
      rightList.content &&
      rightList.content.length > 0
    ) {
      setTimeout(() => {
        this.setState({
          listUrl: pathname,
        });
      });
    }
    const mainStyle = {
      background: '#FFFFFF',
      width: '1200px',
      margin: '12px auto',
      justifyContent: 'flex-start',
    };
    if (topshow.topshow) {
      mainStyle.top = '225px';
    } else {
      mainStyle.top = '105px';
    }
    return (
      <>
        <div className="docs-main" style={mainStyle}>
          <div className="docs-main-left">
            <Menu
              mode="inline"
              selectedKeys={selectedKeys}
              openKeys={openKeys}
              onOpenChange={this.onOpenChange}
              className="docs-main-left-ul"
              onSelect={this.onSelect}
              inlineIndent={20}
            >
              {this.childMenu(list, classify)}
            </Menu>
          </div>
          {detailsId || (rightList && rightList.content && rightList.content.length === 1) ? (
            <Details detailsList={detailsList} url={url} history={history} />
          ) : (
            <Rights rightList={rightList} id={selectedKeys} match={match} />
          )}
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  topshow: state.topshow,
  selectedKeys: state.dhselecteds.selectedKeys,
  versionType: state.account.versionType,
});
const mapDispatchToProps = (dispatch) => {
  return {
    SetTopShow: (account) => {
      dispatch({
        type: 'SET_TOPSHOW',
        data: account,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Doc);
