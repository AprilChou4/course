import React from 'react';
import { Modal } from 'antd';
import Advise from '@pages/message/systemsg/components/Advise';

const AdviseModal = ({ visible, close }) => {
  return (
    <Modal title="建议反馈" footer={null} centered width={620} visible={visible} onCancel={close}>
      <Advise adviseType={2} close={close} />
    </Modal>
  );
};
export default AdviseModal;
