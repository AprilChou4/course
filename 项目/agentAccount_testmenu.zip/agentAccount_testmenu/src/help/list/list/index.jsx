import React, { Component } from 'react';
import Iconfont from '@components/Iconfont';

class Doc extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  setAid = (val) => {
    const _data = JSON.parse(window.sessionStorage.getItem('listId') || '[]'); // JSON.stringify
    if (!_data.includes(val.id)) {
      _data.push(val.id);
    }
    window.sessionStorage.setItem('listId', JSON.stringify(_data));
  };

  render() {
    const listId = JSON.parse(window.sessionStorage.getItem('listId') || '[]');
    const { rightList, id, match } = this.props;
    const { menuName, content } = rightList;
    const { path } = match;
    const newPath = path.replace(':id', '');
    return (
      <>
        <div className="docs-main-right">
          {menuName && (
            <div className="main-top">
              <p>
                {menuName.map((val, key) => {
                  if (key === 0) {
                    return <a key={key}>{val}</a>;
                  }
                  if (key < menuName.length - 1) {
                    return (
                      <a key={key}>
                        <span>/</span>
                        {val}
                      </a>
                    );
                  }
                  return (
                    <a key={key} className="main-top-a-current">
                      <span>/</span>
                      {val}
                    </a>
                  );
                })}
              </p>
            </div>
          )}
          <div className="main-list">
            {content && content.length > 0
              ? content.map((val, key) => {
                  return (
                    <div key={key} className="main-list-div">
                      <a
                        className={
                          listId.includes(val.detailId) ? 'main-list-div-a on' : 'main-list-div-a'
                        }
                        onClick={() => this.setAid(val)}
                        href={`#${newPath}${id}/${val.detailId}`}
                      >
                        <h5 title={val.title}>
                          {val.title.length > 25 ? `${val.title.substring(0, 25)}...` : val.title}
                          {val.hasVideo === 1 && (
                            <Iconfont className="i-point" name="shipinbiaoshi" code="&#xeb30;" />
                          )}
                        </h5>
                        <div dangerouslySetInnerHTML={{ __html: val.content }} />
                      </a>
                    </div>
                  );
                })
              : content && '列表为空'}
          </div>
        </div>
      </>
    );
  }
}
export default Doc;
