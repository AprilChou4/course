/**
 * @func 组件基础配置
 */
import React from 'react';
import { request, layer, datagrid, util, search, uploader } from 'nuijs';
// 待补充
// import message from 'message';
import { Modal, message } from 'antd';
import clientAPI from '@public/script/clientAPI';
// import clientAPI from 'clientAPI'; // 待补充
// 待补充
// import './events';
// import './util';
// import './number2';
// import 'nuonuo-libs/script/plugins/select';
// import base64 from 'nuonuo-libs/script/polyfill/base64';
import { Base64 } from 'js-base64';

const accountToken = util.getParam('id', `/${location.search}`);

localStorage.setItem('hasShowUpdate', '0');

request.config({
  name: 'status',
  value: '200',
  ext: '.do',
  data: {
    accountToken,
  },
  status: {
    300: (res) => {
      message.error(res.message);
    },
    401: (res) => {
      message.error(res.message);
    },
    other: (res) => {
      message.error(res.message);
    },
  },
  preurl(url) {
    if (/^(https?:)?\/\//.test(url)) {
      return '';
    }
    if (/^(accinfo|instead|clouduser|helpcenter)/.test(url)) {
      return '/';
    }
    return '/jz/';
  },
  intercept(res) {
    if (res) {
      alert(111);
      // 登录拦截
      if ((res.status === 308 || res.status === 312) && this.url.indexOf('sso/login') === -1) {
        if (typeof ExternService === 'object') {
          clientAPI.resScreen();
          location.replace('/client.html');
        } else {
          const referer = Base64.encode(location.href);
          location.replace(`${basePath}?referer=${referer}`);
        }
        return false;
      }
      // 未选择账套 和 账套正在备份
      if (res.status === 309 || res.status === 311) {
        const versionType = localStorage.getItem('versionType');
        // 代账
        if (versionType == '1') {
          location.replace(`${basePath}index.html`);
        } else if (versionType == '0') {
          location.replace(`${basePath}accounts.html`);
        } else if (typeof ExternService === 'object') {
          clientAPI.resScreen();
          location.replace('/client.html');
        } else {
          location.replace(basePath);
        }
        return false;
      }
      // 314在迁移中 315 已经迁移
      if (res.status === 314 || res.status === 315) {
        if (res.status === 314) {
          if (localStorage.getItem('hasShowUpdate') === '1') return;

          Modal.info({
            title: '账套升级中，请稍后访问！',
            okText: '知道了',
            zIndex: 9999999999,
            iconType: 'exclamation-circle',
            className: 'custom-modal-info',
            onOk() {
              const versionType = localStorage.getItem('versionType');

              if (versionType == '1') {
                // location.replace(`${basePath}cloud/index.html#!/account`);
                location.replace(`${basePath}index.html#!/account`);
              } else if (versionType == '0') {
                location.replace(`${basePath}accounts.html`);
              } else {
                // location.replace(`${basePath}cloud/index.html#!/account`);
                location.replace(`${basePath}index.html#!/account`);
              }
              localStorage.setItem('hasShowUpdate', '0');
            },
          });

          localStorage.setItem('hasShowUpdate', '1');
        } else {
          location.href = `${basePath}accounting.html?id=${accountToken}`;
        }
      }
      // 需要完善信息
      else if (res.status === 310) {
        location.replace(basePath);
        return false;
      }
    }
  },
});

// const $app = $('#app');
// const $body = $('body');

// layer.config({
//   width: 360,
//   align: 'center',
//   button: [
//     {
//       id: 'cancel',
//     },
//     {
//       id: 'confirm',
//       name: 'normal',
//     },
//   ],
//   container() {
//     if (this.id === 'loading' && $app.length) {
//       return $app;
//     }
//     return $body;
//   },
//   onHideBefore() {
//     if (this.id === 'loading') {
//       return false;
//     }
//   },
// });

// datagrid.config({
//   isInitCheckradio: false,
//   option: {
//     showtitle: true,
//     nowrap: true,
//     minWidth: 40,
//   },
//   getData(e, elem) {
//     const $row = elem.closest('.table-row');
//     return {
//       ...$row.data(),
//       rowIndex: $row.attr('row-index') | 0,
//     };
//   },
//   storageKey() {
//     return util.storeForUser('enableStorageColumnWidth') ? accountToken : null;
//   },
// });

// search.config({
//   offset: {
//     top: 3,
//   },
// });

// uploader.config({
//   url() {
//     return `${request.config('preurl')(this.action) + this.action}.do`;
//   },
// });
