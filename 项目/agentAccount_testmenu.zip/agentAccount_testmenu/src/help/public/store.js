import { createStore, combineReducers } from 'redux';

const reducers = {};
reducers.account = function (
  state = {
    // 0云记账；1云代账
    versionType: '',
    // 菜单列表
  },
  action,
) {
  switch (action.type) {
    case 'SET_ACCOUNT':
      return { ...state, ...action.account };
    default:
      return state;
  }
};

reducers.affix = function (state = { menus: [] }, action) {
  switch (action.type) {
    case 'menus': {
      return { ...state, ...action.data };
    }
    case 'active': {
      return { ...state, ...action.data };
    }
    default:
      return state;
  }
};
const selectedKeys = ''; // location.hash.substring(1);

reducers.dhselecteds = function (
  state = {
    selectedKeys,
  },
  action,
) {
  switch (action.type) {
    case 'SET_SELECTED':
      return { ...state, ...action.data };
    default:
      return state;
  }
};

reducers.topshow = function (
  state = {
    topshow: true,
  },
  action,
) {
  switch (action.type) {
    case 'SET_TOPSHOW':
      return { ...state, ...action.data };
    default:
      return state;
  }
};

const store = createStore(combineReducers(reducers));
export default store;
