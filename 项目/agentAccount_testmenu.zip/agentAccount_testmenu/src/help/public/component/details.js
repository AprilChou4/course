import React,{Component} from 'react';
import Affix from './Affix';
import {connect} from 'react-redux';
import ReactDom from 'react-dom';
import store from '../store';
import 'nuonuo-libs/script/axnui/jquery.lazyload.min.js';
import {Icon} from 'antd';
import style from './index.less';
import videojs from 'video.js';
import 'video.js/dist/video-js.less';

export default function(Elem){
    class Doc extends Component{
        constructor(props){
            super(props);
            this.state={};
        }
        componentDidMount(){
            this.changeMenus();
            this.player = videojs(this.videoNode, this.props,()=>{

            });
        }
        changeMenus=()=>{
            const _openKeys = this.props.dhselecteds.openKeys;
            const selectedKeys =  location.hash.substring(1);
            const openKeys = location.hash.substring(1).split('/')[1];
            if(_openKeys.indexOf(openKeys) == -1){
                _openKeys.push(openKeys);
            }
            this.props.changeMenus({
                selectedKeys:[selectedKeys],
                openKeys:_openKeys,
            });
        }
        componentWillUnmount(){
            if (this.player) {
                this.player.dispose();
            }
        }
        goBack=()=>{
            this.props.history.go(-1);
        }
        render(){
            return(
                <React.Fragment>
                    <div className="main">
                        <div className="main-top">
                            <a className="main-ui-goBack" onClick={this.goBack}><Icon type="arrow-left" />返回上一页 {this.props.location.pathname} </a>
                        </div>
                        <div className="main-list">
                            <video
                                ref={ node => this.videoNode = node }
                                id='my-video'
                                className='video-js vjs-big-play-centered'
                                controls
                                preload='auto'
                                width='640px'
                                height='264px'
                                poster='/static/images/videoimg.jpg'
                                data-setup='{}'
                                style={{
                                    width:'640px',
                                    height:'264px',
                                }}
                            >
                                <source src="http://vjs.zencdn.net/v/oceans.mp4" type="video/mp4"></source>
                                <source src="http://vjs.zencdn.net/v/oceans.webm" type="video/webm"></source>
                                <source src="http://vjs.zencdn.net/v/oceans.ogv" type="video/ogg"></source>
                            </video>
                        </div>
                    </div>
                    {/* <Affix changeActive={this.changeActive}/> */}
                </React.Fragment>
            );
        }
    }
    const mapStateToProps =(state)=>({
        dhselecteds:state.dhselecteds,
    });
    const mapDispatchToProps =(dispatch)=>{
        return {
            changeMenus:(menus)=>{
                dispatch({
                    type:'SET_SELECTED',
                    selected:menus,
                });
            },
        };
    };
    return connect(mapStateToProps,mapDispatchToProps)(Doc);
};
