import React,{Component} from 'react';
import {connect} from 'react-redux';
import style from './index.less';
class Affix extends Component{

    render(){
        const {menus,active} = this.props;
        if(menus.length){
            return (
                <div
                style={{width:'160px',position:'absolute',right:'-50px',bottom:'80px',backgroundColor:'#fff',paddingLeft:'15px'}} >                    <ul id="demo-toc" className="toc">
                        {
                            menus.map((item,key)=>{
                                return (
                                    <li title={item.name} key={key} className={ active == key ? 'current':''} 
                                        onClick={(e)=>{
                                            this.props.changeActive(e,item,key);
                                        }}
                                    ><a href="javascript:void(0)">{item.name}</a></li>
                                );
                            })
                        }
                    </ul>
                </div>
            );
        }
        else{
            return <React.Fragment />;
        }
    }
}
const mapStateToProps =(state)=>{
    return {
        menus:state.affix.menus,
        active:state.affix.active,
    };
};

export default connect(mapStateToProps)(Affix);
