## 开始

- 开发环境
  yarn install
  yarn start

- 测试环境/生产环境
  yarn install
  yarn build

### 查看文档
npm run docs (http://localhost:9000/)
