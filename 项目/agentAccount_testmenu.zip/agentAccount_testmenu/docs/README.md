---
home: true
tagline:
footer: MIT Licensed | Copyright © 2019
---

## 开始

- 开发环境

```shell
 yarn install

 npm start

 npm run docs (http://localhost:9000) 查看文档
```

- 测试环境/生产环境

```shell
yarn install
npm run build
```
