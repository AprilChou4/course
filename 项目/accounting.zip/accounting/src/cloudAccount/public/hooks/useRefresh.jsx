import React, { useEffect } from 'react';

const useRefresh = () => {
  const refreshPage = (e) => {
    const { data } = e;
    if (typeof data === 'string') {
      const { type } = JSON.parse(data);
      if (type === 'accounting/reload') {
        window.location.reload();
      }
    }
  };
  useEffect(() => {
    window.addEventListener('message', refreshPage, false);
    return () => {
      window.addEventListener('message', refreshPage, false);
    };
  });
};

export default useRefresh;
