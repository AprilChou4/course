import React from 'react';
import moment from 'moment';
import { DatePicker, Button } from 'antd';
import Icon from 'Icon';
import './style.less';

const { MonthPicker } = DatePicker;

const Month = ({ onChange, value, maxDate, minDate, ...rest }) => {
  const newMaxDate = () => {
    return maxDate ? moment(maxDate) : moment().endOf('day');
  };
  const newMinDate = () => {
    return minDate ? moment(minDate) : moment('1971-01');
  };
  const disabledDate = (current) => {
    return current && (current > newMaxDate() || current < newMinDate());
  };
  const btnOnChange = (type) => {
    onChange(moment(value).subtract(type, 'months'));
  };

  return (
    <div styleName="ui-monthpicker">
      <Button
        disabled={value < newMinDate().subtract(-1, 'months')}
        onClick={() => btnOnChange(1)}
        className="ui-monthpicker-btn ui-monthpicker-left"
      >
        <Icon type="left-small" />
      </Button>
      <MonthPicker
        className="ui-monthpicker-main"
        allowClear={false}
        onChange={onChange}
        value={value}
        disabledDate={disabledDate}
        {...rest}
      />
      <Button
        disabled={value > newMaxDate().subtract(1, 'months')}
        onClick={() => btnOnChange(-1)}
        className="ui-monthpicker-btn ui-monthpicker-right"
      >
        <Icon type="right-small" />
      </Button>
    </div>
  );
};

export default Month;
