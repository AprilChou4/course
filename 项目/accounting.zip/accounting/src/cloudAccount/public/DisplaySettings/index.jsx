import React, { useState } from 'react';
import { Modal, Button, message } from 'antd';
import SuperTable from 'SuperTable';
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import update from 'immutability-helper';
import services from 'crservices/currency';
import columns from './columns';
import DragableBodyRow from './drag';
import './style.less';

const Main = ({ isShowSettings, onCancel, onSave, titList, type }) => {
  const [selectedRowKeys, setSelectedRowKeys] = useState(
    titList.filter((val) => val.isEnable).map((val) => val.id),
  );
  const [dataSource, setDataSource] = useState([...titList]);

  // 重置
  const onResetDefault = async () => {
    const newkeys = [];
    const res = await services[type]();
    setDataSource(
      res.map((val, index) => {
        newkeys.push(`${index + 1}`);
        return {
          id: `${index + 1}`,
          name: val,
        };
      }),
    );
    setSelectedRowKeys(newkeys);
  };
  // 保存
  const onSaveColumns = () => {
    const subData = [];
    dataSource.forEach((val, index) => {
      if (val.name) {
        subData.push({
          ...val,
          isEnable: selectedRowKeys.indexOf(val.id) !== -1,
          sort: index + 1,
          id: val.sort ? val.id : '',
        });
      }
    });
    onSave(subData);
  };
  const components = {
    body: {
      row: DragableBodyRow,
    },
  };
  const moveRow = (dragIndex, hoverIndex) => {
    const dragRow = dataSource[dragIndex];
    setDataSource(
      update(dataSource, {
        $splice: [
          [dragIndex, 1],
          [hoverIndex, 0, dragRow],
        ],
      }),
    );
  };
  const rowSelection = {
    selectedRowKeys,
    columnWidth: 60,
    onChange: (selectedRowKeysArg) => {
      setSelectedRowKeys(selectedRowKeysArg);
    },
  };
  // 新增
  const addList = (id) => {
    if (dataSource.length >= 20) {
      message.warning('最多20个列名称！');
      return;
    }
    const newDataSource = [].concat(dataSource);
    const index = newDataSource.findIndex((item) => item.id === id) + 1;
    const dates = new Date().getTime();
    newDataSource.splice(index, 0, {
      id: `${id || ''}${dates}`,
      name: '',
    });
    setDataSource(newDataSource);
  };
  // 删除
  const delList = (id) => {
    const newDataSource = [].concat(dataSource);
    const index = newDataSource.findIndex((item) => item.id === id);
    if (dataSource.length <= 1) {
      const dates = new Date().getTime();
      newDataSource.splice(index, 1, {
        id: `${id}${dates}`,
      });
    } else {
      newDataSource.splice(index, 1);
    }
    setDataSource(newDataSource);
  };
  // 失去焦点 更新数据
  const onBlur = (e, id) => {
    const newDataSource = [].concat(dataSource);
    const index = newDataSource.findIndex((item) => item.id === id);
    newDataSource[index].name = e.target.value;
    setDataSource(newDataSource);
  };

  return (
    <Modal
      visible={isShowSettings}
      styleName="modal-settings"
      title="显示列设置"
      footer={null}
      onCancel={onCancel}
      maskClosable={false}
      bodyStyle={{ paddingTop: 0 }}
    >
      <div className="tips">注：鼠标拖动行，可调整顺序</div>
      <SuperTable
        noLazyLoading
        className="ui-table-settings"
        rowKey="id"
        columns={columns({ addList, delList, onBlur, length: dataSource.length })}
        dataSource={dataSource}
        rowSelection={rowSelection}
        components={components}
        pagination={false}
        // scroll={{ y: 500 }}
        bordered
        onRow={(record, index) => ({
          index,
          moveRow,
        })}
      />
      <div className="bottom-btn">
        <Button className="e-ml10" onClick={onResetDefault}>
          恢复默认
        </Button>
        <Button className="e-ml10" type="primary" onClick={onSaveColumns}>
          保存
        </Button>
      </div>
    </Modal>
  );
};

export default DragDropContext(HTML5Backend)(Main);
