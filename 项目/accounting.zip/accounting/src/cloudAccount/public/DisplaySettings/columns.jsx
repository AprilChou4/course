import React from 'react';
import Icon from 'Icon';
import { Input } from 'antd';

export default ({ addList, delList, onBlur, length }) => {
  const initialization = (index) => {
    // 位数
    const newLength = `${length}`.length > 3 ? `${length}`.length : 3;
    // 序号
    let newIndex = `${index + 1}`;
    for (let i = newIndex.length; i < newLength; i++) {
      newIndex = `0${newIndex}`;
    }
    return newIndex;
  };
  const columns = [
    {
      title: (
        <>
          <div className="posi-left" />
          序号
        </>
      ),
      dataIndex: 'stor',
      width: 60,
      minWidth: 60,
      align: 'center',
      render: (text, record, index) => {
        return (
          <>
            <div className="posi-left" style={length > 1 ? {} : { lineHeight: '25px' }}>
              <Icon type="tianjia" onClick={() => addList(record.id)} />
              {length > 1 && <Icon type="shanchuxinxi" onClick={() => delList(record.id)} />}
            </div>
            {initialization(index)}
          </>
        );
      },
    },
    {
      title: '列名',
      dataIndex: 'name',
      minWidth: 120,
      align: 'left',
      editable: true,
      render: (text, record) => {
        return <Input maxLength={20} defaultValue={text} onBlur={(e) => onBlur(e, record.id)} />;
      },
    },
  ];
  return columns;
};
