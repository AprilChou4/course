import React from 'react';
import Icon from 'Icon';
import { SearchSelect } from '@/selects';

const formulaList = [
  {
    name: '+',
  },
  {
    name: '-',
  },
];
export default ({
  length,
  addList,
  delList,
  subjectList,
  onChangeSubjectList,
  itemList,
  type = 1,
}) => {
  const titleText = type === 2 ? '账套' : '科目';
  const columns = [
    {
      title: (
        <>
          <div className="posi-left" />
          {titleText}
        </>
      ),
      dataIndex: ['subjectId', 'itemAccountId'][type - 1],
      width: 233,
      minWidth: 233,
      align: 'left',
      render: (text, record) => {
        const addObj = {};
        if (type === 2) {
          addObj.itemText = 'accountName';
          addObj.itemKey = 'accountId';
          addObj.filter = 'accountName';
        } else {
          addObj.type = 'subject';
        }
        return (
          <>
            <div className="posi-left" style={length > 1 ? {} : { lineHeight: '25px' }}>
              <Icon type="tianjia" onClick={() => addList(record.id)} />
              {length > 1 && <Icon type="shanchuxinxi" onClick={() => delList(record.id)} />}
            </div>
            <SearchSelect
              placeholder={`请选择${titleText}`}
              showSearch
              value={text}
              onChange={(val, data) => {
                let obj = {
                  ...record,
                  ...{ [['subjectId', 'itemAccountId'][type - 1]]: val },
                };
                if (+type === 2) {
                  const { accounting } = data.props.data;
                  obj = { ...obj, itemAccounting: accounting, itemName: itemList[accounting][0] };
                }
                onChangeSubjectList(obj, record.id);
              }}
              style={{ width: '100%' }}
              dataSource={subjectList}
              {...addObj}
            />
          </>
        );
      },
    },
    {
      title: '取数规则',
      dataIndex: 'stor',
      width: 133,
      align: 'center',
      render: () => {
        return '余额';
      },
    },
    {
      title: '计算方式',
      dataIndex: 'computeSign',
      align: 'left',
      editable: true,
      render: (text, record) => {
        return (
          <SearchSelect
            showSearch
            placeholder="请选择计算方式"
            value={text}
            onChange={(val) => {
              const obj = {
                ...record,
                ...{ computeSign: val },
              };
              onChangeSubjectList(obj, record.id);
            }}
            itemText="name"
            style={{ width: '100%' }}
            itemKey="name"
            dataSource={formulaList}
          />
        );
      },
    },
  ];

  if (type === 2) {
    columns.splice(1, 1, {
      title: '报表项目',
      dataIndex: 'itemName',
      width: 217,
      minWidth: 217,
      align: 'left',
      render: (text, record) => {
        const data = (itemList[record.itemAccounting] || []).map((val) => {
          return {
            name: val,
          };
        });
        return (
          <SearchSelect
            placeholder="请选择项目"
            showSearch
            value={text || (data[0] || {}).name}
            onChange={(val) => {
              const obj = {
                ...record,
                ...{ itemName: val },
              };
              onChangeSubjectList(obj, record.id);
            }}
            style={{ width: '100%' }}
            itemText="name"
            itemKey="name"
            dataSource={data}
          />
        );
      },
    });
  }

  return columns;
};
