import React, { useState, useEffect, useRef } from 'react';
import { Modal, message } from 'antd';
import SuperTable from 'SuperTable';
import columns from './columns';
import './style.less';

const EditFormula = ({
  isShowEditFormula,
  onCancel,
  type,
  formulaList,
  subjectList,
  itemList,
  onSave,
  tableProps = {},
}) => {
  const addRef = useRef(null);
  const [dataSource, setDataSource] = useState(formulaList);
  useEffect(() => {
    if (formulaList.length <= 0) {
      setDataSource([{}]);
    }
  }, [formulaList]);
  // 新增
  const addList = async (id) => {
    if (addRef.current) {
      return;
    }
    addRef.current = true;
    if (dataSource.length >= 500) {
      message.warning('最多增加500行！');
      return;
    }
    const newDataSource = [].concat(dataSource);
    const index = newDataSource.findIndex((item) => item.id === id) + 1;
    const dates = new Date().getTime();
    newDataSource.splice(index, 0, {
      id: `${id || ''}${dates}`,
      name: '',
    });
    await setDataSource(newDataSource);
    addRef.current = false;
  };
  // 删除
  const delList = (id) => {
    const newDataSource = [].concat(dataSource);
    const index = newDataSource.findIndex((item) => item.id === id);
    if (dataSource.length <= 1) {
      const dates = new Date().getTime();
      newDataSource.splice(index, 1, {
        id: `${id}${dates}`,
      });
    } else {
      newDataSource.splice(index, 1);
    }
    setDataSource(newDataSource);
  };

  // 失去焦点 更新数据
  const onChangeSubjectList = (obj, id) => {
    const newDataSource = [].concat(dataSource);
    const index = newDataSource.findIndex((item) => item.id === id);
    newDataSource[index] = obj;
    setDataSource(newDataSource);
  };

  const onOk = () => {
    const data = [];
    dataSource.forEach((val) => {
      if (type === 2) {
        if (val.computeSign || val.itemAccountId || val.itemName) {
          data.push({
            computeSign: val.computeSign,
            itemAccountId: val.itemAccountId,
            itemName: val.itemName,
          });
        }
      } else if (val.computeSign || val.subjectId) {
        data.push({
          computeSign: val.computeSign,
          subjectId: val.subjectId,
        });
      }
    });
    onSave(data);
  };

  return (
    <Modal
      visible={isShowEditFormula}
      styleName="modal-editFormula"
      title="编辑公式"
      cancelText="取消"
      okText="保存"
      onOk={onOk}
      // footer={null}
      width={612}
      onCancel={onCancel}
      maskClosable={false}
      {...tableProps}
    >
      <SuperTable
        className="ui-table-editFormula"
        columns={columns({
          length: dataSource.length,
          addList,
          delList,
          subjectList,
          itemList,
          onChangeSubjectList,
          type,
        })}
        bordered
        pagination={false}
        idName="id"
        dataSource={dataSource}
        rowKey={(record, index) => {
          return record.id || index;
        }}
        onTdChange={() => {}}
      />
    </Modal>
  );
};

export default EditFormula;
