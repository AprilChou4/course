const TABS = [
  { value: 1, name: '科目模板' },
  { value: 2, name: '凭证模板' },
  { value: 3, name: '记账设置' },
  { value: 4, name: '打印设置' },
];

export { TABS };
