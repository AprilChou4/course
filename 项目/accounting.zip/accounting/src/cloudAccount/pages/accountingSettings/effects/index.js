import { message } from 'antd';
import createAuth from 'customReport/utils/inAuth';
import services from '../services';

export default {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  },
  async onInit() {
    await this.getAuthorities();
    await this.getList();
  },
  async getList() {
    const { current, pageSize } = this.getState();
    this.setState({ loading: true });
    let data;
    try {
      data = await services.getList({ current, pCount: pageSize });
    } finally {
      this.setState({
        loading: false,
      });
    }
    const { total, list } = data;

    this.setState({
      total: Number(total),
      dataSource: list.map((item, index) => {
        const flag = item;
        flag.index = index + 1;
        return item;
      }),
    });
  },
  async stopSubject({ id, type }) {
    const { current, pageSize, total } = this.getState();
    await services.stopSubject({ templateId: id, type });
    message.success('操作成功！');
    if (current !== 1 && (total - 1) % pageSize === 0 && type === 1) {
      this.setState({
        current: current - 1,
      });
    }
    this.getList();
  },
  async copy({ id, name }) {
    await services.copy({ templateId: id, name });
    message.success('操作成功！');
    this.getList();
  },
  async add(params) {
    await services.add(params);
    message.success('操作成功！');
    this.setState({
      showTemplateModal: false,
    });
    this.getList();
  },
  async getVerifySet() {
    const data = await services.getVerifySet();
    const { needVerify, verifyType, vatTypes, bookkeepingStaffIds } = data;
    this.setState({
      needVerify,
      verifyType,
      vatTypes: vatTypes || [],
      bookkeepingStaffIds: bookkeepingStaffIds || [],
    });
  },
  async updateVerifySet(params) {
    await services.updateVerifySet(params);
    message.success('操作成功');
    await this.getVerifySet();
  },
  async getAccountList() {
    const data = await services.getAccountList();
    this.setState({
      accountList: data,
    });
  },
  async getMensList(params) {
    const data = await services.getMensList({ isDefault: params || false });
    this.setState({
      menusData: data.map((item, index) => {
        const flag = item;
        flag.key = index;
        flag.code = index + 1 < 10 ? `0${index + 1}` : index + 1;
        return flag;
      }),
    });
  },
  async updateMenusList(params) {
    await services.updateMenusList({ menuList: params });
    message.success('操作成功');
    this.getMensList();
  },
  async getInvoiceSet() {
    const { isSeparateCarry, id } = await services.getInvoiceSet();
    this.setState({
      isSeparateCarry,
      id,
    });
  },
  async updateInvoiceSet(params) {
    const { id } = this.getState();
    await services.updateInvoiceSet({ isSeparateCarry: params, id });
    message.success('操作成功');
    this.getInvoiceSet();
  },
  async getPickUpSet() {
    const data = await services.getPickUpSet();
    this.setState({
      pickUpSet: data,
    });
  },
  async updatePickUpSet(params) {
    await services.updatePickUpSet(params);
    message.success('操作成功');
    this.getPickUpSet();
  },
  async getAuthorities() {
    const data = await services.getAuthorities();
    await createAuth({ authorities: data.split('#') });
  },
};
