// import mock from './mock';
import util from 'util';

export default util.createRequest({
  // ...mock,
  getList: 'account/subjectTemplate/query',
  stopSubject: 'account/subjectTemplate/deleteOrEnable:post',
  copy: 'account/subjectTemplate/copy:post',
  add: 'account/subjectTemplate/add:post',
  getVerifySet: 'account/company/verifySet/get',
  updateVerifySet: 'account/company/verifySet/update:postJSON',
  getAccountList: 'instead/v2/user/staff/bookkeep/list',
  getMensList: 'account/company/menuSet/get',
  updateMenusList: 'account/company/menuSet/update:postJSON',
  getInvoiceSet: 'account/invoiceSet/getInvoiceSet',
  updateInvoiceSet: 'account/invoiceSet/updateInvoiceSet:postJSON',
  getPickUpSet: 'account/invoiceSet/invoicePickUpType/get',
  updatePickUpSet: 'account/invoiceSet/invoicePickUpType/update:post',
  checkPickUpSet: 'account/invoiceSet/invoicePickUpType/check',
  getAuthorities: 'account/invoiceSet/invoicePickUpType/getAuthorities',
});
