import React from 'react';
import Layout from './components/Layout';
import effects from './effects';

const urlhash = window.location.hash.split('?')[1] || '';
const type =
  urlhash && ['type=1', 'type=2', 'type=3', 'type=4'].includes(urlhash)
    ? urlhash.replace('type=', '') || 1
    : 1;

export default {
  state: {
    dataSource: [], // 表格数据
    total: 0,
    current: 1,
    pageSize: 15,
    type: +type, // 记账设置的类型，1为科目管理 2为凭证模板 3 记账设置 4 打印设置
    showTemplateModal: false, // 是否显示科目模板弹窗
    subjectId: '',
    loading: false,
    voucherAccount: undefined,
    needVerify: false, // 是否开启审核
    verifyType: 0, // 需要审核的类型
    bookkeepingStaffIds: [], // 会计类型
    vatTypes: [],
    accountList: [],
    menusData: [], // 菜单列表
    isSeparateCarry: 0, // 是否开启结转模块设置
    id: '',
    pickUpSet: 0, // 发票提取
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    this.store.dispatch({ type: 'onInit' });
  },
};
