/* eslint-disable import/prefer-default-export */
export const printState = {
  isDaizhang: true,
  // 原始数据
  source: [],
  // 当前页码
  current: 1,
  // 数据总数
  total: 0,
  // 每页显示数量
  pageSize: 20,
  // 加载数据时loading状态
  loading: false,
  // 表格数据
  dataSource: [],
  // 编辑模板 id
  editId: null,
  printDetailVisible: false,
  dataSourceOriginal: [], // 源数据
  printSetupMenus: [
    {
      key: 'voucher',
      title: '总账',
      parentId: '0',
    },
    {
      key: '1',
      title: '凭证',
      parentId: 'voucher',
    },
    {
      key: '2',
      title: '凭证汇总表',
      parentId: 'voucher',
    },
    {
      key: 'stock',
      title: '存货',
      parentId: '0',
    },
    {
      key: '3',
      title: '入库明细表',
      parentId: 'stock',
    },
    {
      key: '4',
      title: '出库明细表',
      parentId: 'stock',
    },
    {
      key: '5',
      title: '销售明细表',
      parentId: 'stock',
    },
    {
      key: '6',
      title: '进销存台账（数量式）',
      parentId: 'stock',
    },
    {
      key: '7',
      title: '进销存台账（数量金额式）',
      parentId: 'stock',
    },
    {
      key: 'book',
      title: '账簿',
      parentId: '0',
    },
    {
      key: '8',
      title: '总账',
      parentId: 'book',
    },
    {
      key: '9',
      title: '明细账',
      parentId: 'book',
    },
    {
      key: '10',
      title: '多栏账',
      parentId: 'book',
    },
    {
      key: '11',
      title: '科目余额表',
      parentId: 'book',
    },
    {
      key: '12',
      title: '辅助核算明细账',
      parentId: 'book',
    },
    {
      key: '13',
      title: '辅助核算余额表',
      parentId: 'book',
    },
    {
      key: 'sheet',
      title: '会计报表',
      parentId: '0',
    },
    {
      key: '14',
      title: '小企业会计准则-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '15',
      title: '小企业会计准则-利润表',
      parentId: 'sheet',
    },
    {
      key: '16',
      title: '小企业会计准则-利润季报',
      parentId: 'sheet',
    },
    {
      key: '17',
      title: '小企业会计准则-现金流量表',
      parentId: 'sheet',
    },
    {
      key: '18',
      title: '小企业会计准则-现金流量季报',
      parentId: 'sheet',
    },
    {
      key: '19',
      title: '企业会计准则-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '20',
      title: '企业会计准则-利润表',
      parentId: 'sheet',
    },
    {
      key: '21',
      title: '企业会计准则-利润季报',
      parentId: 'sheet',
    },
    {
      key: '22',
      title: '企业会计准则-现金流量表',
      parentId: 'sheet',
    },
    {
      key: '23',
      title: '企业会计准则-现金流量季报',
      parentId: 'sheet',
    },
    {
      key: '24',
      title: '民间非营利组织-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '25',
      title: '民间非营利组织-业务活动表',
      parentId: 'sheet',
    },
    {
      key: '26',
      title: '民间非营利组织-现金流量表',
      parentId: 'sheet',
    },
    {
      key: '27',
      title: '个体工商户-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '28',
      title: '个体工商户-应税所得表',
      parentId: 'sheet',
    },
    {
      key: '29',
      title: '个体工商户-留存利润表',
      parentId: 'sheet',
    },
    {
      key: '30',
      title: '农民专业合作社-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '31',
      title: '农民专业合作社-盈余及盈余分配表',
      parentId: 'sheet',
    },
    {
      key: '32',
      title: '农民专业合作社-成员权益变动表',
      parentId: 'sheet',
    },
    {
      key: '33',
      title: '政府会计制度-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '34',
      title: '政府会计制度-收入费用表',
      parentId: 'sheet',
    },
    {
      key: '35',
      title: '政府会计制度-预算收入支出表',
      parentId: 'sheet',
    },
    {
      key: '36',
      title: '国有建设单位会计制度-资金平衡表',
      parentId: 'sheet',
    },
    {
      key: '37',
      title: '国有建设单位会计制度-建设单位管理费用表',
      parentId: 'sheet',
    },
    {
      key: '38',
      title: '国有建设单位会计制度-待摊投资明细表',
      parentId: 'sheet',
    },
  ],
  printSetupMenusPersonal: [
    {
      key: 'voucher',
      title: '总账',
      parentId: '0',
    },
    {
      key: '1',
      title: '凭证',
      parentId: 'voucher',
    },
    {
      key: 'book',
      title: '账簿',
      parentId: '0',
    },
    {
      key: '8',
      title: '总账',
      parentId: 'book',
    },
    {
      key: '9',
      title: '明细账',
      parentId: 'book',
    },
    {
      key: '10',
      title: '多栏账',
      parentId: 'book',
    },
    {
      key: '11',
      title: '科目余额表',
      parentId: 'book',
    },
    {
      key: '12',
      title: '辅助核算明细账',
      parentId: 'book',
    },
    {
      key: '13',
      title: '辅助核算余额表',
      parentId: 'book',
    },
    {
      key: 'sheet',
      title: '会计报表',
      parentId: '0',
    },
    {
      key: '14',
      title: '小企业会计准则-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '15',
      title: '小企业会计准则-利润表',
      parentId: 'sheet',
    },
    {
      key: '16',
      title: '小企业会计准则-利润季报',
      parentId: 'sheet',
    },
    {
      key: '17',
      title: '小企业会计准则-现金流量表',
      parentId: 'sheet',
    },
    {
      key: '18',
      title: '小企业会计准则-现金流量季报',
      parentId: 'sheet',
    },
    {
      key: '19',
      title: '企业会计准则-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '20',
      title: '企业会计准则-利润表',
      parentId: 'sheet',
    },
    {
      key: '21',
      title: '企业会计准则-利润季报',
      parentId: 'sheet',
    },
    {
      key: '22',
      title: '企业会计准则-现金流量表',
      parentId: 'sheet',
    },
    {
      key: '23',
      title: '企业会计准则-现金流量季报',
      parentId: 'sheet',
    },
    {
      key: '24',
      title: '民间非营利组织-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '25',
      title: '民间非营利组织-业务活动表',
      parentId: 'sheet',
    },
    {
      key: '26',
      title: '民间非营利组织-现金流量表',
      parentId: 'sheet',
    },
    {
      key: '27',
      title: '个体工商户-资产负债表',
      parentId: 'sheet',
    },
    {
      key: '28',
      title: '个体工商户-应税所得表',
      parentId: 'sheet',
    },
    {
      key: '29',
      title: '个体工商户-留存利润表',
      parentId: 'sheet',
    },
  ],
  selectedPrintSetupMenu: {
    key: '1',
    title: '凭证',
    parentId: 'voucher',
  },
  refreshDetail: 0,
  templateDetails: {
    setting: {
      pageSetup: {},
      paperSize: {},
      pageMargins: {},
    },
  },
  paginationProps: {
    current: 1,
    total: 0,
    pageSize: 15,
  },
  tableStyleObj: {}, // 表格样式
};
