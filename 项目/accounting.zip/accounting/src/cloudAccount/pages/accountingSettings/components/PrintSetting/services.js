import util from 'util';
// import mock from './mock';

export default util.createRequest({
  // 转跳到打印前验证模板是否停用或者被删除
  checkPrintTemplate: 'account/companyTemplate/checkPrintTemplate.do:post',
  // 模板名查重
  checkTemplateName: 'account/companyTemplate/checkVoucherPrintTemplateName.do:post',
  // 删除打印模板
  deletePrintTemplate: 'account/companyTemplate/deleteVoucherPrintTemplate.do:post',
  // 编辑打印模板
  editPrintTemplate: 'account/companyTemplate/editVoucherPrintTemplate.do:postJSON',
  // 获取公司级模板列表
  getCompanyPrintTemplate: 'accountbook/voucherPrint/getCompanyPrintTemplate.do:post',
  // 获取专业打印的json文件url
  getPrintJsonUrl: 'accountbook/voucherPrint/getPrintJsonUrl.do:post',
  // 获取最近使用的模板打印参数
  getPrintParam: 'accountbook/voucherPrint/getPrintParam.do:post',
  // 根据要打印的获取凭证数据获取有多少种打印类型(金额式,数量外币金额式等)
  getVoucherType: 'accountbook/voucherPrint/getVoucherType.do:post',
  // 引入公司级模板
  importCompanyPrintTemplate: 'accountbook/voucherPrint/importCompanyPrintTemplate.do:postJSON',
  // 预览自定义
  previewPrintTemplate: 'accountbook/voucherPrint/previewPrintTemplate.do:post',
  // 打印PDF文件
  print: 'accountbook/voucherPrint/print.do:post',
  // 获得打印模板详情(编辑页面加载信息)
  printTemplateInfo: 'account/companyTemplate/getVoucherPrintTemplateInfo.do:post',
  // 恢复默认参数
  recoverPrintTemplate: 'account/companyTemplate/revertVoucherPrintTemplate.do:post',
  // 保存新增打印模板
  saveNewPrintTemplate: 'account/companyTemplate/saveVoucherPrintTemplate.do:postJSON',
  // 凭证打印模板列表
  voucherPrintTemplateList: 'account/companyTemplate/list.do:post',
  // 开启关闭录凭证借贷方智能定位
  updateSetting: 'account/systemSetting/personalize/updateSetting.do:postJSON',

  // 新版打印设置
  listTplWorkbook: 'account/tplWorkbook/listTplWorkbook',
  getSharedTemplateList: 'account/tplWorkbook/getSharedTemplateList',
  templateDetail: 'account/tplWorkbook/detail',
  enableTemplate: 'account/tplWorkbook/openOrClose:post',
  delTemplate: 'account/tplWorkbook/delTemplate:post',
  updateTplWorkbook: 'account/tplWorkbook/updateTplWorkbook:postJSON',
  saveTplWorkbook: 'account/tplWorkbook/saveTplWorkbook:postJSON',

  // ...mock,
});
