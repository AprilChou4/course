import React from 'react';
import { PropTypes } from 'prop-types';
import './index.less';

const ModuleItem = ({ title, content }) => {
  return (
    <div styleName="accountSetting-item">
      <div styleName="accountSetting-item-slider">{title}</div>
      <div styleName="accountSetting-item-content">{content}</div>
    </div>
  );
};

ModuleItem.propTypes = {
  title: PropTypes.string.isRequired,
  content: PropTypes.element.isRequired,
};

export default ModuleItem;
