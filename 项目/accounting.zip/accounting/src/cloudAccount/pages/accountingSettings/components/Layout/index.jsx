import React from 'react';
import useRefresh from 'crPublic/hooks/useRefresh';
import Head from '../Head';
import Content from '../Content';
import './index.less';

const { inAuth } = window;

const Layout = () => {
  useRefresh();
  return (
    inAuth(508) && (
      <div styleName="accounting-settings">
        <Head />
        <Content />
      </div>
    )
  );
};

export default Layout;
