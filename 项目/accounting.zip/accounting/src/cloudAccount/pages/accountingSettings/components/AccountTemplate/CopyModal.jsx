import React from 'react';
import { Modal, Form, Input } from 'antd';
import { PropTypes } from 'prop-types';
import './index.less';

const formItemLayout = {
  labelCol: {
    sm: { span: 5 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};

const CopyModal = ({ visible, form, subjectName, onOk, onCancel }) => {
  const { getFieldDecorator, validateFields } = form;
  const handleOnOk = () => {
    validateFields((errors, values) => {
      if (errors) return;
      onOk(values);
    });
  };
  return (
    <Modal
      width={640}
      title="复制模板"
      visible={visible}
      onCancel={onCancel}
      onOk={handleOnOk}
      centered
    >
      <div styleName="tips">
        <i className="iconfont icon-tishi1" />
        <span>温馨提示：复制科目模板默认也复制科目模板下的凭证模板</span>
      </div>
      <Form {...formItemLayout} style={{ marginTop: 40 }}>
        <Form.Item label="科目模板名称">
          {getFieldDecorator('name', {
            initialValue: `${subjectName}1`,
            rules: [
              {
                required: true,
                message: '模板名称不能为空',
              },
            ],
          })(<Input maxLength={30} />)}
        </Form.Item>
      </Form>
    </Modal>
  );
};

CopyModal.propTypes = {
  visible: PropTypes.bool.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  subjectName: PropTypes.string.isRequired,
  onOk: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
};

export default Form.create()(CopyModal);
