import React, { useState } from 'react';
import { Button } from 'antd';
import { PropTypes } from 'prop-types';
import { connect } from 'nuomi';
import { ConfirmModal } from '@/modal';
import CopyModal from './CopyModal';

const { inAuth } = window;
const Operate = ({ record, dispatch }) => {
  const [visible, setVisible] = useState(false);
  const { id, source, status, name, type } = record;
  const handleLinkToVoucher = () => {
    dispatch({
      type: 'setState',
      payload: {
        type: 2,
        subjectId: id,
        voucherAccount: Number(type),
      },
    });
  };
  const handleLinkToEdit = () => {
    // eslint-disable-next-line
    window.parent.postMessage(
      JSON.stringify({
        type: 'agentAccount/routerLocation',
        payload: {
          url: `/accounting-settings/edit`,
          query: { id },
        },
      }),
      '*',
    );
    // router.location(`/accounting-settings/edit/${id}`, true);
    localStorage.setItem('subjectName', name);
  };
  const handleClick = () => {
    ConfirmModal({
      title: '确定要停用此模板吗？',
      content: '停用后可重新启用',
      centered: true,
      width: 340,
      onOk() {
        dispatch({ type: 'stopSubject', payload: { id, type: 2 } });
      },
    });
  };
  const enAbleClick = () => {
    dispatch({ type: 'stopSubject', payload: { id, type: 3 } });
  };
  const deleteClick = () => {
    ConfirmModal({
      title: '确定要删除此模板吗？',
      content: '删除科目模板也将删除对应的凭证模板',
      centered: true,
      width: 340,
      onOk() {
        dispatch({ type: 'stopSubject', payload: { id, type: 1 } });
      },
    });
  };
  const handleCopyClick = () => {
    setVisible(true);
  };
  const handleOnOk = (values) => {
    dispatch({ type: 'copy', payload: { id, ...values } }).then(() => {
      setVisible(false);
    });
  };
  return (
    inAuth(509) && (
      <>
        <Button type="link" onClick={handleLinkToEdit}>
          编辑
        </Button>
        <Button type="link" onClick={handleCopyClick}>
          复制
        </Button>
        {source === 0 && status === 0 && (
          <Button type="link" onClick={handleClick}>
            停用
          </Button>
        )}
        {source === 0 && status === 1 && (
          <Button type="link" onClick={enAbleClick}>
            启用
          </Button>
        )}
        {source === 1 && (
          <Button type="link" onClick={deleteClick}>
            删除
          </Button>
        )}
        <Button type="link" onClick={handleLinkToVoucher}>
          查看凭证模板
        </Button>
        {visible && (
          <CopyModal
            visible={visible}
            onCancel={() => {
              setVisible(false);
            }}
            onOk={handleOnOk}
            subjectName={name}
          />
        )}
      </>
    )
  );
};

Operate.propTypes = {
  record: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect()(Operate);
