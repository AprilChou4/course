import React, { useState } from 'react';
import { Input, Select, Radio, Form } from 'antd';
import { PropTypes } from 'prop-types';
import LabelTips from './LabelTips';

const { Option } = Select;

const formItemLayout = {
  labelCol: {
    sm: { span: 5 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};
const industry = [
  {
    name: '农林牧渔',
  },
  {
    name: '采矿业',
  },
  {
    name: '制造业',
  },
  {
    name: '电力、热力、燃气及水生产和供应业',
  },
  {
    name: '建筑业',
  },
  {
    name: '批发零售业',
  },
  {
    name: '交通运输、仓储和邮政业',
  },
  {
    name: '住宿和餐饮业',
  },
  {
    name: '信息传输、软件和信息技术服务业',
  },
  {
    name: '金融业',
  },
  {
    name: '房地产业',
  },
  {
    name: '租赁和商务服务业',
  },
  {
    name: '科学研究和技术服务业',
  },
  {
    name: '水利、环境和公告设施管理业',
  },
  {
    name: '居民服务、修理、和其他服务业',
  },
  {
    name: '教育',
  },
  {
    name: '卫生和社会工作',
  },
  {
    name: '文化、体育和娱乐业',
  },
  {
    name: '公共管理、社会保障和社会组织',
  },
  {
    name: '国际组织',
  },
];
// todo 行业类型走接口，会计制度跟据行业类型变化
const TemplateForm = ({ form }) => {
  const { getFieldDecorator } = form;
  const [typeData, setTypeData] = useState([
    { value: 0, label: '小企业会计准则' },
    { value: 1, label: '企业会计准则' },
    { value: 2, label: '民间非营利组织' },
    { value: 6, label: '农合会计制度' },
    { value: 7, label: '政府会计制度' },
    { value: 8, label: '国有建设单位会计制度' },
  ]);
  const handleVatTypeChange = (e) => {
    const {
      target: { value },
    } = e;
    const params = JSON.parse(JSON.stringify(typeData));
    let newParams = params;
    if (value === 0 && !params.some((item) => item.value === 8)) {
      params.push({ value: 8, label: '国有建设单位会计制度' });
      newParams = params;
    } else if (value === 1 && params.some((item) => item.value === 8)) {
      newParams = params.filter((item) => item.value !== 8);
    }
    setTypeData(newParams);
    form.setFieldsValue({ type: newParams[0].value });
  };
  const handleSelectChange = (e) => {
    // 行业分类为空时，预置模板库显示 小企业会计准则、企业会计准则、民间非营利组织、农合会计制度
    // 行业分类是"房地产业"时， 预置模板库只显示 小企业会计准则、企业会计准则
    // 行业分类是"公共管理、社会保障和社会组织"时， 预置模板库只显示 民间非营利组织
    // 行业分类非上面这几种的时，预置模板库只显示 小企业会计准则、企业会计准则
    // 行业分类选择农林牧渔 ，预置模板库只显示 小企业会计准则、企业会计准则，农合会计制度
    const vatType = form.getFieldValue('vatType');
    if (!e) {
      const params = [
        { value: 0, label: '小企业会计准则' },
        { value: 1, label: '企业会计准则' },
        { value: 2, label: '民间非营利组织' },
        { value: 6, label: '农合会计制度' },
        { value: 7, label: '政府会计制度' },
      ];
      vatType === 0 && params.push({ value: 8, label: '国有建设单位会计制度' });
      setTypeData(params);
      form.setFieldsValue({ type: params[0].value });
    } else if (e === '公共管理、社会保障和社会组织') {
      const params = [
        { value: 2, label: '民间非营利组织' },
        { value: 7, label: '政府会计制度' },
      ];
      vatType === 0 && params.push({ value: 8, label: '国有建设单位会计制度' });
      setTypeData(params);
      form.setFieldsValue({ type: params[0].value });
    } else if (e === '农林牧渔') {
      const params = [
        { value: 0, label: '小企业会计准则' },
        { value: 1, label: '企业会计准则' },
        { value: 6, label: '农合会计制度' },
        { value: 7, label: '政府会计制度' },
      ];
      vatType === 0 && params.push({ value: 8, label: '国有建设单位会计制度' });
      setTypeData(params);
      form.setFieldsValue({ type: params[0].value });
    } else {
      const params = [
        { value: 0, label: '小企业会计准则' },
        { value: 1, label: '企业会计准则' },
        { value: 7, label: '政府会计制度' },
      ];
      vatType === 0 && params.push({ value: 8, label: '国有建设单位会计制度' });
      setTypeData(params);
      form.setFieldsValue({ type: params[0].value });
    }

  };
  return (
    <Form {...formItemLayout}>
      <Form.Item label="科目模板名称">
        {getFieldDecorator('name', {
          initialValue: '小企业会计准则',
          rules: [
            {
              required: true,
              message: '模板名称不能为空',
            },
          ],
        })(<Input maxLength={30} allowClear />)}
      </Form.Item>
      <Form.Item label="行业分类">
        {getFieldDecorator(
          'industryType',
          {},
        )(
          <Select
            placeholder="请选择行业分类"
            optionFilterProp="children"
            showSearch
            allowClear
            onChange={handleSelectChange}
          >
            {industry.map(({ name }) => (
              <Option key={name} value={name}>
                {name}
              </Option>
            ))}
          </Select>,
        )}
      </Form.Item>
      <Form.Item
        label={
          <>
            纳税性质
            <LabelTips />
          </>
        }
      >
        {getFieldDecorator('vatType', {
          initialValue: 0,
        })(
          <Radio.Group onChange={handleVatTypeChange}>
            <Radio value={1}>小规模纳税人</Radio>
            <Radio value={0}>一般纳税人</Radio>
          </Radio.Group>,
        )}
      </Form.Item>
      <Form.Item label="预置模板库">
        {getFieldDecorator('type', { initialValue: typeData[0].value })(
          <Radio.Group>
            {typeData.map(({ value, label }) => {
              return (
                <Radio key={value} value={value}>
                  {label}
                </Radio>
              );
            })}
          </Radio.Group>,
        )}
      </Form.Item>
    </Form>
  );
};

TemplateForm.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default Form.create()(TemplateForm);
