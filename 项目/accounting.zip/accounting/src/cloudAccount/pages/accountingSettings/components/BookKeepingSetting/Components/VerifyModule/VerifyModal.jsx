import React, { useRef } from 'react';
import { Modal } from 'antd';
import { PropTypes } from 'prop-types';
import VerifyForm from './VerifyForm';
import './index.less';

const VerifyModal = ({ visible, onCancel, onOk }) => {
  const verifyForm = useRef(null);
  const handleOnOk = () => {
    verifyForm.current.validateFields((err, values) => {
      if (!err) {
        onOk(values);
      }
    });
  };
  return (
    <Modal
      className="accountSetting-verifySetting-modal"
      title="批量审核设置"
      width={460}
      visible={visible}
      centered
      onCancel={onCancel}
      onOk={handleOnOk}
    >
      <VerifyForm ref={verifyForm} />
    </Modal>
  );
};

VerifyModal.propTypes = {
  visible: PropTypes.bool.isRequired,
  onCancel: PropTypes.func.isRequired,
  onOk: PropTypes.func.isRequired,
};

export default VerifyModal;
