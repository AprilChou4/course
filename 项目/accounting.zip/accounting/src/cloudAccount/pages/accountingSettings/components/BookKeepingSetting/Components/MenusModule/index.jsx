import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import ModuleItem from '../ModuleItem/index';
import CustomizeColumns from './CustomizeColumns';

const MenusModule = ({ dispatch }) => {
  const handleOnOk = (data, callback) => {
    dispatch({ type: 'updateMenusList', payload: data }).then(() => {
      callback && callback();
    });
  };
  const handleOnCancel = () => {
    dispatch({ type: 'getMensList', payload: true });
  };
  useEffect(() => {
    dispatch({ type: 'getMensList' });
  }, []);
  return (
    <ModuleItem
      title="流程化菜单设置"
      content={
        <div className="accountSetting-item-content-item">
          <div className="accountSetting-item-content-item-title">
            可根据做账流程设置记账菜单顺序
          </div>
          <CustomizeColumns onOk={handleOnOk} onCancel={handleOnCancel} />
        </div>
      }
    />
  );
};

MenusModule.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

export default connect()(MenusModule);
