// import mock from './mock';
import util from 'util';

export default util.createRequest({
  // ...mock,
  getSubjectList: 'account/subjectTemplate/querySubjectTemplateList',
  getList: 'account/systemVoucherTemplate/queryVoucherTemplateList',
  getSubject: 'account/subject/querySubjectList',
  batchAccDelete: 'account/systemVoucherTemplate/delete:post',
  getVoucherTemplate: 'account/systemVoucherTemplate/queryAllVoucherTemplateList',
  batchImport: 'account/systemVoucherTemplate/batchImport:post',
  batchImportCover: 'account/systemVoucherTemplate/batchImportAfterHandleSubject:post',
  getVoucherDetail: 'account/systemVoucherTemplate/allow/queryVoucherTemplateById',
  replaceSubject: 'account/systemVoucherTemplate/replaceSubject:post',
  getInvoiceSet: 'account/invoiceSet/getInvoiceSet',
});
