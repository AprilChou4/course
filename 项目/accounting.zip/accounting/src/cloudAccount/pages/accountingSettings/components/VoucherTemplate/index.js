import defaultProps from '../../../../../platform/pages/setting/voucherTemplate';
import effects from './effects';

export default {
  ...defaultProps,
  state: {
    ...defaultProps.state,
    isDaizhang: true, // 是否是代账
    subjectTemplateList: [], // 科目模板数据
    selectTemplateId: '', // 选中的科目模板
    current: 1, // 当前页数
    pageSize: 15, // 每页数量
    system: 1, // 是否预制，1预制，0自制
    subjectId: '', // 查询的科目id
    summary: '', // 摘要
    type: 3, // 总账3，发票1，资金2，存货4
    invoiceType: '', // 发票类型
    queryParam: '', // 查询条件
    isStock: false,
    voucherAccount: undefined,
  },
  effects,
  async onInit() {
    const { subjectId, voucherAccount } = this;
    await this.store.dispatch({ type: 'onInit', payload: { subjectId, voucherAccount } });
  },
};
