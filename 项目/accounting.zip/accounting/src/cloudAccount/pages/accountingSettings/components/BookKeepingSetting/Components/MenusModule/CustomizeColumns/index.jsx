/* eslint-disable prettier/prettier */
import React, { useState, useEffect } from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import { Button, Modal } from 'antd';
import Table from './Table';
import './index.less';

const { inAuth } = window;
const CustomizeColumns = ({ onOk, menusData, onCancel }) => {
  const [visible, setVisible] = useState(false);


  const [data, setData] = useState([]);

  useEffect(() => {
    setData(menusData);
  }, [menusData]);
  const hideModal = () => {
    setVisible(false);
  };

  const showModal = () => {
    setVisible(!visible);
  };

  const handleOnCancel = () => {
    onCancel();
  }

  const handleOnOk = () => {
    const newData = JSON.parse(JSON.stringify(data));
    newData.map((item, i) => {
      const flag = item;
      flag.sort = i + 1;
      delete flag.key;
      delete flag.i;
      return flag;
    });
    onOk(newData,  setVisible(false));
  };
  return (
    <>
      <Button type="link" onClick={showModal} disabled={!inAuth(509)}>流程化菜单设置&gt;&gt;</Button>
      {visible && (
        <Modal
          title="菜单显示设置"
          centered
          maskClosable={false}
          width={518}
          visible={visible}
          onCancel={hideModal}
          wrapClassName="custom-columns"
          footer={<><Button type="default" onClick={handleOnCancel}>恢复默认</Button><Button type="primary" onClick={handleOnOk}>保存</Button></>}
        >
          <p styleName="custom-tips">注：鼠标拖动行，可调整顺序</p>
          <div styleName="custom-table">
            <Table setData={setData} data={data} />
          </div>
        </Modal>
      )}
    </>
  );
};

CustomizeColumns.propTypes = {
  onOk: PropTypes.func.isRequired, // 保存时的回调
  onCancel: PropTypes.func.isRequired, // 恢复默认的回调
  menusData: PropTypes.arrayOf(PropTypes.any).isRequired, // 自定义显示列的数据
};

export default connect(({menusData}) => ({menusData}))(CustomizeColumns);
