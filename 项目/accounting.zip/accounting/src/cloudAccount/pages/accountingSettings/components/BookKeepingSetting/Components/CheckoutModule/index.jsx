import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import { Radio } from 'antd';
import { PropTypes } from 'prop-types';
import ModuleItem from '../ModuleItem';

const { inAuth } = window;

const CheckoutModule = ({ dispatch, isSeparateCarry }) => {
  useEffect(() => {
    dispatch({ type: 'getInvoiceSet' });
  }, []);
  const handleRadioChange = (e) => {
    dispatch({ type: 'updateInvoiceSet', payload: e.target.value });
  };
  return (
    <ModuleItem
      title="结转模块设置"
      content={
        <div className="accountSetting-item-content-item">
          <div className="accountSetting-item-content-item-title">
            分开结转后，系统会分成两种凭证
          </div>
          <div className="accountSetting-item-content-item-content">
            <Radio.Group
              onChange={handleRadioChange}
              value={isSeparateCarry}
              disabled={!inAuth(509)}
            >
              <Radio value={0}>收入与成本费用合并结转</Radio>
              <Radio value={1}>收入与成本费用分开结转</Radio>
            </Radio.Group>
          </div>
        </div>
      }
    />
  );
};

CheckoutModule.propTypes = {
  isSeparateCarry: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ isSeparateCarry }) => ({ isSeparateCarry }))(CheckoutModule);
