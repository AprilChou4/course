import React from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'nuomi';
import { Tabs, Popover } from 'antd';
import { TABS } from '../../common';
import './index.less';

const { TabPane } = Tabs;

const Head = ({ type, dispatch }) => {
  const handleTabChange = (tab) => {
    dispatch({ type: 'setState', payload: { type: Number(tab) } });
  };
  return (
    <div styleName="head">
      <Tabs onChange={handleTabChange} animated={false} activeKey={String(type)}>
        {TABS.map(({ value, name }) => {
          if (value === 2)
            return (
              <TabPane
                tab={
                  <span>
                    {name}
                    <Popover
                      overlayClassName="accounting-settings-tips-xb"
                      title="凭证模板按照科目模板分别预置"
                      placement="bottomLeft"
                      content={
                        <ul>
                          <li>1、新增账套时会根据这里的设置进行预置；</li>
                          <li>
                            2、已建账的账套，需要通过账套中的设置-凭证模板-引入，进行模板引入；
                          </li>
                          <li>3、总账凭证模板用于录凭证时快速带出分录信息；</li>
                          <li>4、发票凭证模板用于票据管理中的发票生成凭证；</li>
                          <li>5、资金凭证模板用于日记账生成凭证。</li>
                        </ul>
                      }
                    >
                      <i className="iconfont icon-bangzhu" />
                    </Popover>
                  </span>
                }
                key={value}
              />
            );
          return <TabPane tab={name} key={value} />;
        })}
      </Tabs>
    </div>
  );
};

Head.propTypes = {
  type: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ type }) => ({ type }))(Head);
