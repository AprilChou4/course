/* eslint-disable prettier/prettier */
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { DragDropContextProvider, DragSource, DropTarget } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import SuperTable from '@/SuperTable';
import TableCell from '@/TableCell';
import BodyRow from './BodyRow';

const Table = ({ setData, data }) => {
  const filterData = (targetData) => {
    targetData.map((item, index) => {
      const s = item;
      s.i = index;
      return s;
    });
    return targetData;
  };
  const [dataSource, setDataSource] = useState([]);
  useEffect(() => {
    setDataSource(filterData(data))
  }, data)

  // eslint-disable-next-line
  let dragingIndex = -1;
  const rowSource = {
    beginDrag(e) {
      dragingIndex = e.index;
      return {
        index: e.index,
      };
    },
  };
  const rowTarget = {
    drop(e, s) {
      const dragIndex = s.getItem().index;
      const hoverIndex = e.index;

      if (dragIndex === hoverIndex) {
        return;
      }

      e.moveRow(dragIndex, hoverIndex);
      // eslint-disable-next-line
      s.getItem().index = hoverIndex;
    },
  };

  const DragableBodyRow = DropTarget('row', rowTarget, (connect, monitor) => ({
    connectDropTarget: connect.dropTarget(),
    isOver: monitor.isOver(),
  }))(
    DragSource('row', rowSource, (connect) => {
      return {
        connectDragSource: connect.dragSource(),
      };
    })(BodyRow),
  );



  const components = {
    body: {
      row: DragableBodyRow,
    },
  };

  const columns = [
    {
      title: '序号',
      width: 100,
      align: 'left',
      dataIndex: 'code',
      render: (text, record, index) => {
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '可选信息',
      width: 300,
      align: 'left',
      dataIndex: 'menuName',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
  ];
  const moveRow = (dragIndex, hoverIndex) => {
    const newArr = [...dataSource];
    const hoverData = newArr[hoverIndex];
    newArr.splice(hoverIndex, 1, newArr[dragIndex]);
    newArr.splice(dragIndex, 1, hoverData);
    const newData = JSON.parse(JSON.stringify(newArr));
    setDataSource(filterData(newData));
    setData(filterData(newData));
  };
  return (
    <DragDropContextProvider backend={HTML5Backend}>
      <SuperTable
        columns={columns}
        dataSource={dataSource}
        components={components}
        bordered
        pagination={false}
        rowKey={(record) => record.key}
        onRow={(record) => ({
          index: record.i,
          moveRow,
        })}
      />
    </DragDropContextProvider>
  );
};

Table.propTypes = {
  setData: PropTypes.func.isRequired,
  data: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default Table;
