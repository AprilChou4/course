import React, { useEffect } from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'nuomi';
import { Form, Radio, Select, Checkbox } from 'antd';

const formItemLayout = { labelCol: { span: 6 }, wrapperCol: { span: 18 } };

const verifyTypeList = [
  {
    value: 0,
    label: '全部账套',
  },
  {
    value: 1,
    label: '纳税性质',
  },
  {
    value: 2,
    label: '记账会计',
  },
];

const vatTypesList = [
  {
    value: 0,
    label: '一般纳税人',
  },
  {
    value: 1,
    label: '小规模纳税人',
  },
];

const VerifyForm = ({ form, verifyType, bookkeepingStaffIds, vatTypes, accountList, dispatch }) => {
  const { getFieldDecorator, getFieldValue, setFieldsValue } = form;
  useEffect(() => {
    dispatch({ type: 'getAccountList' });
  }, [getFieldValue('verifyType'), dispatch]);
  const handleBookKeepAccountingChange = (value) => {
    const i = value.indexOf('all');
    // 当选择其他的时候去除全部选项
    if (value.length > 1) {
      if (value[value.length - 1] === 'all') {
        setTimeout(() => {
          setFieldsValue({ bookkeepingStaffIds: ['all'] });
        });
      } else {
        const newValue = JSON.parse(JSON.stringify(value));
        newValue.splice(i, 1);
        setTimeout(() => {
          setFieldsValue({ bookkeepingStaffIds: i !== -1 ? newValue : value });
        });
      }
    }
    if (i === -1 && value.length === accountList.length) {
      console.log(2);
      setTimeout(() => {
        setFieldsValue({ bookkeepingStaffIds: ['all'] });
      });
    }
  };
  return (
    <Form>
      <Form.Item className="accountSetting-verifySetting-modal-verifyType">
        {getFieldDecorator('verifyType', {
          initialValue: verifyType,
          rules: [{ required: true, message: '请选择需要审核的类型' }],
        })(<Radio.Group options={verifyTypeList} />)}
      </Form.Item>
      {[1, 2].includes(getFieldValue('verifyType')) && (
        <div className="accountSetting-verifySetting-modal-verifyType-content">
          {getFieldValue('verifyType') === 1 ? (
            <Form.Item label="纳税性质" required={false} {...formItemLayout}>
              {getFieldDecorator('vatTypes', {
                initialValue: vatTypes,
                rules: [{ required: true, message: '纳税性质至少勾选一项' }],
              })(<Checkbox.Group options={vatTypesList} />)}
            </Form.Item>
          ) : (
            <Form.Item label="记账会计" required={false} {...formItemLayout}>
              {getFieldDecorator('bookkeepingStaffIds', {
                initialValue:
                  bookkeepingStaffIds?.length <= 0 ||
                  bookkeepingStaffIds?.length === accountList?.length
                    ? ['all']
                    : bookkeepingStaffIds,
                rules: [{ required: true, message: '记账会计不能为空' }],
              })(
                <Select
                  allowClear
                  showArrow
                  mode="multiple"
                  placeholder="请选择记账会计"
                  onChange={handleBookKeepAccountingChange}
                >
                  <Select.Option value="all">全部</Select.Option>
                  {accountList.map(({ realName, staffId }) => {
                    return (
                      <Select.Option value={staffId} key={staffId}>
                        {realName}
                      </Select.Option>
                    );
                  })}
                </Select>,
              )}
            </Form.Item>
          )}
        </div>
      )}
    </Form>
  );
};

VerifyForm.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  verifyType: PropTypes.number.isRequired,
  bookkeepingStaffIds: PropTypes.arrayOf(PropTypes.any).isRequired,
  vatTypes: PropTypes.arrayOf(PropTypes.any).isRequired,
  accountList: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default Form.create()(
  connect(({ verifyType, bookkeepingStaffIds, vatTypes, accountList }) => ({
    verifyType,
    bookkeepingStaffIds,
    vatTypes,
    accountList,
  }))(VerifyForm),
);
