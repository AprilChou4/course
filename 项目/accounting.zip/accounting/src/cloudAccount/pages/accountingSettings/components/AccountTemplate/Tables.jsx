import React, { useState, useEffect } from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'nuomi';
import { Table } from 'antd';
import moment from 'moment';
import TabelCell from '@/TableCell';
import Operate from './Operate';

const Tables = ({ total, dataSource, current, pageSize, loading, dispatch }) => {
  const [y, setY] = useState(document.body.clientHeight - 240);
  useEffect(() => {
    const resizeY = () => {
      setY(document.body.clientHeight - 240);
    };
    window.addEventListener('resize', resizeY, false);
    return () => {
      window.removeEventListener('resize', resizeY, false);
    };
  }, [y]);
  const columns = [
    {
      title: '编号',
      dataIndex: 'index',
      align: 'center',
      width: 70,
    },
    {
      title: '模板名称',
      dataIndex: 'name',
      className: 'th-center',
      align: 'left',
      width: '32%',
      render: (text) => {
        return <TabelCell>{text}</TabelCell>;
      },
    },
    {
      title: '模板类型',
      dataIndex: 'typeName',
      align: 'left',
      className: 'th-center',
      width: '17%',
    },
    {
      title: '行业类型',
      dataIndex: 'industryType',
      align: 'left',
      className: 'th-center',
      width: '17%',
      render: (text) => text || '-',
    },
    {
      title: '最后修改人',
      dataIndex: 'editUser',
      align: 'center',
      width: '12%',
    },
    {
      title: '最后修改时间',
      dataIndex: 'editTime',
      align: 'center',
      width: '13%',
      render: (text) => moment(text).format('YYYY-MM-DD HH:mm:SS'),
    },
    {
      title: '操作',
      align: 'center',
      className: 'operate-cell',
      dataIndex: 'operate',
      width: '20%',
      render: (text, record) => {
        return <Operate record={record} />;
      },
    },
  ];
  const onShowSizeChange = (c, p) => {
    dispatch({ type: 'setState', payload: { current: c, pageSize: p } });
    dispatch({ type: 'getList' });
  };
  const handlePageChange = (c) => {
    dispatch({ type: 'setState', payload: { current: c } });
    dispatch({ type: 'getList' });
  };
  return (
    <Table
      loading={loading}
      className="ant-supertable"
      pagination={{
        current,
        total,
        pageSizeOptions: ['15', '50', '100'],
        pageSize,
        showSizeChanger: true,
        onShowSizeChange,
        onChange: handlePageChange,
      }}
      columns={columns}
      dataSource={dataSource}
      bordered
      rowKey={(record, index) => record.id || index}
      scroll={{ y }}
    />
  );
};

Tables.propTypes = {
  total: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired,
  pageSize: PropTypes.number.isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
  current: PropTypes.number.isRequired,
};

export default connect(({ total, dataSource, current, pageSize, loading }) => ({
  total,
  dataSource,
  current,
  pageSize,
  loading,
}))(Tables);
