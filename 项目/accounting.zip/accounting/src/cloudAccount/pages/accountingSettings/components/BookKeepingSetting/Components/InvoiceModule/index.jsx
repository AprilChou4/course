import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import { Radio, Popover, message, Modal } from 'antd';
import ModuleItem from '../ModuleItem/index';
import services from '../../../../services';

const { inAuth } = window;

const InvoiceModule = ({ dispatch, pickUpSet }) => {
  useEffect(() => {
    dispatch({ type: 'getPickUpSet' });
  }, []);
  const handlePickUpSetChange = async (e) => {
    const {
      target: { value },
    } = e;
    if (value === 1) {
      const res = await services.checkPickUpSet();
      if (!res) {
        message.warning('无盘取数需在终端运行，终端的咨询与购买，请联系当地运营人员！');
        return;
      }
    }
    Modal.confirm({
      title: '确认切换所有账套的发票提取方式？',
      width: 284,
      centered: true,
      onOk() {
        dispatch({ type: 'updatePickUpSet', payload: { pickUpType: value } });
      },
    });
  };
  return (
    <ModuleItem
      title="发票提取方式"
      content={
        <div className="accountSetting-item-content-item">
          <div className="accountSetting-item-content-item-content">
            <Radio.Group value={pickUpSet} onChange={handlePickUpSetChange} disabled={!inAuth(509)}>
              <Radio value={0}>本地提取</Radio>
              <Radio value={1}>
                无盘提取
                <Popover
                  content="需在客户管理页面维护税号，以及客户信息-税务信息-电子税务局用户名密码"
                  placement="right"
                  overlayStyle={{ width: 312, fontSize: 13 }}
                >
                  <i className="iconfont icon-bangzhu" />
                </Popover>
              </Radio>
            </Radio.Group>
          </div>
        </div>
      }
    />
  );
};

InvoiceModule.propTypes = {
  pickUpSet: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ pickUpSet }) => ({ pickUpSet }))(InvoiceModule);
