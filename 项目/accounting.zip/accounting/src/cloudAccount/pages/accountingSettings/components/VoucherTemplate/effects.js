import { store } from 'nuomi';
import { message } from 'antd';
import TemplateOperation from '@/TemplateOperation';
import services from './services';

const voucherTypeMap = {
  1: '1',
  0: '2',
};

export default {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  },
  async onInit(params) {
    await this.getInvoiceSet();
    await this.getSubjectList(params);
    await this.getList();
  },
  async getSubjectList(params) {
    const data = await services.getSubjectList({ type: 0 });
    this.setState({
      subjectTemplateList: data.customList,
      selectTemplateId: params.subjectId || data.customList[0].subjectTemplateId,
      voucherAccount: params.voucherAccount || data.customList[0].accounting,
    });
  },
  // 获取凭证列表数据
  async getList() {
    const {
      current,
      pageSize,
      system,
      subjectId,
      summary,
      invoiceType,
      type,
      selectTemplateId,
      queryParam,
    } = this.getState();
    let data = {};
    this.setState({
      loading: true,
    });
    try {
      const params = {
        current,
        pCount: pageSize,
        system,
        subjectId,
        summary,
        invoiceType,
        type,
        templateId: selectTemplateId,
        queryParam,
      };
      // const isAllAccGovernment = this.checkIsAllAccGovernment();
      const { defaultActiveKey } = this.getState();
      data = await services.getList({ ...params, voucherType: voucherTypeMap[defaultActiveKey] });
    } finally {
      this.setState({
        loading: false,
        tableData: data.list,
        total: data.total,
        modifyInfo: data.editTime,
      });
    }
  },
  // 更改科目模板
  async subjectTemplateChange(params) {
    const { subjectTemplateList } = this.getState();
    const { accounting } = subjectTemplateList.find(
      ({ subjectTemplateId }) => subjectTemplateId === params,
    );
    const isGovernment = [14, 15].includes(accounting);
    await this.reset();
    await this.setState({
      selectTemplateId: params,
      voucherAccount: accounting,
      current: 1,
      subjectId: undefined,
      summary: '',
      invoiceType: '',
      queryParam: '',
      ...(isGovernment ? { type: 3 } : {}),
    });
    await this.getSubject();
    await this.getList();
  },
  // 更改凭证模板
  async changeType(params) {
    await this.reset();
    await this.setState({
      type: params,
      pCount: 15,
      current: 1,
      system: params === 4 ? '' : 1,
      subjectId: '',
      invoiceType: '',
      summary: '',
      defaultActiveKey: '1',
      queryParam: '',
    });
    await this.getList();
  },
  // 检查是否是政府会计制度，并且凭证模板类型是总账
  checkIsAllAccGovernment() {
    const { isDaizhang, voucherAccount, templateType, type } = this.getState();
    const {
      account: { accounting },
    } = store.getState();
    return (
      [14, 15].includes(isDaizhang ? voucherAccount : accounting) &&
      (isDaizhang ? type === 3 : templateType === 'allAcc')
    );
  },

  // 系统预置与自建之间转换
  async defaultActiveKeyChange(params) {
    await this.reset();
    const { defaultActiveKey } = params;
    await this.setState({
      defaultActiveKey,
      current: 1,
      system: !Number(defaultActiveKey) ? 0 : 1,
    });
    this.getList();
  },
  // 获取科目数据
  async getSubject(flag) {
    const { selectTemplateId, toAccountId, type } = this.getState();
    const data = await services.getSubject({
      subjectTemplateId: flag === 'share' ? toAccountId : selectTemplateId,
      type,
    });
    this.setState({
      subjectList: [
        {
          subjectId: '',
          code: '',
          codeName: '（空）',
          subjectName: '（空）',
        },
        ...data,
      ],
      replaceSubjectList: [
        ...[{ subjectId: '', subjectCode: '', codeName: '（空）', subjectName: '（空）' }],
        ...data,
      ],
    });
  },
  // 页码变动
  async pageChange(params) {
    const { current, pageSize } = params;
    await this.setState({
      current,
      pageSize,
    });
    await this.getList();
  },
  // 批量删除
  async batchAccDelete() {
    const { selectedRowKeys, type, selectTemplateId, total, pageSize, current } = this.getState();
    await services.batchAccDelete({
      ids: selectedRowKeys.join(','),
      subjectTemplateId: selectTemplateId,
      type,
    });
    message.success('操作成功');
    if ((total - selectedRowKeys.length) % pageSize === 0 && current !== 1) {
      this.setState({
        current: current - 1,
      });
    }
    this.getList();
  },
  // 更改搜索条件查询
  async filterChange(params) {
    const { subject, summary, invoiceTypes, queryParam } = params;
    await this.reset();
    await this.setState({
      current: 1,
      subjectId: subject,
      summary: summary || '',
      invoiceType: invoiceTypes?.join(',') || '',
      queryParam: queryParam || '',
    });
    await this.getList();
  },
  // 获取模板数据
  async getTemplateList() {
    const { selectTemplateId } = this.getState();
    const data = await services.getSubjectList({ type: 1, subjectTemplateId: selectTemplateId });
    this.setState({
      templateList: data.systemList,
      accountList: data.customList,
    });
  },
  async getVoucherTemplate(params) {
    const { type, defaultActiveKey } = this.getState();
    const data = await services.getVoucherTemplate({
      ...params,
      type,
      voucherType: voucherTypeMap[defaultActiveKey],
    });
    this.setState({
      importList: data,
    });
  },

  // 数据重置
  reset() {
    this.setState({
      isShowAddTplModal: false,
      isShowImportTplModal: false,
      isShowShareModal: false,
      isShowUpdateSubjectModal: false,
      selectedRowKeys: [],
    });
  },

  // 批量引入
  async batchImport(params) {
    const { type, selectTemplateId, importTableKeys, defaultActiveKey } = this.getState();
    const { sourceAccountId, templateSource, replaceSubjectList, isCover, ignoreMatch } = params;
    let data;
    if (ignoreMatch) {
      const newData = [];
      replaceSubjectList.forEach((item) => {
        newData.push({
          id: item.sourceTemplateId,
          voucherId: item.sourceTemplateLineId,
          subjectId: item.targetSubjectId,
        });
      });
      data = await services.batchImportCover({
        type,
        accounting: templateSource ? sourceAccountId : '',
        fromSubjectTemplateId: templateSource ? '' : sourceAccountId,
        system: templateSource,
        toSubjectTemplateId: selectTemplateId,
        ids: importTableKeys.join(','),
        importVoucherSubjectDTO: JSON.stringify(newData),
        voucherType: voucherTypeMap[defaultActiveKey],
      });
    }
    if (!isCover) {
      data = await services.batchImport({
        type,
        accounting: templateSource ? sourceAccountId : '',
        fromSubjectTemplateId: templateSource ? '' : sourceAccountId,
        system: templateSource,
        toSubjectTemplateId: selectTemplateId,
        ids: importTableKeys.join(','),
        voucherType: voucherTypeMap[defaultActiveKey],
      });
    }
    if (isCover && !ignoreMatch) {
      data = await services.batchImportCover({
        type,
        accounting: templateSource ? sourceAccountId : '',
        fromSubjectTemplateId: templateSource ? '' : sourceAccountId,
        system: templateSource,
        toSubjectTemplateId: selectTemplateId,
        ids: importTableKeys.join(','),
        voucherType: voucherTypeMap[defaultActiveKey],
      });
    }
    return data;
  },
  // 筛选数据用于显示
  filterOutSubjectList(params) {
    const { defaultOutSubjectList } = this.getState();
    let newData = [...defaultOutSubjectList];
    Object.keys(params).forEach((key) => {
      if (key === 'codeName') {
        newData = newData.filter((item) => {
          return (
            String(item.code).indexOf(params[key]) !== -1 || item.name.indexOf(params[key]) !== -1
          );
        });
      }
      if (key === 'out') {
        if (params[key]) {
          newData = newData.filter((item) => {
            return item.subjectId === params[key];
          });
        }
      }
      if (key === 'replace') {
        if (params[key]) {
          newData = newData.filter((item) => {
            return item.replace === params[key];
          });
        }
      }
    });
    this.setState({
      outSubjectList: newData,
    });
  },

  // 批量替换账外科目数据
  batchRepalceOutSubjectList(params) {
    const { outSujectKeys, defaultOutSubjectList, replaceSubjectList } = this.getState();
    const data = [...defaultOutSubjectList];
    const newData = replaceSubjectList.find((sub) => {
      return sub.subjectId === params.replace;
    });
    outSujectKeys.forEach((value) => {
      data.map((item) => {
        const trem = item;
        if (value === trem.myId) {
          trem.replace = newData.subjectId;
          trem.targetSubject = newData.codeName;
        }
        return trem;
      });
    });
    this.setState({
      outSubjectList: data,
      defaultOutSubjectList: data,
      outSujectKeys: [],
    });
  },
  // 更新账外科目列表数据
  updateOutSubjectList(record) {
    const { defaultOutSubjectList } = this.getState();
    const newData = [...defaultOutSubjectList];
    newData.map((item) => {
      const trem = item;
      if (trem.myId === record.myId) {
        trem.replace = record.replace;
        trem.targetSubject = record.targetSubject;
      }
      return trem;
    });
    this.setState({
      // outSubjectList: newData,
      defaultOutSubjectList: newData,
    });
  },

  // 编辑
  async onEdit(params) {
    const { isDaizhang, selectTemplateId, type } = this.getState();
    const { id } = params;
    const data = await services.getVoucherDetail({ id, type, subjectTemplateId: selectTemplateId });
    const that = this;
    TemplateOperation({
      isDaizhang,
      type: `${type}`,
      subjectTemplateId: selectTemplateId,
      getDatas: {
        templateLineList: data.lines?.map((item) => {
          const flag = { ...item };
          flag.sort = item.orderId;
          flag.accessMode = type === 3 ? '1' : item.valueType;
          return flag;
        }),
        isSystem: data.system ? 1 : 0,
        templateId: data.id,
        templateType: data.billType,
        templateName: data.name,
        helpCode: data.helpCode,
      },
      callback() {
        message.success('操作成功');
        that.getList();
      },
    });
  },

  // 批量修改
  async updateSubject(params) {
    const { isTemplate, newSubjectId, newSubjectName, oldSubjectId } = params;
    const { type, selectedRowKeys } = this.getState();
    await services.replaceSubject({
      type,
      subjectId: oldSubjectId,
      replaceSubjectId: newSubjectId,
      replaceSubjectName: type === 4 ? newSubjectName : undefined,
      isSummaryTemplate: isTemplate ? 1 : 0,
      ids: selectedRowKeys.join(','),
    });
    message.success('操作成功');
    this.getList();
  },

  // 代账层是否开启存货
  async getInvoiceSet() {
    const { inventorySwitch } = await services.getInvoiceSet();
    this.setState({
      isStock: !!inventorySwitch,
    });
  },

  // 获取可分享列表
  async getShareList() {
    const { selectTemplateId } = this.getState();
    const data = await services.getSubjectList({ type: 0, subjectTemplateId: selectTemplateId });
    this.setState({
      shareList: data.customList,
    });
  },

  // 分享模板
  async shareTemplate(params) {
    const {
      type,
      selectedRowKeys,
      toAccountId,
      selectTemplateId,
      defaultActiveKey,
    } = this.getState();
    const { replaceSubjectList, isCover, ignoreMatch } = params;
    let data;
    // 不存在帐外科目时
    if (!ignoreMatch) {
      // 没有重复时
      if (!isCover) {
        data = await services.batchImport(
          {
            type,
            ids: selectedRowKeys.join(','),
            toSubjectTemplateId: toAccountId,
            fromSubjectTemplateId: selectTemplateId,
            voucherType: voucherTypeMap[defaultActiveKey],
          },
          { returnAll: true },
        );
      } else {
        // 存在重复的时候
        data = await services.batchImportCover(
          {
            type,
            ids: selectedRowKeys.join(','),
            toSubjectTemplateId: toAccountId,
            fromSubjectTemplateId: selectTemplateId,
            voucherType: voucherTypeMap[defaultActiveKey],
          },
          { returnAll: true },
        );
      }
    } else {
      // 存在帐外科目时
      const newData = [];
      replaceSubjectList.forEach((item) => {
        newData.push({
          id: item.sourceTemplateId,
          voucherId: item.sourceTemplateLineId,
          subjectId: item.targetSubjectId,
        });
      });
      data = await services.batchImportCover(
        {
          type,
          fromSubjectTemplateId: selectTemplateId,
          toSubjectTemplateId: toAccountId,
          ids: selectedRowKeys.join(','),
          importVoucherSubjectDTO: JSON.stringify(newData),
          voucherType: voucherTypeMap[defaultActiveKey],
        },
        { returnAll: true },
      );
    }

    return data;
  },
};
