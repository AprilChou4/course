import React from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import { Button } from 'antd';
import Tables from './Tables';
import TemplateModal from './TemplateModal';
import './index.less';

const { inAuth } = window;
const AccountTemplate = ({ dispatch }) => {
  const handleAddClick = () => {
    dispatch({
      type: 'setState',
      payload: {
        showTemplateModal: true,
      },
    });
  };
  return (
    <>
      <div styleName="head">
        {inAuth && inAuth(509) && (
          <Button type="primary" onClick={handleAddClick}>
            新增
          </Button>
        )}
      </div>
      <div styleName="content">
        <Tables />
      </div>
      <TemplateModal />
    </>
  );
};

AccountTemplate.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

export default connect()(AccountTemplate);
