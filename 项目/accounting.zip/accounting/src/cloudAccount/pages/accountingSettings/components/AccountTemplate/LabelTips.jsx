import React from 'react';
import { Popover, List, Card } from 'antd';

const DATA = [
  {
    value: '小规模纳税人',
    title: '科目名称',
    content: [
      {
        title: '应交税费',
        children: [
          {
            title: '应交增值税',
          },
          {
            title: '转让金融商品应交增值税',
          },
          {
            title: '代扣代交增值税',
          },
        ],
      },
    ],
  },
  {
    value: '一般纳税人',
    title: '科目名称',
    content: [
      {
        title: '应交增值税',
        children: [
          {
            title: '进项税额',
          },
          {
            title: '销项税额抵减',
          },
          {
            title: '已交税金',
          },
          {
            title: '转出未交增值税',
          },
          {
            title: '减免税款',
          },
          {
            title: '出口抵减内销产品应纳税额',
          },
          {
            title: '销项税额',
          },
          {
            title: '出口退税',
          },
          {
            title: '进项税额转出',
          },
          {
            title: '转出多交增值税',
          },
        ],
      },
    ],
  },
];

const Content = () => {
  const renderContent = (data) =>
    data.map((item, index) => {
      const key = index;
      if (item.children) {
        return (
          <div key={key}>
            <p>{item.title}</p>
            <div>{renderContent(item.children)}</div>
          </div>
        );
      }
      return (
        <div key={key}>
          <p>{item.title}</p>
        </div>
      );
    });
  return (
    <div>
      <List
        grid={{ gutter: 16, column: 2 }}
        dataSource={DATA}
        renderItem={(item) => (
          <List.Item>
            <h1 style={{ color: '#000' }}>{item.value}：</h1>
            <Card title={item.title}>{renderContent(item.content)}</Card>
          </List.Item>
        )}
      />
    </div>
  );
};

const LabelTips = () => {
  return (
    <Popover
      placement="bottomLeft"
      content={<Content />}
      title="应交税费下关于增值税的科目设置不同"
      overlayClassName="label-tips-xb"
    >
      <i className="iconfont icon-bangzhu" />
    </Popover>
  );
};

export default LabelTips;
