import { message } from 'antd';
import services from './services';

export default {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  },
  // 获取列表数据
  async $getList() {
    const { current, pageSize } = this.getState();

    const data = await services.voucherPrintTemplateList({
      pageNum: current,
      pageSize,
    });
    const dataSource = data.list.map((ele, i) => {
      const item = ele;
      item.index = i + 1;
      item.key = ele.id;
      return item;
    });

    this.setState({ source: data.list, dataSource, total: Number(data.total) });
  },

  // 初始化页面
  async initData() {
    await this.$getList();
  },
  async setData(payload) {
    this.dispatch({
      type: 'updateState',
      payload,
    });
  },
  // 获得打印模板详情(编辑页面加载信息)
  async printTemplateInfo(id) {
    const data = await services.printTemplateInfo({
      id,
    });
    return data;
  },
  // 保存编辑打印模板
  async editPrintTemplate(payload) {
    try {
      const data = await services.editPrintTemplate(payload);
      return data;
    } catch (res) {
      return res;
    }
  },
  // 保存新增打印模板
  async saveNewPrintTemplate(payload) {
    try {
      const data = await services.saveNewPrintTemplate(payload);
      return data;
    } catch (res) {
      return res;
    }
  },
  async query(payload) {
    this.setData({
      // loading: true,
      ...payload,
    });
    await this.$getList();
  },
  // 转跳到打印前验证模板是否停用或者被删除
  async checkPrintTemplate(payload) {
    const data = await services.checkPrintTemplate({
      id: payload.id,
    });
    return data;
  },

  // 检查模板名称是否可用
  async checkTemplateName(payload) {
    try {
      const data = await services.checkTemplateName({
        id: payload.id,
        name: payload.name,
      });
      return data;
    } catch (res) {
      return res;
    }
  },

  // 删除打印模板
  async deletePrintTemplate(payload) {
    const { id } = payload;
    const data = await services.deletePrintTemplate({
      id,
    });
    return data;
  },

  // 恢复内置打印模板默认参数
  async recoverPrintTemplate(payload) {
    const { id, name } = payload;
    const data = await services.recoverPrintTemplate({
      id,
      name,
    });
    return data;
  },

  // 引入模板前校验是否有重名覆盖
  async checkImportPrintTemplateName(payload) {
    const data = await services.checkImportPrintTemplateName(payload);

    return data;
  },

  // 获取公司级模板列表
  async getCompanyPrintTemplate() {
    const data = await services.getCompanyPrintTemplate();

    return data;
  },

  // 引入公司级模板
  async importCompanyPrintTemplate(payload) {
    const data = await services.importCompanyPrintTemplate(payload);

    return data;
  },

  async activateOrDeactivate(payload) {
    const { id, type } = payload;
    try {
      const data = await services[type]({
        printSettingId: id,
      });
      return data;
    } catch (res) {
      return res;
    }
  },
  // 以下最新的打印========================================================================
  async updatePagination(state) {
    const { paginationProps } = this.getState();
    await this.dispatch({
      type: 'updateState',
      payload: {
        paginationProps: {
          ...paginationProps,
          ...state,
        },
      },
    });
    await this.paginationChange();
  },
  async $getNewList() {
    const {
      paginationProps,
      selectedPrintSetupMenu: { key: menuKey },
    } = this.getState();
    const data = await services.listTplWorkbook(
      {
        tplSource: 1,
        tplType: menuKey,
      },
      {
        loading: true,
      },
    );
    const dataSource = (data || []).map((ele, i) => {
      const item = ele;
      item.index = i + 1;
      item.key = ele.tplWorkbookId;
      return item;
    });

    await this.dispatch({
      type: 'updateState',
      payload: {
        dataSourceOriginal: dataSource,
        paginationProps: {
          ...paginationProps,
          total: 0,
        },
      },
    });
    await this.paginationChange();
  },
  async paginationChange() {
    const { dataSourceOriginal, paginationProps } = this.getState();
    const { pageSize } = paginationProps;
    let { current } = paginationProps;
    let begin = (current - 1) * pageSize;
    let end = current * pageSize;
    let dataSource = [];
    if (dataSourceOriginal.length > 0) {
      if (begin >= dataSourceOriginal.length) {
        current = Math.ceil(dataSourceOriginal.length / pageSize);
        begin = (current - 1) * pageSize;
        end = current * pageSize;
      }
      dataSource = dataSourceOriginal.slice(begin, end);
    }
    this.dispatch({
      type: 'updateState',
      payload: {
        dataSource,
        paginationProps: {
          ...paginationProps,
          current,
          total: dataSourceOriginal.length,
        },
      },
    });
  },

  async getSharedTemplateList(state) {
    const { sharePaginationProps } = this.getState();
    const data = await services.getSharedTemplateList(state);
    const dataSource = data.map((ele, i) => {
      const item = ele;
      item.index = i + 1;
      item.key = ele.tplWorkbookId;
      return item;
    });

    await this.dispatch({
      type: 'updateState',
      payload: {
        shareDataSourceOriginal: dataSource,
        sharePaginationProps: {
          ...sharePaginationProps,
          total: 0,
        },
      },
    });
    await this.sharePaginationChange();
  },

  async sharePaginationChange() {
    const { shareDataSourceOriginal, sharePaginationProps } = this.getState();
    const { current, pageSize } = sharePaginationProps;
    const begin = (current - 1) * pageSize;
    const end = current * pageSize;
    let shareDataSource = [];
    if (shareDataSourceOriginal.length > 0) {
      shareDataSource = shareDataSourceOriginal.slice(begin, end);
    }
    this.dispatch({
      type: 'updateState',
      payload: {
        shareDataSource,
        sharePaginationProps: {
          ...sharePaginationProps,
          total: shareDataSourceOriginal.length,
        },
      },
    });
  },

  async templateDetail(state) {
    const { tplWorkbookId, type } = state;
    const data = await services.templateDetail({ tplWorkbookId });
    const { tplSource, isShare } = data;
    let { tplName } = data;
    tplName = `${type === 'add' ? '' : tplName}${type === 'copy' ? '（复制）' : ''}`;
    this.dispatch({
      type: 'updateState',
      payload: {
        templateDetails: {
          ...data,
          tplWorkbookId: ['update', 'show'].includes(type) ? tplWorkbookId : '',
          tplSource: ['update', 'show'].includes(type) ? tplSource : 1,
          tplName: tplName.slice(0, 20),
          isShare: ['copy', 'add'].includes(type) ? false : isShare,
        },
        printDetailVisible: type,
      },
    });
  },

  async enableTemplate(args) {
    const { state } = args;
    await services.enableTemplate({ ...args, tplSource: 1 });
    message.success(`模板已${['停用', '启用'][state]}！`);
    await this.$getNewList();
  },

  async delTemplate(state) {
    await services.delTemplate({ ...state, tplSource: 1 });
    message.success('删除成功');
    await this.$getNewList();
  },

  async updateTplWorkbook(state) {
    const { tplWorkbookId, tplName, tplType, tplSource, style, setting, isShare, type } = state;
    await services.updateTplWorkbook(
      {
        tplWorkbookId,
        tplName,
        tplType,
        tplSource,
        style,
        setting,
        isShare,
      },
      {
        loading: true,
      },
    );
    type !== 'preview' && message.success('保存成功');
    return tplWorkbookId;
  },

  async saveTplWorkbook(state) {
    const { tplName, tplType, style, setting, isShare, type } = state;
    const { templateDetails } = this.getState();
    const data = await services.saveTplWorkbook(
      {
        tplName,
        tplType,
        tplSource: 1,
        style,
        setting,
        isShare,
      },
      {
        loading: true,
      },
    );
    this.dispatch({
      type: 'updateState',
      payload: {
        templateDetails: {
          ...templateDetails,
          tplWorkbookId: data,
        },
      },
    });
    type !== 'preview' && message.success('保存成功');
    return data;
  },
};
