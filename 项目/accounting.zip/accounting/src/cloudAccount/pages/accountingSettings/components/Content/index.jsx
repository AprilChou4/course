import React from 'react';
import { connect, Nuomi } from 'nuomi';
import { PropTypes } from 'prop-types';
import AccountTemplate from '../AccountTemplate';
import VoucherTemplate from '../VoucherTemplate';
import BookKeepingSetting from '../BookKeepingSetting';
import PrintSetting from '../PrintSetting';

import './index.less';

const Content = ({ type, subjectId, voucherAccount }) => {
  return (
    <div styleName="content">
      {type === 1 && <AccountTemplate />}
      {type === 2 && (
        <Nuomi {...VoucherTemplate} subjectId={subjectId} voucherAccount={voucherAccount} />
      )}
      {type === 3 && <BookKeepingSetting />}
      {type === 4 && <Nuomi {...PrintSetting} />}
    </div>
  );
};

Content.defaultProps = {
  voucherAccount: undefined,
};

Content.propTypes = {
  type: PropTypes.number.isRequired,
  subjectId: PropTypes.string.isRequired,
  voucherAccount: PropTypes.number,
};

export default connect(({ type, subjectId, voucherAccount }) => ({
  type,
  subjectId,
  voucherAccount,
}))(Content);
