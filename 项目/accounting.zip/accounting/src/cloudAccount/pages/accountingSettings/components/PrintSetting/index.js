import defaultProps from '../../../../../platform/pages/systemSetting/index';
import { printState } from '../../state/printState';
import effects from './effects';

export default {
  ...defaultProps,
  state: {
    ...defaultProps.state,
    ...printState,
  },
  effects,
};
