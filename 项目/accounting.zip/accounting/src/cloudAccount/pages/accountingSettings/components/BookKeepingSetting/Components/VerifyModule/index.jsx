import React, { useEffect, useState } from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import { Checkbox, Button, Modal } from 'antd';
import ModuleItem from '../ModuleItem';
import VerifyModal from './VerifyModal';

const { inAuth } = window;

const VerifyModule = ({ dispatch, needVerify, accountList }) => {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    dispatch({ type: 'getVerifySet' });
  }, []);
  const afterChange = (type, params) => {
    dispatch({
      type: 'updateVerifySet',
      payload: { ...params, isEffectOld: type },
    }).then(() => {
      setVisible(false);
    });
  };
  const confirm = (params) => {
    Modal.confirm({
      title: '是否同时修改历史账套审核设置？',
      content: (
        <>
          “是” 表示同时对历史账套和新增账套生效
          <br />
          “否” 表示只对新增账套生效
        </>
      ),
      okText: '是',
      cancelText: '否',
      centered: true,
      width: 336,
      onOk() {
        afterChange(1, params);
      },
      onCancel() {
        afterChange(0, params);
      },
    });
  };
  const handleCheckChange = () => {
    confirm({ needVerify: !needVerify, verifyType: 0 });
  };
  const handleOnOk = (data) => {
    const newData = JSON.parse(JSON.stringify(data));
    const { bookkeepingStaffIds } = data;
    const arr = [];
    if (
      bookkeepingStaffIds &&
      bookkeepingStaffIds.length === 1 &&
      bookkeepingStaffIds[0] === 'all'
    ) {
      accountList.forEach(({ staffId }) => {
        arr.push(staffId);
      });
      newData.bookkeepingStaffIds = arr;
    }
    confirm({ needVerify: 1, ...newData });
  };
  return (
    <ModuleItem
      title="是否需要审核"
      content={
        <div className="accountSetting-item-content-item">
          <div className="accountSetting-item-content-item-title">
            开启后月末结账前，当前凭证必须经过审核
          </div>
          <Checkbox checked={needVerify} onChange={handleCheckChange} disabled={!inAuth(509)}>
            开启审核控制
          </Checkbox>
          {!!needVerify && (
            <Button
              type="link"
              onClick={() => {
                setVisible(true);
              }}
            >{`审核控制设置>>`}</Button>
          )}
          {visible && (
            <VerifyModal
              visible={visible}
              onCancel={() => {
                setVisible(false);
              }}
              onOk={handleOnOk}
            />
          )}
        </div>
      }
    />
  );
};

VerifyModule.propTypes = {
  dispatch: PropTypes.func.isRequired,
  needVerify: PropTypes.bool.isRequired,
  accountList: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect(({ needVerify, accountList }) => ({ needVerify, accountList }))(
  VerifyModule,
);
