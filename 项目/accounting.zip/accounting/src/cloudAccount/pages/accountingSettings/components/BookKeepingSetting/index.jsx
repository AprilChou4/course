import React from 'react';
import VerifyModule from './Components/VerifyModule';
import CheckoutModule from './Components/CheckoutModule';
import InvoiceModule from './Components/InvoiceModule';
import MenusModule from './Components/MenusModule';
import './index.less';

const BookKeepingSetting = () => {
  return (
    <div styleName="book-keeping-setting">
      <VerifyModule />
      <CheckoutModule />
      <InvoiceModule />
      <MenusModule />
    </div>
  );
};

export default BookKeepingSetting;
