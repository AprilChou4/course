import React, { useRef } from 'react';
import { connect } from 'nuomi';
import { Modal } from 'antd';
import { PropTypes } from 'prop-types';
import TemplateForm from './TemplateForm';

const TemplateModal = ({ showTemplateModal, dispatch }) => {
  const templateForm = useRef(null);
  const handleCancel = () => {
    dispatch({ type: 'setState', payload: { showTemplateModal: false } });
  };
  const handleOnOk = () => {
    templateForm.current.validateFields((errors, values) => {
      if (errors) return;
      dispatch({ type: 'add', payload: { ...values } });
    });
  };
  return (
    showTemplateModal && (
      <Modal
        title="新增科目模板"
        visible={showTemplateModal}
        width={730}
        centered
        onCancel={handleCancel}
        maskClosable={false}
        onOk={handleOnOk}
        className="template-modal-xb"
      >
        <TemplateForm ref={templateForm} />
      </Modal>
    )
  );
};
TemplateModal.propTypes = {
  showTemplateModal: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ showTemplateModal }) => ({ showTemplateModal }))(TemplateModal);
