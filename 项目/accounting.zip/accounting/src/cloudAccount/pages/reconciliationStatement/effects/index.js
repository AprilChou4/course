import { message } from 'antd';
import reconciliationStatement from 'crservices/reconciliationStatement';
import statisticalTable from 'crservices/statisticalTable';

export default {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  },
  services() {
    const { invoiceType } = this.getState();
    if (invoiceType === 'statisticalTable') {
      return statisticalTable;
    }
    return reconciliationStatement;
  },
  // 更新公式
  async updateFormula(subData) {
    await this.services().updateFormula(subData);
    message.success('保存成功');
    this.setState({
      isShowEditFormula: false,
    });
    this.getList();
  },
  // 获取科目
  async getSubjectList(data) {
    const res = await this.services().getSubjectList(data);
    return res;
  },
  // 获取公式
  async getFormulaList(data) {
    const res = await this.services().getFormulaList(data);
    const subjectList = await this.getSubjectList({
      accountId: data.accountId,
    });
    this.setState({
      isShowEditFormula: true,
      formulaList:
        res.map((val, index) => {
          return {
            ...val,
            id: `${index + 1}`,
          };
        }) || [],
      subjectList,
      ...data,
    });
    // console.log(res);
  },
  // 修改表头
  async updateColumn(subData) {
    await this.services().updateColumn(subData);
    message.success('保存成功');
    this.setState({
      isShowSettings: false,
    });
    this.getList();
  },
  // 初始化编号
  initialization(index, length) {
    // 位数
    const newLength = `${length}`.length > 3 ? `${length}`.length : 3;
    // 序号
    let newIndex = `${index + 1}`;
    for (let i = newIndex.length; i < newLength; i++) {
      newIndex = `0${newIndex}`;
    }
    return newIndex;
  },
  // 获取列表
  async getList(datas) {
    this.setState({ spinning: true });
    const date = this.getState().date.split('-');
    const subData = datas || {
      year: date[0],
      month: date[1],
    };
    try {
      const res = await this.services().getList(subData);
      const newDataSource = res.dataList.map((val, index) => {
        const addSource = {};
        res.colList.forEach((v) => {
          addSource[v.id] = val.amtMap[v.id];
        });
        return {
          ...val,
          ...addSource,
          total: val.amtMap['合计'],
          sort: this.initialization(index, res.dataList.length - 1),
        };
      });
      const summaryData = newDataSource.slice(newDataSource.length - 1, newDataSource.length);
      const dataSource = newDataSource.slice(0, newDataSource.length - 1);
      this.setState({
        spinning: false,
        dataSource,
        summaryData,
        titList: res.colList.length > 0 ? res.colList : [{ id: '' }],
      });
    } catch {
      this.setState({
        spinning: false,
      });
    }
  },
  // 初始化
  async initData() {
    const date = this.getState().date.split('-');
    const subData = {
      year: date[0],
      month: date[1],
    };
    await this.getList(subData);
    // console.log(123);
  },
};
