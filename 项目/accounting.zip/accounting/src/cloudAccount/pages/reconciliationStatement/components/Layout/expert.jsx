import React from 'react';
import { connect } from 'nuomi';
import util from 'util';
import { Button } from 'antd';

const Main = ({ date, expert }) => {
  const exportCallback = () => {
    util.submit(
      expert,
      { year: date.split('-')[0], month: date.split('-')[1] },
      '_blank',
      'download',
    );
  };
  return (
    <Button type="primary" onClick={exportCallback} ghost>
      导出
    </Button>
  );
};

export default connect(({ date, expert }) => ({
  date,
  expert,
}))(Main);
