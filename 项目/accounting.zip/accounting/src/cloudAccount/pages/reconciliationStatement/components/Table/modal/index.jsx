import React from 'react';
import { connect } from 'nuomi';
import DisplaySettings from 'crPublic/DisplaySettings';
import EditFormula from 'crPublic/EditFormula';

const Modal = ({
  isShowSettings,
  isShowEditFormula,
  titList,
  formulaList,
  subjectList,
  accountId,
  colId,
  invoiceType,
  dispatch,
}) => {
  const onCancel = (type) => {
    dispatch({
      type: 'setState',
      payload: {
        [type]: false,
      },
    });
  };
  const onSave = (data) => {
    dispatch({
      type: 'updateColumn',
      payload: data,
    });
  };
  const formulaSave = (data) => {
    dispatch({
      type: 'updateFormula',
      payload: {
        accountId,
        colId,
        lines: data,
      },
    });
  };

  return (
    <>
      {isShowSettings && (
        <DisplaySettings
          isShowSettings={isShowSettings}
          titList={titList}
          type={
            invoiceType === 'statisticalTable'
              ? 'constructionGetDefaultCols'
              : 'checkStatementGetDefaultCols'
          }
          onSave={onSave}
          onCancel={() => onCancel('isShowSettings')}
        />
      )}
      {isShowEditFormula && (
        <EditFormula
          isShowEditFormula={isShowEditFormula}
          formulaList={formulaList}
          subjectList={subjectList}
          onSave={formulaSave}
          onCancel={() => onCancel('isShowEditFormula')}
        />
      )}
    </>
  );
};

export default connect(
  ({
    isShowSettings,
    isShowEditFormula,
    titList,
    formulaList,
    subjectList,
    accountId,
    colId,
    invoiceType,
  }) => ({
    isShowSettings,
    isShowEditFormula,
    titList,
    formulaList,
    subjectList,
    accountId,
    colId,
    invoiceType,
  }),
)(Modal);
