import React from 'react';
import { connect } from 'nuomi';
import useRefresh from 'crPublic/hooks/useRefresh';
import { Layout, Head, Center, Content, Left, Right, Title } from '@/Layout';
import MonthPicker from './MonthPicker';
import Table from '../Table';
import Spin from './spin';
import Expert from './expert';
import './style/index.less';

const Main = () => {
  useRefresh();
  return (
    <div styleName="reconciliation-statement">
      <Layout>
        <Head>
          <Center>
            <Title />
          </Center>
          <Left>
            <MonthPicker />
          </Left>
          <Right>
            <Expert />
          </Right>
        </Head>
        <Content>
          <Table />
        </Content>
        <Spin />
      </Layout>
    </div>
  );
};

export default connect()(Main);
