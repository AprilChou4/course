import React from 'react';
import { connect } from 'nuomi';
import { Spin } from 'antd';

const Spins = ({ spinning }) => {
  return (
    spinning && (
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: '99',
          paddingTop: 150,
          textAlign: 'center',
          background: '#ffffff',
          opacity: '0.7',
        }}
      >
        <Spin tip="正在加载中..." spinning={spinning} />
      </div>
    )
  );
};

export default connect(({ spinning }) => ({
  spinning,
}))(Spins);
