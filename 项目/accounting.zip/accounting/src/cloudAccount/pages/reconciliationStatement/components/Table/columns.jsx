import React from 'react';
import Icon from 'Icon';
import { Tooltip } from 'antd';
import currency from 'currency.js';
import TableCell from '@/TableCell';

export default ({ titList, setState, editFormula }) => {
  const fixed = (text, f = 2, showZero) => {
    const defaultValue = showZero ? '0.00' : '';
    const returnText = text ? currency(text, { precision: f }).format() : defaultValue;
    if (text < 0) {
      return <em style={{ color: 'red' }}>{returnText.replace('-', '')}</em>;
    }
    return returnText;
  };

  let columns = [
    {
      title: '序号',
      dataIndex: 'sort',
      width: 60,
      minWidth: 60,
      align: 'center',
      render: (text, record) => {
        return record.isTotalRow ? '合计' : text;
      },
    },
    {
      title: '公司',
      dataIndex: 'accountName',
      width: 180,
      align: 'left',
      render: (text, record) => {
        return record.isTotalRow ? '' : <TableCell>{text}</TableCell>;
      },
    },
  ];

  const addList = [];
  titList.forEach((val) => {
    if (val.isEnable) {
      addList.push({
        title: val.name,
        dataIndex: val.id,
        width: 120,
        align: 'right',
        render: (text, record) => {
          return record.isTotalRow ? (
            <TableCell>{fixed(text)}</TableCell>
          ) : (
            <div className="ui-td-posi">
              <Icon
                className="ui-calculator"
                onClick={() => editFormula(record.accountId, val.id)}
              />
              <TableCell>{fixed(text)}</TableCell>
            </div>
          );
        },
      });
    }
  });

  addList.push({
    title: (
      <div>
        <span>合计</span>
        <Tooltip placement="bottom" title="显示列设置">
          <Icon
            onClick={() =>
              setState({
                isShowSettings: true,
              })
            }
            type="zidingyixianshi"
            style={{ float: 'right' }}
          />
        </Tooltip>
      </div>
    ),
    className: 'ui-total',
    dataIndex: 'total',
    align: 'right',
    width: 120,
    minWidth: 120,
    render: (text) => {
      return <TableCell>{fixed(text)}</TableCell>;
    },
  });
  columns = columns.concat(addList);
  return columns;
};
