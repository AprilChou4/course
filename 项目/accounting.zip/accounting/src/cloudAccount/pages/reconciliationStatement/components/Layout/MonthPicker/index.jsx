import React from 'react';
import { connect } from 'nuomi';
import moment from 'moment';
import MonthPicker from 'crPublic/MonthPicker';

const Main = ({ date, dispatch }) => {
  const onChange = (e) => {
    const newDate = moment(e).format('YYYY-MM');
    dispatch({
      type: 'getList',
      payload: {
        year: newDate.split('-')[0],
        month: newDate.split('-')[1],
      },
    });
    dispatch({
      type: 'setState',
      payload: {
        date: newDate,
      },
    });
  };
  return <MonthPicker onChange={onChange} value={moment(date)} />;
};

export default connect(({ date }) => ({
  date,
}))(Main);
