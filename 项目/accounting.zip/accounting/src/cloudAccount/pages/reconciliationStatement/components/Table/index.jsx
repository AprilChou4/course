// import React, { useEffect } from 'react';
import React, { useRef } from 'react';
import SuperTable from 'SuperTable';
import { connect } from 'nuomi';
import useSummaryTableScroll from 'hooks/useSummaryTableScroll';
import columns from './columns';
import Moadl from './modal';

const Tables = ({ dataSource, summaryData, titList, dispatch }) => {
  const footerTableRef = useRef(null);
  const tableRef = useRef(null);
  const setState = (data) => {
    dispatch({
      type: 'setState',
      payload: data,
    });
  };
  const editFormula = (accountId, id) => {
    dispatch({
      type: 'getFormulaList',
      payload: {
        accountId,
        colId: id,
      },
    });
  };
  const col = columns({
    titList,
    setState,
    editFormula,
  });
  useSummaryTableScroll(tableRef, footerTableRef, dataSource);
  return (
    <>
      <SuperTable
        ref={tableRef}
        id="reconciliationStatements"
        className="ui-table summary-table"
        rowKey="accountId"
        bordered
        pagination={false}
        columns={col}
        scroll={{ x: '100%', y: '100%' }}
        dataSource={dataSource}
        footer={() => (
          <SuperTable
            className={dataSource.length === 0 ? 'f-dn' : ''}
            ref={footerTableRef}
            columns={col}
            dataSource={summaryData}
            pagination={false}
            showHeader={false}
            rowKey="accountId"
            // scroll={{ x: '100%' }}
            // isSummaryTable
          />
        )}
      />
      <Moadl />
    </>
  );
};

export default connect(({ dataSource, summaryData, titList }) => ({
  dataSource,
  summaryData,
  titList,
}))(Tables);
