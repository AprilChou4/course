import React from 'react';
import moment from 'moment';
import Layout from './components/Layout';
import effects from './effects';

export default {
  state: {
    spinning: false,
    title: '核算中心对账表',
    // 是否显示 ‘显示列设置’ 弹层
    isShowSettings: false,
    // 是否显示 ‘编辑公式’ 弹层
    isShowEditFormula: false,
    // 默认日期 (自然月的上一个月)
    date: moment().endOf('day').subtract(1, 'months').format('YYYY-MM'),
    // 默认数据
    dataSource: [],
    // 底部数据
    summaryData: [],
    // 表头数据
    titList: [{ id: '' }],
    // 获取的公式数据
    formulaList: [],
    // 当前选择的账套科目
    subjectList: [],
    // 编辑公式的id
    accountId: '',
    // 编辑公式的列id
    colId: '',
    expert: 'report/py/checkStatement/export',
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    this.store.dispatch({ type: 'initData' });
  },
};
