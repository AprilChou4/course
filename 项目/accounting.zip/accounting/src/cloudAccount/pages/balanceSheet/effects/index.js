import { message } from 'antd';
import services from 'crservices/balanceSheet';

export default {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  },
  // 更新公式
  async updateFormula(subData) {
    await services.updateFormula(subData);
    message.success('保存成功');
    this.setState({
      isShowEditFormula: false,
    });
    this.setList();
  },
  // 获取项目账套的报表项目
  async getAccountItemList(data) {
    const res = await services.getAccountItemList(data);
    return res;
  },
  // 获取单个企业的账套列表
  async getItemAccountList(data) {
    const res = await services.getItemAccountList(data);
    return res;
  },
  // 获取公式
  async getFormulaList(data) {
    const res = await services.getFormulaList(data);
    return res;
  },
  // 获取公式列表、账套列表和报表项目列表  --- 和 ---
  async getAccountItem(data) {
    const formulaSub = { ...data };
    const listSub = { accountId: data.accountId };
    const datas = await Promise.all([
      this.getFormulaList(formulaSub),
      this.getItemAccountList(listSub),
      this.getAccountItemList(listSub),
    ]);
    // const itemList = datas[2].map((val) => {
    //   return {
    //     name: val,
    //   };
    // });
    this.setState({
      formulaList:
        datas[0].map((val, index) => {
          return {
            ...val,
            id: `${index + 1}`,
          };
        }) || [],
      itemAccountList: datas[1],
      itemList: datas[2],
      isShowEditFormula: true,
      rowNumber: data.rowNumber,
    });
  },
  // 获取列表
  async $getList(datas = {}) {
    const { date, accountId, isContainItemData } = this.getState();
    const dates = date.split('-');
    const subData = {
      year: dates[0],
      month: dates[1],
      accountId,
      isContainItemData,
      ...datas,
    };
    const res = await services.getList(subData);
    return res;
  },
  // 更新列表
  async setList(data) {
    const listData = await this.$getList(data);
    this.setState({
      dataSource: listData.list,
      editableRowList: listData.editableRowList,
      ...data,
    });
  },
  // 获取会计期间
  async getPeriods(data) {
    const periods = await services.getPeriods(data);
    return periods;
  },
  // 选择公司账套列表
  async getListPeriods(data) {
    const { isContainItemData } = this.getState();
    const periods = await this.getPeriods(data);
    const listData = await this.$getList({
      year: periods.curPeriod.split('-')[0],
      month: periods.curPeriod.split('-')[1],
      isContainItemData,
      ...data,
    });
    this.setState({
      periods: periods.periods,
      date: periods.curPeriod,
      dataSource: listData.list,
      editableRowList: listData.editableRowList,
      ...data,
    });
  },
  // 获取公司账套列表
  async getCompanyAccountList() {
    const { isContainItemData } = this.getState();
    const res = await services.getCompanyAccountList();
    const periods = await this.getPeriods({
      accountId: res[0].accountId,
    });
    const listData = await this.$getList({
      year: periods.curPeriod.split('-')[0],
      month: periods.curPeriod.split('-')[1],
      accountId: res[0].accountId,
      isContainItemData,
    });
    this.setState({
      accountList: res,
      accountId: res[0].accountId,
      accounting: res[0].accounting,
      periods: periods.periods,
      date: periods.curPeriod,
      dataSource: listData.list,
      editableRowList: listData.editableRowList,
    });
  },
  // 初始化
  async initData() {
    await this.getCompanyAccountList();
  },
};
