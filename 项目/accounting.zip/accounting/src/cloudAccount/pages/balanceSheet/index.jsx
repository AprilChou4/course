import React from 'react';
import moment from 'moment';
import Layout from './components/Layout';
import effects from './effects';

export default {
  state: {
    // 公司账套列表
    accountList: [],
    // 账套id
    accountId: '',
    // 会计制度
    accounting: '',
    // 当前编辑行
    rowNumber: '',
    // 包含项目公司账套数据(默认true)
    isContainItemData: true,
    // 会计期间
    periods: [],
    // 当前期间
    date: moment().endOf('day').subtract(1, 'months').format('YYYY-MM'),
    // 表格列表数据
    dataSource: [],
    // 可编辑行列表
    editableRowList: [],

    // 公式列表
    formulaList: [],
    // 账套列表
    itemAccountList: [],
    // 项目列表
    itemList: [],
    // 是否显示编辑弹层
    isShowEditFormula: false,
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    this.store.dispatch({ type: 'initData' });
  },
};
