import React from 'react';
import Icon from 'Icon';
import currency from 'currency.js';
import TableCell from '@/TableCell';

export default ({ editFormula, editableRowList, isContainItemData }) => {
  const fixed = (text, f = 2, showZero) => {
    const defaultValue = showZero ? '0.00' : '';
    const returnText = text ? currency(text, { precision: f }).format() : defaultValue;
    if (text < 0) {
      return <em style={{ color: 'red' }}>{returnText.replace('-', '')}</em>;
    }
    return returnText;
  };
  const preSpace = (val = '', flag = false, fn) => {
    // flag启用标签
    const len = val.length;
    const value = val.trimLeft();
    const str = flag ? (
      // eslint-disable-next-line
      <a className="a-link" pointerEvents="auto" onClick={fn}>
        {value}
      </a>
    ) : (
      value
    );
    const px = `${(len - value.length) * 4}px`;
    return (
      <em
        style={{
          paddingLeft: px,
        }}
      >
        {value}
      </em>
    );
    // return {
    //   paddingLeft: px,
    // };
    // return (
    //   <div style={{ paddingLeft: px }} className="a-link-p">
    //     {str}
    //   </div>
    // );
    //    return val.padStart( len - val.length, '&nbsp;' ); // 有坑
  };
  const columns = [
    {
      title: '资产',
      dataIndex: 'name',
      width: 200,
      align: 'left',
      render: (text, record) => {
        return (
          <div className="ui-td-posi">
            {editableRowList.indexOf(record.rowNumber) !== -1 && isContainItemData && (
              <Icon className="ui-calculator" onClick={() => editFormula(record.rowNumber)} />
            )}
            <TableCell>{preSpace(text)}</TableCell>
          </div>
        );
      },
    },
    {
      title: '行次',
      dataIndex: 'rowNumber',
      width: 46,
      align: 'center',
    },
    {
      title: '期末金额',
      dataIndex: 'balanceAmt',
      width: 107,
      align: 'right',
      render: (text) => {
        return <TableCell>{fixed(text)}</TableCell>;
      },
    },
    {
      title: '年初余额',
      dataIndex: 'yearInitAmt',
      width: 107,
      align: 'right',
      render: (text) => {
        return <TableCell>{fixed(text)}</TableCell>;
      },
    },
    {
      title: '负债和所有者权益',
      dataIndex: 'name1',
      width: 200,
      align: 'left',
      render: (text, record) => {
        return (
          <div className="ui-td-posi">
            {editableRowList.indexOf(record.rowNumber1) !== -1 && isContainItemData && (
              <Icon className="ui-calculator" onClick={() => editFormula(record.rowNumber1)} />
            )}
            <TableCell>{preSpace(text)}</TableCell>
          </div>
        );
      },
    },
    {
      title: '行次',
      dataIndex: 'rowNumber1',
      width: 46,
      align: 'center',
    },
    {
      title: '期末金额',
      dataIndex: 'balanceAmt1',
      width: 107,
      align: 'right',
      render: (text) => {
        return <TableCell>{fixed(text)}</TableCell>;
      },
    },
    {
      title: '年初余额',
      dataIndex: 'yearInitAmt1',
      width: 107,
      align: 'right',
      render: (text) => {
        return <TableCell>{fixed(text)}</TableCell>;
      },
    },
  ];
  return columns;
};
