import React from 'react';
import { connect } from 'nuomi';
import EditFormula from 'crPublic/EditFormula';

const Modal = ({
  isShowEditFormula,
  formulaList,
  itemAccountList,
  itemList,
  accountId,
  rowNumber,
  dispatch,
}) => {
  const onCancel = (type) => {
    dispatch({
      type: 'setState',
      payload: {
        [type]: false,
      },
    });
  };
  const formulaSave = (data) => {
    dispatch({
      type: 'updateFormula',
      payload: {
        accountId,
        rowNumber,
        lines: data,
      },
    });
  };
  return (
    <>
      {isShowEditFormula && (
        <EditFormula
          isShowEditFormula={isShowEditFormula}
          type={2}
          tableProps={{
            width: 680,
          }}
          formulaList={formulaList}
          subjectList={itemAccountList}
          itemList={itemList}
          onSave={formulaSave}
          onCancel={() => onCancel('isShowEditFormula')}
        />
      )}
    </>
  );
};

export default connect(
  ({
    isShowSettings,
    isShowEditFormula,
    formulaList,
    itemAccountList,
    itemList,
    accountId,
    rowNumber,
  }) => ({
    isShowSettings,
    isShowEditFormula,
    formulaList,
    itemAccountList,
    itemList,
    accountId,
    rowNumber,
  }),
)(Modal);
