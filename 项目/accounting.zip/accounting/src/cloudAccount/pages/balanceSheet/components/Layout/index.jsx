import React from 'react';
import { connect } from 'nuomi';
import util from 'util';
import useRefresh from 'crPublic/hooks/useRefresh';
import { Layout, Head, Center, Content, Left, Right } from '@/Layout';
import { Button, Checkbox } from 'antd';
import { SearchSelect } from '@/selects';
import MonthPicker from './MonthPicker';
import Table from '../Table';
import Print from './print';
import './style/index.less';

const Main = ({ accountList, accountId, dispatch, date, isContainItemData }) => {
  useRefresh();
  const onChange = async (e) => {
    await dispatch({
      type: 'setList',
      payload: {
        isContainItemData: e.target.checked,
      },
    });
  };
  const exportCallback = () => {
    util.submit(
      'report/py/balanceSheet/export',
      { accountId, isContainItemData, year: date.split('-')[0], month: date.split('-')[1] },
      '_blank',
      'download',
    );
  };

  return (
    <div styleName="reconciliation-statement">
      <Layout>
        <Head>
          <Center>资产负债表</Center>
          <Left>
            <SearchSelect
              placeholder="请选择账套"
              showSearch
              value={accountId}
              filter="accountName"
              onChange={(val, data) => {
                dispatch({
                  type: 'getListPeriods',
                  payload: {
                    accountId: val,
                  },
                });
                dispatch({
                  type: 'setState',
                  payload: {
                    accounting: data.props.data.accounting,
                  },
                });
              }}
              style={{ width: '180px', marginRight: '12px' }}
              itemText="accountName"
              itemKey="accountId"
              dataSource={accountList}
            />
            <MonthPicker />
            <Checkbox
              checked={isContainItemData}
              style={{ marginLeft: '12px' }}
              onChange={onChange}
            >
              包含项目公司账套数据
            </Checkbox>
          </Left>
          <Right>
            <Print />
            <Button
              onClick={exportCallback}
              type="primary"
              className="e-ml12"
              style={{ verticalAlign: 'top' }}
              ghost
            >
              导出
            </Button>
          </Right>
        </Head>
        <Content>
          <Table />
        </Content>
      </Layout>
    </div>
  );
};

export default connect(({ accountList, accountId, isContainItemData, date }) => ({
  accountList,
  accountId,
  isContainItemData,
  date,
}))(Main);
