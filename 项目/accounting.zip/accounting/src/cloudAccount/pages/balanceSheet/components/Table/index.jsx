// import React, { useEffect } from 'react';
import React from 'react';
import SuperTable from 'SuperTable';
import { connect } from 'nuomi';
import columns from './columns';
import Moadl from './modal';

const Tables = ({
  dataSource,
  editableRowList,
  isContainItemData,
  accountId,
  $getList,
  dispatch,
}) => {
  // 编辑公式
  const editFormula = (rowNumber) => {
    dispatch({
      type: 'getAccountItem',
      payload: {
        accountId,
        rowNumber,
      },
    });
  };
  const col = columns({
    editFormula,
    editableRowList,
    isContainItemData,
  });
  return (
    <>
      <SuperTable
        id="reconciliationStatements"
        className="ui-table"
        rowKey="sort"
        bordered
        pagination={false}
        loading={$getList}
        columns={col}
        scroll={{ x: '100%' }}
        dataSource={dataSource}
      />
      <Moadl />
    </>
  );
};

export default connect(
  ({ dataSource, accountId, editableRowList, isContainItemData, loadings: { $getList } }) => ({
    dataSource,
    editableRowList,
    accountId,
    $getList,
    isContainItemData,
  }),
)(Tables);
