import React from 'react';
import { connect } from 'nuomi';
import PrintButton from 'pages/sheet/public/PrintButton';
import './style/index.less';

const typeId = {
  0: 14,
  4: 14,
  10: 14,
  11: 14,

  1: 19,
  5: 19,
  8: 19,
  9: 19,

  2: 24,
  3: 24,

  6: 27,
  7: 27,

  12: 30,
  13: 30,

  14: 33,
  15: 33,
};
const Main = ({ accounting, accountId, isContainItemData, date }) => {
  const params = {
    year: date.split('-')[0],
    month: date.split('-')[1],
    accountId,
    isContainItemData,
  };
  return (
    (accounting || accounting === 0) && (
      <PrintButton
        params={params}
        url="report/py/balanceSheet/print"
        typeId={typeId[accounting]}
        customReport
      />
    )
  );
};

export default connect(({ accounting, accountId, isContainItemData, date }) => ({
  accounting,
  accountId,
  isContainItemData,
  date,
}))(Main);
