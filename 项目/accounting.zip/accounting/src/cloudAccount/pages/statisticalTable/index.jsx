import defaultProps from '../reconciliationStatement';

export default {
  ...defaultProps,
  state: {
    ...defaultProps.state,
    title: '在建工程统计表',
    invoiceType: 'statisticalTable',
    expert: 'report/py/construction/export',
  },
};
