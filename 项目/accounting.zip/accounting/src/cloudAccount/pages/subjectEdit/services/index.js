import util from 'util';
// import mock from './mock';

export default util.createRequest({
  getSubjectInfo: 'account/subject/getSubjectInfo',
  findSubject: 'account/subject/findSubject',
  beforeDel: 'account/subject/beforeDel',
  del: 'account/subject/delSubject:post',
  beforeEdit: 'account/subject/toEditSubject:post',
  beforeAdd: 'account/subject/toAddSubject',
  hideOrShowSubject: 'account/subject/hideAccount:post',
  batchAddSubject: 'account/subject/batchAddSubject:post',
  updateSubjectName: 'account/subjectTemplate/update:post',
  addSubject: 'account/subject/addSubject:post',
  editSubject: 'account/subject/editSubject:postJSON',
  beforeAddCheck: 'account/subject/beforeAdd:post',
});
