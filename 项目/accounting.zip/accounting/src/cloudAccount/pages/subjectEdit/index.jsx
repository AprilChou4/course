import React from 'react';
import Layout from './components/Layout';
import effects from './effects';

export default {
  state: {
    dataSource: [], // 表格数据
    tabsData: [], // 导航栏数据
    activeKey: '1', // 选中的导航栏
    auxiliaryType: [], // 辅助核算得数据
    hideAccount: true, // 是否显示禁用得科目 true=显示 false=不显示
    subId: undefined, // 科目模板id
    hasHide: 0, // 是否存在禁用科目 1=存在 0=不存在
    table: null,
    loading: false,
    spanning: false,
    formData: {}, // 修改时详情数据
    addCode: '', // 新增时的最小编码
    isShowAddOrEdit: false, // 是否显示新增编辑弹窗
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    const {
      location: {
        query: { id },
      },
    } = this;
    this.store.dispatch({ type: 'setState', payload: { subId: id } });
    this.store.dispatch({ type: 'initData' });
  },
};
