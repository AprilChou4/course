import { Modal, message } from 'antd';
import services from '../services';

export default {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  },

  initData() {
    this.getSubjectInfo();
    this.findSubject();
  },

  async getSubjectInfo() {
    const { subId } = this.getState();
    const data = await services.getSubjectInfo({ subId });
    const { accountTypeList, auxiliaryTypeList } = data;
    this.setState({
      tabsData: accountTypeList,
      auxiliaryType: auxiliaryTypeList,
    });
  },

  async findSubject() {
    const { subId, hideAccount } = this.getState();
    this.setState({ loading: true });
    let data;
    try {
      data = await services.findSubject({ subId, hideAccount: hideAccount ? 1 : 0 });
    } finally {
      this.setState({ loading: false });
    }

    const { subjectWrapperList, hasHide } = data;
    this.setState({
      dataSource: subjectWrapperList,
      hasHide,
    });
  },

  async beforeDel({ id, name }) {
    await services.beforeDel(
      { subjectId: id },
      {
        loading: true,
        status: {
          201: (res) => {
            this.del({ id, msg: res.message });
          },
          300: (res) => {
            message.error(res.message);
          },
        },
      },
    );
    await this.del({ id, msg: `是否要删除科目：${name}？` });
  },

  async del({ id, msg }) {
    const { subId } = this.getState();
    const that = this;
    Modal.confirm({
      className: 'modal-without-close',
      title: msg,
      width: 416,
      centered: true,
      async onOk() {
        await services.del({ subDetailId: id, subId });
        message.success('操作成功');
        that.findSubject();
      },
    });
  },

  async hideOrShowSubject(params) {
    const { subId } = this.getState();
    await services.hideOrShowSubject({ subId, ...params });
    message.success('操作成功');
    this.findSubject();
  },

  async batchAddSubject(params) {
    const { subId } = this.getState();
    await services.batchAddSubject({ subId, ...params });
    message.success('操作成功');
    this.findSubject();
  },

  async updateSubjectName(params) {
    const { subId } = this.getState();
    await services.updateSubjectName({ templateId: subId, ...params });
    message.success('操作成功');
  },

  async beforeAdd(params) {
    const { subId } = this.getState();
    let data = '';
    try {
      this.setState({
        spanning: true,
      });
      data = await services.beforeAdd({ subId, ...params }, { loading: true });
      return data;
    } finally {
      this.setState({
        spanning: false,
        addCode: data,
      });
    }
  },

  async beforeEdit(params) {
    let data;
    try {
      this.setState({
        spanning: true,
      });
      data = await services.beforeEdit(params, { loading: true });
      return data;
    } finally {
      this.setState({
        spanning: false,
        formData: data,
      });
    }
  },
  async addSubject(params) {
    const { subId } = this.getState();
    await services.addSubject({ subId, ...params });
    message.success('操作成功');
    this.findSubject();
  },

  async editSubject(params) {
    const { subId } = this.getState();
    await services.editSubject({ subId, ...params });
    message.success('操作成功');
    this.findSubject();
  },
};
