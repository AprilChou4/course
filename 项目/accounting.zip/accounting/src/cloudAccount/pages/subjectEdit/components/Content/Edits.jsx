import React, { useState } from 'react';
import { connect } from 'nuomi';
import { Tooltip } from 'antd';
import { PropTypes } from 'prop-types';
import BatchAdd from './BatchAdd';
import './index.less';

const Edits = ({ record, dispatch }) => {
  const { hide, id, code } = record;
  const [visible, setVisible] = useState(false);
  const handleBatchAdd = () => {
    setVisible(true);
  };
  const handleOnOk = (value) => {
    dispatch({ type: 'batchAddSubject', payload: { parentId: id, names: value } }).then(() => {
      setVisible(false);
    });
  };
  const handleClick = (e) => {
    dispatch({ type: 'hideOrShowSubject', payload: { hideAccount: e, code } });
  };
  return (
    <>
      <span styleName="edits">
        {hide === 0 && (
          <>
            <Tooltip title="批量新增">
              <i className="iconfont icon-fuzhihang" onClick={handleBatchAdd} />
            </Tooltip>
            <Tooltip
              title="禁用"
              onClick={() => {
                handleClick(true);
              }}
            >
              <i className="iconfont icon-jinyong1" />
            </Tooltip>
          </>
        )}
        {hide === 1 && (
          <>
            {}
            <Tooltip
              title="启用"
              onClick={() => {
                handleClick(false);
              }}
            >
              <i className="iconfont icon-huifu" />
            </Tooltip>
          </>
        )}
      </span>
      {visible && (
        <BatchAdd
          visible={visible}
          onOk={handleOnOk}
          onCancel={() => {
            setVisible(false);
          }}
        />
      )}
    </>
  );
};

Edits.propTypes = {
  record: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect()(Edits);
