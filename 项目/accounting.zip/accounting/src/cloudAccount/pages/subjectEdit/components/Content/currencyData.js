// 外币数据
export default [
  {
    text: '英镑 GBP',
    value: 'GBP',
  },
  {
    text: '美元 USD',
    value: 'USD',
  },
  {
    text: '日元 JPY',
    value: 'JPY',
  },
  {
    text: '港元 HKD',
    value: 'HKD',
  },
  {
    text: '欧元 EUR',
    value: 'EUR',
  },
  {
    text: '德国马克 DEM',
    value: 'DEM',
  },
  {
    text: '瑞士法郎 CHF',
    value: 'CHF',
  },
  {
    text: '法国法郎 FRF',
    value: 'FRF',
  },
  {
    text: '荷兰盾 NLG',
    value: 'NLG',
  },
  {
    text: '奥地利先令 ATS',
    value: 'ATS',
  },
  {
    text: '比利时法郎 BEF',
    value: 'BEF',
  },
  {
    text: '意大利里拉 ITL',
    value: 'ITL',
  },
  {
    text: '加拿大元 CAD',
    value: 'CAD',
  },
  {
    text: '澳大利亚元 AUD',
    value: 'AUD',
  },
  {
    text: '瑞典克朗 SEK',
    value: 'SEK',
  },
  {
    text: '丹麦克朗 DKK',
    value: 'DKK',
  },
  {
    text: '挪威克朗 NOK',
    value: 'NOK',
  },
  {
    text: '芬兰马克 F1M',
    value: 'F1M',
  },
  {
    text: '韩国元 KRW',
    value: 'KRW',
  },
  {
    text: '泰国铢 THB',
    value: 'THB',
  },
  {
    text: '菲律宾比索 PHP',
    value: 'PHP',
  },
  {
    text: '印度卢比 INR',
    value: 'INR',
  },
  {
    text: '俄罗斯卢布 SUR',
    value: 'SUR',
  },
  {
    text: '缅甸元 BUK',
    value: 'BUK',
  },
  {
    text: '新西兰元 NZD',
    value: 'NZD',
  },
  {
    text: '新加坡元 SGD',
    value: 'SGD',
  },
  {
    text: '老挝基普 LAK',
    value: 'LAK',
  },
  {
    text: '人民币 RMB',
    value: 'RMB',
  },
];
