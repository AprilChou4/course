import React, { useRef, useEffect } from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import SuperTable from '@/SuperTable';
import ComboCell from '@/ComboCell';
import TableCell from '@/TableCell';
import Operate from './Operate';
import Edits from './Edits';
import Tips from './Tips';

const Table = ({ dataSource, activeKey, dispatch, table, loading }) => {
  const superTable = useRef(null);
  useEffect(() => {
    dispatch({ type: 'setState', payload: { table: superTable.current } });
  }, [table]);
  const columns = [
    {
      title: '编码',
      dataIndex: 'code',
      className: 'th-center',
      align: 'left',
      width: '17%',
      render(text, record) {
        return (
          <ComboCell>
            <TableCell>{text}</TableCell>
            <Edits record={record} />
          </ComboCell>
        );
      },
    },
    {
      title: '名称',
      dataIndex: 'name',
      className: 'th-center',
      align: 'left',
      width: '55%',
      render(text, record) {
        return (
          <ComboCell>
            <TableCell>{text}</TableCell>
            <Tips record={record} />
          </ComboCell>
        );
      },
    },
    {
      title: '方向',
      dataIndex: 'balanceDe',
      align: 'center',
      width: '8%',
    },
    {
      title: '操作',
      dataIndex: 'operate',
      align: 'center',
      width: '20%',
      render: (text, record) => {
        return <Operate record={record} />;
      },
    },
  ];
  const handleOnScroll = (scrollTop, scrollFlag) => {
    const currentDataSource = superTable.current.state.dataSource;
    const { code } = currentDataSource.length <= 0 ? { activeKey } : currentDataSource[0];
    if (!scrollFlag && activeKey !== code.charAt(0)) {
      dispatch({
        type: 'setState',
        payload: {
          activeKey: String(code).charAt(0),
        },
      });
    }
  };
  return (
    <SuperTable
      ref={superTable}
      bordered
      columns={columns}
      dataSource={dataSource}
      rowKey={({ id }, index) => id || index}
      pagination={false}
      onScroll={handleOnScroll}
      rowClassName={({ hide }) => (hide === 1 ? 'hide-row' : '')}
      loading={loading}
    />
  );
};
Table.defaultProps = {
  table: null,
};
Table.propTypes = {
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
  activeKey: PropTypes.string.isRequired,
  dispatch: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired,
  table: PropTypes.objectOf(PropTypes.any),
};
export default connect(({ dataSource, activeKey, table, loading }) => ({
  dataSource,
  activeKey,
  table,
  loading,
}))(Table);
