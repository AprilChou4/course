import React, { useState, useEffect, forwardRef } from 'react';
import { AutoComplete, Input, Popover } from 'antd';
import { PropTypes } from 'prop-types';
import data from './currencyData';

const Currency = forwardRef(({ form }, ref) => {
  const { getFieldValue, setFieldsValue } = form;
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState(getFieldValue('currency'));
  useEffect(() => {
    setValue(getFieldValue('currency'));
  }, [getFieldValue('currency')]);
  const filter = (e, option) => {
    if (e) {
      if (/[a-z]/gi.test(e) && option.key.indexOf(e.toUpperCase()) !== -1) {
        return true;
      }
      if (option.props.children.indexOf(e) !== -1) {
        return true;
      }
    }
    return false;
  };

  const onVisibleChange = (v) => {
    setVisible(v);
  };

  const change = (v) => {
    const flag = v.trim();
    setValue(flag);
    setFieldsValue({
      currency: flag,
      finalTransfer: flag ? 1 : 0,
    });
  };

  const popoverSelect = (t) => {
    setVisible(false);
    change(t.value);
  };

  const blur = () => {
    if (
      !data.some((val) => {
        return val.text === value || val.value === value;
      })
    ) {
      change('');
    }
  };

  return (
    <AutoComplete
      ref={ref}
      value={value}
      dataSource={data}
      autoComplete="off"
      onBlur={blur}
      filterOption={filter}
      optionFilterProp="children"
      onChange={change}
      placeholder="请输入标准外币符号"
      getPopupContainer={(trigger) => trigger.parentNode}
    >
      <Input
        suffix={
          <span onClick={(e) => e.stopPropagation()}>
            <Popover
              overlayClassName="currency"
              placement="bottomRight"
              arrowPointAtCenter
              visible={visible}
              onVisibleChange={onVisibleChange}
              getPopupContainer={(trigger) => trigger.parentNode.parentNode}
              trigger="click"
              content={data.map((v, i) => {
                const index = i;
                return (
                  <span key={index} onClick={() => popoverSelect(v)}>
                    <em>{v.value}</em>
                    <b>{v.text.split(' ')[0]}</b>
                  </span>
                );
              })}
            >
              <i
                className="iconfont icon-bibie f-cblue"
                style={{ margin: '-12px 0 0 -10px' }}
                title="点击查看全部外币符号"
              />
            </Popover>
          </span>
        }
      />
    </AutoComplete>
  );
});

Currency.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default Currency;
