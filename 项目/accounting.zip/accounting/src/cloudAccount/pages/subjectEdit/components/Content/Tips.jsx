import React from 'react';
import { PropTypes } from 'prop-types';
import './index.less';

const Tips = ({ record }) => {
  const { unit, symbol, auxiliaryType } = record;
  return (
    <span styleName="tips">
      {auxiliaryType && <span className="item">{auxiliaryType}</span>}
      {unit && <span className="item unit">{unit}</span>}
      {symbol && <span className="item symbol">{symbol}</span>}
    </span>
  );
};

Tips.propTypes = {
  record: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default Tips;
