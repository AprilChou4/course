import React, { useEffect } from 'react';
import Head from '../Head';
import Content from '../Content';
import './index.less';

const Layout = () => {
  const refreshPage = (e) => {
    const { data } = e;
    if (typeof data === 'string') {
      const { type } = JSON.parse(data);
      if (type === 'accounting/reload') {
        window.location.reload();
      }
    }
  };
  useEffect(() => {
    window.addEventListener('message', refreshPage, false);
    return () => {
      window.addEventListener('message', refreshPage, false);
    };
  });
  return (
    <div styleName="subject-edit">
      <Head />
      <Content />
    </div>
  );
};

export default Layout;
