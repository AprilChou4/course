import React from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'nuomi';
import { Form, Input, Radio, Checkbox, Modal } from 'antd';
import Currency from './Currency';
import './index.less';

const formItemLayout = {
  labelCol: {
    sm: { span: 5 },
  },
  wrapperCol: {
    sm: { span: 19 },
  },
};

const SubjectFrom = ({ form, auxiliaryType, addCode, record, type, formData }) => {
  const { getFieldDecorator, getFieldValue, setFieldsValue } = form;
  const { code, name, balanceDe, id } = record;
  const auxiliaryChange = (e) => {
    const { value, checked } = e.target;
    const val = getFieldValue('type');
    let prevName = '';
    let nextName = '';
    auxiliaryType.forEach((ele) => {
      if (String(val) === String(ele.type)) {
        prevName = ele.name;
      } else if (String(value) === String(ele.type)) {
        nextName = ele.name;
      }
    });
    // if (res.hasChild) {
    //   message.warning('该科目有下级科目，不能绑定辅助核算');
    //   return false;
    // }
    if (prevName && checked && val !== value) {
      Modal.confirm({
        title: '温馨提示',
        centered: true,
        className: 'modal-without-close',
        content: `亲，你需要将辅助核算方式由“${prevName}”修改为“${nextName}”吗？（一个科目只能启用一种辅助核算方式）`,
        onOk: () => {
          setFieldsValue({
            type: value,
          });
        },
      });
    } else {
      setFieldsValue({
        type: checked ? value : '',
      });
    }
  };
  const handleCodeBlur = (e) => {
    if (e.target.value === code && type === 'add') {
      setFieldsValue({
        code: `${code}${addCode}`,
      });
    }
    if (e.target.value === formData?.parentCode && type !== 'add') {
      setFieldsValue({
        code: formData?.subject?.code,
      });
    }
    if (e.target.value.substring(e.target.value.length - 2) === '00') {
      setFieldsValue({
        code: type === 'add' ? `${code}${addCode}` : formData?.subject?.code,
      });
    }
  };
  return (
    <Form {...formItemLayout}>
      {/* {type !== 'add' &&
        getFieldDecorator('hasChild', {
          initialValue: formData?.hasChild,
        })(<Input type="hidden" />)} */}
      {type !== 'add' &&
        getFieldDecorator('id', {
          initialValue: formData?.subject?.id,
        })(<Input type="hidden" />)}
      <Form.Item label="上级科目">
        {getFieldDecorator('parentId', {
          initialValue: type === 'add' ? id : formData?.subject?.parentId,
        })(<Input type="hidden" />)}
        <Input
          disabled
          value={
            type === 'add'
              ? `${code}${name}`
              : `${formData?.parentCode || ''} ${formData?.parentName || ''}`
          }
        />
      </Form.Item>
      <Form.Item label="科目编码">
        {getFieldDecorator('code', {
          initialValue: type === 'add' ? `${code}${addCode}` : formData?.subject?.code,
          normalize(value) {
            if (
              (type === 'add' && value === code) ||
              (type !== 'add' && formData?.parentCode && value === formData?.parentCode) ||
              (type === 'add' && value.length <= code.length) ||
              (type === 'add' && value.indexOf(code) === -1) ||
              (type !== 'add' && formData?.parentCode && value.indexOf(formData?.parentCode) === -1)
            ) {
              return type === 'add' ? code : formData?.parentCode;
            }
            return value;
          },
          rules: [
            {
              pattern: /^[a-zA-Z0-9]+$/,
              message: '编码只能输入数字或字母',
            },
          ],
        })(
          <Input
            disabled={!!formData.hasChild}
            maxLength={type === 'add' ? `${code}${addCode}`.length : formData?.subject?.code.length}
            onBlur={handleCodeBlur}
          />,
        )}
      </Form.Item>
      <Form.Item label="科目名称">
        {getFieldDecorator('name', {
          initialValue: type !== 'add' ? formData?.subject?.name : '',
          rules: [
            {
              required: true,
              message: '科目名称不能为空',
            },
          ],
        })(<Input disabled={!!formData?.hasChild} placeholder="请输入科目名称" />)}
      </Form.Item>
      <Form.Item label="科目方向">
        {getFieldDecorator('balanceDe', {
          initialValue: balanceDe || formData?.subject?.balanceDe,
        })(
          <Radio.Group disabled={!formData?.parentCode && type !== 'add'}>
            <Radio value="借">借</Radio>
            <Radio value="贷">贷</Radio>
          </Radio.Group>,
        )}
      </Form.Item>
      <Form.Item label="计量单位">
        {getFieldDecorator('unit', {
          initialValue: type !== 'add' ? formData?.subject?.unit : '',
        })(<Input placeholder="录入单位即可启用数量核算" />)}
      </Form.Item>
      <Form.Item label="外币符号">
        {getFieldDecorator('currency', {
          initialValue: type !== 'add' ? formData?.subject?.symbol : '',
        })(<Currency form={form} />)}
      </Form.Item>
      <Form.Item
        wrapperCol={{ offset: 5 }}
        style={{
          marginBottom: '0px',
          marginTop: '-24px',
          display: getFieldValue('currency') ? 'block' : 'none',
        }}
      >
        {getFieldDecorator('finalTransfer', {
          initialValue: type !== 'add' ? formData?.subject?.finalTransfer : '',
        })(<Checkbox checked={!!getFieldValue('finalTransfer')}>期末调汇</Checkbox>)}
      </Form.Item>
      <Form.Item label="辅助核算" style={{ marginBottom: 0 }}>
        {getFieldDecorator('type', {
          initialValue: type !== 'add' ? formData?.subject?.auxiliaryTypeId : '',
        })(<Input type="hidden" />)}
        <div styleName="auxiliaryButton">
          {auxiliaryType.map((item) => {
            const disabled = item.name === '存货' && !!getFieldValue('unit');
            return (
              <Checkbox
                onChange={auxiliaryChange}
                checked={String(item.type) === String(getFieldValue('type'))}
                key={item.id}
                value={item.type}
                disabled={disabled}
              >
                {item.name}
              </Checkbox>
            );
          })}
        </div>
      </Form.Item>
    </Form>
  );
};

SubjectFrom.defaultProps = {
  formData: null,
};

SubjectFrom.propTypes = {
  auxiliaryType: PropTypes.arrayOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  formData: PropTypes.objectOf(PropTypes.any),
  record: PropTypes.objectOf(PropTypes.any).isRequired,
  addCode: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
};

export default Form.create()(
  connect(({ auxiliaryType, addCode, formData }) => ({ auxiliaryType, addCode, formData }))(
    SubjectFrom,
  ),
);
