import React, { useRef } from 'react';
import { connect } from 'nuomi';
import { Modal, Button, Spin } from 'antd';
import { PropTypes } from 'prop-types';
import SubjectForm from './SubjectForm';
import services from '../../services';

const SubjectModal = ({ type, visible, onCancel, dispatch, record, spanning, formData, subId }) => {
  const { id } = record;
  const subjectForm = useRef(null);
  const addSubject = (params, flag) => {
    dispatch({ type: 'addSubject', payload: params }).then(() => {
      if (flag === 2) {
        subjectForm.current.resetFields();
        dispatch({ type: 'beforeAdd', payload: { parentId: id } });
      }
      if (flag !== 2) {
        onCancel();
      }
    });
  };
  const handleSaveClick = (flag) => {
    subjectForm.current.validateFields(async (errors, values) => {
      const params = JSON.parse(JSON.stringify(values));
      params.finalTransfer = params.finalTransfer ? 1 : 0;
      if (!errors) {
        if (flag === 3) {
          if (params.hasChild) {
            delete params.type;
          }
          if (formData?.usedByVoucher) {
            Modal.confirm({
              className: 'modal-without-close',
              title: '该科目模板已被凭证模板使用，确认更新全部凭证模板？',
              centered: true,
              onOk: () => {
                dispatch({ type: 'editSubject', payload: params }).then(() => {
                  onCancel();
                });
              },
            });
          }
          dispatch({ type: 'editSubject', payload: params }).then(() => {
            onCancel();
          });
        }
        if (flag !== 3) {
          await services.beforeAddCheck(
            { subId, ...params },
            {
              status: {
                201: (res) => {
                  Modal.confirm({
                    title: res.message,
                    centered: true,
                    width: 418,
                    okText: '确认替换',
                    cancelText: '保留本级',
                    onOk: async () => {
                      const newParams = { ...params, replaceFlag: 1 };
                      addSubject(newParams, flag);
                    },
                    onCancel: async () => {
                      addSubject(params, flag);
                    },
                  });
                },
              },
            },
          );
          addSubject(params, flag);
        }
      }
    });
  };
  return (
    <Modal
      title={type === 'add' ? '新增下级科目' : '修改科目'}
      width={418}
      centered
      maskClosable={false}
      visible={visible}
      onCancel={onCancel}
      footer={
        type === 'add' ? (
          <>
            <Button
              type="default"
              onClick={() => {
                handleSaveClick(1);
              }}
            >
              保存
            </Button>
            <Button
              type="primary"
              onClick={() => {
                handleSaveClick(2);
              }}
            >
              保存并新增
            </Button>
          </>
        ) : (
          <>
            <Button
              type="default"
              onClick={() => {
                onCancel();
              }}
            >
              取消
            </Button>
            <Button
              type="primary"
              onClick={() => {
                handleSaveClick(3);
              }}
            >
              保存
            </Button>
          </>
        )
      }
      className="subject-modal-xb"
    >
      <Spin spinning={spanning}>
        <SubjectForm ref={subjectForm} record={record} type={type} />
      </Spin>
    </Modal>
  );
};

SubjectModal.defaultProps = {
  formData: null,
};

SubjectModal.propTypes = {
  type: PropTypes.string.isRequired,
  record: PropTypes.objectOf(PropTypes.any).isRequired,
  formData: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool.isRequired,
  onCancel: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
  spanning: PropTypes.bool.isRequired,
  subId: PropTypes.string.isRequired,
};

export default connect(({ spanning, subId }) => ({ spanning, subId }))(SubjectModal);
