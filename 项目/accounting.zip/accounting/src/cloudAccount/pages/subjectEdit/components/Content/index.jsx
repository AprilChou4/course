import React from 'react';
import Control from './Control';
import Table from './Table';
import './index.less';

const Content = () => {
  return (
    <div styleName="content">
      <Control />
      <div styleName="table">
        <Table />
      </div>
    </div>
  );
};

export default Content;
