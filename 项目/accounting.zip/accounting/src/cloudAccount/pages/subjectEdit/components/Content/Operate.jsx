import React, { useState } from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import { Button } from 'antd';
import SubjectModal from './SubjectModal';

const Operate = ({ record, dispatch }) => {
  const { hide, deleltable, id, name, system } = record;
  const [visible, setVisible] = useState(false);
  const [type, setType] = useState('add');
  const beforeAddOrEdit = (flag) => {
    const params = flag === 'add' ? { parentId: id } : { id };
    return dispatch({ type: flag === 'add' ? 'beforeAdd' : 'beforeEdit', payload: params });
  };
  const handleAddClick = () => {
    setType('add');
    beforeAddOrEdit('add').then((res) => {
      if (res) {
        setVisible(true);
      }
    });
  };
  const handleEditClick = () => {
    setType('edit');
    beforeAddOrEdit('edit').then((res) => {
      if (res) {
        setVisible(true);
      }
    });
  };
  const handleDelClick = () => {
    dispatch({ type: 'beforeDel', payload: { id, name } });
  };
  return (
    <>
      <Button disabled={hide === 1} type="link" onClick={handleAddClick}>
        新增
      </Button>
      <Button disabled={hide === 1} type="link" onClick={handleEditClick}>
        修改
      </Button>
      <Button
        disabled={hide === 1 || deleltable === 0 || system === 1}
        type="link"
        onClick={handleDelClick}
      >
        删除
      </Button>
      {visible && (
        <SubjectModal
          visible={visible}
          onCancel={() => {
            setVisible(false);
          }}
          type={type}
          record={record}
        />
      )}
    </>
  );
};

Operate.propTypes = {
  record: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect()(Operate);
