import React, { useState } from 'react';
import { PropTypes } from 'prop-types';
import { connect } from 'nuomi';
import { Input, Button } from 'antd';
import './index.less';

const Head = ({ dispatch }) => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState(localStorage.getItem('subjectName'));
  const handleChange = (e) => {
    setValue(e.target.value);
  };
  const handleSave = () => {
    dispatch({ type: 'updateSubjectName', payload: { name: value } }).then(() => {
      setVisible(false);
      localStorage.setItem('subjectName', value);
    });
  };
  const handleCancel = () => {
    setVisible(false);
  };
  return (
    <div styleName="head">
      <span>科目模板名称：</span>
      <Input
        value={value}
        maxLength={30}
        onChange={handleChange}
        suffix={
          visible ? (
            <span style={{ zIndex: 9999 }}>
              <Button type="link" onClick={handleCancel}>
                取消
              </Button>
              <Button type="link" onClick={handleSave}>
                保存
              </Button>
            </span>
          ) : (
            <span />
          )
        }
        onFocus={() => {
          setVisible(true);
        }}
        onBlur={() => {
          setTimeout(() => {
            setVisible(false);
          }, 500);
        }}
      />
    </div>
  );
};

Head.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

export default connect()(Head);
