import React, { useState } from 'react';
import { Modal, Row, Col, Input } from 'antd';
import { PropTypes } from 'prop-types';

const { TextArea } = Input;

const BatchAdd = ({ visible, onCancel, onOk }) => {
  const [value, setValue] = useState('');
  const [total, setTotal] = useState(0);
  const [error, setError] = useState(false);
  const handleChange = (e) => {
    const currentValue = e.target.value;
    setValue(currentValue);
    if (currentValue) {
      setError(false);
    }
    if (!currentValue) {
      setTotal(0);
      setError(true);
    } else if (currentValue.split('\n')[currentValue.split('\n').length - 1]) {
      setTotal(currentValue.split('\n').length);
    } else {
      setTotal(currentValue.split('\n').length - 1);
    }
  };
  return (
    <Modal
      title="批量新增"
      visible={visible}
      centered
      maskClosable={false}
      width={580}
      onCancel={onCancel}
      onOk={() => {
        if (!value) {
          setError(true);
          return;
        }
        onOk(value);
      }}
    >
      <Row>
        <Col span={5}>新增科目名称：</Col>
        <Col span={19} className={error ? 'has-error' : ''}>
          <TextArea style={{ height: '240px' }} value={value} onChange={handleChange} />
          <div>
            {error && <span className="ant-form-explain">科目名称不能为空</span>}
            <span style={{ float: 'right' }}>共{total}项</span>
          </div>
        </Col>
      </Row>
    </Modal>
  );
};

BatchAdd.propTypes = {
  visible: PropTypes.bool.isRequired,
  onCancel: PropTypes.func.isRequired,
  onOk: PropTypes.func.isRequired,
};

export default BatchAdd;
