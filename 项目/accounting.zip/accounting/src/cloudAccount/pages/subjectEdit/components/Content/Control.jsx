import React from 'react';
import { connect } from 'nuomi';
import { PropTypes } from 'prop-types';
import { Tabs, Button } from 'antd';
import './index.less';

const { TabPane } = Tabs;
const Control = ({ tabsData, activeKey, hasHide, hideAccount, dispatch, table }) => {
  const handleTabsChange = (e) => {
    dispatch({ type: 'setState', payload: { activeKey: e } });
    table.scrollTo(({ code }) => String(code).charAt(0) === e);
  };
  const handleClick = () => {
    dispatch({ type: 'setState', payload: { hideAccount: !hideAccount } });
    dispatch({ type: 'findSubject' });
  };
  return (
    <div styleName="control">
      <Tabs activeKey={activeKey} onChange={handleTabsChange}>
        {tabsData.map(({ name }, index) => {
          const key = index + 1;
          return <TabPane tab={name} key={String(key)} />;
        })}
      </Tabs>
      {hasHide === 1 && (
        <div styleName="control-buttons">
          <Button type="primary" ghost={hideAccount} onClick={handleClick}>
            {hideAccount ? '显示禁用科目' : '隐藏禁用科目'}
          </Button>
        </div>
      )}
    </div>
  );
};
Control.defaultProps = {
  table: null,
};

Control.propTypes = {
  tabsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  table: PropTypes.objectOf(PropTypes.any),
  activeKey: PropTypes.string.isRequired,
  dispatch: PropTypes.func.isRequired,
  hasHide: PropTypes.number.isRequired,
  hideAccount: PropTypes.bool.isRequired,
};

export default connect(({ tabsData, activeKey, hasHide, hideAccount, table }) => ({
  tabsData,
  activeKey,
  hasHide,
  hideAccount,
  table,
}))(Control);
