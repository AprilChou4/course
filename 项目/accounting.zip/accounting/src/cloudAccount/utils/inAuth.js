import { Component } from 'react';

const createAuth = ({ authorities }) => {
  // type 作为后续多权限类型区分
  window.inAuth = (code) => {
    // 存在权限代码 并且 代码中不包含传入 code
    if (authorities && code && authorities.indexOf(code.toString()) === -1) {
      return false;
    }

    return true;
  };

  Component.prototype.inAuth = window.inAuth;
};

export default createAuth;
