/* eslint-disable react/jsx-filename-extension */
import React from 'react';
import { nuomi, store } from 'nuomi';
import { Modal } from 'antd';
import Icon from '@/Icon';
// import { activeRoute } from './utils';

const nuomiConfig = {
  state: {
    account: {
      user: { versionType: 100 },
    },
  },
  reducers: {
    updateQuery: (state, { payload }) => ({ ...state, account: { ...state.account, ...payload } }),
  },
  effects: {
    updateState(payload) {
      this.dispatch({
        type: '_updateState',
        payload,
      });
    },
  },
  onChange: {
    // 刷新路由删除superLayer
    removeSuperLayer() {
      const { data } = this;
      if (this.reload && data.superLayers && data.superLayers.length) {
        data.superLayers = data.superLayers.filter((v) => {
          v.destroy();
          return false;
        });
      }
    },
    // 存储当前路由props
    // storeRoute() {
    //   activeRoute(this);
    // },
    // 更新菜单状态
    // updateMenus() {
    //   const { selectedKeys, openKeys } = this;
    //   const {
    //     account: {
    //       menus: { collapsed },
    //     },
    //   } = store.getState();
    //   this.store.dispatch({
    //     type: 'account/updateMenus',
    //     payload: {
    //       selectedKeys: selectedKeys || [],
    //       // 收起时，切换路由不用打开菜单
    //       openKeys: collapsed ? [] : openKeys || [],
    //       openKeysTemp: openKeys || [],
    //     },
    //   });
    // },
  },
};

// nuomi 全局配置
nuomi.config(nuomiConfig);

const { warn, confirm, info, success, warning, error } = Modal;
const modalTypes = {
  warn,
  confirm,
  info,
  success,
  warning,
  error,
};

Object.keys(modalTypes).forEach((type) => {
  Modal[type] = (options) => {
    const opts = {};
    if (['confirm', 'warn', 'warning'].includes(type)) {
      opts.icon = <Icon type="tanhao" />;
    }
    return modalTypes[type]({
      ...opts,
      okText: '确定',
      cancelText: '取消',
      ...options,
    });
  };
});

export default nuomiConfig;
