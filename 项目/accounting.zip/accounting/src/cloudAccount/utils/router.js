// 含有菜单的路由
const routes = [
  // 代账系统的记账设置
  {
    path: '/accounting-settings',
    async: () => import('../pages/accountingSettings'),
  },
  {
    path: '/accounting-settings/edit/:id',
    async: () => import('../pages/subjectEdit'),
  },
  {
    // 核算中心对账表
    path: '/reconciliation-statement',
    async: () => import('../pages/reconciliationStatement'),
  },
  {
    // 在建工程统计表
    path: '/statistical-table',
    async: () => import('../pages/statisticalTable'),
  },
  {
    // 资产负债表
    path: '/balance-sheet',
    async: () => import('../pages/balanceSheet'),
  },
];

export default routes;
