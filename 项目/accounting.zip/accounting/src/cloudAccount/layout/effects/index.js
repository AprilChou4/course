// import services from '../services/services';
import createAuth from 'customReport/utils/inAuth';

export default {
  async Init() {
    await this.getAuthorities();
    // 兼容部分propTypes
    await this.updateState({
      user: {
        versionType: 4,
      },
      versionType: '4',
      accounting: 100,
      inventoryCost: 100,
    });
  },
  async getAuthorities() {
    await createAuth({ authorities: '' });
  },
};
