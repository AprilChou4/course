import React from 'react';
import { connect, Route, Router, Redirect } from 'nuomi';
import routeList from '../../utils/router';
import './style.less';

const Layout = () => {
  const routes = routeList;
  return (
    <div styleName="content">
      <div styleName="page-content">
        <Router hashPrefix="!">
          {routes.map(({ path, ...rest }) => (
            <Route key={path} path={path} {...rest} />
          ))}
          {/* <Redirect to={routes[2].path} /> */}
        </Router>
      </div>
    </div>
  );
};

export default connect()(Layout);
