// import mock from './mock';
import util from 'util';

export default util.createRequest({
  // ...mock,
  getAuthorities: 'account/invoiceSet/invoicePickUpType/getAuthorities',
});
