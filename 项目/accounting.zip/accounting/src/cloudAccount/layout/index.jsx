import React from 'react';
import effects from './effects';
import Component from './components';

export default {
  id: 'account',
  state: {},
  reducers: {},
  effects,
  render() {
    return <Component />;
  },
  onInit() {
    this.store.dispatch({ type: 'Init' });
  },
};
