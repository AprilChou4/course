import React from 'react';
import ReactDOM from 'react-dom';
import { Nuomi } from 'nuomi';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import './style/index.less';
import '../public/config';
import '../public/method';
import './utils/config';
import layout from './layout';
import customEvents from '../platform/public/customEvents';

window.menuRouterPath = [];
window.customEvents = customEvents;

ReactDOM.render(
  <ConfigProvider locale={zhCN}>
    <Nuomi {...layout} />
  </ConfigProvider>,
  document.getElementById('app'),
);
