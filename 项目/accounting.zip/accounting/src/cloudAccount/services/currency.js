import util from 'util';

export default util.createRequest({
  checkStatementGetDefaultCols: 'report/py/checkStatement/getDefaultCols',
  constructionGetDefaultCols: 'report/py/construction/getDefaultCols',
});
