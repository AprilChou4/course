import util from 'util';

export default util.createRequest({
  // checkStatementGetList: 'report/py/checkStatement/getList',
  getCompanyAccountList: 'report/py/balanceSheet/getCompanyAccountList',
  getPeriods: 'report/py/balanceSheet/getPeriods',
  getList: 'report/py/balanceSheet/getList',
  getFormulaList: 'report/py/balanceSheet/getFormulaList',
  getItemAccountList: 'report/py/balanceSheet/getItemAccountList',
  getAccountItemList: 'report/py/balanceSheet/getAccountItemInfo',
  updateFormula: 'report/py/balanceSheet/updateFormula:postJSON',
});
