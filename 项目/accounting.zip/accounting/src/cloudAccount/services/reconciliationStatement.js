import util from 'util';

export default util.createRequest({
  getList: 'report/py/checkStatement/getList',
  updateColumn: 'report/py/checkStatement/updateColumn:postJSON',
  getFormulaList: 'report/py/checkStatement/getFormulaList',
  getSubjectList: 'report/py/checkStatement/getSubjectList',
  updateFormula: 'report/py/checkStatement/updateFormula:postJSON',
});
