import util from 'util';

export default util.createRequest({
  getList: 'report/py/construction/getList',
  updateColumn: 'report/py/construction/updateColumn:postJSON',
  getFormulaList: 'report/py/construction/getFormulaList',
  getSubjectList: 'report/py/construction/getSubjectList',
  updateFormula: 'report/py/construction/updateFormula:postJSON',
});
