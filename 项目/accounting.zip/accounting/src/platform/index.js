/* eslint-disable react/jsx-filename-extension */
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Nuomi } from 'nuomi';
import { ConfigProvider } from 'antd';
/* eslint-disable camelcase */
import zh_CN from 'antd/lib/locale-provider/zh_CN';
import './public/style/index.less';
import './public/config';
import '../public/config';
import '../public/method';
import layout from './layout';
import trackEvent from '../public/trackEvent';
import customEvents from './public/customEvents';

// if (typeof window.ExternService === 'object') {
//   window.changeLogo('云记账4.0');
// }

Component.prototype.trackEvent = trackEvent;

window.customEvents = customEvents;

ReactDOM.render(
  /* eslint-disable camelcase */
  <ConfigProvider locale={zh_CN}>
    <Nuomi {...layout} />
  </ConfigProvider>,
  document.getElementById('app'),
);
