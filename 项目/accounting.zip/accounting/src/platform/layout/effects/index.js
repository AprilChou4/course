/* eslint-disable class-methods-use-this */
import $data from 'data';
import util from 'util';
import { message } from 'antd';
import { ConfirmModal, SuperModal } from '@/modal';
import { BaseEffects } from '../../public/effects';
import services from '../services';
import { handleAccount, createAuth, createMenus, defaultMenuList } from '../utils';
import mergeMessage from '../modals/mergeMessage';
import AuxiRepeatModal from '../components/AuxiRepeatModal';

export default class Effects extends BaseEffects {
  async getUnreadNoticeList() {
    const nreadNoticeList = await services.getUnreadNoticeList();
    this.dispatch({
      type: 'updateMsg',
      payload: {
        count: (nreadNoticeList || []).length,
        list: nreadNoticeList || [],
      },
    });
  }

  $initMenus() {
    const { data, list } = createMenus(this.getState(), this.dispatch);
    this.dispatch({
      type: 'updateMenus',
      payload: {
        data,
        list,
      },
    });
  }

  updateAccount(payload) {
    this.updateState(payload);
    this.$initMenus();
  }

  async updateAccountPeriods() {
    const datas = await Promise.all([services.getAccount(), services.getPeriods()]);
    const [account, period] = datas;
    this.updateState({
      ...handleAccount(account),
      period,
    });
  }

  async getAccount() {
    const account = await services.getAccount();
    this.updateAccount(handleAccount(account));
    return account;
  }

  async getPeriods() {
    const period = await services.getPeriods();
    this.updateState({ period });
  }

  async getCommonlyBooks() {
    const commonlyBooks = await services.getCommonlyBooks();
    this.updateAccount({ commonlyBooks });
  }

  async getAccountNotice(data) {
    const getAccountNotice = await services.getAccountNotice(data);
    if (getAccountNotice.tipNotice) {
      SuperModal({
        title: '温馨提示',
        width: 320,
        centered: true,
        content: getAccountNotice.noticeMsg || '合同已经到期，请尽快处理',
        okText: '知道了',
        cancelText: '关闭',
        onOk: async () => {},
      });
    }
  }

  async getUser() {
    const user = await services.getUser();
    this.updateState({ user });
  }

  // 获取企业版地址
  async getEntUrl() {
    // const { versionType } = this.getState().account;
    const entoken = (util.getParam().entoken || '').split('#!/')[0];

    // if (entoken || versionType === '2') {
    const entUrl = await services.enterpriseConfig();
    this.updateState({
      entUrl,
      entoken,
    });
    // }
  }

  async updataMenu() {
    const res = await services.getTaxMenuList();
    return res;
  }

  async getTaxMenuList() {
    const res = await this.updataMenu();
    this.updateState({ taxMenuList: res });
    this.$initMenus();
  }

  async $initData() {
    const datas = await Promise.all([
      services.getAccount(),
      services.getUser(), // 1
      services.getPeriods(),
      services.getCommonlyBooks(), // 3
      services.getEnableList(), // 4
      services.getScaleConfig(),
      services.getCurrencyData(), // 6
      services.getTaxSetting(), // 7
    ]);
    const account = datas[0];
    const user = datas[1];
    user.menuList = user.menuList || defaultMenuList; // 给菜单加默认值
    const period = datas[2];
    const commonlyBooks = datas[3];
    this.getAccountNotice({
      year: account.currentYear,
      month: account.currentMonth,
    });
    const enableList = datas[4] || [];
    const scaleConfig = datas[5] || {};
    const currencyData = datas[6] || [];
    const taxSetting = datas[7] || {};

    const taxMenuList = account.versionType === '2' ? await this.updataMenu() : [];
    // 外币和汇率精度
    const currencyScale = currencyData.map((item) => {
      const trem = item;
      const settings = scaleConfig.currencyScaleDTOList.filter((value) => {
        return value.currencyId === trem.currencyId;
      })[0];
      if (settings) {
        trem.currencyPrecision =
          settings.currencyPrecision === '' || settings.currencyPrecision === undefined
            ? 2
            : settings.currencyPrecision;
        trem.exchangeRatePrecision =
          settings.exchangeRatePrecision === '' || settings.exchangeRatePrecision === undefined
            ? 2
            : settings.exchangeRatePrecision;
      } else {
        trem.currencyPrecision = 2;
        trem.exchangeRatePrecision = 4;
      }
      return trem;
    });
    // 模拟企业版
    // user.versionType = '2';
    const { authorities, versionType } = user;
    if (account.isExistExternalSubject) {
      account.isInitSubject = true;
    }

    const payload = {
      ...handleAccount({ ...account }), // 将账套设置中的参数保存到全局store中
      ...{
        // 数量长度
        quantityPrecision: scaleConfig.quantityScale || 4,
        // 单价长度
        unitPricePrecision: scaleConfig.unitPriceScale || 4,
      },
      enableList,
      user,
      period,
      commonlyBooks,
      currencyScale,
      ...taxSetting,
      taxMenuList,
    };

    // 存储权限 authorities
    createAuth({
      authorities:
        authorities && (versionType === '1' || versionType === '2' || versionType === '3')
          ? authorities.split('#')
          : null,
      account,
      user,
    });

    this.updateState(payload);
    this.$initMenus();

    if (account && user) {
      // 增值服务产品信息
      const getProductList = await services.getProductList();
      const productList = {};

      getProductList.forEach((val) => {
        productList[val.productType] = val.productId;
      });
      $data('goodsData', productList);
    }
    if (account && account.versionType === '0') {
      this.getUnreadNoticeList();
    }
    if (account.isExistExternalSubject && !account.isInitSubject) {
      mergeMessage(true);
    }

    this.getEntUrl();

    // 修复数据 △
    await this.repairData();

    // 只在企业版、代账版开启存货时查询
    if (
      (account.versionType === '2' || account.versionType === '1') &&
      account.inventoryCost === 2
    ) {
      this.getStockSettings();
    }
    util.ArgeementSDK(account.versionType);
  }

  async repairData() {
    await services.repair();
  }

  // 对账点击
  async onCheckAccount() {
    const { year, month } = this.getState();
    const params = { year, month };

    const res = await services.checkAccount(params);
    if (!res) return;

    if (res.result) {
      message.success(res.message);
    } else if (res.message.includes('当月辅助核算总账数据有重复')) {
      AuxiRepeatModal({ type: 0 });
    } else if (res.message.includes('存在重复辅助核算')) {
      AuxiRepeatModal({ type: 1, data: res.auxDuplicateList });
    } else {
      ConfirmModal({
        title: res.message,
        content: '是否进行数据修复',
        okText: '数据修复',
        onOk: async () => {
          this.repairAccount();
        },
      });
    }
  }

  async repairAccount() {
    const { year, month } = this.getState();
    const params = { year, month };
    await services.repairAccount(params);
    message.success('修复成功');
  }

  // 解锁
  async unlock(value) {
    const res = await services.unlock({ password: value });

    message.success('解锁成功');
    return res;
  }

  async getStockSettings() {
    const res = await services.getStockSetting();
    this.setState({ ...this.getState(), stockSetting: res || {} });
  }

  // 购买 type: 4 ocr 发票识别，5：查验录入
  async onBuy(type) {
    const {
      entUrl,
      user: { companyId },
    } = this.getState();

    // 客户端
    if (typeof ExternService === 'object') {
      message.error('暂不支持购买！');
      return;
    }

    const data = await services.getBuyDetail({ productType: type, companyId });

    const urlData = encodeURIComponent(encodeURIComponent(JSON.stringify(data)));
    window.open(
      `${entUrl}/list/#!/enterprisebuy?buyId=details&urlData=${urlData}&companyId=${companyId}`,
    );
  }
}
