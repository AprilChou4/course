import util from 'util';
// import mock from './mock';
const { entoken } = util.getParam();

export default util.createRequest({
  getTaxSetting: 'account/getDeclareMethod',
  // ...mock,
  // 获取账套数据
  getAccount: 'account/getCurrent',
  // 获取用户数据
  getUser: entoken ? 'account/enterprise/user/getCurrent' : 'jz/user/getCurrent',
  // 获取区间列表
  getPeriods: 'account/period/getPeriods',
  // 获取常用账簿
  getCommonlyBooks: 'accountbook/book/commonly/commonly',

  // 获取账套列表
  getAccountList: entoken ? 'account/enterprise/account/listAccount' : 'jz/account/getList',
  // 获取代账账套列表
  getDzList: entoken
    ? 'account/enterprise/account/listAccount'
    : 'instead/v2/customer/account/listAccountStatus:post',

  // 获取打赏
  getPayQRCode: 'jz/reward/getPayQRCode',
  // 获取打赏列表
  getRewardRecordList: 'jz/reward/getRewardRecordList',
  // 获取打赏列表
  getPayResult: 'jz/reward/getPayResult',
  // 获取了解商品详情 的商品id
  getProductList: 'account/trialpay/getProductList',

  // 系统消息
  getUnreadNoticeList: 'jz/notice/unreadNoticeList',
  // 设置已读
  updateNotice: 'jz/notice/updateNotice:post',

  // 企业列表
  getUserCompanyList: 'instead/v2/user/company/list:postJSON',
  // 切换企业
  switchCompany: 'instead/v2/user/company/change:post',
  // 获取企业url地址
  getCloudEnterprise: 'instead/v2/user/cloudEnterprise',
  // 撤回申请
  cancelUserAppByUser: 'instead/v2/user/dz/allow/cancelJoinStatus:postJSON',
  // 重新申请
  restartJoinCompany: 'instead/v2/user/dz/allow/reJoinStatus:postJSON',
  // ...mock,

  // 会计工厂、账套进度相关
  // 理票完成前提示获取
  getTicketInfo: 'accountbook/factoryMode/beforeInvoiceArrange',
  ticketFinish: 'accountbook/factoryMode/invoiceArrange:post',
  // 记账完成
  getRecordInfo: 'accountbook/factoryMode/beforeVoucherRegister',
  recordFinish: 'accountbook/factoryMode/voucherRegister:post',

  // 解锁
  unlock: '/accountCheck/unlock:post',
  // 对账
  checkAccount: 'accountbook/accountcheck/check',
  // 修复
  repairAccount: 'accountbook/accountcheck/repair',
  // 删除折旧
  deleteZheJiu: 'assetCard/confirmProcessData:post',

  // 数据修复相关
  // 固定资产折旧修复
  processHistoricalData: 'assetCard/processHistoricalData',
  checkNotLeaf: 'accountCheck/checkNotLeaf',
  resetSwitchCount: 'accountCheck/resetBalanceSheetSwitchCount',
  // 获取账套设置的数据
  getAccountSetting: 'account/accountSetting/getAccountSetting',
  // 检查是否合同到期
  getAccountNotice: 'account/notice/getAccountNotice',
  // 获取凭证类别
  getEnableList: 'accountbook/voucherType/getList:post',
  // 获取外币和汇率精度
  getListCurrencyScale: 'account/accountSetting/listCurrencyScale',
  // 获取精度设置的数据
  getScaleConfig: 'account/accountSetting/getScaleConfig',
  // 获取外币列表
  getCurrencyData: 'account/currency/getForeignCurrencys',
  // 获取qq账号
  getQQnumber: 'account/index/getQqNumber',
  // 获取企业版地址
  enterpriseConfig: 'account/enterprise/user/config',

  // 企业版存货设置查询
  getStockSetting: 'inventory/stockSetup/detail',

  // 修复数据
  repair: 'account/repair/repair:post',
  // 获取购买订单信息
  getBuyDetail: 'invoice/bill/getExtendsServiceProduct',
  // 检查当前账套是否在备份或者还原,0未备份 1备份还原中
  checkBackup: 'account/backup/checkBackup',
  checkStatus: 'jz/backups/checkStatus',

  getTaxMenuList: 'account/taxSetting/getTaxMenu', // 获取纳税申报菜单
});
