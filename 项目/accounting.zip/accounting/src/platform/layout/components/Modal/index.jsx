import React, { useState } from 'react';
import { Modal, Button } from 'antd';
import { setCookie } from 'utils';
import { store } from 'nuomi';

const LayerModal = () => {
  const [visible, setVisible] = useState(true);
  const clear = () => {
    setVisible(false);
    const {
      user: { username },
    } = store.getState().account;
    setCookie({ name: '_layerModal', data: { [username]: true } });
  };
  return (
    <Modal
      title="温馨提示"
      visible={visible}
      centered
      width={400}
      footer={
        <Button type="primary" onClick={clear}>
          关闭
        </Button>
      }
      onCancel={clear}
    >
      “系统设置”改名搬家啦！以后请到右上角-“用户设置”找我哦~
    </Modal>
  );
};

export default LayerModal;
