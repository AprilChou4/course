import React, { useState, useEffect } from 'react';
import { Dropdown, Menu, Popover, Button } from 'antd';
import { connect } from 'nuomi';
import util from 'util';
import PropTypes from 'prop-types';

import Icon from '@/Icon';

import NuomiTabs from '../NuomiTabs';
import Period from '../Period';
import HeaderTitle from '../HeaderTitle';
import CollapseButton from '../buttons/CollapseButton';
import ZoomButton from '../buttons/ZoomButton';
import HelperButton from '../buttons/HelperButton';
import UserButton from '../buttons/UserButton';
import MessageButton from '../buttons/MessageButton';
import AccountProcess from '../AccountProcess';

// import RechargeButton from '../buttons/RechargeButton';

import './style.less';

const Header = ({
  versionType,
  isInitSubject,
  username,
  entUrl,
  collapsed,
  openKeysTemp,
  dispatch,
  nuomiEnabled,
}) => {
  const [values, setvalues] = useState(true);
  const getItemGuide = '2020-03-05';
  const data = JSON.parse(localStorage.getItem('_getTitleGuide_') || '{}')[username];
  const getTitleGuide =
    typeof data === 'object' ? data.date !== getItemGuide : data !== getItemGuide;

  const content = (
    <div styleName="title-pop-main">
      <h6>新手引导</h6>
      <p>智能客服入口在这里啦~有问题请点我！</p>
      <span style={{ display: 'block', textAlign: 'right', paddingTop: '10px' }}>
        <Button
          type="primary"
          onClick={() => {
            setvalues(false);
            const list = JSON.parse(localStorage.getItem('_getTitleGuide_') || '{}');
            localStorage.setItem(
              '_getTitleGuide_',
              JSON.stringify({ ...list, [username]: { date: getItemGuide, ...data } }),
            );
          }}
        >
          知道啦
        </Button>
      </span>
    </div>
  );

  const menu = (
    <Menu styleName="title-menu-down">
      <Menu.Item key="0">
        <a href="https://ny.nuonuo.com/" rel="noreferrer noopener" target="_blank">
          诺诺课堂
          <Icon type="huo" style={{ color: '#FC4F7D', padding: '0 5px' }} />
        </a>
      </Menu.Item>
      <Menu.Item key="1">
        <a href={`${util.getNewUrl('//sds.jss.com.cn')}`} rel="noreferrer noopener" target="_blank">
          所得税汇算清缴
        </a>
      </Menu.Item>
    </Menu>
  );

  const { entoken } = util.getParam();

  useEffect(() => {
    if (typeof ExternService === 'object') {
      window.isClientObjInit({
        shrink: () => {
          dispatch({
            type: 'updateMenus',
            payload: {
              openKeys: !collapsed ? [] : openKeysTemp,
              collapsed: !collapsed,
            },
          });
        },
      });
    }
  }, [collapsed, dispatch, openKeysTemp]);
  useEffect(() => {
    if (typeof ExternService === 'object') {
      window.isClientObjInit({
        znkf: () => {
          util.location(
            `${util.getNewUrl(
              'https://robot.jss.com.cn/pc.do?newKey=kwy6d386c7566304a685742516c67636e6651755a454b773d3d',
            )}`,
            '_blank',
          );
        },
        bzzx: () => {
          util.location('/helpNew.html#/index', '_blank');
          // util.location('https://help.nuonuo.com/yjz/', '_blank');
        },
      });
    }
  }, []);

  return (
    <>
      {getTitleGuide && versionType !== '2' && username && values && (
        <div
          style={{
            background: 'rgba(0, 0, 0, 0.5)',
            position: 'fixed',
            top: '0px',
            width: '100%',
            height: '100%',
            zIndex: '999',
            left: '0px',
          }}
        />
      )}

      <div styleName="wrapper">
        <div styleName="header-top">
          <div styleName="header-left">
            <CollapseButton />
            <HeaderTitle />
            <Period />
            {!isInitSubject && <AccountProcess />}
            {(versionType === '0' || entoken) && typeof window.ExternService !== 'object' && (
              <a
                className="link e-ml8"
                href={entoken ? `${entUrl}/list#!/index` : '/accounts.html'}
              >
                返回账套管理
              </a>
            )}
          </div>
          <div styleName="header-right">
            {/* {!isInitSubject && versionType === '2' && (
              <a href="#!/guide" style={{ color: '#FF8B00', marginLeft: '10px' }}>
                <Icon
                  type="xingongnengicon"
                  style={{
                    fontSize: '32px',
                    height: '32px',
                    display: 'inline-block',
                    verticalAlign: 'top',
                  }}
                />
              </a>
            )} */}
            {versionType === '0' && !isInitSubject && (
              <span
                style={{
                  display: 'inline-block',
                  height: '26px',
                  verticalAlign: 'middle',
                  paddingRight: '20px',
                  borderRight: '1px solid #979797',
                }}
              >
                <Dropdown overlay={menu} trigger={['click']}>
                  <a
                    style={{
                      display: 'inline-block',
                      lineHeight: '24px',
                      height: '24px',
                      color: '#008CFF',
                      verticalAlign: 'top',
                    }}
                    onClick={(e) => e.preventDefault()}
                  >
                    <Icon
                      type="gengduo"
                      style={{
                        fontSize: '14px',
                        paddingRight: '5px',
                      }}
                    />
                    更多
                    <Icon
                      type="xialafuben"
                      style={{
                        fontSize: '14px',
                        paddingLeft: '5px',
                      }}
                    />
                  </a>
                </Dropdown>
              </span>
            )}
            {versionType === '2' && (
              <a
                className="ant-btn ant-btn-primary"
                href="https://ny.nuonuo.com/"
                rel="noreferrer noopener"
                target="_blank"
                styleName="personal-service-btn"
              >
                <Icon
                  type="caishuiketang"
                  style={{
                    fontSize: '15px',
                    paddingRight: '5px',
                  }}
                />
                诺诺课堂
                {nuomiEnabled && (
                  <Icon
                    type="vip-nuonuoketang"
                    style={{
                      fontSize: '24px',
                      position: 'absolute',
                      top: '-5px',
                      right: '-2px',
                      color: '#FF991F',
                    }}
                  />
                )}
              </a>
            )}
            {values && getTitleGuide && username && versionType !== '2' ? (
              <Popover
                placement="bottom"
                visible={values && getTitleGuide && username}
                title=""
                content={content}
                trigger="click"
              >
                <a
                  className="ant-btn ant-btn-primary"
                  href={`${util.getNewUrl(
                    'https://robot.jss.com.cn/pc.do?newKey=kwy6d386c7566304a685742516c67636e6651755a454b773d3d',
                  )}`}
                  rel="noreferrer noopener"
                  target="_blank"
                  styleName="personal-service-btn"
                >
                  <Icon
                    type="zhinengkefu1"
                    style={{
                      fontSize: '15px',
                      paddingRight: '5px',
                    }}
                  />
                  智能客服
                </a>
              </Popover>
            ) : (
              <a
                className="ant-btn ant-btn-primary"
                href={`${util.getNewUrl(
                  'https://robot.jss.com.cn/pc.do?newKey=kwy6d386c7566304a685742516c67636e6651755a454b773d3d',
                )}`}
                rel="noreferrer noopener"
                target="_blank"
                styleName="service-btn"
              >
                <Icon
                  type="zhinengkefu1"
                  style={{
                    fontSize: '15px',
                    paddingRight: '5px',
                  }}
                />
                智能客服
              </a>
            )}
            {/* {versionType === '0' && !isInitSubject && (
              <a
                className="ant-btn ant-btn-primary"
                // styleName="orange"
                href={`/order.html?id=${accountId}`}
                rel="noreferrer noopener"
                target="_blank"
                style={{
                  lineHeight: '26px',
                  height: '28px',
                  background: '#008CFF',
                  borderColor: '#008CFF',
                  minWidth: '60px',
                  padding: '0 10px',
                  marginLeft: '20px',
                }}
              >
                <Icon
                  type="zengzhigongneng"
                  style={{
                    fontSize: '12px',
                    paddingRight: '5px',
                  }}
                />
                增值功能
              </a>
            )} */}

            {/* {versionType == '2' && isAdmin && <RechargeButton status={status} />} */}
            {/* 太难 诺账通和代账帮助中心位置不一样 HelperButton */}
            {!isInitSubject && +versionType === 2 && <HelperButton />}
            {typeof window.ExternService !== 'object' && <ZoomButton />}
            {!isInitSubject && +versionType !== 2 && <HelperButton />}
            {versionType === '0' && !isInitSubject && <MessageButton />}
            {!isInitSubject && <UserButton />}
            {versionType === '1' &&
              versionType !== '3' &&
              typeof window.ExternService !== 'object' && (
                <a
                  styleName="back-btn"
                  className="ant-btn ant-btn-primary ant-btn-background-ghost"
                  href="/cloud/index.html#!/account"
                >
                  返回云代账
                </a>
              )}
          </div>
        </div>
        <div styleName="header-nav">
          <NuomiTabs />
        </div>
      </div>
    </>
  );
};

Header.defaultProps = {
  // accountId: '',
  versionType: '',
  isInitSubject: false,
  username: '',
  entUrl: '',
};

Header.propTypes = {
  // accountId: PropTypes.string,
  versionType: PropTypes.string,
  isInitSubject: PropTypes.bool,
  username: PropTypes.string,
  entUrl: PropTypes.string,
  collapsed: PropTypes.bool.isRequired,
  openKeysTemp: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect(
  ({
    accountId,
    isInitSubject,
    entUrl,
    versionType,
    user: { username, roleName, status, nuomiEnabled },
    menus: { collapsed, openKeysTemp },
  }) => ({
    accountId,
    isInitSubject,
    versionType,
    username,
    entUrl,
    isAdmin: roleName?.indexOf('管理员') !== -1,
    status,
    nuomiEnabled,
    collapsed,
    openKeysTemp,
  }),
)(Header);
