import React from 'react';
import { Route, connect, Redirect } from 'nuomi';
import PropTypes from 'prop-types';
import routeList from '../../../public/router';
import './style.less';

const Content = ({ list, $initMenus }) => {
  const routes = routeList(list);
  return (
    <div id="container" styleName="content">
      {routes.map(({ path, ...rest }) => (
        <Route key={path} path={path} {...rest} />
      ))}
      {/* 因为路由通过接口动态配置的，不控制则会导致刷新页面时跳转到首页 */}
      {$initMenus === false && <Redirect to={routes[0].path} />}
    </div>
  );
};

Content.defaultProps = {
  $initMenus: true,
};

Content.propTypes = {
  list: PropTypes.arrayOf(PropTypes.any).isRequired,
  $initMenus: PropTypes.bool,
};

export default connect(({ menus: { list }, loadings: { $initMenus } }) => ({ list, $initMenus }))(
  Content,
);
