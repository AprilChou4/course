import React, { Component } from 'react';
import { Popover, Button, Modal } from 'antd';
import { setGuideType, getGuideType } from 'utils';
import PropTypes from 'prop-types';
import { layer } from 'nuijs';
import { router, store } from 'nuomi';
import style from './style.less';
import mergeMessage from '../../modals/mergeMessage';

const popverDatas = [
  {
    url: '/setting/account-set',
    // 是否需要加载列表后进行导航传样式名称
    getList: '',
    // 滚动条元素（需要滚动至显示的元素） css 从当前元素往上找
    scrollDom: 'content-body',
    data: [
      {
        // 定位
        placement: 'right',
        // 当前位置
        index: 1,
        // 寻找样式名称
        newGuideClass: 'newGuide1',
        // 导航 type和navigation配套使用
        // type: 'navigation',
        // navigation: '固定资产$Menu',
        // 当前引导标记
        sessionType: null,
        // 寻找id名称
        newGuideId: '',
        // 再加个遮罩
        isMask: false,
        // 头名称
        title: '精度设置',
        // 内容
        content: `可以设置单价、数量、外币、汇率的小数位数。系统默认4位，新建账套记得先设置哦！`,
        oktext: '下一步',
        cleartext: '稍后再看',
        // 方法打开执行一遍 关闭执行一遍 data = 当前元素 type = 当前状态0第一次，1第二次, center = 当前容器
        // aflfun: (data, type) => {},
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: -12,
        },
        // // 气泡的依赖元素内div自定义样式 有才添加div没有则空
        // popDivStyle: {},
        // 额外样式合并样式内
        optionStyle: {},
        // 用于自定义
        option: {
          // 是否自适应
          Percentage: 0.125,
          // 右边显示最大宽度 小于时 用100%
          maxWidth: 650,
        },
      },
      {
        placement: 'topRight',
        index: 2,
        newGuideClass: 'newGuide2',
        title: '编码长度设置',
        content: `可以设置最多九级的科目编码长度。新建账套请先进行设置哦`,
        oktext: '下一步',
        cleartext: '稍后再看',
        addStyle: {
          top: 10,
          left: 5,
          right: 15,
          bottom: -12,
        },
        option: {
          Percentage: 0.18,
          maxWidth: 910,
        },
      },
      {
        placement: 'top',
        index: 3,
        newGuideClass: 'newGuide3',
        title: '凭证类别设置',
        content: `可以设置“收”“付”“转”等凭证类别，满足企业级精准核算。`,
        oktext: '下一步',
        cleartext: '稍后再看',
        addStyle: {
          top: 10,
          left: 5,
          right: 5,
          bottom: -12,
        },
        option: {
          Percentage: 0.125,
          maxWidth: 650,
        },
      },
      {
        placement: 'right',
        index: 4,
        newGuideClass: 'newGuide4',
        title: '模块启用-存货成本',
        content: `只需勾选“存货成本”模块，即可使用出入库单自动生成、进销存台账、成本结转、暂估计算等功能`,
        oktext: '下一步',
        cleartext: '稍后再看',
        addStyle: {
          top: 10,
          left: 5,
          right: 5,
          bottom: -12,
        },
        option: {
          Percentage: 0.125,
          maxWidth: 560,
        },
      },
      {
        placement: 'right',
        index: 5,
        newGuideClass: 'newGuide5',
        title: '模块启用-存货成本',
        content: `选择商贸型，期末-结转中可进行成本结转、暂估计算；选择制造型，期末-结转中还可进行生产领料、制造费用结转、完工入库智能结转。`,
        oktext: '下一步',
        cleartext: '稍后再看',
        addStyle: {
          top: 16,
          left: 5,
          right: 5,
          bottom: 16,
        },
        option: {
          Percentage: 0,
          maxWidth: 200,
        },
      },
    ],
  },
  {
    url: '/setting/subject-manage',
    data: [
      {
        placement: 'right',
        index: 6,
        newGuideClass: 'newGuide6',
        isMask: true,
        title: '新增科目方向',
        content: `可编辑新增下级科目的科目方向。科目方向听我的`,
        oktext: '下一步',
        cleartext: '稍后再看',
        addStyle: {
          top: 5,
          left: 0,
          right: 15,
          bottom: 5,
        },
        optionStyle: {
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
        },
        option: {
          Percentage: 0,
          maxWidth: 400,
        },
      },
      {
        placement: 'right',
        index: 7,
        newGuideClass: 'newGuide7',
        isMask: true,
        title: '多辅助多外币',
        content: `全面支持科目多辅助多外币核算！`,
        oktext: '下一步',
        cleartext: '稍后再看',
        aflfun(data, type, center) {
          if (type === '1' && center && data) {
            center.querySelectorAll('.ant-modal-close-x')[0].click();
          }
        },
        addStyle: {
          top: 5,
          left: 0,
          right: 15,
          bottom: 5,
        },
        optionStyle: {
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
        },
        option: {
          Percentage: 0,
          maxWidth: 200,
        },
      },
    ],
  },
  {
    url: '/voucher/record',
    data: [
      {
        placement: 'bottomLeft',
        index: 8,
        newGuideClass: 'newGuide8',
        sessionType: '8',
        title: '复制分录行次',
        content: `解放双手，让录凭证“飞起来”！`,
        oktext: '下一步',
        cleartext: '稍后再看',
        aflfun(data, type, center) {
          if (center) {
            if (type === '1') {
              center.classList.remove('guide-s-hover');
            } else {
              center.classList.add('guide-s-hover');
            }
          }
        },
        addStyle: {
          top: 0,
          left: 0,
          right: 0,
          bottom: -170,
        },
      },
    ],
  },
  {
    url: '/billmanage/entry-invoice',
    data: [
      {
        placement: 'left',
        index: 9,
        newGuideClass: 'newGuide9',
        sessionType: '9',
        aflfun(data) {
          if (data) {
            data.click();
          }
        },
        addStyle: {
          top: 10,
          left: 55,
          right: 10,
          bottom: 170,
        },
        bottom: 0,
        title: '自定义显示列',
        content: `可以设置想要展示的发票字段，高效和简洁可以兼得！`,
        oktext: '下一步',
        cleartext: '稍后再看',
      },
    ],
  },
  {
    url: '/assets/card',
    data: [
      {
        placement: 'right',
        index: 10,
        type: 'navigation',
        navigation: '固定资产$Menu',
        addStyle: {
          top: 40,
          left: 0,
          right: 0,
          bottom: 0,
        },
        title: '固定资产',
        content: `全模块更新！固定资产数量、拆分、停用、启用…均已上线！`,
        oktext: '下一步',
        cleartext: '稍后再看',
      },
      {
        placement: 'left',
        index: 11,
        newGuideClass: 'newGuide11',
        sessionType: '11',
        aflfun(data) {
          if (data) {
            data.click();
          }
        },
        addStyle: {
          top: 20,
          left: 12,
          right: 25,
          bottom: 210,
        },
        title: '更多…',
        content: `清理、变动均支持批量操作！点击更多，发现更多！`,
        oktext: '下一步',
        cleartext: '稍后再看',
      },
    ],
  },
  {
    url: '/assets/depreciation',
    data: [
      {
        placement: 'right',
        index: 12,
        newGuideClass: 'newGuide12',
        sessionType: '12',
        aflfun(data) {
          if (data) {
            data.querySelectorAll('.ant-input')[0].click();
          }
        },
        addStyle: {
          top: 10,
          left: 45,
          right: 150,
          bottom: 305,
        },
        title: '开账',
        content: `点我，连续计提折旧！`,
        oktext: '下一步',
        cleartext: '稍后再看',
        optionStyle: {
          height: 50,
          position: 'absolute',
          right: 0,
          bottom: 68,
        },
        popDivStyle: {
          float: 'right',
          width: '160px',
          height: '50px',
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
          marginRight: '18px',
        },
      },
    ],
  },
  {
    url: '/assets/depreciation-detail',
    data: [
      {
        placement: 'right',
        index: 13,
        newGuideClass: 'newGuide13',
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 5,
        },
        title: '选择期间',
        content: `生成账簿升级为期间选择，想看哪个期间可以自由选择！`,
        oktext: '下一步',
        cleartext: '稍后再看',
      },
      {
        placement: 'right',
        index: 14,
        newGuideClass: 'newGuide14',
        sessionType: '14',
        aflfun(data, type) {
          if (data) {
            if (type === '0') {
              data.querySelectorAll('.ant-input-prefix')[0].childNodes[0].click();
            } else {
              data.querySelectorAll('.ant-input')[0].click();
            }
          }
        },
        addStyle: {
          top: 10,
          left: -10,
          right: 55,
          bottom: 305,
        },
        bottom: 0,
        title: '已清理固定资产折旧统计',
        content: `选上它，已清理的固定资产折旧也能统计啦！`,
        oktext: '下一步',
        cleartext: '稍后再看',
        optionStyle: {
          height: 40,
          position: 'absolute',
          left: 0,
          bottom: 82,
        },
        popDivStyle: {
          float: 'right',
          width: '296px',
          height: '40px',
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
          marginRight: '14px',
        },
      },
    ],
  },
  {
    url: '/terminal/carryover',
    getList: 'ui-tmp-card',
    data: [
      {
        placement: 'right',
        index: 15,
        newGuideClass: 'newGuide15',
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 5,
        },
        title: '结转增值税',
        content: `一键解决销项税金、进项税金长期挂账`,
        oktext: '下一步',
        cleartext: '稍后再看',
      },
      {
        placement: 'left',
        index: 16,
        newGuideClass: 'newGuide16',
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 5,
        },
        title: '计提所得税设置',
        content: `解决三个问题：依据什么计提？计提了多少？应该计提多少？`,
        oktext: '下一步',
        cleartext: '稍后再看',
        optionStyle: {
          height: 36,
          marginTop: 5,
        },
        popDivStyle: {
          float: 'right',
          width: '65px',
          height: '38px',
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
          marginRight: '5px',
        },
      },
      {
        placement: 'left',
        index: 17,
        newGuideClass: 'newGuide17',
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 5,
        },
        title: '列表展示',
        content: `厌倦了卡片展示？换个风格～`,
        oktext: '下一步',
        cleartext: '稍后再看',
        optionStyle: {
          height: 32,
          marginTop: 5,
        },
        popDivStyle: {
          float: 'right',
          width: '38px',
          height: '32px',
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
          marginRight: '5px',
        },
      },
    ],
  },
  {
    url: '/books/balance',
    data: [
      {
        placement: 'left',
        index: 18,
        newGuideClass: 'newGuide18',
        sessionType: '18',
        aflfun(data) {
          if (data) {
            data.click();
          }
        },
        addStyle: {
          top: 5,
          left: 5,
          right: 360,
          bottom: 425,
        },
        title: '常用条件',
        content: `经常需要查看去年数据？试试存为常用条件吧！`,
        oktext: '下一步',
        cleartext: '稍后再看',
        optionStyle: {
          height: 44,
          position: 'absolute',
          left: 0,
          bottom: 27,
        },
        popDivStyle: {
          float: 'left',
          marginLeft: '83px',
          width: '116px',
          height: '44px',
          background: 'rgba(255,139,0,0.10)',
          border: `2px dashed #FF8B00`,
        },
      },
    ],
  },
  {
    url: '/setting/backup-manage',
    data: [
      {
        placement: 'left',
        index: 19,
        newGuideClass: 'newGuide19',
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 5,
        },
        title: '归档',
        content: `年度归档无需逐个页面点击导出，点我一键搞定！`,
        oktext: '下一步',
        cleartext: '稍后再看',
      },
    ],
  },
  {
    url: '/systemSetting',
    data: [
      {
        placement: 'right',
        index: 20,
        newGuideClass: 'newGuide20',
        addStyle: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 20,
        },
        title: '打印平台',
        content: `凭证、账簿、报表支持自定义纸张大小、页边距调整，还可以分享模板哦！`,
        oktext: '开始使用！',
        cleartext: '',
      },
    ],
    scrollDom: 'newGuide20',
  },
];

class Main extends Component {
  constructor(props) {
    super(props);
    // 定时器
    let position =
      typeof getGuideType(null, 1) === 'object' ? getGuideType(null, 1).position || [0, 0] : [0, 0];
    if (!popverDatas[position[0]].data[position[1]]) {
      position = [position[0] + 1, 0];
    }
    this.elems = null;
    this.times = null;
    this.contentRef = null;
    this.state = {
      // 是否显示遮罩
      fig: true,
      // 提示信息是否显示
      popFig: false,
      // 当前页面的元素
      container: null,
      // 当前引导的元素
      onGuide: null,
      // 当前页需要引导集合
      // containerList: [],
      // 当前引导页面排位
      index: position[0],
      // 当前页面为第几个引导
      len: position[1],
      // 当前引导元素大小
      conSize: {
        top: 0,
        left: 0,
        width: 0,
        height: 0,
      },
    };
  }

  // 加载完毕 执行resize和获取页面元素
  componentDidMount() {
    document.body.classList.add('guideBody');
    const urlList = window.location.href.split('#!');
    const { index } = this.state;
    // 判断url是否相同
    if (urlList[1] !== popverDatas[index].url) {
      this.times = setTimeout(() => {
        this.onJump(popverDatas[index].url);
      }, 100);
    } else {
      // url 相同
      this.times = setTimeout(() => {
        this.getElements();
      }, 300);
    }
    window.addEventListener('resize', this.resize);
  }

  // 注销resize
  componentWillUnmount() {
    clearTimeout(this.times);
    if (this.resize) {
      window.removeEventListener('resize', this.resize);
    }
  }

  // 浏览器宽度发生变化
  resize = () => {
    this.eleSize();
  };

  // 获取offsetTop
  offsetTop = (el, size = 0) => {
    if (!el) {
      return size;
    }
    return this.offsetTop(el.offsetParent, size + el.offsetTop || 0);
  };

  // 获取offsetLeft
  offsetLeft = (el, size = 0) => {
    if (!el) {
      return size;
    }
    return this.offsetLeft(el.offsetParent, size + el.offsetLeft || 0);
  };

  // 更新位置
  setConSize = (vals) => {
    const { len, index, container } = this.state;
    const conSize = {
      top: this.offsetTop(vals),
      left: this.offsetLeft(vals),
      width: vals.offsetWidth,
      height: vals.offsetHeight,
    };
    this.setState({
      conSize,
      onGuide: vals,
      popFig: true,
    });
    sessionStorage.setItem('guideoption', popverDatas[index].data[len].sessionType);
    if (popverDatas[index].data[len].aflfun) {
      popverDatas[index].data[len].aflfun(vals, '0', container);
    }
  };

  // 获取当前元素信息
  eleSize = () => {
    const { len, index, container } = this.state;
    // 如果当前有节点存在不需要再取
    let vals = container.querySelectorAll(`.${popverDatas[index].data[len].newGuideClass}`)[0];
    // 需要定位到导航
    if (!vals && popverDatas[index].data[len].type === 'navigation') {
      const ul = window.document.getElementById(popverDatas[index].data[len].navigation).childNodes;
      for (let i = 0; i < ul.length; i++) {
        if (ul[i].firstChild.getAttribute('href') === `#!${popverDatas[index].url}`) {
          vals = ul[i];
        }
      }
      setTimeout(() => {
        this.setConSize(vals);
      }, 500);
      return;
    }
    if (!vals) {
      this.okOnFun();
      return;
    }
    this.setConSize(vals);
  };

  voucherHover = (vals) => {
    const lists = vals.querySelectorAll('.table-row');
    if (lists.length > 0) {
      lists[0].classList.add('s-hover');
    } else {
      setTimeout(() => {
        this.voucherHover(vals);
      }, 300);
    }
  };

  // 给浮沉添加样式使他可见
  onModal = () => {
    const modal = window.document.getElementsByClassName('guide-modals');
    if (modal.length > 0) {
      modal[0].parentNode.setAttribute('style', `z-index: 11001;`);
      modal[0].parentNode.previousSibling.setAttribute('style', `display: none;`);
      this.setState(
        {
          container: modal[0],
        },
        () => {
          setTimeout(() => {
            this.eleSize();
          }, 200);
        },
      );
    } else {
      setTimeout(() => {
        this.onModal();
      }, 300);
    }
  };

  // 查询点击的科目
  onSubject = (container) => {
    const list = container.querySelectorAll('.icon-bianji');
    if (list.length <= 0) {
      setTimeout(() => {
        this.onSubject(container);
      }, 300);
    } else {
      list[0].click();
      this.onModal();
    }
  };

  getList = (container, className) => {
    const { index } = this.state;
    const list = container.querySelectorAll(`.${className}`);
    if (popverDatas[index].url === '/terminal/carryover') {
      if (container.querySelectorAll(`.ant-supertable`).length) {
        this.eleSize();
      }
    }
    if (list.length <= 0) {
      setTimeout(() => {
        this.getList(container, className);
      }, 200);
      return;
    }
    this.eleSize();
  };

  // 获取当前页面容器
  getElements = () => {
    const { index } = this.state;
    const divList = window.document.getElementById('container').children;
    let container = null;
    if (divList.length <= 0) {
      setTimeout(() => {
        this.getElements();
      }, 300);
      return;
    }
    for (let i = 0; i < divList.length; i++) {
      if (!divList[i].style || divList[i].style.display !== 'none') {
        container = divList[i];
      }
    }
    if (!container) {
      setTimeout(() => {
        this.getElements();
      }, 300);
      return;
    }
    this.setState(
      {
        container,
      },
      () => {
        const { isDisable, user } = store.getState().account;
        if (
          popverDatas[index].url === '/setting/subject-manage' &&
          !isDisable &&
          user.useStatus !== 3
        ) {
          this.onSubject(container);
          return;
        }
        // 需要列表出来才进行计算
        if (popverDatas[index].getList) {
          this.getList(container, popverDatas[index].getList);
          return;
        }
        this.eleSize();
      },
    );
  };

  // 跳转到相应的url地址
  onJump = (url) => {
    const { list } = store.getState().account.menus;
    const { index } = this.state;
    const newIndex = index + 1;
    const onMenu = list.filter((val) => val.path === url);
    // 导航没有的都要添加 要不然要报错
    if (onMenu.length <= 0 && url !== '/systemSetting') {
      this.setState(
        {
          index: newIndex,
        },
        () => {
          this.onJump(popverDatas[newIndex].url);
        },
      );
      return;
    }
    router.location(url, true);
    setTimeout(() => {
      this.getElements();
    }, 500);
  };

  // 下一步
  okOnFun = () => {
    const { len, index, container } = this.state;
    if (popverDatas[index].data[len + 1]) {
      this.setState(
        {
          len: len + 1,
          onGuide: null,
          conSize: {
            top: 0,
            left: 0,
            width: 0,
            height: 0,
          },
        },
        () => {
          this.eleSize();
        },
      );
    } else if (popverDatas.length > index + 1) {
      const newIndex = index + 1;
      this.setState(
        {
          len: 0,
          index: newIndex,
          popFig: false,
          onGuide: null,
          conSize: {
            top: 0,
            left: 0,
            width: 0,
            height: 0,
          },
        },
        () => {
          layer.hide();
          Modal.destroyAll();
          store.getStore('tabs').dispatch({
            type: 'removeAll',
          });
          setTimeout(() => {
            this.onJump(popverDatas[newIndex].url);
          });
        },
      );
    } else {
      mergeMessage();
      layer.hide();
      Modal.destroyAll();
      store.getStore('tabs').dispatch({
        type: 'removeAll',
      });
      // this.setState({
      //   fig: false,
      // });
      document.body.classList.remove('guideBody');
      setGuideType({
        position: [index, len],
        index: popverDatas[index].data[len].index,
      });

      store.getStore('account').dispatch({
        type: 'account/updateState',
        payload: {
          isGuide: {
            isShow: false,
            index: len + 1,
          },
        },
      });
    }
    sessionStorage.setItem('guideoption', '');
    if (popverDatas[index].data[len].aflfun) {
      popverDatas[index].data[len].aflfun(
        container.querySelectorAll(`.${popverDatas[index].data[len].newGuideClass}`)[0],
        '1',
        container,
      );
    }
  };

  render() {
    const { fig, conSize, index, len, popFig, onGuide, container } = this.state;
    let popStyle = { width: '100%', height: '100%' };
    // 上中下左右
    let popShang = {};
    let popxia = {};
    let popzuo = {};
    let popyou = {};
    let popzhong = {};

    const vals = { ...popverDatas[index].data[len] };

    const docWidth = document.documentElement.clientWidth;
    const docHeight = document.documentElement.clientHeight;
    const {
      addStyle = {
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
      },
    } = vals;
    const upStyles = { ...addStyle };
    const conSizes = { ...conSize };
    if (
      conSizes.top === 0 &&
      conSizes.left === 0 &&
      conSizes.width === 0 &&
      conSizes.height === 0
    ) {
      upStyles.top = 0;
      upStyles.left = 0;
      upStyles.right = 0;
      upStyles.bottom = 0;
    }

    if (docHeight < conSizes.top + conSizes.height + 50 && popverDatas[index].scrollDom) {
      const scrollDom = container.querySelectorAll(`.${popverDatas[index].scrollDom}`)[0];
      const { scrollHeight, clientHeight, scrollTop } = scrollDom;
      let scrollTops = scrollTop + (conSizes.height < 150 ? 150 : conSizes.height);
      // if (
      //   scrollTops > scrollHeight - clientHeight ||
      //   (scrollTop === 0 && scrollHeight > clientHeight)
      // ) {
      if (scrollTops > scrollHeight - clientHeight) {
        scrollTops = scrollHeight - clientHeight;
        if (vals.placement === 'right') {
          vals.placement = 'topRight';
        }
      }

      if (this.elems === onGuide) {
        scrollDom.scrollTop = scrollTop;
        conSizes.top -= scrollTop;
      } else {
        scrollDom.scrollTop = scrollTops;
        conSizes.top -= scrollTops;
        this.elems = onGuide;
      }
    } else if (container && popverDatas[index].scrollDom) {
      const scrollDom = container.querySelectorAll(`.${popverDatas[index].scrollDom}`)[0];
      const { scrollTop } = scrollDom || {};
      conSizes.top -= scrollTop || 0;
    }

    const newConSize = {
      top: conSizes.top - upStyles.top,
      left: conSizes.left - upStyles.left,
      width: conSizes.width + upStyles.left + upStyles.right,
      height: conSizes.height + upStyles.top + upStyles.bottom,
    };
    // 账套设置特殊 处理
    if (popverDatas[index].url === '/setting/account-set') {
      const popWidth = Math.floor(
        vals.option.Percentage &&
          conSizes.width - conSizes.width * vals.option.Percentage < vals.option.maxWidth
          ? conSizes.width
          : vals.option.maxWidth + conSizes.width * vals.option.Percentage,
      );
      if (
        conSizes.width - (conSizes.width * vals.option.Percentage + 344) < vals.option.maxWidth &&
        vals.placement === 'right'
      ) {
        vals.placement = 'topRight';
      }
      newConSize.width = popWidth >= vals.option.maxWidth + 334 ? newConSize.width : popWidth;
    }

    popStyle = { ...popStyle, ...vals.optionStyle };
    /** 兼容缩放 取整数部分 * start */
    const pixe = (window.devicePixelRatio * 100).toString().split('.')[0];
    if (pixe !== '100' && newConSize.top) {
      const pixeTop = ((newConSize.top * pixe) / 100).toFixed(2).toString().split('.')[1];
      const pixHeight = ((newConSize.height * pixe) / 100).toFixed(2).toString().split('.')[1];
      if (pixHeight && pixHeight[0] >= 1) {
        const pixes = {
          height: Number(((100 - Number(pixHeight.substring(0, 2))) / pixe).toFixed(2)),
        };
        newConSize.height += pixes.height;
      }
      if (pixeTop && pixeTop[0] >= 1) {
        const pixes = {
          top: Number(((100 - Number(pixeTop.substring(0, 2))) / pixe).toFixed(2)),
        };
        newConSize.top += pixes.top;
      }
    }
    /** 兼容缩放 取整数部分 * end */
    popShang = {
      opacity: 0.5,
      background: '#000000',
      height: newConSize.top <= 0 ? 0 : newConSize.top,
      width: '100%',
    };
    popxia = {
      opacity: 0.5,
      background: '#000000',
      height:
        docHeight - newConSize.top - newConSize.height < 0
          ? 0
          : docHeight - newConSize.top - newConSize.height,
      width: '100%',
      top: newConSize.top > 0 ? newConSize.top + newConSize.height : 0,
    };
    popzuo = {
      top: newConSize.top,
      opacity: 0.5,
      background: '#000000',
      height: newConSize.height <= 0 ? 0 : newConSize.height,
      width: newConSize.left,
    };
    popyou = {
      top: newConSize.top,
      opacity: 0.5,
      background: '#000000',
      height: newConSize.height <= 0 ? 0 : newConSize.height,
      width:
        docWidth - newConSize.left - newConSize.width < 0
          ? 0
          : docWidth - newConSize.left - newConSize.width,
    };
    popzhong = {
      height: newConSize.height <= 0 ? 0 : newConSize.height,
      width: newConSize.width,
      top: newConSize.top,
      left: newConSize.left,
      zIndex: 11002,
    };

    const html = (
      <div style={{ padding: 8 }}>
        <h5 style={{ fontSize: '16px', color: '#000000', marginBottom: '8px', fontWeight: 'bold' }}>
          {vals.title}
        </h5>
        <p style={{ marginBottom: '16px', fontSize: '13px', color: '#323232' }}>{vals.content}</p>
        <div style={{ textAlign: 'center' }}>
          {vals.cleartext && (
            <span
              onClick={() => {
                const { setStates } = this.props;
                setStates({
                  visible: true,
                  cbk: () => {
                    store.getStore('account').dispatch({
                      type: 'account/updateState',
                      payload: {
                        isGuide: {
                          isShow: false,
                          index: len + 1,
                        },
                      },
                    });
                    setGuideType({
                      position: [index, len + 1],
                      index: vals.index,
                    });
                    sessionStorage.setItem('guideoption', '');
                    if (popverDatas[index].data[len].aflfun) {
                      popverDatas[index].data[len].aflfun(
                        container.querySelectorAll(
                          `.${popverDatas[index].data[len].newGuideClass}`,
                        )[0],
                        '1',
                        container,
                      );
                    }
                  },
                });
              }}
              style={{ border: '0 none', marginRight: 50, cursor: 'pointer', color: '#008CFF' }}
            >
              {vals.cleartext}
            </span>
          )}
          <Button type="primary" onClick={this.okOnFun}>
            {`${vals.oktext} ( ${vals.index} / 20)`}
          </Button>
        </div>
      </div>
    );
    const { contentRef } = this;
    return fig ? (
      <>
        {vals.isMask && (
          <div
            style={{
              position: 'absolute',
              zIndex: '11002',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
            }}
          />
        )}
        <div style={popShang} className={style['ui-guide-shang']} />
        <div style={popyou} className={style['ui-guide-you']} />
        <div style={popxia} className={style['ui-guide-xia']} />
        <div style={popzuo} className={style['ui-guide-zuo']} />
        <div
          style={
            popFig ? popzhong : { ...popzhong, opacity: 0.5, background: '#000000', zIndex: 11001 }
          }
          className={style['ui-guide-zhong']}
          ref={(e) => {
            this.contentRef = e;
          }}
        >
          {onGuide && popFig && (
            <Popover
              placement={vals.placement}
              title={null}
              content={html}
              visible={popFig}
              autoAdjustOverflow={false}
              getPopupContainer={() => contentRef}
              overlayStyle={{
                width: 334,
              }}
            >
              <div style={popStyle}>{vals.popDivStyle && <div style={vals.popDivStyle} />}</div>
            </Popover>
          )}
        </div>
      </>
    ) : (
      ''
    );
  }
}

Main.propTypes = {
  setStates: PropTypes.func.isRequired,
};

export default Main;
