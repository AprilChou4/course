import React, { Component } from 'react';
import { Button, Modal } from 'antd';
import { setGuideType } from 'utils';
import { layer } from 'nuijs';
import { store } from 'nuomi';
import PropTypes from 'prop-types';
import { SuperModal } from '@/modal';
import mergeMessage from '../../modals/mergeMessage';
import Guide from './guide';
import style from './style.less';

class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fig: false,
      visible: false,
      cbk: null,
    };
    this.modals = null;
  }

  componentDidMount() {
    if (store.getState().account.isGuide.isShow) {
      this.setState({
        fig: true,
      });
      return;
    }
    this.showModal();
  }

  showModal = () => {
    const { versionType } = this.props;
    this.modals = SuperModal({
      zIndex: 11001,
      width: 560,
      className: style.guideLayer,
      title: `欢迎使用云记账${versionType === '2' ? '新' : 'V4.0'}版本`,
      centered: true,
      content: '',
    });
    this.modals.update({
      content: (
        <div className="guideLayer-main">
          <p>
            <em />
            <span>{`新手引导将向您介绍云记账${versionType === '2' ? '' : '4.0'}的全新改变`}</span>
            <em />
          </p>
          <Button className="experiencePlan-button" onClick={this.onClick}>
            点我！开始新功能引导
          </Button>
          <br />
          <span
            onClick={() => {
              // this.modals.destroy();
              this.setState({
                visible: true,
              });
              // setGuideType({ position: [0, 0] });
            }}
            style={{
              lineHeight: '45px',
              display: 'inline-block',
              color: '#7A3605',
              fontSize: '14px',
              cursor: 'pointer',
              textDecoration: 'underline',
            }}
          >
            不，我已熟悉
          </span>
        </div>
      ),
    });
  };

  onClick = () => {
    this.modals.destroy();
    this.setState({
      fig: true,
    });
  };

  onRemove = () => {
    mergeMessage();
    layer.hide();
    Modal.destroyAll();
    store.getStore('tabs').dispatch({
      type: 'removeAll',
    });
  };

  render() {
    const { fig, visible, cbk } = this.state;
    return (
      (fig || visible) && (
        <>
          {fig && <Guide setStates={(data) => this.setState(data)} />}
          <Modal
            title="温馨提示"
            width={418}
            zIndex={11003}
            centered
            maskClosable={false}
            visible={visible}
            onOk={() => {
              if (cbk) {
                cbk();
              } else {
                store.getStore('account').dispatch({
                  type: 'account/updateState',
                  payload: {
                    isGuide: {
                      isShow: false,
                      index: 0,
                    },
                  },
                });
                setGuideType({
                  position: [0, 0],
                  index: 0,
                });
              }
              // setTimeout(() => {
              this.setState({ visible: false, fig: false });
              this.onRemove();
              document.body.classList.remove('guideBody');
              // }, 100);
            }}
            onCancel={() => {
              this.setState({ visible: false });
            }}
            cancelText="取消"
          >
            <h6 style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold' }}>
              是否确定退出新手引导？
            </h6>
            <p style={{ textAlign: 'center', marginBottom: '0px' }}>
              新功能引导可帮助您快速了解云记账新特性,
              <br />
              可以在<span style={{ color: '#FF8B00' }}>右上角-新手功能介绍</span>中再次开启。
            </p>
          </Modal>
        </>
      )
    );
  }
}

Main.defaultProps = {
  versionType: '2',
};

Main.propTypes = {
  versionType: PropTypes.string,
};

export default Main;
