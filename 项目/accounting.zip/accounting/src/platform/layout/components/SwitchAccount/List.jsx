import { Col, Row, Button } from 'antd';
import React from 'react';
import PropTypes from 'prop-types';
import List from 'react-virtualized/dist/commonjs/List';
import TableCell from '@/TableCell';
import './style.less';

const SwitchAccountList = ({ keyword, onSelectAcc, list }) => {
  const rowRenderer = ({ key, index, style }) => {
    const item = list[index];
    const newStyle = { ...style };
    // // 第一行显示当前账套，添加文本 color 样式
    // if (index === 0 && style.position && !keyword) {
    //   newStyle = {
    //     ...style,
    //     color: '#008CFF',
    //   };
    // }

    return (
      <div key={key} style={newStyle} styleName="v-list-item">
        <Row gutter={8}>
          <Col span={13}>
            <TableCell>{item.name}</TableCell>
          </Col>
          <Col span={4}>{item.accountState}</Col>
          <Col span={7}>
            <span styleName="date">{item.statePeriod}</span>
            <Button styleName="btn" type="primary" size="small" onClick={() => onSelectAcc(item)}>
              切换账套
            </Button>
          </Col>
        </Row>
      </div>
    );
  };

  rowRenderer.propTypes = {
    key: PropTypes.string.isRequired,
    index: PropTypes.number.isRequired,
    style: PropTypes.objectOf(PropTypes.any).isRequired,
  };

  if (keyword) {
    list.forEach((val) => {
      const item = val;
      if (!item || item.name) return;
      if (item.name.indexOf(keyword) > -1) {
        const index = item.name.indexOf(keyword);
        const beforeStr = item.name.substr(0, index);
        const afterStr = item.name.substr(index + keyword.length);
        item.name =
          index > -1 ? (
            <span>
              {beforeStr}
              <span styleName="highlight">{keyword}</span>
              {afterStr}
            </span>
          ) : (
            <span>{item.name}</span>
          );
      }
    });
    // list.map((val) => {
    //   const item = val;
    //   if (!item || item.name) return;

    //   if (item.name.indexOf(keyword) > -1) {
    //     const index = item.name.indexOf(keyword);
    //     const beforeStr = item.name.substr(0, index);
    //     const afterStr = item.name.substr(index + keyword.length);
    //     item.name =
    //       index > -1 ? (
    //         <span>
    //           {beforeStr}
    //           <span styleName="highlight">{keyword}</span>
    //           {afterStr}
    //         </span>
    //       ) : (
    //         <span>{item.name}</span>
    //       );
    //   }
    //   return false;
    // });
  }

  return (
    <div>
      {list && list.length ? (
        <List
          style={{ outline: 'none', paddingRight: 4 }}
          width={316}
          height={280}
          rowCount={list.length || 0}
          rowHeight={32}
          rowRenderer={rowRenderer}
        />
      ) : (
        <div styleName="noData">暂无数据</div>
      )}
    </div>
  );
};

// SwitchAccountList.defaultProps = {
//   versionType: '',
// };

SwitchAccountList.propTypes = {
  keyword: PropTypes.string.isRequired,
  onSelectAcc: PropTypes.func.isRequired,
  // count: PropTypes.number.isRequired,
  list: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default SwitchAccountList;
