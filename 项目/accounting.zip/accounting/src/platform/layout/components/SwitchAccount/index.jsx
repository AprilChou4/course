/* eslint-disable no-param-reassign */
import { connect } from 'nuomi';
import { Popover, Input, message } from 'antd';
import moment from 'moment';
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import List from './List';
import services from '../../services';

const { Search } = Input;
// const formatDate = (date) =>
//   date && date.indexOf('年') !== -1 ? date.replace(/(\d+)(\D)(\d+)(\D)/g, '$1-$3') : '1970-01';

// const sortByDate = (list) => {
//   // 根据建账时间升序排序
//   return list.sort((a, b) => {
//     const A = formatDate(a.statePeriod);
//     const B = formatDate(b.statePeriod);
//     if (moment(A).isBefore(moment(B))) {
//       return 1;
//     }
//     if (moment(A).isSame(moment(B))) {
//       return 0;
//     }
//     return -1;
//   });
// };

const SwitchAccount = ({ children, versionType, account }) => {
  const [keyword, setKeyword] = useState('');
  const [allList, setAllList] = useState([]);
  const [list, setList] = useState(null);
  const { accountId, entoken } = account;
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!accountId) return;
    const getList = async () => {
      let tempList = [];
      // 加载记账账套列表
      if (versionType === '0') {
        const res = await services.getAccountList({
          order: 'desc',
          pCount: '10',
          current: 1,
        });
        if (!res) return;

        tempList = res.list.filter((item) => {
          const accountState = item.accountState.substr(-3);
          item.statePeriod = item.accountState.replace(accountState, '');
          item.accountState = accountState;
          return accountId !== item.id && item.isTransfer !== 1;
        });
      }
      // 加载代账账套列表
      else {
        const res = await services.getDzList();
        if (!res) return;
        tempList = res.filter((item) => {
          const { accountName, accountId: accID } = item;
          item.accID = accID;
          item.id = accID;
          item.name = accountName;
          return accountId !== accID;
        });
      }

      // tempList = sortByDate(tempList);

      setAllList(tempList);
    };

    getList();
  }, [accountId]);

  const onSearch = (value) => {
    const v = value.trim();
    if (v === '') {
      setKeyword(v);
      setList(null);
      return;
    }

    let filterList = allList.filter((item) => item && item.name && item.name.indexOf(v) > -1);
    filterList = filterList.map((item) => ({ ...item }));

    setKeyword(v);
    setList(filterList);
  };

  const onSelectAcc = async (acc) => {
    // window.location.href = `${basePath || ''}platform.html?id=${acc.id}`;
    const { id, accountSource } = acc;
    let res;
    let flag = false;
    if (accountSource === 1) {
      res = await services.checkBackup({ accId: id });
      if (res === false) {
        flag = true;
      } else {
        flag = false;
      }
    } else if (entoken) {
      flag = true;
    } else {
      res = await services.checkStatus({ accId: id }, { disabledAccountToken: true });
      if (res) {
        flag = true;
      } else {
        flag = false;
      }
    }
    if (flag) {
      window.location.href = `${basePath || ''}${
        accountSource === 1 || entoken ? 'accounting' : 'platform'
      }.html?id=${id}${entoken ? `&entoken=${entoken}` : ''}`;
    } else {
      message.error('账套正在备份/还原，暂时无法访问');
    }
  };

  const content = (
    <div style={{ width: '317px' }}>
      <Search
        placeholder="搜索账套"
        onSearch={(value) => onSearch(value)}
        onChange={(e) => onSearch(e.target.value)}
        style={{ wid2th: '100%', marginBottom: '12px' }}
      />
      <List keyword={keyword} list={list || allList} onSelectAcc={onSelectAcc} />
    </div>
  );

  const props = {
    placement: 'bottomLeft',
    content,
    trigger: 'hover',
  };

  if (typeof ExternService === 'object') {
    props.visible = visible;
    props.trigger = 'click';
    props.onVisibleChange = (status) => {
      setVisible(status);
    };
  }

  useEffect(() => {
    if (typeof ExternService === 'object') {
      window.isClientObjInit({
        switchAccount: () => {
          setVisible(true);
        },
      });
    }
  }, []);
  return (
    <span>
      <Popover {...props}>{children || '账套标题'}</Popover>
    </span>
  );
};

SwitchAccount.defaultProps = {
  versionType: '',
  // currentMonth: null,
};

SwitchAccount.propTypes = {
  children: PropTypes.objectOf(PropTypes.any).isRequired,
  versionType: PropTypes.string,
  account: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ versionType, accountId, user }, { account }) => ({
  versionType,
  accountId,
  mobile: user.mobile,
  account,
}))(SwitchAccount);
