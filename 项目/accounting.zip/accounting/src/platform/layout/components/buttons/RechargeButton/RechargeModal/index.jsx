import React, { useState } from 'react';
import { connect } from 'nuomi';
import { Modal, Row, Col } from 'antd';
import PropTypes from 'prop-types';
import trackEvent from 'public/trackEvent';

import ItemCard from './ItemCard';

import ocrImg from './images/ocr.png';
import ticketImg from './images/ticket.png';

const CHARGE_ITEM_CFG = [
  {
    title: 'OCR票据识别',
    icon: ocrImg,
    price: '100',
    count: '1000',
    type: 4,
  },
  {
    title: '发票查验录入',
    icon: ticketImg,
    price: '100',
    count: '500',
    type: 5,
  },
];

const RechargeModal = ({ onCancel, dispatch }) => {
  const [loading, setLoading] = useState(false);

  const onBuy = async ({ type, title }) => {
    if (loading) return;
    setLoading(true);
    await dispatch({ type: 'onBuy', payload: type });

    trackEvent(title, '立即购买');

    setLoading(false);
  };

  return (
    <Modal
      title="额度充值服务"
      width={646}
      maskClosable={false}
      visible
      footer={null}
      onCancel={onCancel}
    >
      <Row>
        {CHARGE_ITEM_CFG.map((item) => {
          const { title } = item;

          return (
            <Col style={{ textAlign: 'center' }} key={title} span={12}>
              <ItemCard data={item} onClick={onBuy} />
            </Col>
          );
        })}
      </Row>
    </Modal>
  );
};

RechargeModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect()(RechargeModal);
