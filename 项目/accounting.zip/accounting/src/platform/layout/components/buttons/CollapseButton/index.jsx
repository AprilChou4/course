import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import Icon from '@/Icon';
import './style.less';

const CollapseButton = ({ collapsed, openKeysTemp, dispatch }) => {
  const onClick = () => {
    dispatch({
      type: 'updateMenus',
      payload: {
        openKeys: !collapsed ? [] : openKeysTemp,
        collapsed: !collapsed,
      },
    });
  };

  return (
    <span id="collapsedId" styleName="button" onClick={onClick}>
      <Icon style={collapsed ? { color: '#008cff' } : {}} type={collapsed ? 'zhankai' : 'shouqi'} />
    </span>
  );
};

CollapseButton.propTypes = {
  dispatch: PropTypes.func.isRequired,
  collapsed: PropTypes.bool.isRequired,
  openKeysTemp: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect(({ menus: { collapsed, openKeysTemp } }) => ({ collapsed, openKeysTemp }))(
  CollapseButton,
);
