import React, { useState, useEffect } from 'react';
import { connect } from 'nuomi';
import { Popover } from 'antd';
import { util } from 'nuijs';
import Icon from '@/Icon';
import trackEvent from 'public/trackEvent';
import PropTypes from 'prop-types';
import forget from './forgetPassword';
import style from './style.less';
import entlist from './entList/index';

const data = [
  {
    text: '诺诺服务',
    onClick: () => {
      trackEvent('账户操作', '跳转', '诺诺服务');
      util.location(util.getNewUrl('https://www.jss.com.cn'), '_blank');
    },
  },
  {
    text: '修改密码',
    onClick: () => {
      trackEvent('账户操作', '修改密码');
      if (typeof ExternService === 'object') {
        forget();
      } else {
        util.location(userCenter, '_blank');
      }
    },
  },
  {
    text: '切换企业',
    onClick: () => {
      trackEvent('账户操作', '切换企业');
      entlist();
    },
  },
  {
    text: '用户设置',
    onClick: () => {
      util.location('#!/systemSetting');
    },
  },
  {
    text: '退出登录',
    onClick: () => {
      trackEvent('账户操作', '退出');
      util.logout();
    },
  },
].map((v) => {
  const { entoken } = util.getParam();
  if (entoken && v.text === '切换企业') {
    return '';
  }
  if (
    typeof ExternService === 'object' &&
    (v.text === '切换企业' ||
      v.text === '诺诺服务' ||
      v.text === '修改密码' ||
      v.text === '退出登录')
  ) {
    return '';
  }
  return (
    <a key={v.text} className={style.item} {...v}>
      {v.text}
    </a>
  );
});

const UserButton = ({ realName, username, versionType }) => {
  const [visible, setVisible] = useState(false);

  const title = (
    <>
      <i className="iconfont icon-user" />
      <span>
        <em>{realName || username || ''}</em>
        <s>欢迎使用{+versionType === 2 ? '诺账通' : '诺诺云记账'}！</s>
      </span>
    </>
  );

  const props = {
    overlayClassName: style.user,
    arrowPointAtCenter: true,
    placement: 'bottomRight',
    title,
    content: data,
    onVisibleChange: (status) => {
      setVisible(status);
    },
  };
  if (typeof ExternService === 'object') {
    props.visible = visible;
    props.trigger = 'click';
  }

  useEffect(() => {
    if (typeof ExternService === 'object') {
      window.isClientObjInit({
        yhzx: () => {
          setVisible(true);
        },
      });
    }
  }, []);

  return (
    <Popover {...props}>
      <Icon type="ico_user" className={visible ? 'primary' : 'btn-link'} />
    </Popover>
  );
};

UserButton.defaultProps = {
  realName: '',
  username: '',
  versionType: '',
};

UserButton.propTypes = {
  realName: PropTypes.string,
  username: PropTypes.string,
  versionType: PropTypes.string,
};

export default connect(({ user: { realName, username, versionType } }) => ({
  realName,
  username,
  versionType,
}))(UserButton);
