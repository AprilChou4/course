/* *
 * 这是选择企业列表弹层
 * 参数说明
 *
 */
import React from 'react';
import { message } from 'antd';
import { store } from 'nuomi';
import { util } from 'nuijs';
import { SuperModal } from '@/modal';
import services from '../../../../services';
import Content from './content';
import style from './style.less';

// 切换企业
const setUserCompanyList = async ({
  companyId,
  versionType,
  enterpriseCompanyId,
  userEnable,
  accountSource,
  accountId,
}) => {
  if (versionType === 4) {
    if (userEnable === false) {
      message.error(`您的账号未启用，请联系管理员！`);
      return;
    }
    const url = await services.getCloudEnterprise();
    util.location(`${url}/list#!/index?companyId=${enterpriseCompanyId}`);
    return;
  }
  let url = '';
  if (versionType === 3) {
    if (accountSource === 1) {
      const checkBackupData = await services.checkBackup({ accId: accountId });
      if (!checkBackupData) {
        url = '/accounting.html';
      } else {
        message.error('账套正在备份/还原，暂时无法访问');
        return;
      }
    } else {
      const checkStatusData = await services.checkStatus({ accId: accountId });
      if (checkStatusData) {
        url = '/platform.html';
      } else {
        message.error('账套正在备份/还原，暂时无法访问');
        return;
      }
    }
    // util.location(`${url}?id=${accountId}#!/home`);
    // return;
  }

  try {
    await services.switchCompany({ companyId, accountId });
    if (versionType === 3) {
      util.location(`${url}?id=${accountId}#!/home`);
      return;
    }
    if (companyId === '') {
      localStorage.setItem('versionType', '0');
      util.location(`${basePath}accounts.html`);
    } else {
      localStorage.setItem('versionType', '1');
      util.location(`${basePath}cloud/index.html`);
    }
  } catch (e) {
    message.error(e.message || `获取企业列表失败`);
  }
};

// 撤回申请
const cancelUserAppByUser = async (data, cbk) => {
  try {
    await services.cancelUserAppByUser(data);
    message.success('撤回成功');
    if (cbk) {
      cbk();
    }
  } catch (e) {
    // message.error(e.message || `撤回失败`);
  }
};

// 重新申请
const restartJoinCompany = async (data, cbk) => {
  try {
    await services.restartJoinCompany(data);
    message.success('重新申请成功');
    if (cbk) {
      cbk();
    }
  } catch (e) {
    // message.error(e.message || `重新申请失败`);
  }
};

// 弹层
const modalFun = async (userCompanyList = []) => {
  // 企业信息
  const { user, accountId, accountName } = store.getState().account;
  const datas = { ...user, accountId, accountName };
  // console.log(store.getState());
  // 当前企业名称
  const userName = datas.versionType === '1' ? datas.companyName : datas.realName;
  // 是否客户端
  const client = typeof ExternService === 'object';
  // 过滤后的列表
  const list = [];
  // 所有列表的名称列表 去除重名的
  const listName = [];
  // 重名列表
  const duplicateName = [];
  userCompanyList.forEach((val) => {
    if (client) {
      if (val.versionType !== 0 && !val.notActive) {
        list.push(val);
        if (listName.includes(val.companyName)) {
          duplicateName.push(val.companyName);
        } else {
          listName.push(val.companyName);
        }
      }
    } else if (!val.notActive) {
      list.push(val);
      if (listName.includes(val.companyName)) {
        duplicateName.push(val.companyName);
      } else {
        listName.push(val.companyName);
      }
    }
  });
  const modal = SuperModal({
    content: null,
    title: null,
    centered: true,
    width: 600,
    className: style.modalEntList,
  });
  modal.update({
    content: (
      <Content
        data={{ datas, userName, client, list, listName, duplicateName }}
        setUserCompanyList={setUserCompanyList}
        cancelUserAppByUser={cancelUserAppByUser}
        restartJoinCompany={restartJoinCompany}
      />
    ),
  });
};

// 获取列表
const getUserCompanyList = async () => {
  try {
    const userCompanyList = await services.getUserCompanyList();
    modalFun(userCompanyList);
  } catch (e) {
    message.error(e.message || `获取企业列表失败`);
  }
};

export default getUserCompanyList;
