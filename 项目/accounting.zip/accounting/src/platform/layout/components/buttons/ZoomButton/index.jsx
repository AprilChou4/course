import React from 'react';
import PropTypes from 'prop-types';
import { usePersistFn, useFullscreen } from 'ahooks';
import { connect } from 'nuomi';
import { Popover } from 'antd';
import Icon from '@/Icon';

const ZoomButton = ({ dispatch }) => {
  const [isFullscreen, { toggleFull }] = useFullscreen(() => document.querySelector('body > #app'));

  const handleToggleFull = usePersistFn(() => {
    toggleFull();
    dispatch({
      type: 'updateState',
      payload: { isFullscreen: !isFullscreen },
    });
  });

  return (
    <Popover content="全屏">
      <Icon
        className="btn-link"
        type={isFullscreen ? 'quxiaoquanping' : 'quanping1'}
        onClick={handleToggleFull}
      />
    </Popover>
  );
};

// const ZoomButton = ({ isFullscreen, dispatch }) => {
//   useEffect(() => {
//     const resize = () => {
//       const fullScreen = !!(
//         window.fullScreen ||
//         document.webkitIsFullScreen ||
//         document.msFullscreenEnabled
//       );
//       dispatch({
//         type: 'updateState',
//         payload: { isFullscreen: fullScreen },
//       });
//     };
//     window.addEventListener('resize', resize);
//     return () => {
//       window.removeEventListener('resize', resize);
//     };
//   }, []);

//   const requestFullScreen = () => {
//     const ele = document.documentElement;
//     const cb =
//       ele.requestFullScreen ||
//       ele.webkitRequestFullScreen ||
//       ele.mozRequestFullScreen ||
//       ele.msRequestFullScreen;
//     if (typeof cb === 'function') {
//       trackEvent('全屏', '开启');
//       cb.call(ele);
//     }
//   };

//   const cancelFullScreen = () => {
//     const cb =
//       document.exitFullscreen || document.mozCancelFullScreen || document.webkitExitFullscreen;
//     if (typeof cb === 'function') {
//       trackEvent('全屏', '取消');
//       cb.call(document);
//     }
//   };

//   const onClick = () => {
//     if (isFullscreen) {
//       cancelFullScreen();
//     } else {
//       requestFullScreen();
//     }
//   };

//   return (
//     <Popover content="全屏">
//       <Icon
//         className="btn-link"
//         type={isFullscreen ? 'quxiaoquanping' : 'quanping1'}
//         onClick={onClick}
//       />
//     </Popover>
//   );
// };

ZoomButton.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

export default connect()(ZoomButton);
