import React, { useState } from 'react';
import PropTypes from 'prop-types';

const Header = ({
  data: { datas, userName, list, duplicateName },
  setUserCompanyList,
  cancelUserAppByUser,
  restartJoinCompany,
}) => {
  const [lists, setList] = useState([].concat(list));
  const onClick = (className, item) => {
    if (className.length <= 0) {
      setUserCompanyList(item);
    }
  };
  const applyRecall = (item, type) => {
    const param = {
      phoneNum: datas.mobile,
      companyId: item.companyId,
    };
    if (item.remoteId) {
      param.remoteId = item.remoteId;
    }
    if (type === 'recall') {
      restartJoinCompany(param);
    } else {
      cancelUserAppByUser(param, () => {
        const data = [];
        lists.forEach((val) => {
          if (val.companyId !== item.companyId) {
            data.push(val);
          }
        });
        setList(data);
      });
    }
  };

  return (
    <div className="m-changeCompany">
      <h3>选择企业</h3>
      <ul className="m-list">
        {lists.map((val, key) => {
          let texts = '';
          if (duplicateName.includes(val.companyName)) {
            if (val.versionType === 0) {
              texts = '(云记账)';
            } else {
              texts = `${'(云代账'} ${val.unitNumber})`;
            }
          }
          const className = [];
          if (val.notReview) {
            className.push('m-verify');
          }
          if (
            (userName || datas.accountName) !== '' &&
            (userName === val.companyName || datas.accountName === val.companyName) &&
            ((val.companyId === datas.companyId && datas.companyId) ||
              (val.companyId === '' && datas.versionType === 0) ||
              datas.accountId === val.accountId)
          ) {
            className.push('s-crt');
          }
          return (
            <li
              key={`${val.companyId + key}`}
              title={val.companyName + texts}
              data-id={val.companyId}
              data-name={val.companyName}
              className={className.join(' ')}
            >
              <div className="m-item" onClick={() => onClick(className, val)}>
                {val.versionType !== 3 && (
                  <i className="m-name-type m-name-type1">
                    {val.versionType === 0 && '个'}
                    {val.versionType === 4 && '企'}
                    {![0, 4].includes(val.versionType) && '代'}
                  </i>
                )}
                {val.companyName}
                <font style={{ color: '#999999', fontSize: '13px' }}>{texts}</font>
                {val.versionType === 3 && <i className="m-name-type m-name-type2">查</i>}
                {val.notReview ? (
                  <>
                    <span className="m-warn f-fr">
                      <i />
                      审核中
                    </span>
                    <em className="ui-recallApply">
                      <font className="j-recall" onClick={() => applyRecall(val, 'recall')}>
                        重新申请
                      </font>
                      <font className="j-apply" onClick={() => applyRecall(val, 'apply')}>
                        撤回申请
                      </font>
                    </em>
                  </>
                ) : (
                  <a className="ui-blue f-fr">
                    {userName !== '' && userName === val.companyName && val.companyId === ''
                      ? ''
                      : `进入企业 >>`}
                  </a>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

Header.propTypes = {
  data: PropTypes.objectOf(PropTypes.any).isRequired,
  setUserCompanyList: PropTypes.func.isRequired,
  cancelUserAppByUser: PropTypes.func.isRequired,
  restartJoinCompany: PropTypes.func.isRequired,
};

export default Header;
