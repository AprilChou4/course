/* eslint-disable react/prop-types */
import React, { useState, useCallback } from 'react';
import { Button } from 'antd';

import { ConfirmModal } from '@/modal';
import RechargeModal from './RechargeModal';

import './style.less';

const RechargeButton = ({ status }) => {
  const [visible, setVisible] = useState(false);

  const onClick = () => {
    // status = 账套使用状态(1:试用中，2:正式使用中，3试用过期，4正式过期

    if (status == 3 || status == 4) {
      ConfirmModal({
        title: '需先购买产品再行充值',
        hideCancel: true,
      });
      return;
    }

    setVisible(true);
  };

  const onCloseModal = useCallback(() => {
    setVisible(false);
  }, []);

  return (
    <>
      <Button styleName="btn" type="primary" icon="pay-circle" onClick={onClick}>
        额度充值
      </Button>
      {visible && <RechargeModal onCancel={onCloseModal} />}
    </>
  );
};

export default RechargeButton;
