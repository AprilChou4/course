import React, { useState } from 'react';
import { connect, router } from 'nuomi';
import { Badge, Drawer, List, Button, message } from 'antd';
import PropTypes from 'prop-types';
import Icon from '@/Icon';
import RequestButton from '@/buttons/RequestButton';
import style from './style.less';
import services from '../../../services';

const MessageButton = ({ count, list, dispatch }) => {
  const [visible, setVisible] = useState(false);
  const onClose = () => {
    setVisible(false);
  };

  const onClick = () => {
    setVisible(true);
  };

  const load = async (ids) => {
    const newList = [];
    list.forEach((item) => {
      if (ids !== item.noticeid) {
        newList.push(item);
      }
    });
    dispatch({
      type: 'updateMsg',
      payload: {
        count: newList.length,
        list: newList,
      },
    });
  };

  return (
    <>
      <Badge count={count} onClick={onClick} style={{ cursor: 'pointer' }}>
        <Icon type="xiaoxi" className={style.icon} style={{ cursor: 'pointer' }} />
      </Badge>
      <Drawer
        width={420}
        className={style.messageDrawer}
        placement="right"
        title={
          <>
            <span>未读消息</span>
            <Button
              className="e-ml10"
              onClick={() => {
                router.location('message', true);
              }}
            >
              进入消息中心
            </Button>
          </>
        }
        onClose={onClose}
        visible={visible}
      >
        <List
          split
          dataSource={list}
          renderItem={(v) => (
            <li>
              <div>
                <em>[ {v.type === 0 ? '系统消息' : '工作提醒'} ]</em>
                <span className="f-fr">
                  <b>{v.addtime}</b>
                  <RequestButton
                    request={async () => {
                      return services.updateNotice({ ids: v.noticeid });
                    }}
                    success={() => {
                      message.success('设置成功');
                      load(v.noticeid);
                    }}
                    error={(data) => {
                      message.error(data.message || '设置失败');
                    }}
                    type="primary"
                    size="small"
                  >
                    设为已读
                  </RequestButton>
                </span>
              </div>
              <a
                onClick={() =>
                  router.location(`message?_=${new Date().getTime()}`, { noticeid: v.noticeid })
                }
              >
                {v.title}
              </a>
            </li>
          )}
        />
      </Drawer>
    </>
  );
};

// MessageButton.defaultProps = {
//   versionType: '',
// };

MessageButton.propTypes = {
  dispatch: PropTypes.func.isRequired,
  count: PropTypes.number.isRequired,
  list: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect(({ message: { count, list } }) => ({ count, list }))(MessageButton);
