import React, { useState } from 'react';
import { Popover } from 'antd';
import { connect } from 'nuomi';
import util from 'util';
import trackEvent from 'public/trackEvent';
import PropTypes from 'prop-types';
import Icon from '@/Icon';
import style from './style.less';

const data = [
  {
    url: '/docs.html#/build/subject',
    text: '建账操作流程',
  },
  {
    url: '/docs.html#/daily/voucher',
    text: '日常操作流程',
  },
  {
    url: '/docs.html#/added/auxiliary',
    text: '云记账增值功能',
  },
];

const HelperButton = ({ versionType }) => {
  const [visible, setVisible] = useState(false);
  if (versionType === '0') {
    const onClick = (url, text) => {
      if (typeof ExternService === 'object') {
        localStorage.setItem('REFERRER', window.location.href);
      }
      trackEvent('帮助中心', '跳转', text, url);
      util.location(url, '_blank');
    };

    const popoverProps = {
      overlayClassName: style.helper,
      arrowPointAtCenter: true,
      placement: 'bottomRight',
      content: data.map(({ url, text }) => (
        <a key={url} styleName="item" onClick={() => onClick(url, text)}>
          {text}
        </a>
      )),
      onVisibleChange: (status) => {
        setVisible(status);
      },
    };
    return (
      <Popover {...popoverProps}>
        <Icon type="ico_help" className={visible ? 'primary' : 'btn-link'} />
      </Popover>
    );
  }

  const path =
    ['/docs.html#/build/subject', '/helpNew.html#/index', 'https://help.nuonuo.com/yjz/'][
      +versionType
    ] || '/helpNew.html#/index';

  return (
    <a href={path} className="btn-link" rel="noopener noreferrer" target="_blank">
      {+versionType === 2 ? (
        <span>
          <Icon type="ico_help" /> 帮助中心
        </span>
      ) : (
        <Popover content="帮助中心">
          <Icon type="ico_help" />
        </Popover>
      )}
    </a>
  );
};

HelperButton.defaultProps = {
  versionType: '',
};

HelperButton.propTypes = {
  versionType: PropTypes.string,
};

export default connect(({ versionType }) => ({ versionType }))(HelperButton);
