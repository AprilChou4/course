import React from 'react';
import { Popover } from 'antd';
import Icon from '@/Icon';

const SettingButton = () => {
  return (
    <Popover>
      <Icon type="ico_individuation" />
    </Popover>
  );
};

export default SettingButton;
