import React from 'react';
import { Button } from 'antd';
import PropTypes from 'prop-types';
import './style.less';

const ItemCard = ({ data, onClick }) => {
  const { title, icon, price, count } = data;
  return (
    <div styleName="box">
      <div styleName="top">
        <div>
          <img styleName="img" src={icon} alt={title} />
        </div>
        <span styleName="title">{title}</span>
      </div>

      <div>
        <div styleName="price">
          ￥{price}
          <span styleName="unit">（元）</span>
        </div>
        <div styleName="count">额度：{count} 张</div>
      </div>

      <div>
        <Button styleName="btn" type="primary" onClick={() => onClick(data)}>
          立即购买
        </Button>
      </div>
    </div>
  );
};

ItemCard.propTypes = {
  data: PropTypes.objectOf(PropTypes.any).isRequired,
  onClick: PropTypes.func.isRequired,
};

export default ItemCard;
