import React from 'react';
import { Nuomi, router, store } from 'nuomi';
import Tabs from './Tabs';

const props = {
  id: 'tabs',
  state: {
    activeKey: '/',
    panes: [
      {
        path: '/',
        title: '首页',
        closable: false,
      },
    ],
  },
  effects: {
    removeOther(activePath) {
      const { panes } = this.getState();
      this.dispatch({
        type: '_updateState',
        payload: {
          panes: panes.filter(({ path }, i) => i === 0 || path === activePath),
        },
      });
      router.location(activePath);
    },
    onInitSubject({ title }) {
      const { panes } = this.getState();
      const panesList = [{ ...panes[0], title }];
      this.dispatch({
        type: '_updateState',
        payload: {
          panes: panesList,
        },
      });
    },
    removeAll() {
      const { panes } = this.getState();
      this.dispatch({
        type: '_updateState',
        payload: {
          panes: [panes[0]],
        },
      });
      router.location(panes[0].path);
    },
    remove(removePath) {
      const removePaths = [].concat(removePath);
      const { panes, activeKey } = this.getState();
      const newPanes = panes.filter(({ path }) => !removePaths.includes(path));

      // 关闭录凭证标签页时，判断是否有未保存但已导入的附件，如有，需要调用接口删除，并重置录凭证的附件数量显示
      if (removePath === '/voucher/record' || removePath === '/voucher/record-budget') {
        const allState = store.getState();
        const stateName = removePath === '/voucher/record' ? 'record' : 'records';

        if (allState[stateName]?.attachVoucherId) {
          this.dispatch({ type: `${stateName}/deleteVoucherAttachment` });
          setTimeout(() => {
            this.dispatch({
              type: `${stateName}/setState`,
              payload: {
                attachVoucherId: '',
                voucherAffixCount: allState[stateName]?.oldVoucherAffixCount || '',
                isShowAffixIcon: false,
                isImportAffix: false,
              },
            });
          }, 100);
        }
      }
      this.dispatch({
        type: '_updateState',
        payload: {
          panes: newPanes,
        },
      });
      if (removePaths.includes(activeKey)) {
        router.location(newPanes[newPanes.length - 1].path);
      }
    },
    add({ pathname, title }) {
      const { panes } = this.getState();
      let newPanes = panes;
      // 不存在新增，存在直接展示
      if (!panes.find(({ path }) => path === pathname)) {
        newPanes = newPanes.concat({ path: pathname, title });
      }
      this.dispatch({
        type: '_updateState',
        payload: {
          panes: newPanes,
          activeKey: pathname,
        },
      });
    },
    insert({ pathname, title }) {
      const { panes, activeKey } = this.getState();
      if (pathname !== activeKey) {
        const index = panes.findIndex(({ path }) => path === activeKey);
        this.dispatch({
          type: '_updateState',
          payload: {
            panes: [...panes.slice(0, index), { path: pathname, title }, ...panes.slice(index)],
            activeKey: pathname,
          },
        });
      }
    },
  },
  render() {
    return <Tabs />;
  },
};

export default () => {
  return <Nuomi {...props} />;
};
