import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Icon } from 'antd';
import isNil from 'utils/isNil';
import SwitchAccount from '../SwitchAccount';
import './style.less';

const HeaderTitle = ({ accountName, versionType }) => {
  const name = useMemo(
    () => (
      <em
        style={{
          display: 'inline-block',
          maxWidth: '210px',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          verticalAlign: 'top',
          marginTop: '11px',
        }}
      >
        {accountName || ''}
      </em>
    ),
    [accountName],
  );

  // 授权查账时 不能切换账套
  return (
    !!accountName &&
    (isNil(versionType, '3') ? (
      <span styleName="title">{name}</span>
    ) : (
      <SwitchAccount>
        <span styleName="title">
          {name}
          <Icon styleName="icon" style={{ marginLeft: '0px' }} type="down" />
        </span>
      </SwitchAccount>
    ))
  );
};

HeaderTitle.defaultProps = {
  accountName: '',
  versionType: '',
};

HeaderTitle.propTypes = {
  accountName: PropTypes.string,
  versionType: PropTypes.string,
};

export default connect(({ accountName, versionType }) => ({ accountName, versionType }))(
  HeaderTitle,
);
