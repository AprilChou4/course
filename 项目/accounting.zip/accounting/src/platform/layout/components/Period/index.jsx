import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import isNil from 'utils/isNil';
import './style.less';

const Period = ({ currentYear, currentMonth }) => {
  return (
    !(isNil(currentYear, '') || isNil(currentMonth, '')) && (
      <span styleName="date">
        {currentYear}年{currentMonth}月
      </span>
    )
  );
};

Period.defaultProps = {
  currentYear: null,
  currentMonth: null,
};

Period.propTypes = {
  currentYear: PropTypes.number,
  currentMonth: PropTypes.number,
};

export default connect(({ currentYear, currentMonth }) => ({ currentYear, currentMonth }))(Period);
