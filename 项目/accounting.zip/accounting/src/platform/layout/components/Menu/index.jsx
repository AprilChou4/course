import React from 'react';
import { connect, Link } from 'nuomi';
import { Menu as AntMenu } from 'antd';
// https://github.com/malte-wessel/react-custom-scrollbars
// import { Scrollbars } from 'react-custom-scrollbars';

import PropTypes from 'prop-types';
import Icon from '@/Icon';
import './style.less';

const { SubMenu } = AntMenu;
const MenuItem = AntMenu.Item;

const Title = ({ icon, title, iconRight }) => {
  return (
    <React.Fragment>
      {icon && <Icon type={icon} styleName="icon" />}
      <span>{title}</span>
      {iconRight && <Icon type="right" styleName="iconRight" />}
    </React.Fragment>
  );
};

Title.defaultProps = {
  icon: undefined,
};

Title.propTypes = {
  icon: PropTypes.string,
  title: PropTypes.string.isRequired,
  iconRight: PropTypes.bool.isRequired,
};

const Menu = ({ collapsed, data, openKeys, selectedKeys, dispatch, style }) => {
  const getMenus = (meuns = [], items = []) => {
    meuns.forEach((ele) => {
      const { children, title, key, selectedKeys: selectedKey, onClick, reload } = ele;
      let { icon } = ele;
      const props = { key, onClick };
      if (children) {
        items.push(
          <SubMenu
            title={<Title icon={icon} title={title} iconRight={!!children && !collapsed} />}
            {...props}
          >
            {getMenus(children)}
          </SubMenu>,
        );
      } else {
        icon = selectedKey.length === 1 ? icon : '';
        let content = '';
        if (ele.path) {
          content = (
            <Link to={ele.path} reload={reload !== false}>
              <Title icon={icon} title={title} iconRight={!!children && !collapsed} />
            </Link>
          );
        } else {
          content = <a>{ele.title}</a>;
        }
        items.push(<MenuItem {...props}>{content}</MenuItem>);
      }
    });
    return items;
  };

  const getOpenKeys = (currentKey, array) => {
    let newOpenKeys = [];
    for (let i = 0; i < array.length; i += 1) {
      const { key, children, openKeys: keys } = array[i];
      if (key === currentKey) {
        return [...keys, currentKey];
      }
      if (children) {
        newOpenKeys = getOpenKeys(currentKey, children);
        if (newOpenKeys.length) {
          break;
        }
      }
    }
    return newOpenKeys;
  };

  const onOpenChange = (keys) => {
    let newOpenKeys = [];
    // 展开
    if (keys.length > openKeys.length) {
      newOpenKeys = getOpenKeys(keys.pop(), data);
    } else {
      newOpenKeys = keys;
    }

    dispatch({
      type: 'updateMenus',
      payload: {
        openKeys: newOpenKeys,
      },
    });
  };
  return (
    <div className="antd-menu-wrapper" style={style}>
      {/* <Scrollbars
        style={{ width: '100%', height: '100%' }}
        renderTrackVertical={(props) => <div {...props} className="track-vertical" />}
        renderThumbVertical={(props) => <div {...props} className="thumb-vertical" />}
      > */}
      <AntMenu
        mode="inline"
        inlineCollapsed={collapsed}
        inlineIndent={20}
        openKeys={openKeys}
        selectedKeys={selectedKeys}
        onOpenChange={onOpenChange}
      >
        {getMenus(data)}
      </AntMenu>
      {/* </Scrollbars> */}
    </div>
  );
};

Menu.defaultProps = {
  style: {},
};

Menu.propTypes = {
  collapsed: PropTypes.bool.isRequired,
  data: PropTypes.arrayOf(PropTypes.any).isRequired,
  openKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  style: PropTypes.objectOf(PropTypes.any),
};

export default connect(({ menus: { collapsed, data, openKeys, selectedKeys } }) => ({
  collapsed,
  data,
  openKeys,
  selectedKeys,
}))(Menu);
