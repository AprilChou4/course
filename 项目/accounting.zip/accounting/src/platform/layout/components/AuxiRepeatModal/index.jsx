import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Modal } from 'antd';
import Ico from '@/Icon';
import './style.less';

const Modal2 = ({ data }) => {
  const [visible, setVisible] = useState(false);
  return (
    <div styleName="repeat-aux">
      <div styleName="fb">存在重复辅助核算！</div>
      <div styleName="fb">可点击智能客服联系我们反馈问题，我们会立即修复解决！</div>
      <div styleName="detail">
        <div styleName="title">
          详细原因
          <span styleName="click-area" onClick={() => setVisible(!visible)}>
            {visible ? '收起' : '展开'}
            <Ico type={visible ? 'up2' : 'down2'} />
          </span>
        </div>
        {visible && (
          <div styleName="content">
            {data.map((v) => (
              <div styleName="repeat-aux-item">
                <div>[{v.auxTypeName}]辅助核算：</div>
                {(v.auxCodeAndNameList || []).map((h) => (
                  <div>{h}</div>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
Modal2.propTypes = {
  data: PropTypes.arrayOf(PropTypes.any).isRequired,
};
const Confirm = ({ type, data = [] }) => {
  const $modal = Modal.success({
    width: [320, 440][type],
    title: '温馨提示',
    centered: true,
    okText: '知道了',
    className: 'check-aux-repeat-modal',
    content: type === 0 ? <div>当月辅助核算总账数据有重复！</div> : <Modal2 data={data} />,
  });
  return $modal;
};

export default Confirm;
