import React from 'react';
import util from 'util';
import { router, connect } from 'nuomi';
import PropTypes from 'prop-types';
import Icon from '@/Icon';
import logo from './logo.png';
import './style.less';

const Logo = ({ versionType, serviceVersion }) => {
  const onClick = () => {
    router.location('/');
  };
  const { entoken } = util.getParam();
  return (
    <div styleName="logo" onClick={onClick}>
      <Icon type="yunjizhangxin" className="icon-logo-img" />
      {versionType === '1' || versionType === '3' ? (
        <img src={logo} alt="" />
      ) : (
        <span styleName="icon-logo-text">
          <b className="f-fs16">{entoken ? '诺账通' : '诺诺.云记账'}</b>
          <br />
          {entoken ? (
            <em style={{ fontSize: '12px' }}>{['基础版', '标准版', '增强版'][+serviceVersion]}</em>
          ) : (
            <em>Workbench</em>
          )}
        </span>
      )}
      {/* <img src={logo} alt="" /> */}
    </div>
  );
};

Logo.defaultProps = {
  versionType: '',
  serviceVersion: '1',
};

Logo.propTypes = {
  versionType: PropTypes.string,
  serviceVersion: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default connect((menus, { account: { versionType, user: { serviceVersion } } }) => ({
  versionType,
  serviceVersion,
}))(Logo);
