import React from 'react';
import { Router, connect } from 'nuomi';
import PropTypes from 'prop-types';
import Header from '../Header';
import Content from '../Content';
import './style.less';

const Main = ({ collapsed }) => {
  return (
    <div styleName={`main${collapsed ? ' collapsed' : ''}`}>
      <Header />
      <Router hashPrefix="!">
        <Content />
      </Router>
    </div>
  );
};

Main.propTypes = {
  collapsed: PropTypes.bool.isRequired,
};

export default connect(({ menus: { collapsed } }) => ({ collapsed }))(Main);
