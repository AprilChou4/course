import React, { useState } from 'react';
import Icon from 'Icon';
import style from '../style/index.less';
import gif from '../images/reward.gif';
import SelectAmtModal from './SelectAmtModal';

const Reward = () => {
  const [isShowGif, setIsShowGif] = useState(!localStorage.getItem('closeReward'));
  const [isShowModal, setIsShowModal] = useState(false);

  const showModal = () => {
    setIsShowModal(true);
  };
  const hideModal = () => {
    setIsShowModal(false);
  };

  const closeGif = (e) => {
    e.stopPropagation();
    localStorage.setItem('closeReward', 1);
    setIsShowGif(false);
  };

  return (
    <React.Fragment>
      {isShowGif && (
        <div className={style.tips} onClick={showModal}>
          <i onClick={closeGif} />
          <em className={style[`text${Math.floor(Math.random() * 5)}`]} />
          <img src={gif} alt="reward gif" />
        </div>
      )}
      <a onClick={showModal}>
        <Icon type="dashang" />
        <b>打赏</b>
      </a>

      {isShowModal && <SelectAmtModal onCancel={hideModal} />}
    </React.Fragment>
  );
};

export default Reward;
