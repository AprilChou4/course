import React, { useState, useEffect, useRef } from 'react';
import Icon from 'Icon';
import PropTypes from 'prop-types';

const PaySuccess = ({ money, onCancel }) => {
  const [time, setTime] = useState(3);
  const timeRef = useRef(time);

  timeRef.current = time;

  useEffect(() => {
    const timer = setInterval(() => {
      const currentTime = timeRef.current;
      if (currentTime > 0) {
        setTime(currentTime - 1);
      } else {
        clearInterval(timer);
        onCancel();
      }
    }, 1000);
    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <span>
      <Icon type="zhengque" className="e-mr5" />
      支付成功！感谢您的打赏金{money}元，<s className="f-cred">{time}s</s>后自动跳转到打赏页面
    </span>
  );
};

PaySuccess.propTypes = {
  money: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  onCancel: PropTypes.func.isRequired,
};

export default PaySuccess;
