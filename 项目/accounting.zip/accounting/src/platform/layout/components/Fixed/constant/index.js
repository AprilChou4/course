export const serviceUrl =
  'https://robot.jss.com.cn/pc.do?newKey=kwy6d386c7566304a685742516c67636e6651755a454b773d3d';
