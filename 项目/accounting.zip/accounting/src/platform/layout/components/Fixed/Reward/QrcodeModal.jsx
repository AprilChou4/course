/* eslint-disable no-undef */
import React, { Component } from 'react';
import { Row, Col, message, Modal } from 'antd';
import Icon from 'Icon';
import PropTypes from 'prop-types';

import './qrcode';
import PaySuccess from './PaySuccess';
import services from '../../../services';

import '../style/index.less';

class QrcodeModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      status: '',
    };
  }

  componentDidMount() {
    this.request();

    // 3分钟自动关闭
    this.timer2 = setTimeout(() => {
      this.clear('error', '支付超时');
    }, 180000);

    this.setImg();
  }

  componentDidUpdate() {
    this.setImg();
  }

  componentWillUnmount() {
    clearTimeout(this.timer);
    clearTimeout(this.timer2);
  }

  clear = (status, msg) => {
    const { onCancel } = this.props;
    clearTimeout(this.timer);
    if (status === 'error') {
      if (msg === '支付超时') {
        onCancel();
      } else {
        this.setState({
          status: 'error',
        });
      }
    } else {
      this.setState({ status: 'success' });
    }

    message[status](msg);
  };

  request = () => {
    const { alipay } = this.getData();
    if (!alipay || !alipay.orderNo) {
      return;
    }

    this.timer = setTimeout(async () => {
      const res = await services.getPayResult({
        orderNumber: alipay.orderNo,
      });

      // 支付成功
      if (res.reward_result === true) {
        this.clear('success', '支付成功');
      } else {
        if (res.reward_result === false) {
          this.setState({
            status: 'error',
          });
        }
        this.request();
      }
    }, 3000);
  };

  qrcode = (ele, url) => {
    // eslint-disable-next-line no-new
    new QRCode(ele, {
      text: url,
      width: 150,
      height: 150,
    });
  };

  getData = () => {
    const { payCode } = this.props;
    const defaultValue = { weixin: { money: '' }, alipay: { money: '' } };
    return payCode || defaultValue;
  };

  setImg = () => {
    const { alipay, weixin } = this.getData();

    alipay && alipay.url && this.alipayElement && this.qrcode(this.alipayElement, alipay.url);
    weixin && weixin.url && this.weixinElement && this.qrcode(this.weixinElement, weixin.url);
  };

  render() {
    const { onCancel } = this.props;
    const { alipay, weixin } = this.getData();

    const isTwo = alipay && weixin && alipay.money && weixin.money;

    const { status } = this.state;
    return (
      <Modal
        visible
        width={500}
        onOk={() => {}}
        onCancel={onCancel}
        maskClosable={false}
        footer={null}
      >
        <div styleName="qrcode">
          <h4>支付中心</h4>
          <p>
            {!status && <b>请选择相应的支付方式，使用手机扫码支付</b>}
            {status === 'error' && (
              <em>
                <Icon type="shanchuxinxi" className="e-mr5" />
                支付失败！您可以重新扫描二维码进行打赏哦~
              </em>
            )}
            {status === 'success' && (
              <PaySuccess money={(Number(alipay.money) || 0).toFixed(2)} onCancel={onCancel} />
            )}
          </p>

          {!status && (
            <Row>
              {alipay && alipay.money && (
                <Col span={isTwo ? 12 : 24} styleName={isTwo ? 'border' : ''}>
                  <p>支付宝扫一扫，打赏{alipay && alipay.money ? alipay.money : ''}元</p>
                  <div
                    ref={(ele) => {
                      this.alipayElement = ele;
                    }}
                  />
                </Col>
              )}

              {weixin && weixin.money && (
                <Col span={isTwo ? 12 : 24}>
                  <p>微信扫一扫，打赏{weixin && weixin.money ? weixin.money : ''}元</p>
                  <div
                    ref={(ele) => {
                      this.weixinElement = ele;
                    }}
                  />
                </Col>
              )}
            </Row>
          )}
        </div>
      </Modal>
    );
  }
}

QrcodeModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  payCode: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default QrcodeModal;
