import React, { Component } from 'react';
import PropTypes from 'prop-types';

class OptionalAmount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
    };
  }

  showInput = () => {
    this.setState({
      show: true,
    });
    setTimeout(() => {
      this.input.focus();
    }, 0);
  };

  number = (e) => {
    $(e.target).number({
      integer: 3,
      minus: false,
      onBlur: (self, value) => {
        if (!value && !this.hover) {
          this.setState({
            show: false,
          });
        }
      },
    });
  };

  toPay = () => {
    const { value } = this.input;
    const { toPay } = this.props;
    if (!value) {
      this.input.focus();
    } else {
      toPay(value);
    }
  };

  mouseover = () => {
    this.hover = true;
  };

  mouseout = () => {
    this.hover = false;
  };

  keyup = (e) => {
    if (e.keyCode === 13) {
      this.toPay();
    }
  };

  render() {
    const { show } = this.state;
    return (
      // eslint-disable-next-line jsx-a11y/mouse-events-have-key-events
      <span onMouseOver={this.mouseover} onMouseOut={this.mouseout}>
        {show ? (
          <React.Fragment>
            <input
              ref={(ele) => {
                this.input = ele;
              }}
              onKeyUp={this.keyup}
              onFocus={this.number}
              autoComplete="off"
              placeholder="打赏金额"
            />
            <button type="button" onClick={this.toPay}>
              赏
            </button>
          </React.Fragment>
        ) : (
          <em onClick={this.showInput}>随意赏</em>
        )}
      </span>
    );
  }
}

OptionalAmount.propTypes = {
  toPay: PropTypes.func.isRequired,
};

export default OptionalAmount;
