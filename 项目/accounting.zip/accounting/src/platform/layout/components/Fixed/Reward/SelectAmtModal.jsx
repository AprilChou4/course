import React, { useState, useEffect, useRef } from 'react';
import { Carousel, Row, Col, Modal } from 'antd';
import PropTypes from 'prop-types';

import Icon from '@/Icon';
import OptionalAmount from './OptionalAmount';
import QrcodeModal from './QrcodeModal';
import services from '../../../services';

import './selectModal.less';

const moneyData = [1, 2, 5, 10, 20];

const SelectMoney = ({ onCancel }) => {
  const [list, setlist] = useState([]);
  const [isShowModal, setisShowModal] = useState(false);
  const [payCode, setpayCode] = useState({});

  const isModalRef = useRef(isShowModal);

  const toPay = async (amount) => {
    const res = await services.getPayQRCode({ amt: amount });

    if (res && !isModalRef.current) {
      setisShowModal(true);
      isModalRef.current = true;
      setpayCode(res);
    }
  };

  useEffect(() => {
    const getList = async () => {
      const res = await services.getRewardRecordList();
      res && setlist(res);
    };

    getList();
  }, []);

  return (
    <Modal onCancel={onCancel} visible maskClosable={false} footer={null} styleName="reward-modal">
      <div styleName="wrap">
        <dl>
          <dt>
            <span styleName="font white">随手赞赏云记账</span>
            <i />
          </dt>
          <dd>
            <p styleName="font">您的赞赏是我们产品优化更新的动力，鼓励我们一下吧</p>
          </dd>
        </dl>
        <p>
          {moneyData.map((v) => {
            return (
              <span key={v} onClick={() => toPay(v)}>
                {v.toFixed(2)}元
              </span>
            );
          })}
          <OptionalAmount toPay={toPay} />
        </p>
        {!!list.length && (
          <Row>
            <Col span={3} styleName="info-icon">
              <Icon type="laba" styleName="icon" />
            </Col>
            <Col span={20} styleName="text">
              <Carousel vertical autoplay dots={false}>
                {list.map((v) => (
                  <React.Fragment key={v}>{v}</React.Fragment>
                ))}
              </Carousel>
            </Col>
          </Row>
        )}

        {isShowModal && (
          <QrcodeModal
            payCode={payCode}
            onCancel={() => {
              setisShowModal(false);
              isModalRef.current = false;
            }}
          />
        )}
      </div>
    </Modal>
  );
};

SelectMoney.propTypes = {
  onCancel: PropTypes.func.isRequired,
};

export default SelectMoney;
