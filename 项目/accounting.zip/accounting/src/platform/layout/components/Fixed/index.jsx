import React, { Component } from 'react';
import { connect, router } from 'nuomi';
import util from 'util';
// import { reactLayer } from 'layer';
import PropTypes from 'prop-types';
import Icon from '@/Icon';
import RewardButton from './Reward';
import style from './style/index.less';

// import Send from '../../../pages/message/send/feedback';
import { serviceUrl } from './constant';
import serviceImg from './images/service.png';

class Fixed extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: !util.store('FLOAT_LAYER_VISIBLE'),
    };
  }

  visibleChange = () => {
    const { visible } = this.state;
    util.store('FLOAT_LAYER_VISIBLE', !visible ? '' : 1);
    this.setState({
      visible: !visible,
    });
    this.trackEvent('悬浮菜单', visible ? '展开' : '收起');
  };

  getBottom = (size, versionType, visible) => {
    if (visible) return 10;
    return versionType === '0' ? -((size + 1) * 52) : -(size * 52);
  };

  onFeedback = () => {
    const { entUrl, versionType } = this.props;
    // const type = 1;

    // if (type === 10 || type === 9) {
    //   reactLayer({
    //     width: 620,
    //     id: 'feedbacks',
    //     height: '300',
    //     title: '建议反馈',
    //     render() {
    //       return <Send self={this.self} />;
    //     },
    //     cancel: {
    //       enable: false,
    //       text: '取消',
    //     },
    //     confirm: {
    //       enable: false,
    //       text: '提交',
    //       callback() {},
    //     },
    //   });
    //   return;
    // }
    if (versionType === '2') {
      window.open(`${entUrl}/list/#!/message/suggest`);
      return;
    }

    router.location('/message', { key: 'form' }, true);
    this.trackEvent('建议反馈', '跳转');
  };

  render() {
    const { versionType } = this.props;

    const { visible } = this.state;
    const size = versionType !== '2' ? 2 : 1;
    const wrapStyle = {
      display: versionType !== '' ? 'block' : 'none',
      bottom: this.getBottom(size, versionType, visible),
    };

    const helpPath = versionType === '1' ? '/helpNew.html#/index' : '/docs.html#/build/subject';

    return (
      <div className={style.fixed} style={wrapStyle}>
        {versionType === '2' && (
          <a
            onClick={() => {
              this.trackEvent('智能客服', '跳转');
            }}
            href={util.getNewUrl(serviceUrl)}
            target="_blank"
            rel="noopener noreferrer"
            style={{ background: 'none', position: 'relative', right: 10 }}
          >
            <img style={{ width: 60, height: 60 }} src={serviceImg} alt="智能客服" />
          </a>
        )}

        <a
          onClick={this.visibleChange}
          style={{ height: 28, borderRadius: visible ? '3px' : '3px 3px 0 0' }}
        >
          <Icon type={visible ? 'down' : 'up-copy'} style={{ fontSize: 20, top: 1 }} />
          <b>{visible ? '收起' : '展开'}</b>
        </a>

        {+versionType === 0 && <RewardButton />}

        <a onClick={this.onFeedback}>
          <Icon type="fankui" />
          <b>建议反馈</b>
        </a>

        {versionType !== '2' && (
          <a
            href={helpPath}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              this.trackEvent('帮助中心', '跳转');
            }}
          >
            <Icon type="wenhao1" />
            <b>帮助中心</b>
          </a>
        )}
      </div>
    );
  }
}

Fixed.defaultProps = {
  versionType: '',
};

Fixed.propTypes = {
  versionType: PropTypes.string,
};

export default connect(({ versionType, entUrl }) => ({ versionType, entUrl }))(Fixed);
