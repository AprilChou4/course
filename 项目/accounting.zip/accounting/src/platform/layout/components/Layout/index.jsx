import React from 'react';
import { connect } from 'nuomi';
// import { getGuideType, getCookie } from 'utils';
import { getCookie } from 'utils';
import PropTypes from 'prop-types';
import Sidebar from '../Sidebar';
import Main from '../Main';
import Fixed from '../Fixed';
import Loading, { LoadData } from '../Loading';
// import Guide from '../Guide';
import Modal from '../Modal';

const Layout = ({
  username,
  // isGuide,
  // isExistExternalSubject,
  loadings: { $initData, loading },
  versionType,
}) => {
  const isModals = JSON.parse(getCookie({ name: '_layerModal' }) || '{}')[username];
  const client = typeof ExternService === 'object';
  return (
    <>
      {$initData === true && <Loading />}
      {!!loading && <LoadData loading={loading} />}
      <Main />
      <Sidebar />

      <Fixed />

      {/* {versionType === '2' &&
        username &&
        !isExistExternalSubject &&
        (getGuideType(username) || isGuide.isShow) && <Guide versionType={versionType} />} */}
      {username && !isModals && !client && versionType !== '2' && <Modal versionType />}
    </>
  );
};

Layout.defaultProps = {
  username: '',
  // isExistExternalSubject: true,
  versionType: '2',
};

Layout.propTypes = {
  // isGuide: PropTypes.objectOf(PropTypes.any).isRequired,
  username: PropTypes.string,
  loadings: PropTypes.objectOf(PropTypes.any).isRequired,
  // isExistExternalSubject: PropTypes.bool,
  versionType: PropTypes.string,
};

export default connect(
  (
    { loadings, user: { username } },
    { account: { isGuide, isExistExternalSubject, versionType } },
  ) => ({
    loadings,
    isGuide,
    username,
    isExistExternalSubject,
    versionType,
  }),
)(Layout);
