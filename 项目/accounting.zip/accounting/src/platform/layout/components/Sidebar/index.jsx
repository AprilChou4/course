import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import Logo from '../Logo';
import Menu from '../Menu';
import './style.less';

const Sidebar = ({ collapsed }) => {
  return (
    <div styleName={`sidebar${collapsed ? ' collapsed' : ''}`}>
      <Logo />
      <Menu />
    </div>
  );
};

Sidebar.propTypes = {
  collapsed: PropTypes.bool.isRequired,
};

export default connect(({ menus: { collapsed } }) => ({
  collapsed,
}))(Sidebar);
