/**
 * 账套进度、会计工厂
 */
import React from 'react';
import { connect } from 'nuomi';
import { Menu, Dropdown, Icon, Modal, message } from 'antd';
import PropTypes from 'prop-types';
import isNil from 'utils/isNil';
import services from '../../services';

import './style.less';

class AccountProcess extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      msg: '',
      recordStatus: '',
      ticketStatus: '',
      modalType: 'record', // ticket
    };
  }

  onTicketFinish = async () => {
    if (this.ticketText === '理票完成') return;
    if (this.checkIsRecheck()) {
      return;
    }

    // 先获取提示信息
    const res = await services.getTicketInfo(this.params);

    if (res && res.trim()) {
      this.setState({ msg: res, showModal: true, modalType: 'ticket' });
    } else {
      this.setState({ modalType: 'ticket' }, () => this.onFinish());
    }
  };

  onRecordFinish = async () => {
    if (this.checkIsRecheck()) {
      return;
    }
    if (this.recordText === '记账完成') return;
    // 先获取提示信息
    const res = await services.getRecordInfo(this.params);

    if (res && res.trim()) {
      this.setState({ msg: res, showModal: true, modalType: 'record' });
    } else {
      this.setState({ modalType: 'record' }, () => this.onFinish());
    }
  };

  cancelTicket = async () => {
    if (this.checkIsRecheck()) {
      return;
    }
    if (this.ticketText === '理票中') {
      return;
    }
    await services.ticketFinish({ ...this.params, isArranged: 0 });

    message.success('取消理票完成');
    this.setState({ ticketStatus: '理票中' });
  };

  cancelRecord = async () => {
    if (this.checkIsRecheck()) {
      return;
    }
    if (this.recordText === '记账中') {
      return;
    }

    await services.recordFinish({ ...this.params, isRegistered: 0 });

    message.success('取消记账完成');
    this.setState({ recordStatus: '记账中' });
  };

  // 是否反结账
  checkIsRecheck = () => {
    if (+localStorage.getItem('checkout_status_recheck') === 1) {
      message.error('反结账中，不允许操作');
      return true;
    }
    return false;
  };

  RenderAccProcess = () => {
    const { ticketStatus, recordStatus } = this.state;
    const { account } = this.props;
    const { isArranged, isRegistered, businessPattern, versionType } = account;

    const isAccFactory = +businessPattern === 1;

    const isAssistantAcc = ['助理会计', '会计助理'].includes(
      account.user ? account.user.roleName : '',
    );

    this.ticketText = ticketStatus || (+isArranged === 1 ? '理票完成' : '理票中');
    this.recordText = recordStatus || (+isRegistered === 1 ? '记账完成' : '记账中');

    this.params = {
      queryDate: account.currentDate,
    };

    const ticketMenu = (
      <Menu>
        <Menu.Item>
          <em onClick={this.cancelTicket}>理票中</em>
        </Menu.Item>
        <Menu.Item>
          <em onClick={this.onTicketFinish}>理票完成</em>
        </Menu.Item>
      </Menu>
    );
    const recordMenu = (
      <Menu>
        <Menu.Item>
          <em onClick={this.cancelRecord}>记账中</em>
        </Menu.Item>
        <Menu.Item>
          <em onClick={this.onRecordFinish}>记账完成</em>
        </Menu.Item>
      </Menu>
    );

    const disabled = this.inAuth ? this.inAuth() === false : false;

    const ticketEle = (
      <span className="f-fl">
        <Dropdown overlay={ticketMenu} disabled={disabled}>
          <em styleName="dropdown-item">
            {this.ticketText} <Icon type="down" />
          </em>
        </Dropdown>
      </span>
    );
    const recordEle = (
      <span className={`f-fl ${isAccFactory ? 'ie-ml10 e-ml10' : ''}`}>
        <Dropdown overlay={recordMenu} disabled={disabled}>
          <em styleName="dropdown-item">
            {this.recordText} <Icon type="down" />
          </em>
        </Dropdown>
      </span>
    );

    // 授权查账时 不显示
    if ((!isAccFactory && isAssistantAcc) || isNil(versionType, '3')) {
      return null;
    }

    if (!isAccFactory && !isAssistantAcc) {
      return (
        <>
          <span className="f-fl e-ml10">账套进度：</span>
          {recordEle}
        </>
      );
    }
    if (isAccFactory) {
      return (
        <>
          <span className="f-fl e-ml10">账套进度：</span>
          {ticketEle}
          {!isAssistantAcc && recordEle}
        </>
      );
    }
    return null;
  };

  onFinish = async () => {
    const { modalType } = this.state;

    let serviceName = 'ticketFinish';
    let key = 'isArranged';
    let text = '理票完成';

    if (modalType === 'record') {
      serviceName = 'recordFinish';
      key = 'isRegistered';
      text = '记账完成';
    }

    const res = await services[serviceName]({
      ...this.params,
      [key]: 1,
    });

    this.setState({ showModal: false });
    message.success(res.message || `${text}操作成功`);

    if (modalType === 'record') {
      this.setState({ recordStatus: '记账完成' });
    } else {
      this.setState({ ticketStatus: '理票完成' });
    }
  };

  render() {
    const { showModal, msg } = this.state;
    return (
      <>
        <span styleName="acc-process">{this.RenderAccProcess()}</span>
        <Modal
          title="温馨提示"
          width={360}
          maskClosable={false}
          visible={showModal}
          onOk={() => this.onFinish()}
          onCancel={() => this.setState({ showModal: false })}
          cancelText="取消"
          style={{ top: '35%' }}
        >
          <p styleName="header-model-info">{msg}</p>
        </Modal>
      </>
    );
  }
}

AccountProcess.propTypes = {
  account: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect((_, { account }) => ({ account }))(AccountProcess);
