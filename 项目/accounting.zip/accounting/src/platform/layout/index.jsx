import React from 'react';
import { router } from 'nuomi';
import Effects from './effects';
import Layout from './components/Layout';

export default {
  id: 'account',
  state: {
    // 手动新手引导
    isGuide: {
      // 是否显示
      isShow: false,
      // 当前 第几条
      index: 0,
    },
    // 是否全屏
    isFullscreen: false,
    // 期间列表
    period: [],
    // 用户数据
    user: {
      // 0云记账；1云代账
      versionType: '',
    },
    // 常用账簿列表
    commonlyBooks: [],
    // 菜单
    menus: {
      // 菜单数据
      data: [],
      // 有权限的菜单列表（一维数组）
      list: [],
      // 菜单是否收起
      collapsed: false,
      // 展开菜单
      openKeys: [],
      // 存储打开的菜单，用于收起展开后打开菜单
      openKeysTemp: [],
      // 选中菜单
      selectedKeys: [],
    },
    // 未读消息
    message: {
      // 未读消息数量
      count: 0,
      // 未读消息列表
      list: [],
    },
    loadings: {
      $initData: true,
    },
    // 对账解锁 Modal
    isShowUnlockModal: false,
    // 对账数据修复 Modal
    isShowDataRepairModal: false,
    // 存货设置
    stockSetting: {},
    // 企业版地址域名
    entUrl: '',
  },
  reducers: {
    // 更新user状态
    updateUser: (state, { payload }) => ({ ...state, user: { ...state.user, ...payload } }),
    // 更新菜单状态
    updateMenus: (state, { payload }) => ({ ...state, menus: { ...state.menus, ...payload } }),
    // 更新系统消息状态
    updateMsg: (state, { payload }) => ({ ...state, message: { ...state.message, ...payload } }),
  },
  effects() {
    return new Effects(this);
  },
  render() {
    return <Layout />;
  },
  onInit() {
    if (typeof ExternService === 'object') {
      const name = '我是name';
      const isClientObj = {
        // Textlist: {},
        // Functionlist: {},

        Textlist: {
          accountName: name,
          accountDate: '2020年1月',
          isArranged: '1',
          isRegistered: '1',
        },
        Functionlist: {
          // znkf: () => { -------------------------
          //   console.log(`智能客服1${name}`);
          // },
          // bzzx: () => { -------------------------
          //   console.log('帮助中心1${name}');
          // },
          // yhzx: () => { -------------------------
          //   console.log('用户1${name}');
          // },
          // shrink: () => { ------------------------
          //   console.log('收缩菜单栏1${name}');
          // },
          // switchAccount: () => { ------------------------
          //   console.log('切换企业1${name}');
          // },
          // switchArranged: () => {
          //   console.log('理票状态1${name}');
          // },
          // switchRegistered: () => {
          //   console.log('记账状态1${name}');
          // },
        },
      };
      window.isClientObjInit = (data, type) => {
        if (type === 1) {
          isClientObj.Textlist = { ...isClientObj.Textlist, ...data };
        } else {
          isClientObj.Functionlist = { ...isClientObj.Functionlist, ...data };
        }
        // window.Yjz.Init(isClientObj);
      };
    }

    // 进项调用跳转路由，高亮左侧菜单#135904
    window.jxRouterChange = (url) => {
      router.location(`billmanage${url}`, {}, true);
      // window.location.hash = url;
    };
    window.updateInvoiceData = (data) => {
      console.log(data);
      console.log('企业版 不做更新！');
    };
    this.store.dispatch({
      type: '$initData',
    });
  },
};
