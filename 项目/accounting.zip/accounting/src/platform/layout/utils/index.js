export { default as createMenus } from './createMenus';
export { default as createAuth } from './inAuth';

export const handleAccount = (account) => {
  const { year, month, currentYear, currentMonth, subjectLevelStruct } = account;
  const subjectLevelStructs = subjectLevelStruct.split('-');
  return {
    ...account,
    // 创建期间
    createDate: `${year}年${month}月`,
    // 当前期间
    currentDate: `${currentYear}-${currentMonth.toString().padStart(2, '0')}`,
    // 级次编码长度列表
    subjectLevelStructs,
    // 最大级次
    maxLevel: subjectLevelStructs.length,
    // enablePersonalIncomeTax: true, // 模拟是否显示薪酬模块
  };
};

// 默认菜单
export const defaultMenuList = [
  { menuName: '凭证', selected: 'true' },
  { menuName: '日记账', selected: 'true' },
  { menuName: '票据管理', selected: 'true' },
  { menuName: '固定资产', selected: 'true' },
  { menuName: '存货', selected: 'true' },
  { menuName: '薪酬', selected: 'true' },
  { menuName: '期末', selected: 'true' },
  { menuName: '账簿', selected: 'true' },
  { menuName: '会计报表', selected: 'true' },
  { menuName: '纳税申报', selected: 'true' },
  { menuName: '设置', selected: 'true' },
  { menuName: '统计报表', selected: 'true' },
  { menuName: '税务筹划', selected: 'true' },
];
