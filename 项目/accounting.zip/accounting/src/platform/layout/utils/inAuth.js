import { Component } from 'react';

// 基于已有代账权限 code，如果账套禁用时也需要隐藏的按钮权限代码

// 避免冲突 后面进行整理合并
const DISABLED_ACCOUNT_AUTH_CODE = [
  68,
  77,
  78,
  79,
  86,
  87,
  88,
  89,
  98,
  101,
  182,
  185,
  191,
  192,
  193,
  194,
  198,
  200,
  204,
  205,
  206,
  251,
  252,
  256,
  257,
  262,
  263,
  268,
  269,
  498,
  499,
  500,
  501,
  513,
  539,
  540,
  560,
  596,
  597,
  638,
  639,
  640,
  641,
  642,
  643,
  644,
  645,
  647,
  650,
  651,
  653,
  655,
  565,
  566,
  159,
  160,
  165,
  168,
  169,
  172,
  539,
  540,
  541,
  529,
  530,
  738,
  739,
  740,
  741,
  742,
  743,
  745,
  746,
];
const CFG_MAP = {};
for (let i = 0; i < DISABLED_ACCOUNT_AUTH_CODE.length; i++) {
  const item = DISABLED_ACCOUNT_AUTH_CODE[i];
  CFG_MAP[item] = true;
}

// 政府会计制度
const accountingAuth = ({ code, account }) => {
  if (Array.isArray(code)) {
    return code.includes(Number(account?.accounting));
  }

  return Number(account?.accounting) === Number(code);
};

// inAuth 支持的 type 类型和对应判断方法配置
const authTypeConfig = {
  accounting: accountingAuth,
};

const createAuth = ({ authorities, account, user }) => {
  // 代账版禁用 企业版过期
  const isDisable = account.isDisable || [3, 4].includes(+user.useStatus);

  // type 作为后续多权限类型区分
  window.inAuth = (code, type = '') => {
    // 其他角色权限扩展
    if (type) {
      return authTypeConfig[type]({ code, account });
    }

    // code 为空，只判断是否禁用账套
    if (!code) {
      return !isDisable;
    }

    // 首先判断账套是否禁用，如果禁用并且权限在配置项里面，已经配置了 inAuth 的按钮直接 return false
    if (isDisable && CFG_MAP[code]) return false;

    // 存在权限代码 并且代码中不包含传入 code
    if (authorities && code && authorities.indexOf(code.toString()) === -1) {
      return false;
    }

    return true;
  };

  Component.prototype.inAuth = window.inAuth;
};

export default createAuth;
