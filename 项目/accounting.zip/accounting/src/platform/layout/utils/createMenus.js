const getMenusSource = (menus, list, openKeys = [], newMenus = []) => {
  menus.forEach(({ visible, ...rest }) => {
    if (visible || visible === undefined) {
      let ele = rest;
      const parentKey = openKeys.length ? openKeys[openKeys.length - 1] : '';
      const key = parentKey ? `${parentKey}!${ele.title}` : ele.title;
      if (ele.children) {
        const children = getMenusSource(ele.children, list, openKeys.concat(key));
        ele = {
          ...ele,
          children,
        };
      }
      ele = {
        ...ele,
        key,
        openKeys,
        selectedKeys: openKeys.concat(key),
      };
      newMenus.push(ele);
      if (ele.path) {
        list.push(ele);
      }
    }
  });
  return newMenus;
};

export default (accountData, dispatch) => {
  // todo 后台确少新的纳税申报页面
  const {
    user: { menuList = [], serviceVersion = 1 },
  } = accountData;
  const taxMenuList = accountData.taxMenuList || []; // 纳税申报菜单
  // 是否开启票据（平阳项目）
  const enableDailyBookBillSwitch = !!accountData.enableDailyBookBillSwitch;
  // 是否启用了固定资产
  const enableFixedAsset = !!accountData.enableFixedAsset;
  // 是否启用了原始凭证
  const enableOriginalVoucher = !!accountData.enableOriginalVoucher;
  // 是否启用了存货模块  需求 #156998
  const enableStock = accountData.inventoryCost === 1;
  // 是否启用存货核算
  const enableNewStock = accountData.inventoryCost === 2;
  // 是否启用了个税（原薪酬）模块
  const enablePersonalIncomeTax = !!accountData.enablePersonalIncomeTax;
  // 是否启用薪酬模块
  const enableSalary = !!accountData.enableSalary;
  // 是否启用辅助核算
  const enableAuxiliary = !!accountData.enableAuxiliary;
  // 账套类型
  const { accounting } = accountData;
  // 是否是个体工商户
  const isAccounting = [6, 7].includes(accounting);
  // 是否显示薪酬 ---规则： 农合，政府会计制度不显示
  const isSalaryModule = ![12, 13, 14, 15].includes(accounting);
  // 是否是代账
  const isDaizhang =
    accountData.versionType === '1' ||
    accountData.versionType === '2' ||
    accountData.versionType === '3';
  // 是否是个人版
  const isPersonal = accountData.versionType === '0';
  // 是否展示菜单
  const enableMenu = inAuth('54');
  // 是否是vip通道
  const { isVipChannel } = accountData;
  // 是否政府会计制度
  const isGovernment = [14, 15].includes(accounting);
  // 是否是企业或者小企业 或者国有建设单位
  const isEnterPrise = [0, 1, 4, 5, 8, 9, 10, 11, 16].includes(accounting);
  // 是否是小规模纳税人
  const isSmall = [3, 4, 5, 7, 9, 11, 13, 15].includes(accounting);
  // 是否国有会计制度
  const isStateOwned = [16].includes(accounting);
  // 农合、个体、政府集合
  const isAggregate = [12, 13, 6, 7, 14, 15].includes(accounting);
  // 常用账簿列表
  const { commonlyBooks, isInitSubject } = accountData;
  const { taxAuthority, accountAuthority } = accountData.accountAuthority || {
    taxAuthority: true,
    accountAuthority: true,
  };
  // 是否开启生成经营算税
  const { enableOperatingIncome } = accountData;

  const booksUrl = {
    1: '/books/general',
    2: '/books/detail',
    3: '/books/multi',
    4: '/books/balance',
    5: '/books/general-amt',
    6: '/books/detail-amt',
    7: '/books/auxiliary-detail',
    8: '/books/auxiliary-balance',
  };

  const commonlyBook = commonlyBooks
    .filter(({ isCommonlyBook }) => isCommonlyBook === 1)
    .map(({ commonlyName, commonlyId, bookType }) => {
      const parentPath = booksUrl[bookType];
      const path = `${parentPath}/${commonlyId}`;
      return {
        title: commonlyName.replace(/（[^（）]+）$/, ''),
        visible: true,
        commonlyId,
        path,
      };
    });

  const menusObj = {
    // 出纳管理
    cashierManagement: {
      title: '出纳管理',
      icon: 'chunaguanli',
      visible: +accountData.versionType !== 0,
    },
    // 凭证
    piingzheng: {
      title: '凭证',
      icon: 'piingzheng',
      visible: inAuth('66') && accountAuthority,
    },
    voucherRecord: {
      title: '录凭证',
      path: '/voucher/record',
      reload: false,
      icon: 'lupingzheng',
      visible: inAuth('66') && inAuth('68') && accountAuthority,
    },
    voucherList: {
      title: '查凭证',
      path: '/voucher/list',
      icon: 'chapingzheng',
      visible: inAuth('66') && inAuth('76') && accountAuthority,
    },
    voucherGather: {
      title: '凭证汇总表',
      path: '/voucher/gather',
      visible: isDaizhang && inAuth('92'),
    },
    voucherRecycle: {
      title: '凭证回收站',
      path: '/voucher/recycle',
      visible: isDaizhang && inAuth('595') && !isPersonal,
    },

    // 日记账
    rijizhang: {
      title: '日记账',
      icon: 'rijizhang',
      visible: isDaizhang && (inAuth('85') || inAuth('497')) && !isAccounting && accountAuthority, // bankStatement
    },
    voucherJournal: {
      title: '现金日记账',
      path: '/voucher/journal',
      icon: 'lupingzheng',
      visible: inAuth('85'),
    },
    voucherJournalBankStatement: {
      title: '银行日记账',
      path: '/voucher/journal-bankStatement',
      icon: 'chapingzheng',
      visible: inAuth('497'),
    },
    otherJournal: {
      title: '其他货币资金',
      path: '/voucher/journal-otherCurrency',
      icon: 'chapingzheng',
      visible: inAuth('683') && accounting !== 16,
    },

    // 票据
    bills: {
      title: '票据',
      icon: 'rijizhang',
      visible: inAuth('755') && (inAuth('756') || inAuth('760') || inAuth('762') || inAuth('766')),
    },
    billsRegister: {
      title: '登记',
      path: '/bills/register',
      visible: inAuth('756'),
    },
    billsReceive: {
      title: '领用',
      path: '/bills/receive',
      visible: inAuth('760'),
    },
    billsUse: {
      title: '使用',
      path: '/bills/use',
      visible: inAuth('762'),
    },
    billsManage: {
      title: '管理',
      path: '/bills/manage',
      visible: inAuth('766'),
    },

    // 票据管理
    piaojuguanli: {
      title: '发票管理',
      icon: 'piaojuguanli',
      visible: inAuth('95') && !isAccounting && accountAuthority && !isGovernment,
    },
    billmanageOriginalVoucher: {
      title: '原始凭证',
      icon: 'piaojuguanli',
      path: '/billmanage/original-voucher',
      visible:
        inAuth('95') && inAuth('97') && accountAuthority && !isAccounting && accounting !== 16,
    },
    billmanageEntryInvoice: {
      title: '进项发票',
      path: '/billmanage/entry-invoice',
      visible: inAuth('100') && accounting !== 3,
    },
    checkInvoice: {
      title: '进项勾选',
      path: '/billmanage/check-invoice',
      // visible: inAuth('103'),
      visible: true,
    },
    billmanageVatInvoice: {
      title: '销项发票',
      path: '/billmanage/vat-invoice',
      visible: inAuth('103'),
    },

    // 固定资产
    gudingzichan: {
      title: '固定资产',
      icon: 'gudingzichan',
      visible: inAuth('156') && accountAuthority && enableFixedAsset,
    },
    assetsCard: {
      title: '卡片管理',
      path: '/assets/card',
      visible: inAuth('158'),
      // reload: false,
    },
    assetsDepreciation: {
      title: '计提折旧',
      path: '/assets/depreciation',
      visible: inAuth('164'),
      // reload: false,
    },
    assetsVoucher: {
      title: '凭证生成',
      path: '/assets/voucher',
      visible: inAuth('167'),
    },
    assetsDepreciationDetail: {
      title: '折旧明细表',
      path: '/assets/depreciation-detail',
      visible: inAuth('171'),
      // reload: false,
    },
    assetsDepreciationGather: {
      title: '折旧汇总表',
      path: '/assets/depreciation-gather',
      visible: inAuth('176'),
    },

    // 存货
    cunhuo1: {
      title: '存货',
      icon: 'cunhuo1',
      visible:
        inAuth('247') &&
        !isAccounting &&
        !isGovernment &&
        accounting !== 16 &&
        accountAuthority &&
        accountData.versionType !== '2' &&
        enableStock,
    },
    stockIn: {
      title: '入库明细表',
      path: '/stock/in',
      visible: inAuth('249'),
    },
    stockOut: {
      title: '出库明细表',
      path: '/stock/out',
      visible: inAuth('254'),
    },
    stockSale: {
      title: '销售明细表',
      path: '/stock/sale',
      visible: inAuth('266'),
    },
    stockImportSales: {
      title: '进销存台账',
      path: '/stock/import-sales',
      visible: inAuth('259'),
    },

    // 薪酬管理 => 纳税申报
    xinchou: {
      title: '纳税申报',
      icon: 'nashuishenbao',
      visible:
        accountAuthority &&
        inAuth(562) &&
        isDaizhang &&
        !isStateOwned &&
        enablePersonalIncomeTax &&
        !isVipChannel &&
        accounting !== 12 &&
        accounting !== 13 &&
        accounting !== 16 &&
        !isGovernment &&
        accountData.versionType !== '2',
    },
    salaryStaffManagement: {
      title: '员工管理',
      path: '/salary/staff-management',
      visible: inAuth(564),
    },
    salaryWageTax: {
      title: '工资算税',
      path: '/salary/wage-tax',
      visible: inAuth(568),
    },
    salaryProductionTax: {
      title: '生产经营算税',
      path: '/salary/production-tax',
      visible: inAuth(725) && enableOperatingIncome,
    },
    // 薪酬模块
    salary: {
      title: '薪酬',
      icon: 'xinchou',
      visible: isSalaryModule && enableSalary && !isGovernment && accounting !== 16 && inAuth(738),
    },
    payroll: {
      title: '工资表',
      path: '/salaryModule/payroll',
      visible: inAuth(739),
    },
    sheets: {
      title: '统计报表',
      visible: inAuth(743),
    },
    departmentSalarySummary: {
      title: '部门薪酬汇总表',
      path: '/salaryModule/departmentSalarySummary',
      visible: inAuth(743),
    },
    staffSalarySummary: {
      title: '员工薪酬汇总表',
      path: '/salaryModule/staffSalarySummary',
      visible: inAuth(743),
    },
    salarySetting: {
      title: '设置',
      path: '/salaryModule/setting',
      visible: inAuth(745),
    },
    // 期末
    qimochuli: {
      title: '期末',
      icon: 'qimochuli',
      visible: inAuth('179') && accountAuthority,
    },
    terminalCarryover: {
      title: '结转',
      path: '/terminal/carryover',
      visible: inAuth('181') && accounting !== 16,
    },
    terminalCheckout: {
      title: '结账',
      path: '/terminal/checkout',
      visible: inAuth('184'),
    },

    // 账簿
    zhangbu: {
      title: '账簿',
      icon: 'zhangbu',
      visible: inAuth('105') && accountAuthority,
    },
    booksGeneral: {
      title: '总账',
      path: '/books/general',
      bookType: 1,
      visible: inAuth('107'),
    },
    booksDetail: {
      title: '明细账',
      path: '/books/detail',
      bookType: 2,
      visible: inAuth('112'),
    },
    booksMulti: {
      title: '多栏账',
      path: '/books/multi',
      bookType: 3,
      visible: isDaizhang && inAuth('117'),
    },
    booksBalance: {
      title: '科目余额表',
      bookType: 4,
      path: '/books/balance',
      visible: inAuth('120'),
    },
    booksGeneralAmt: {
      title: '数量金额总账',
      bookType: 5,
      path: '/books/general-amt',
      visible: inAuth('238'),
    },
    booksDetailAmt: {
      title: '数量金额明细账',
      path: '/books/detail-amt',
      bookType: 6,
      visible: inAuth('243'),
    },
    booksAuxiliaryDetail: {
      title: '辅助核算明细账',
      path: '/books/auxiliary-detail',
      bookType: 7,
      visible: enableAuxiliary && inAuth('124'),
    },
    booksAuxiliaryBalance: {
      title: '辅助核算余额表',
      path: '/books/auxiliary-balance',
      bookType: 8,
      visible: enableAuxiliary && inAuth('129'),
    },
    commonAccountBook: {
      title: '常用账簿',
      children: commonlyBook,
      visible: commonlyBook.length > 0,
    },
    booksReconciliation: {
      title: '对账',
      visible: inAuth('134'),
      onClick() {
        dispatch({
          type: 'onCheckAccount',
          payload: false,
        });
      },
    },

    // 会计报表
    baobiao: {
      title: '会计报表',
      icon: 'baobiao',
      visible: inAuth('135') && accountAuthority,
    },
    sheetAssetLiabilities: {
      title: isStateOwned ? '资金平衡表' : '资产负债表',
      path: '/sheet/asset-liabilities',
      visible: inAuth('137'),
    },
    sheetActivity: {
      title: '业务活动表',
      path: '/sheet/activity',
      visible:
        inAuth('141') && (accounting === 2 || accounting === 3) && !isGovernment && !isStateOwned,
    },
    sheetProfit: {
      title: isGovernment ? '收入费用表' : '利润表', // 政府会计制度下名称：收入费用表
      path: '/sheet/profit',
      visible:
        !isAccounting && inAuth('141') && ![12, 13, 2, 3].includes(accounting) && !isStateOwned,
    },
    sheetBudgetIncome: {
      title: '预算收入支出表', // 政府会计制度下
      path: '/sheet/budget-income',
      visible: isGovernment && inAuth(735),
    },
    sheetProfitQuarterly: {
      title: '利润季报',
      path: '/sheet/profit-quarterly',
      visible:
        !(accounting === 2 || accounting === 3 || isAccounting) &&
        inAuth('141') &&
        ![12, 13, 14, 15].includes(accounting) &&
        !isStateOwned,
    },
    sheetCashflow: {
      title: '现金流量表',
      path: '/sheet/cashflow',
      visible:
        !isAccounting && inAuth('149') && ![12, 13, 14, 15].includes(accounting) && !isStateOwned,
    },
    sheetCashflowQuarterly: {
      title: '现金流量季报',
      path: '/sheet/cashflow-quarterly',
      visible:
        !(accounting === 2 || accounting === 3 || isAccounting) &&
        inAuth('149') &&
        ![12, 13, 14, 15].includes(accounting) &&
        !isStateOwned,
    },
    sheetTaxableIncome: {
      title: '应税所得表',
      path: '/sheet/taxable-income',
      visible: isAccounting && inAuth('141') && ![12, 13, 14, 15].includes(accounting),
    },
    sheetRetainedProfit: {
      title: '留存利润表',
      path: '/sheet/retained-profit',
      visible: isAccounting && inAuth('533') && ![12, 13, 14, 15].includes(accounting),
    },
    sheetSurplusDistribution: {
      title: '盈余及盈余分配表',
      path: '/sheet/surplus-distribution',
      visible: (accounting === 12 || accounting === 13) && inAuth('141') && !isGovernment,
    },
    sheetEquityChanges: {
      title: '成员权益变动表',
      path: '/sheet/equity-changes',
      visible: (accounting === 12 || accounting === 13) && inAuth('667') && !isGovernment,
    },

    // 纳税申报
    // todo 薪酬改为纳税申报，纳税申报暂未命名
    financeList: {
      title: '纳税申报',
      path: '/finance/list',
      icon: 'nashuishenbao',
      visible: inAuth('561') && isDaizhang && taxAuthority && !isStateOwned,
    },

    // 税务管理
    taxManage: {
      title: '税务管理',
      icon: 'nashuishenbao',
      visible: true,
    },
    tax: {
      title: '增值税',
      path: '/taxManage/tax',
      visible: taxMenuList.includes('增值税'),
    },
    incomeTax: {
      title: '企业所得税',
      path: '/taxManage/incomeTax',
      visible: taxMenuList.includes('企业所得税'),
    },
    additionalTax: {
      title: '附加税',
      path: '/taxManage/additionalTax',
      visible: taxMenuList.includes('附加税'),
    },
    stampTax: {
      title: '印花税',
      path: '/taxManage/stampTax',
      visible: taxMenuList.includes('印花税'),
    },
    taxCalculation: {
      title: '税负测算',
      path: '/taxManage/taxCalculation',
      visible: !isSmall && !isAggregate,
    },
    taxStatistics: {
      title: '纳税统计',
      path: '/taxManage/taxStatistics',
    },

    // 税务筹划
    taxPlanning: {
      title: '税务筹划',
      icon: 'baoshui1',
      visible: !isStateOwned,
    },

    // 设置
    shezhi1: {
      title: '设置',
      icon: 'shezhi1',
      visible: inAuth('188') && accountAuthority,
    },
    settingSubjectManage: {
      title: '科目管理',
      path: '/setting/subject-manage',
      visible: inAuth('190'),
    },
    settingInitialBalance: {
      title: '初始余额',
      path: '/setting/initial-balance',
      visible: inAuth('197'),
    },
    settingAuxiliaryManage: {
      title: '辅助管理',
      path: '/setting/auxiliary-manage',
      type: 'auxiliary',
      visible: enableAuxiliary && inAuth('203'),
    },
    settingVoucherTemplate: {
      title: '凭证模板',
      path: '/setting/voucher-template',
      visible:
        (isDaizhang || enableOriginalVoucher) && inAuth('538') && (enableSalary || !isAccounting),
    },
    settingBackupManage: {
      title: '备份归档',
      path: '/setting/backup-manage',
      visible: inAuth('637'),
    },
    settingAccountBook: {
      title: '常用账簿设置',
      path: '/setting/account-book',
      visible: inAuth('646'),
    },
    settingAccount: {
      title: '账户设置',
      path: '/setting/account',
      visible: isDaizhang && inAuth('648'),
    },
    settingTaxDeclaration: {
      title: '纳税申报设置',
      path: '/setting/taxDeclaration',
      visible: true,
    },
    settingPostSetting: {
      title: '岗位设置',
      path: '/setting/post-setting',
      visible: isDaizhang && accountData.versionType !== '2' && inAuth('652'),
    },
    settingAccountSet: {
      title: '账套设置',
      path: '/setting/account-set',
      visible: isDaizhang && inAuth('654'),
    },

    // 存货核算
    cunhuo2: {
      title: '存货',
      icon: 'cunhuo1',
      visible:
        inAuth('247') &&
        !isAccounting &&
        accountAuthority &&
        enableNewStock &&
        !isGovernment &&
        accounting !== 16,
    },
    stockModuleBill: {
      title: '单据列表',
      path: '',
      icon: '',
      visible: inAuth('674'),
      children: [
        {
          title: '采购入库单',
          path: '/stockModule/bill-purchase-receipt',
        },
        {
          title: '其他入库单',
          path: '/stockModule/bill-miscellaneous-receipt',
        },
        {
          title: '销售出库单',
          path: '/stockModule/bill-sales-issue-doc',
        },
        {
          title: '其他出库单',
          path: '/stockModule/bill-miscellaneous-issue-doc',
        },
        {
          title: '成本调整单',
          path: '/stockModule/bill-cost-adjustment-document',
        },
      ],
    },
    stockModuleFinancialTreatment: {
      title: '财务处理',
      path: '',
      icon: '',
      visible: inAuth('676'),
      children: [
        {
          title: '出库计价',
          path: '/stockModule/financialTreatment-outgoing-valuation',
        },
        {
          title: '生成凭证',
          path: '/stockModule/financialTreatment-create-voucher',
        },
      ],
    },
    stockModuleInventory: {
      title: '存货报表',
      path: '',
      icon: '',
      visible: inAuth('678'),
      children: [
        {
          title: '存货明细表',
          path: '/stockModule/inventory-details',
        },
        {
          title: '收发存明细表',
          path: '/stockModule/transmit-receive-specification',
        },
        {
          title: '收发存汇总表',
          path: '/stockModule/transmit-receive-summary',
        },
        {
          title: '暂估余额表',
          path: '/stockModule/estimated-balance-table',
        },
      ],
    },
    stockModuleStockSetup: {
      title: '存货设置',
      path: '',
      icon: '',
      visible: inAuth('680'),
      children: [
        {
          title: '存货核算设置',
          path: '/stockModule/stockSetup-businessAccounting',
        },
        {
          title: '存货别名对应',
          path: '/stockModule/stockSetup-alias',
        },
        {
          title: '初始余额',
          path: '/stockModule/stockSetup-initialBalance',
        },
      ],
    },

    // 总账
    zhangbu1: {
      title: '总账',
      icon: 'zhangbu',
      visible: inAuth('105') && accountAuthority,
    },

    // 辅助管理
    // stockModuleInstallFileManagement: {
    //   title: '辅助管理',
    //   icon: '',
    //   path: '/stockModule/install-fileManagement',
    //   visible: true && accountData.versionType !== '1',
    // },

    // 账套设置
    settingBusinessAccountSet: {
      title: '账套设置',
      path: '/setting/business-account-set',
      visible: true,
    },
    // 统计报表
    report: {
      title: '统计报表',
      icon: 'tongjibaobiao',
      visible: inAuth('726') && isEnterPrise && accountAuthority,
    },
    costStatistics: {
      title: '成本费用统计表',
      path: '/report/cost-statistics',
      visible: inAuth('727') && accounting !== 16,
    },
    businessStatistics: {
      title: '经营状况统计表',
      path: '/report/business-statistics',
      visible: inAuth('729') && accounting !== 16,
    },
    accountsReceivableStatistics: {
      title: '应收统计表',
      path: '/report/accounts-receivable-statistics',
      visible: inAuth('731') && accounting !== 16,
    },
    accountsPayableStatistics: {
      title: '应付统计表',
      path: '/report/accounts-payable-statistics',
      visible: inAuth('733') && accounting !== 16,
    },
    constructionManager: {
      title: '建设单位管理费用表',
      path: '/report/construction-manager',
      visible: accounting === 16 && inAuth('772'),
    },
    deferredInvestmentDetail: {
      title: '待摊投资明细表',
      path: '/report/deferred-investment-detail',
      visible: accounting === 16 && inAuth('775'),
    },
  };

  let array = [];
  const {
    cashierManagement,
    // 凭证
    piingzheng,
    voucherRecord,
    voucherList,
    voucherGather,
    voucherRecycle,
    // 日记账
    rijizhang,
    voucherJournal,
    voucherJournalBankStatement,
    otherJournal,
    // 票据
    bills,
    billsRegister,
    billsReceive,
    billsUse,
    billsManage,
    // 票据管理
    piaojuguanli,
    billmanageOriginalVoucher,
    billmanageEntryInvoice,
    billmanageVatInvoice,
    checkInvoice,
    // 固定资产
    gudingzichan,
    assetsCard,
    assetsDepreciation,
    assetsVoucher,
    assetsDepreciationDetail,
    assetsDepreciationGather,
    // 存货
    cunhuo1,
    stockIn,
    stockOut,
    stockSale,
    stockImportSales,
    // 薪酬模块
    salary,
    payroll,
    sheets,
    departmentSalarySummary,
    staffSalarySummary,
    salarySetting,
    // 期末
    qimochuli,
    terminalCarryover,
    terminalCheckout,
    // 账簿
    zhangbu,
    booksGeneral,
    booksDetail,
    booksMulti,
    booksBalance,
    booksGeneralAmt,
    booksDetailAmt,
    booksAuxiliaryDetail,
    booksAuxiliaryBalance,
    commonAccountBook,
    booksReconciliation,
    // 会计报表
    baobiao,
    sheetAssetLiabilities,
    sheetActivity,
    sheetProfit,
    sheetBudgetIncome,
    sheetProfitQuarterly,
    sheetCashflow,
    sheetCashflowQuarterly,
    sheetTaxableIncome,
    sheetRetainedProfit,
    sheetSurplusDistribution,
    sheetEquityChanges,
    // 薪酬管理 => 纳税申报
    xinchou,
    salaryStaffManagement,
    salaryWageTax,
    salaryProductionTax,
    // 纳税申报
    financeList,
    // 税务管理
    taxManage,
    tax,
    incomeTax,
    additionalTax,
    stampTax,
    taxCalculation,
    taxStatistics,
    // 税务筹划
    taxPlanning,
    // 设置
    shezhi1,
    settingSubjectManage,
    settingInitialBalance,
    settingAuxiliaryManage,
    settingVoucherTemplate,
    settingBackupManage,
    settingAccountBook,
    settingAccount,
    settingTaxDeclaration,
    settingPostSetting,
    settingAccountSet,
    // 存货核算
    cunhuo2,
    stockModuleBill,
    stockModuleFinancialTreatment,
    stockModuleInventory,
    stockModuleStockSetup,
    // 总账
    zhangbu1,
    // 档案管理
    // stockModuleInstallFileManagement,
    // 账套设置
    settingBusinessAccountSet,
    // 统计报表
    report,
    costStatistics,
    businessStatistics,
    accountsReceivableStatistics,
    accountsPayableStatistics,
    constructionManager,
    deferredInvestmentDetail,
  } = menusObj;
  // 配置菜单 根据versionType判断分配 1 = 代账， 2 = 企业， 0 = 个人 , 3 = 查账
  // ------------------------------------------------------------------------------------------------------------------------------------ //
  const newVoucherRecord = isGovernment
    ? {
        ...voucherRecord,
        path: '',
        icon: '',
        children: [
          {
            ...voucherRecord,
            title: '财务凭证',
          },
          {
            ...voucherRecord,
            title: '预算凭证',
            path: '/voucher/record-budget',
          },
        ],
      }
    : voucherRecord;

  if (['1', '3'].includes(accountData.versionType)) {
    // 代账版
    const menuAuth = {
      // 对平阳项目单独处理
      ...(enableDailyBookBillSwitch
        ? {
            出纳管理: [
              {
                ...cashierManagement,
                children: [
                  {
                    ...rijizhang,
                    icon: '',
                    children: [voucherJournal, voucherJournalBankStatement, otherJournal],
                  },
                  {
                    ...bills,
                    icon: '',
                    children: [billsRegister, billsReceive, billsUse, billsManage],
                  },
                ],
              },
            ],
          }
        : {
            日记账: [
              {
                ...rijizhang,
                children: [voucherJournal, voucherJournalBankStatement, otherJournal],
              },
            ],
          }),
      凭证: [
        {
          ...piingzheng,
          children: [newVoucherRecord, voucherList, voucherGather, voucherRecycle],
        },
      ],
      发票管理: [
        {
          ...piaojuguanli,
          children: [billmanageEntryInvoice, billmanageVatInvoice, billmanageOriginalVoucher],
        },
      ],
      固定资产: [
        {
          ...gudingzichan,
          children: [
            assetsCard,
            assetsDepreciation,
            assetsVoucher,
            assetsDepreciationDetail,
            assetsDepreciationGather,
          ],
        },
      ],
      存货: [
        {
          ...cunhuo1,
          children: [stockIn, stockOut, stockSale, stockImportSales],
        },
        // 存货核算
        {
          ...cunhuo2,
          children: [
            stockModuleBill,
            stockModuleFinancialTreatment,
            stockModuleInventory,
            stockModuleStockSetup,
          ],
        },
      ],
      薪酬: [
        {
          ...xinchou,
          title: '薪酬',
          icon: 'xinchou',
          children: [salaryStaffManagement, salaryWageTax, salaryProductionTax],
        },
      ],
      期末: [
        {
          ...qimochuli,
          children: [terminalCarryover, terminalCheckout],
        },
      ],
      账簿: [
        {
          ...zhangbu,
          children: [
            booksGeneral,
            booksDetail,
            booksMulti,
            booksBalance,
            booksGeneralAmt,
            booksDetailAmt,
            booksAuxiliaryDetail,
            booksAuxiliaryBalance,
            commonAccountBook,
            booksReconciliation,
          ],
        },
      ],
      会计报表: [
        {
          ...baobiao,
          children: [
            sheetAssetLiabilities,
            sheetActivity,
            sheetProfit,
            sheetBudgetIncome,
            sheetProfitQuarterly,
            sheetCashflow,
            sheetCashflowQuarterly,
            sheetTaxableIncome,
            sheetRetainedProfit,
            sheetSurplusDistribution,
            sheetEquityChanges,
          ],
        },
      ],
      纳税申报: [financeList],
      税务筹划: [
        {
          ...taxPlanning,
          visible: taxPlanning.visible && taxCalculation.visible,
          children: [taxCalculation],
        },
      ],
      设置: [
        {
          ...shezhi1,
          children: [
            settingSubjectManage,
            settingInitialBalance,
            settingAuxiliaryManage,
            settingVoucherTemplate,
            settingBackupManage,
            settingAccountBook,
            settingAccount,
            settingPostSetting,
            settingAccountSet,
          ],
        },
      ],
      统计报表: [
        {
          ...report,
          children: [
            costStatistics,
            businessStatistics,
            accountsReceivableStatistics,
            accountsPayableStatistics,
            constructionManager,
            deferredInvestmentDetail,
          ],
        },
      ],
    };
    if (menuList && menuList.length) {
      menuList.forEach((item) => {
        let items = item;
        // 本期暂不做显示隐藏，只跳转顺序
        // if (item.selected === 'true') {
        // 开启票据（平阳项目）时，“日记账”当做“出纳管理”
        if (enableDailyBookBillSwitch && items.menuName === '日记账') {
          items = {
            ...items,
            menuName: '出纳管理',
          };
        }
        array = array.concat(menuAuth[items.menuName] || []);
        // }
      });
    }
  } else if (accountData.versionType === '0') {
    // 个人版
    // 凭证模块
    if (enableFixedAsset || enableOriginalVoucher) {
      array = array.concat([
        {
          ...piingzheng,
          children: [newVoucherRecord, voucherList],
        },
      ]);
    } else {
      array = array.concat([
        {
          ...newVoucherRecord,
          icon: 'piingzheng',
        },
        voucherList,
      ]);
    }
    // 原始凭证
    if (enableOriginalVoucher) {
      array.push(billmanageOriginalVoucher);
    }
    array = array.concat([
      // 固定资产
      {
        ...gudingzichan,
        children: [
          assetsCard,
          assetsDepreciation,
          assetsVoucher,
          assetsDepreciationDetail,
          assetsDepreciationGather,
        ],
      },
      // 期末
      {
        ...qimochuli,
        children: [terminalCarryover, terminalCheckout],
      },
      // 账簿
      {
        ...zhangbu,
        children: [
          booksGeneral,
          booksDetail,
          booksMulti,
          booksBalance,
          booksGeneralAmt,
          booksDetailAmt,
          booksAuxiliaryDetail,
          booksAuxiliaryBalance,
          commonAccountBook,
          booksReconciliation,
        ],
      },
      // 会计报表
      {
        ...baobiao,
        children: [
          sheetAssetLiabilities,
          sheetActivity,
          sheetProfit,
          sheetBudgetIncome,
          sheetProfitQuarterly,
          sheetCashflow,
          sheetCashflowQuarterly,
          sheetTaxableIncome,
          sheetRetainedProfit,
          sheetSurplusDistribution,
          sheetEquityChanges,
        ],
      },
      // 设置
      {
        ...shezhi1,
        children: [
          settingSubjectManage,
          settingInitialBalance,
          settingAuxiliaryManage,
          settingVoucherTemplate,
          settingBackupManage,
          settingAccountBook,
          settingAccount,
          settingPostSetting,
          settingAccountSet,
        ],
      },
    ]);
  } else if (accountData.versionType === '2') {
    // 企业版
    let jxgx = {};
    if (typeof ExternService === 'object') {
      const invoiceMicroServiceMenu = (window.invoiceMicroServiceMenu || []).map((val) => {
        return {
          title: val.title,
          path: `/billmanage${val.path}`,
        };
      });
      jxgx = {
        ...checkInvoice,
        children: invoiceMicroServiceMenu,
      };
    } else {
      jxgx = {
        ...checkInvoice,
      };
    }
    /* * 诺账通菜单根据版本重新调整 ---------------------------------------------------------------------------------------------* */
    // serviceVersion ['基础版', '标准版', '增强版'][+serviceVersion] 诺账通版本

    const entMenuList = [
      // 总账管理
      {
        ...zhangbu1,
        title: '总账管理',
        // 总账管理权限 = 本身 +（凭证管理权限 || 账簿 || 辅助账簿）
        visible:
          zhangbu1.visible &&
          (piingzheng.visible ||
            zhangbu.visible ||
            booksAuxiliaryDetail.visible ||
            booksAuxiliaryBalance.visible),
        children: [
          // 凭证
          {
            ...piingzheng,
            icon: '',
            title: '凭证',
            children: [newVoucherRecord, voucherList, voucherGather, voucherRecycle],
          },
          // 账簿
          {
            ...zhangbu,
            icon: '',
            children: [
              booksGeneral,
              booksDetail,
              booksMulti,
              booksBalance,
              booksGeneralAmt,
              booksDetailAmt,
            ],
          },
          {
            title: '辅助账簿',
            icon: '',
            visible: booksAuxiliaryDetail.visible || booksAuxiliaryBalance.visible,
            children: [booksAuxiliaryDetail, booksAuxiliaryBalance],
          },
        ],
      },
      // 出纳管理
      {
        ...cashierManagement,
        // 权限是出纳管理的权限 + （日记账或者票据的权限）
        visible:
          cashierManagement.visible &&
          (rijizhang.visible || (bills.visible && +serviceVersion !== 0)),
        children: [
          {
            ...rijizhang,
            icon: '',
            children: [voucherJournal, voucherJournalBankStatement, otherJournal],
          },
          {
            ...bills,
            icon: '',
            visible: bills.visible && +serviceVersion !== 0, // 原先的权限下加 基础版不显示
            children: [billsRegister, billsReceive, billsUse, billsManage],
          },
        ],
      },

      // 发票管理 = 原 票据管理 (标准版或加强版)
      {
        ...piaojuguanli,
        title: '发票管理',
        visible: piaojuguanli.visible && +serviceVersion !== 0,
        children: [
          billmanageOriginalVoucher,
          billmanageEntryInvoice,
          {
            ...jxgx,
          },
          billmanageVatInvoice,
        ],
      },
      // 固定资产 (标准版或加强版)
      {
        ...gudingzichan,
        visible: gudingzichan.visible && +serviceVersion !== 0,
        children: [
          assetsCard,
          assetsDepreciation,
          assetsVoucher,
          assetsDepreciationDetail,
          assetsDepreciationGather,
        ],
      },
      // 薪酬管理 (标准版或加强版)
      {
        ...salary,
        title: '薪酬管理',
        visible: salary.visible && +serviceVersion !== 0,
        children: [
          {
            ...payroll,
            icon: '',
          },
          {
            ...sheets,
            icon: '',
            children: [departmentSalarySummary, staffSalarySummary],
          },
          {
            ...salarySetting,
            icon: '',
          },
        ],
      },
      // 税务管理 = 原 纳税申报 (标准版或加强版)
      {
        ...taxManage,
        visible: taxManage.visible && +serviceVersion !== 0,
        children: [
          {
            title: '纳税申报表',
            visible:
              taxManage.visible &&
              (tax.visible || incomeTax.visible || additionalTax.visible || stampTax.visible),
            // 菜单 下级 有增值税、企业所得税、附加税、印花税
            children: [tax, incomeTax, additionalTax, stampTax],
          },
          {
            title: '税务分析',
            // 菜单 下级 有税务测算、纳税统计
            children: [taxCalculation, taxStatistics],
          },
        ],
      },
      // 存货核算 (加强版)
      {
        ...cunhuo2,
        title: '存货核算',
        visible: cunhuo2.visible,
        children: [
          stockModuleBill,
          stockModuleFinancialTreatment,
          stockModuleInventory,
          stockModuleStockSetup,
        ],
      },
      // 期末
      {
        ...qimochuli,
        title: '期末处理',
        // 权限 = 原期末 或 对账
        // visible: booksReconciliation.visible || qimochuli.visible,
        children: [
          {
            ...terminalCarryover,
          },
          {
            ...terminalCheckout,
          },
        ],
      },
      // 会计报表
      {
        ...baobiao,
        title: +serviceVersion !== 2 ? '会计报表' : '报表中心',
        // 权限 = 财务报表 或 管理报表 或 报表设计 （原什么菜单？？？？？？？？？？？？？？？？？？？？？？？ - 没有）
        visible: baobiao.visible || report.visible,
        children: [
          {
            title: '财务报表',
            children: [
              sheetAssetLiabilities,
              sheetActivity,
              sheetProfit,
              sheetBudgetIncome,
              sheetProfitQuarterly,
              sheetCashflow,
              sheetCashflowQuarterly,
              sheetTaxableIncome,
              sheetRetainedProfit,
              sheetSurplusDistribution,
              sheetEquityChanges,
            ],
          },
          // 统计报表 = 管理报表
          {
            ...report,
            icon: '',
            title: '管理报表',
            visible: report.visible && +serviceVersion !== 0,
            children: [
              costStatistics,
              businessStatistics,
              accountsReceivableStatistics,
              accountsPayableStatistics,
              constructionManager,
              deferredInvestmentDetail,
            ],
          },
        ],
      },
      {
        title: '设置',
        icon: shezhi1.icon,
        // 权限 = 财务设置 或 基础设置
        visible:
          settingAccountBook.visible ||
          settingInitialBalance.visible ||
          settingVoucherTemplate.visible ||
          settingBackupManage.visible ||
          settingAccountSet.visible ||
          shezhi1.visible,
        children: [
          {
            title: '财务设置',
            icon: '',
            children: [
              {
                ...settingAccountSet,
                title: '总账设置',
              },
              settingAccountBook,
              {
                ...settingInitialBalance,
                title: '初始余额设置',
              },
              settingVoucherTemplate,
              settingBackupManage,
            ],
          },
          {
            ...shezhi1,
            title: '基础设置',
            icon: '',
            children: [
              settingSubjectManage,
              settingAuxiliaryManage,
              {
                ...settingAccount,
                title: '账户设置',
              },
              {
                ...settingTaxDeclaration,
                visible: settingTaxDeclaration.visible && +serviceVersion !== 0,
              },
              settingPostSetting,
              settingBusinessAccountSet,
            ],
          },
        ],
      },
    ];
    array = array.concat(entMenuList);
  }

  const source = {
    data: [],
    list: [],
  };
  if (enableMenu && !isInitSubject) {
    source.data = getMenusSource(array, source.list);
  }
  return source;
};
