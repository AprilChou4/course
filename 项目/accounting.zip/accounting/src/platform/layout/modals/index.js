import auxiliaryExpired from './auxiliaryExpired';
import notice from './notice';
import mergeMessage from './mergeMessage';

export default async () => {
  await auxiliaryExpired();
  await notice();
  await mergeMessage();
};
