import { confirm, layer } from 'nuijs';
import { store } from 'nuomi';

export default async function (type) {
  // const { versionType } = store.getState().account;
  // if (versionType === '1') {
  let data = {};
  if (!type) {
    data = await store.getStore('account').dispatch({
      type: 'getAccount',
    });
  }
  return new Promise((resolve) => {
    const { isInitSubject } = store.getState().account;
    if (isInitSubject === true) {
      return;
    }
    if (data.isExistExternalSubject || type) {
      confirm({
        // 为了不和loading遮罩冲突
        id: 'initsubject',
        zIndex: 10000,
        container: '#app',
        content: '<p class="e-p12 f-tac">导入数据含表外科目，请合并</p>',
        cancel: {
          text: '关闭',
        },
        confirm: {
          text: '初始化',
          callback() {
            store.getStore('tabs').dispatch({
              type: 'removeAll',
            });
            store.getStore('account').dispatch({
              type: 'account/updateState',
              payload: {
                isInitSubject: true,
              },
            });
            store.getStore('account').dispatch({
              type: 'updateAccount',
            });

            // router.location(
            //   'setting/subject-manage',
            //   {
            //     merge: true,
            //   },
            //   true,
            // );
            return true;
          },
        },
        onInit(self) {
          if (self.element.next().css('z-index') === '10000') {
            self.element.css('z-index', 10001);
          }
        },
        onDestroy() {
          layer.hide('initsubject');
          resolve();
        },
      });
    } else {
      resolve();
    }
  });
  // }
}
