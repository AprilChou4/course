import { request, confirm } from 'nuijs';
import { store } from 'nuomi';

export default () => {
  const { year, month } = store.getState().account;
  return new Promise((resolve) => {
    request
      .get(
        'jz/notice/getAccountNotice',
        {
          year,
          month,
        },
        {
          200: (res) => {
            if (res.data) {
              confirm({
                // 为了不和loading遮罩冲突
                zIndex: 10000,
                container: '#app',
                content: `<p class="e-p12 f-tac">${res.data.notice}</p>`,
                cancel: {
                  enable: false,
                  text: '关闭',
                },
                confirm: {
                  text: '知道了',
                  callback() {
                    return true;
                  },
                },
                onDestroy() {
                  resolve();
                },
                onInit(self) {
                  if (self.element.next().css('z-index') === '10000') {
                    self.element.css('z-index', 10001);
                  }
                },
              });
            } else {
              resolve();
            }
          },
          other() {
            resolve();
          },
        },
        null,
      )
      .error(() => {
        resolve();
      });
  });
};
