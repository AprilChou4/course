import { request } from 'nuijs';
import { store, router } from 'nuomi';
import { gotoOrder } from 'utils';
import expiredModal from '../../../pages/setting/subjectManage/components/editModal/components/Auxiliary/expiredModal';
import { ConfirmModal } from '@/modal';

export default () => {
  const { versionType } = store.getState().account;
  if (versionType === '0') {
    return new Promise((resolve) => {
      // 进入页面时检测辅助核算是否过期
      request
        .get(
          'jz/trialpay/checkEnabled',
          { type: 1 },
          {
            200: ({ data }) => {
              if (data && data.result === 'expired') {
                expiredModal({
                  onCancel: () => {
                    ConfirmModal({
                      title:
                        '取消绑定的辅助核算将进行数据转换。一旦转换，明细数据将不再保留。且该过程不可逆，请知悉！',
                      content: '您确定要(前往科目设置)取消绑定辅助核算吗？',
                      okText: '前往科目设置',
                      cancelText: '去续费',
                      okButtonProps: {
                        type: null,
                      },
                      cancelButtonProps: {
                        type: 'primary',
                      },
                      onOk: (cb) => {
                        cb();
                        router.location('setting/subject-manage');
                        resolve();
                      },
                      onCancel: () => {
                        gotoOrder(1);
                        resolve();
                      },
                    });
                  },
                  onOk: () => {
                    resolve();
                  },
                  onClose: () => {
                    resolve();
                  },
                  cancelText: '取消绑定',
                });
              } else {
                resolve();
              }
            },
            other() {
              resolve();
            },
          },
          null,
        )
        .error(() => {
          resolve();
        });
    });
  }
};
