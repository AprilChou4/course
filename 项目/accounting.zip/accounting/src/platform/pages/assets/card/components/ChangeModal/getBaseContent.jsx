import React, { useEffect, useState } from 'react';
import { Col, Input, Form } from 'antd';
import { util } from 'nuijs';
import services from '../../services';

const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 14 },
};

export default (props) => {
  const { form, type, changeDetail } = props;
  const [taxTotal, setTotalTax] = useState('');
  const [monthDepreciate, setMonthDepreciate] = useState('');
  const [totalDepreciate, setTotalDepreciate] = useState('');
  const [netWorth, setNetWorth] = useState('');
  useEffect(() => {
    setTotalTax(changeDetail.taxTotal);
    setMonthDepreciate(changeDetail.monthDepreciate);
    setTotalDepreciate(changeDetail.totalDepreciate);
    setNetWorth(changeDetail.netWorth);
  }, [changeDetail]);
  const { getFieldDecorator } = form;
  const setTaxTotal = (data) => {
    setTotalTax(data);
    form.setFieldsValue({
      taxTotal: data,
    });
  };
  const numberChange = (e, integer, flag = true) => {
    let { value } = e.target;
    if (flag) {
      value = e.target.value.replace(/[^\d.]+/g, '');
      value = value.replace(/^\./g, '');
      value = value.replace(/\.{2,}/g, '.');
      value = value.split('.').length > 2 ? value.substring(-1, value.length - 1) : value;
    } else {
      e.target.value.replace(/[^\d]+/g, '');
    }
    const [valT, valY] = value.split('.');
    let maxZero = '';
    for (let i = 0; i < integer; i += 1) {
      maxZero += '0';
    }
    const max = 1 + maxZero - 1;
    if (valT > max) {
      e.target.value = valT.substring(0, integer);
    } else if (valY) {
      e.target.value = value.substring(0, valT.length + 3);
    } else {
      e.target.value = value;
    }
    // let dType = changeDetail.isInit;
    if (e.target.id === 'originalValue' || e.target.id === 'tax') {
      const originalValue = Number(
        (e.target.id === 'originalValue' ? value : form.getFieldValue('originalValue')) || 0,
      );
      const tax = Number((e.target.id === 'tax' ? value : form.getFieldValue('tax')) || 0);
      setTaxTotal(util.toFixed(originalValue + tax, 2));
    }
    if (e.target.id === 'originalValue' || e.target.id === 'totalDepreciate') {
      // dType = 1;
      form.setFieldsValue({
        isInit: 1,
      });

      let targetValue = e.target.value;
      if (!targetValue) {
        targetValue = '0';
      }
      const params = {
        ageLimit: changeDetail.ageLimit,
        buyDate: changeDetail.buyDate,
        depreciationMethod: changeDetail.depreciationMethod,
        initDepreciation:
          e.target.id === 'totalDepreciate'
            ? targetValue || changeDetail.totalDepreciate
            : changeDetail.totalDepreciate,
        originalValue:
          e.target.id === 'originalValue'
            ? targetValue || changeDetail.originalValue
            : changeDetail.originalValue,
        remainingRatio: changeDetail.remainingRatio,
        // isInit: form.getFieldValue('isInit') || dType,
        isInit: 1, // 除拆分外isInit都为1
        // addDate: changeDetail.addDate,
        assetTypeId: changeDetail.assetTypeId,
      };
      services.depreciationCalculate(params).then((res) => {
        setMonthDepreciate(res.monthDepreciate);
        setTotalDepreciate(res.totalDepreciate);
        setNetWorth(res.netWorth);
      });
    }
  };
  return {
    content: (
      <>
        <Col span={6}>
          <span>
            折旧方法：
            {/*  eslint-disable-next-line */}
            {changeDetail.depreciationMethod === 1
              ? '年限平均法'
              : changeDetail.depreciationMethod === 2
              ? '双倍余额递减法'
              : '年数总和法'}
          </span>
        </Col>
        <Col span={6}>
          <span>残值率：{changeDetail.remainingRatio}%</span>
        </Col>
        <Col span={6}>
          <span>预计使用月数：{changeDetail.ageLimit}</span>
        </Col>
      </>
    ),
    changeContent: (
      <>
        <Col span={12}>
          <span>原值：{changeDetail.originalValue}</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '1' ? (
              // eslint-disable-next-line
              <Form.Item {...formItemLayout} label="原值">
                {getFieldDecorator('originalValue', {
                  initialValue: changeDetail.originalValue,
                  rules: [
                    {
                      validator(rule, val, callback) {
                        const value = util.toFixed(val, 2);
                        if (value === '0.00' && value !== '') {
                          callback('原值不能为0');
                        }
                        callback();
                      },
                    },
                  ],
                })(
                  <Input
                    onChange={(e) => {
                      numberChange(e, 9);
                    }}
                  />,
                )}
              </Form.Item>
            ) : (
              `原值：${changeDetail.originalValue}`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>税额：{changeDetail.tax}</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '1' ? (
              //  eslint-disable-next-line
              <Form.Item {...formItemLayout} label="税额">
                {getFieldDecorator('tax', {
                  initialValue: changeDetail.tax,
                })(<Input onChange={(e) => numberChange(e, 9)} />)}
              </Form.Item>
            ) : (
              `税额：${changeDetail.tax}`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>原值（价税合计）：{changeDetail.taxTotal}</span>
          {type === '1' &&
            getFieldDecorator('taxTotal', {
              initialValue: changeDetail.taxTotal,
            })(<Input type="hidden" />)}
        </Col>
        <Col span={12}>
          <span>原值（价税合计）：{taxTotal}</span>
        </Col>
        <Col span={12}>
          <span>累计折旧：{changeDetail.totalDepreciate}</span>
        </Col>
        <Col span={12}>
          <span>
            {getFieldDecorator('isInit', {
              initialValue: changeDetail.isInit,
            })(<Input type="hidden" />)}
            {type === '2' ? (
              <>
                {/* eslint-disable-next-line */}
                <Form.Item {...formItemLayout} label="累计折旧">
                  {getFieldDecorator('totalDepreciate', {
                    initialValue: changeDetail.totalDepreciate,
                    rules: [
                      {
                        validator(rule, val, callback) {
                          const value =
                            changeDetail.originalValue -
                            (changeDetail.originalValue * changeDetail.remainingRatio) / 100;
                          if (val > value) {
                            callback('期初累计折旧不能大于原值-残值');
                          }
                          callback();
                        },
                      },
                    ],
                  })(<Input onChange={(e) => numberChange(e, 9)} />)}
                </Form.Item>
              </>
            ) : (
              `累计折旧：${totalDepreciate}`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>资产净值：{changeDetail.netWorth}</span>
        </Col>
        <Col span={12}>
          <span>资产净值：{netWorth}</span>
        </Col>
        <Col span={12}>
          <span>月折旧额：{changeDetail.monthDepreciate}</span>
        </Col>
        <Col span={12}>
          <span>月折旧额：{monthDepreciate}</span>
        </Col>
        {type === '2' && (
          <>
            {getFieldDecorator('originalValue', {
              initialValue: changeDetail.originalValue,
            })(<Input type="hidden" />)}
            {getFieldDecorator('tax', {
              initialValue: changeDetail.tax,
            })(<Input type="hidden" />)}
            {getFieldDecorator('taxTotal', {
              initialValue: changeDetail.taxTotal,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 3,
            })(<Input type="hidden" />)}
          </>
        )}
        {type === '1' && (
          <>
            {getFieldDecorator('changeType', {
              initialValue: 1,
            })(<Input type="hidden" />)}
            {getFieldDecorator('totalDepreciate', {
              initialValue: changeDetail.totalDepreciate,
            })(<Input type="hidden" />)}
          </>
        )}
        <>
          {getFieldDecorator('ageLimit', {
            initialValue: changeDetail.ageLimit,
          })(<Input type="hidden" />)}
          {getFieldDecorator('assetTypeId', {
            initialValue: changeDetail.assetTypeId,
          })(<Input type="hidden" />)}
          {getFieldDecorator('assetCode', {
            initialValue: changeDetail.assetCode,
          })(<Input type="hidden" />)}
          {getFieldDecorator('depreciationMethod', {
            initialValue: changeDetail.depreciationMethod,
          })(<Input type="hidden" />)}
          {getFieldDecorator('quantity', {
            initialValue: changeDetail.quantity,
          })(<Input type="hidden" />)}
          {getFieldDecorator('remainingRatio', {
            initialValue: changeDetail.remainingRatio,
          })(<Input type="hidden" />)}
          {getFieldDecorator('useDeptId', {
            initialValue: changeDetail.useDeptId,
          })(<Input type="hidden" />)}
          {getFieldDecorator('useProjectId', {
            initialValue: changeDetail.useProjectId,
          })(<Input type="hidden" />)}
        </>
      </>
    ),
  };
};
