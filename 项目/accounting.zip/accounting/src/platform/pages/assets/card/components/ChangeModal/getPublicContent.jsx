import React from 'react';
import { Col, Select, Form, Input } from 'antd';

const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 14 },
};

const { Option } = Select;

export default (props) => {
  const { form, type, changeDetail, typeList, useDepartmentsData, useProjectsData } = props;
  const { getFieldDecorator } = form;
  return {
    content: (
      <>
        <Col span={24}>
          <span className="change-title">财务信息</span>
        </Col>
        <Col span={6}>
          <span>原值（价税合计）：{changeDetail.taxTotal}</span>
        </Col>
        <Col span={6}>
          <span>残值率：{changeDetail.remainingRatio}%</span>
        </Col>
        <Col span={6}>
          <span>累计折旧：{changeDetail.totalDepreciate}</span>
        </Col>
        <Col span={6}>
          <span>资产净值：{changeDetail.netWorth}</span>
        </Col>
        <Col span={6}>
          <span>预计使用月数：{changeDetail.ageLimit}</span>
        </Col>
        <Col span={6}>
          <span>
            折旧方法：
            {/*  eslint-disable-next-line */}
            {changeDetail.depreciationMethod === 1
              ? '年限平均法'
              : changeDetail.depreciationMethod === 2
              ? '双倍余额递减法'
              : '年数总和法'}
          </span>
        </Col>
        <Col span={6}>
          <span>月折旧额：{changeDetail.monthDepreciate}</span>
        </Col>
      </>
    ),
    changeContent: (
      <>
        <Col span={12}>
          <span>资产类别：{changeDetail.assetTypeName}</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '6' ? (
              // eslint-disable-next-line
              <Form.Item {...formItemLayout} label="资产类别">
                {getFieldDecorator('assetTypeId', {
                  initialValue: changeDetail.assetTypeId,
                })(
                  <Select>
                    {typeList.map((item) => {
                      return (
                        <Option
                          value={item.assetTypeId}
                          key={item.assetTypeId}
                          style={{ minHeight: 32 }}
                        >
                          {item.assetTypeName}
                        </Option>
                      );
                    })}
                  </Select>,
                )}
              </Form.Item>
            ) : (
              `资产类别：${changeDetail.assetTypeName ? changeDetail.assetTypeName : ''}`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>使用部门：{changeDetail.useDeptName ? changeDetail.useDeptName : ''}</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '7' ? (
              // eslint-disable-next-line
              <Form.Item {...formItemLayout} label="使用部门">
                {getFieldDecorator('useDeptId', {
                  initialValue: changeDetail.useDeptId,
                })(
                  <Select>
                    {useDepartmentsData.map((item) => {
                      return (
                        <Option key={item.id} value={item.id}>
                          {`${item.code} ${item.name}`}
                        </Option>
                      );
                    })}
                  </Select>,
                )}
              </Form.Item>
            ) : (
              `使用部门：${changeDetail.useDeptName ? changeDetail.useDeptName : ''}`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>使用项目：{changeDetail.useProjectName ? changeDetail.useProjectName : ''}</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '8' ? (
              // eslint-disable-next-line
              <Form.Item {...formItemLayout} label="使用项目">
                {getFieldDecorator('useProjectId', {
                  initialValue: changeDetail.useProjectId,
                })(
                  <Select>
                    {useProjectsData.map((item) => {
                      return (
                        <Option key={item.id} value={item.id}>
                          {`${item.code} ${item.name}`}
                        </Option>
                      );
                    })}
                  </Select>,
                )}
              </Form.Item>
            ) : (
              `使用项目：${changeDetail.useProjectName ? changeDetail.useProjectName : ''}`
            )}
          </span>
        </Col>
        {type === '6' && (
          <>
            {getFieldDecorator('useDeptId', {
              initialValue: changeDetail.useDeptId,
            })(<Input type="hidden" />)}
            {getFieldDecorator('useProjectId', {
              initialValue: changeDetail.useProjectId,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 7,
            })(<Input type="hidden" />)}
          </>
        )}
        {type === '7' && (
          <>
            {getFieldDecorator('assetTypeId', {
              initialValue: changeDetail.assetTypeId,
            })(<Input type="hidden" />)}
            {getFieldDecorator('useProjectId', {
              initialValue: changeDetail.useProjectId,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 8,
            })(<Input type="hidden" />)}
          </>
        )}
        {type === '8' && (
          <>
            {getFieldDecorator('assetTypeId', {
              initialValue: changeDetail.assetTypeId,
            })(<Input type="hidden" />)}
            {getFieldDecorator('useDeptId', {
              initialValue: changeDetail.useDeptId,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 9,
            })(<Input type="hidden" />)}
          </>
        )}
        <>
          {getFieldDecorator('ageLimit', {
            initialValue: changeDetail.ageLimit,
          })(<Input type="hidden" />)}
          {getFieldDecorator('assetCode', {
            initialValue: changeDetail.assetCode,
          })(<Input type="hidden" />)}
          {getFieldDecorator('depreciationMethod', {
            initialValue: changeDetail.depreciationMethod,
          })(<Input type="hidden" />)}
          {getFieldDecorator('quantity', {
            initialValue: changeDetail.quantity,
          })(<Input type="hidden" />)}
          {getFieldDecorator('remainingRatio', {
            initialValue: changeDetail.remainingRatio,
          })(<Input type="hidden" />)}
          {getFieldDecorator('totalDepreciate', {
            initialValue: changeDetail.totalDepreciate,
          })(<Input type="hidden" />)}
          {getFieldDecorator('originalValue', {
            initialValue: changeDetail.originalValue,
          })(<Input type="hidden" />)}
          {getFieldDecorator('tax', {
            initialValue: changeDetail.tax,
          })(<Input type="hidden" />)}
          {getFieldDecorator('taxTotal', {
            initialValue: changeDetail.taxTotal,
          })(<Input type="hidden" />)}
        </>
      </>
    ),
  };
};
