import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Row, Col, Input, Button, message } from 'antd';
import { util } from 'nuijs';
import getBaseContent from './getBaseContent';
import getFinaceContent from './getFinaceContent';
import getPublicContent from './getPublicContent';
import getSplitContent from './getSplitContent';
/* eslint-enable  */
/* eslint-enable  */

const ChangeContent = (props) => {
  const { type, form, hideChangeModal, changeDetail, query, dispatch } = props;
  const { getFieldDecorator, validateFields, setFieldsValue } = form;
  const BaseContent = type === '1' || type === '2' || type === '9' ? getBaseContent(props) : {};
  const FinaceContent = type === '3' || type === '4' || type === '5' ? getFinaceContent(props) : {};
  const PublicContent = type === '6' || type === '7' || type === '8' ? getPublicContent(props) : {};
  const SplitContent = type === '9' ? getSplitContent(props) : {};
  // 上传数据处理
  const filterData = (e) => {
    const values = e;
    if (values.isMonth) {
      values.ageLimit = values.isMonth === 1 ? values.ageLimit : values.ageLimit * 12;
    }
    let params = {};
    if (type === '9') {
      const newValues = {
        originalValue: util.toFixed(changeDetail.originalValue - values.originalValue, 2),
        tax: util.toFixed(changeDetail.tax - values.tax, 2) || 0,
        quantity: changeDetail.quantity - values.quantity,
        totalDepreciate:
          util.toFixed(changeDetail.totalDepreciate - values.totalDepreciate, 2) || 0,
        taxTotal: util.toFixed(changeDetail.taxTotal - values.taxTotal),
        changeRemark: values.changeRemark,
        assetCode: changeDetail.assetCode,
      };
      const splitValues = JSON.parse(JSON.stringify(values));
      delete splitValues.changeRemark;
      params = {
        assetCardChangeRequest: {
          ...values,
          ...newValues,
          changeType: 12,
          lock: true,
        },
        assetCardSplitRequest: {
          ...splitValues,
          remark: changeDetail.remark,
        },
      };
      delete params.assetCardSplitRequest.fixedAssetId;
      delete params.assetCardSplitRequest.fixedAssetSubjectName;
      // delete params.assetCardSplitRequest.remark;
    } else {
      params = {
        assetCardChangeRequest: {
          isLocked: 0,
          lock: true,
          ...values,
        },
      };
    }
    if (type === '4') {
      delete params.assetCardChangeRequest.isMonth;
    }
    // 除了拆分外其余isInit都为1
    if (type !== '9') {
      params.assetCardChangeRequest.isInit = 1;
    }
    return params;
  };
  const handleSaveEvent = () => {
    validateFields((error, values) => {
      if (error) return;
      console.log(values);
      for (let i = 0; i < Object.keys(values).length; i++) {
        const key = Object.keys(values)[i];
        const flag = values[key] === '' || values[key] === null || values[key] === undefined;
        if (key === 'quantity' && flag) {
          message.warning('请输入数量!');
          return;
        }
        if (key === 'originalValue' && flag) {
          message.warning('请输入原值！');
          return;
        }
        if (key === 'ageLimit' && flag) {
          message.warning('请输入预计使用月数！');
          return;
        }
        if (key === 'remainingRatio' && flag) {
          message.warning('请输入残值率！');
          return;
        }
        if (type === '2' && key === 'totalDepreciate' && values[key] === '') {
          message.warning('请输入累计折旧！');
          return;
        }
      }
      const params = filterData(values);
      dispatch({ type: 'change', payload: { ...params } });
    });
  };
  // 4.2.1.1 版本不上多辅助核算
  // useEffect(() => {
  //   const newData = [];
  //   // eslint-disable-next-line
  //   changeDetail.depts?.forEach((item) => {
  //     newData.push({
  //       costSubject: item.costSubject,
  //       useDeptId: item.useDeptId,
  //       shareScale: item.shareScale,
  //       useProjectId: item.useDeptId,
  //     });
  //   });
  //   console.log(newData);
  //   setFieldsValue({ depts: newData });
  // }, []);
  return (
    <Form className="change-content">
      <Row>
        <Col span={6}>
          <span>资产编码：{changeDetail.assetCode}</span>
        </Col>
        <Col span={6}>
          <span>资产名称：{changeDetail.assetName}</span>
        </Col>
        <Col span={6}>
          <span>规格型号：{changeDetail.assetModel}</span>
        </Col>
        <Col span={6}>
          <span>开始使用日期：{changeDetail.buyDate}</span>
        </Col>
        {(type === '1' || type === '2' || type === '9') && BaseContent.content}
        {(type === '3' || type === '4' || type === '5') && FinaceContent.content}
        {(type === '6' || type === '7' || type === '8') && PublicContent.content}
        <Col className="change-line" span={24} />
        {type !== '9' && (
          <>
            <Col span={12}>
              <span className="change-title">变动前</span>
            </Col>
            <Col span={12}>
              <span className="change-title">变动后</span>
            </Col>
            {(type === '1' || type === '2') && BaseContent.changeContent}
            {(type === '3' || type === '4' || type === '5') && FinaceContent.changeContent}
            {(type === '6' || type === '7' || type === '8') && PublicContent.changeContent}
            <Col span={12} offset={12}>
              <span>变动期间：{query.endDate}</span>
            </Col>
          </>
        )}
        {type === '9' && SplitContent.changeContent}
        <Col span={24}>
          <span>
            <Form.Item labelCol={{ span: 2 }} wrapperCol={{ span: 20 }} label="备注">
              {getFieldDecorator('changeRemark', {
                initialValue: changeDetail.changeRemark,
              })(<Input.TextArea placeholder="可输入备注信息" rows={2} maxLength={200} />)}
            </Form.Item>
          </span>
        </Col>
        <>
          {getFieldDecorator('addDate', {
            initialValue: changeDetail.addDate,
          })(<Input type="hidden" />)}
          {getFieldDecorator('addUser', {
            initialValue: changeDetail.addUser,
          })(<Input type="hidden" />)}
          {getFieldDecorator('assetName', {
            initialValue: changeDetail.assetName,
          })(<Input type="hidden" />)}
          {getFieldDecorator('buyDate', {
            initialValue: changeDetail.buyDate,
          })(<Input type="hidden" />)}
          {getFieldDecorator('costSubject', {
            initialValue: changeDetail.costSubject,
          })(<Input type="hidden" />)}
          {getFieldDecorator('depreciationSubject', {
            initialValue: changeDetail.depreciationSubject,
          })(<Input type="hidden" />)}
          {getFieldDecorator('fixedAssetId', {
            initialValue: changeDetail.fixedAssetId,
          })(<Input type="hidden" />)}
          {getFieldDecorator('fixedAssetSubject', {
            initialValue: changeDetail.fixedAssetSubject,
          })(<Input type="hidden" />)}
          {getFieldDecorator('isLocked', {
            initialValue: changeDetail.isLocked,
          })(<Input type="hidden" />)}
          {getFieldDecorator('taxSubject', {
            initialValue: changeDetail.taxSubject,
          })(<Input type="hidden" />)}
          {getFieldDecorator('remark', {
            initialValue: changeDetail.remark,
          })(<Input type="hidden" />)}
          {/* 多部门核算4.2.1.1版本不上 */}
          {/* {getFieldDecorator('isMultipleDept', {
            initialValue: changeDetail.isMultipleDept || 0,
          })(<Input type="hidden" />)}
          {getFieldDecorator('depts', {
            initialValue: changeDetail.depts,
          })(<Input type="hidden" />)} */}
        </>
      </Row>
      <div className="change-footer">
        <Button
          onClick={() => {
            hideChangeModal();
          }}
        >
          取消
        </Button>
        <Button type="primary" className="e-ml12" onClick={handleSaveEvent}>
          保存
        </Button>
      </div>
    </Form>
  );
};

ChangeContent.propTypes = {
  type: PropTypes.string.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  hideChangeModal: PropTypes.func.isRequired,
  changeDetail: PropTypes.objectOf(PropTypes.any).isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default Form.create()(ChangeContent);
