import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Tabs } from 'antd';
import { Layout, Head, Center, Title, Left, Content } from '@/Layout';
import Footer from './Footer';
import ContentForm from './ContentForm';
import ChangeLogs from './ChangeLogs';
import StopLogs from './StopLogs';
import Detail from './Detail';
import '../../styles/index.less';

const { TabPane } = Tabs;
class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tableKey: '1',
    };
  }

  render() {
    const { props } = this;
    const { currentDate, type, datail, pageType } = props;
    const { tableKey } = this.state;
    const { isStop, isClear } = datail;
    const getText = () => {
      switch (type) {
        case 0:
          return '新增卡片';
        case 1:
          return '查看卡片';
        case 2:
          return '编辑卡片';
        case 3:
          return '修改卡片';
        default:
          return '卡片管理';
      }
    };
    const form = {};
    const tabChange = (e) => {
      this.setState({
        tableKey: e,
      });
      const {
        datail: { assetId },
        dispatch,
      } = props;
      dispatch({ type: 'getDetailByRecordId', payload: { assetId } });
    };
    return datail.assetCode ? (
      <div>
        <Layout>
          <div styleName="card-manage">
            <Head>
              <Left />
              <Center>
                <Title text={getText()} />
              </Center>
            </Head>
            {type === 0 && (
              <Content>
                <ContentForm
                  currentDate={currentDate}
                  style={{ maxHeight: '85%', overflow: 'auto' }}
                  ref={(e) => {
                    form.contentForm = e;
                  }}
                />
              </Content>
            )}
            {type !== 0 && (
              <Content>
                <Tabs
                  activeKey={tableKey}
                  animated={false}
                  className="card-tabs"
                  onChange={tabChange}
                  tabBarExtraContent={
                    <div className="card-status">
                      <span className="status-title">资产状态</span>
                      {isStop === 0 ? (
                        <span className="status status-on">启用中</span>
                      ) : (
                        <span className="status status-off">停用中</span>
                      )}
                      {isClear === 0 ? (
                        <span className="status status-on">未清理</span>
                      ) : (
                        <span className="status status-off">已清理</span>
                      )}
                    </div>
                  }
                >
                  <TabPane tab="卡片详情" key="1" style={{ height: '100%' }}>
                    {type === 1 && (
                      <Detail style={{ maxHeight: '85%', overflow: 'auto' }} datail={datail} />
                    )}
                    {type !== 1 && (
                      <ContentForm
                        currentDate={currentDate}
                        style={{ maxHeight: '85%', overflow: 'auto' }}
                        ref={(e) => {
                          form.contentForm = e;
                        }}
                      />
                    )}
                  </TabPane>
                  <TabPane tab="变动记录" key="2">
                    {tableKey === '2' && (
                      <Content className="change-logs-body">
                        <ChangeLogs />
                      </Content>
                    )}
                  </TabPane>
                  <TabPane tab="停启用记录" key="3">
                    {tableKey === '3' && (
                      <Content>
                        <StopLogs />
                      </Content>
                    )}
                  </TabPane>
                </Tabs>
              </Content>
            )}
          </div>
        </Layout>
        {/* eslint-disable-next-line */}
        {tableKey === '1' && <Footer {...props} form={form} pageType={pageType} />}
      </div>
    ) : (
      ''
    );
  }
}

Main.defaultProps = {
  type: 100000,
};

Main.propTypes = {
  pageType: PropTypes.string.isRequired,
  type: PropTypes.number,
  currentDate: PropTypes.string.isRequired,
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ datail, type }, { account: { currentDate } }) => ({
  type,
  currentDate,
  datail,
}))(Main);
