import { BaseEffects } from 'effects';
import { message } from 'antd';
import $data from 'data';
import services from '../../services';

export default class Effcts extends BaseEffects {
  // 更新state
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  }

  // 初始化
  async init() {
    await Promise.all([this.initPeriod()]);
    this.getUseList();
    this.setState({
      componentKey: Date.now(),
    });
  }

  // 获取部门信息和员工信息
  async getAllInfo() {
    const data = await Promise.all([this.useDepartmentsData(), this.useProjectsData()]);
    const setData = {};
    if (data[0]) {
      setData.useDepartmentsData = [].concat(data[0]);
      $data('useDepartmentsData', setData.useDepartmentsData);
    }
    if (data[1]) {
      setData.useProjectsData = [].concat(data[1]);
      $data('useProjectsData', setData.useProjectsData);
    }
    this.setState(setData);
  }

  // 重置表格数据
  async reset() {
    await this.setState({
      selectedRows: [],
      selectedRowKeys: [],
    });
  }

  // 获取 资产类别
  typeList = async (fig) => {
    const res = await services.typeList();
    if (fig) {
      this.setState({
        typeList: res,
      });
    }
    return res;
  };

  // 获取 部门数据
  useDepartmentsData = async () => {
    const res = await services.getDeptList();
    return res;
  };

  // 获取 项目数据
  useProjectsData = async () => {
    const res = await services.getProjectList();
    return res;
  };

  // 查询科目列表
  getSubjectList = async () => {
    const res = await services.getSubjectList();
    return res;
  };

  // 详情初始话
  async initDetail() {
    await this.initPeriod();
  }

  // 一起获取 资产类别 部门数据 项目数据 科目数据
  async getUseList(fig) {
    // 资产类别和科目数据会发生变化需要重新获取
    const data = await Promise.all([
      this.useDepartmentsData(),
      this.useProjectsData(),
      this.typeList(),
      this.getSubjectList(),
    ]);

    const setData = {};
    if (data[0]) {
      setData.useDepartmentsData = [].concat(data[0]);
      $data('useDepartmentsData', setData.useDepartmentsData);
    }
    if (data[1]) {
      setData.useProjectsData = [].concat(data[1]);
      $data('useProjectsData', setData.useProjectsData);
    }
    if (data[2]) {
      setData.typeList = [].concat(data[2]);
      $data('typeList', setData.typeList);
    }
    if (data[3]) {
      setData.getSubjectList = [].concat(data[3]);
      $data('getSubjectList', setData.getSubjectList);
    }
    // 需要
    if (fig && this.nuomiProps.data.datail) {
      setData.datail = this.nuomiProps.data.datail;
      setData.type = this.nuomiProps.data.type;
    }
    this.setState(setData);
  }

  getDetailByRecordId = async (params) => {
    try {
      const res = await services.getLifeRecord(params);
      this.setState({
        datail: { ...res, ...params, ...{ fixedAssetId: params.assetId } },
      });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };
}
