import React, { useRef, useState } from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import { Button, Icon, Modal, message } from 'antd';
import util from 'util';
import { layer } from 'nuijs';
import Upload from '@/Upload';
import img from './upload.png';
import './index.less';
import rateLayer from '../../../public/rateLayer';
import Confirm from '../More/Confirm';

const ImportModal = (props) => {
  const { className, dispatch, isCheckOut } = props;
  const [isShowImportModal, setIsShowImportModal] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const uploadRef = useRef(null);
  const uploadProps = {
    accept: '.xlsx,.xls,.csv',
    url: 'fixedasset/importAssetCard',
    onChange: (e) => {
      const file = e.target.files[0];
      if (file) {
        if (
          !file.name.includes('.xlsx') &&
          !file.name.includes('.xls') &&
          !file.name.includes('.csv')
        ) {
          setErrorMsg(
            <>
              <Icon type="exclamation-circle" theme="filled" />
              文件格式错误，请检查后重新上传！
            </>,
          );
          setError(true);
          return false;
        }
        if (file.size > 20 * 1024 * 1024) {
          setErrorMsg(
            <>
              <Icon type="exclamation-circle" theme="filled" />
              文件过大，请将文件大小控制在20M内！
            </>,
          );
          setError(true);
          return false;
        }
        if (file.size <= 0) {
          setErrorMsg(
            <>
              <Icon type="exclamation-circle" theme="filled" />
              文件不可用，请检查后重新上传！
            </>,
          );
          setError(true);
          return false;
        }
        setUploadFile(file);
        setError(false);
        setErrorMsg('');
      }
      return true;
    },
    onEnd: (res) => {
      if (res.status === '200') {
        rateLayer(
          {
            url: 'fixedasset/importResult',
            type: 'post',
            values: {
              success: 'success',
              progressing: 'processing',
            },
          },
          ({ data }) => {
            if (data.status === 'success') {
              setIsShowImportModal(false);
              const text = data.size !== 0 ? `存在${data.size}重复数据。` : '';
              if (data.size && data.size <= 0) {
                message.success('导入成功!');
                dispatch({ type: 'queryCardList' });
              } else {
                Confirm({
                  title: '导入',
                  children: data.size !== 0 && data.msg.length > 0 && (
                    <>
                      <p>以下数据存在重复数据：</p>
                      {data.msg &&
                        data.msg.map((item) => {
                          return <p key={item}>{item}</p>;
                        })}
                      <p>请重新上传。</p>
                    </>
                  ),
                  errorMsg: `${data.allSize - data.failAllRow}条导入成功${
                    data.failAllRow
                  }条导入失败! ${text}`,
                  handleOk: () => {
                    dispatch({ type: 'queryCardList' });
                  },
                });
              }
            } else {
              layer.hide('rateLayer');
              let errMsg = '';
              if (data.reasonList && data.reasonList.length > 0) {
                if (data.reasonList.length === 1) {
                  errMsg = `${data.reasonList[0]}`;
                } else {
                  errMsg = ` 第${data.firstRow}行等${data.reasonList.length}行内容不符合要求，请检查后重新上传`;
                }
                Confirm({
                  title: '导入',
                  children: (
                    <>
                      {data.reasonList &&
                        data.reasonList.map((item, i) => {
                          // 超过9条特殊处理
                          if (i > 8) {
                            return <p key={item}>...</p>;
                          }
                          if (i > 9) {
                            return false;
                          }
                          if (i < 8) {
                            return <p key={item}>{item}</p>;
                          }
                          return false;
                        })}
                      <p>请重新上传。</p>
                    </>
                  ),
                  errorMsg: ` 第${data.firstRow}行等${data.failAllRow}行内容不符合要求，请检查后重新上传`,
                  handleOk: () => {
                    dispatch({ type: 'queryCardList' });
                  },
                });
              } else {
                errMsg = '文件数据处理失败，请稍后重试';
              }
              const errorMsgList = (
                <>
                  <Icon type="exclamation-circle" theme="filled" />
                  {errMsg}
                </>
              );
              setUploadFile(null);
              setErrorMsg(errorMsgList);
              setError(true);
            }
          },
        );
      } else {
        message.error(res.message);
      }
    },
  };
  const reset = () => {
    setUploadFile(null);
    setError(false);
    setErrorMsg('');
  };
  const handleShowImportModal = () => {
    setIsShowImportModal(true);
    reset();
  };
  const handleOkEvent = async () => {
    await uploadRef.current.upload();
  };
  const handleDownloadFile = () => {
    util.submit('fixedasset/downloadTemplate', {}, '_blank', 'download');
  };
  return (
    <>
      {window.inAuth(160) && (
        <Button
          disabled={isCheckOut}
          className={className}
          type="primary"
          ghost
          onClick={handleShowImportModal}
        >
          导入
        </Button>
      )}
      <Modal
        width={600}
        title="导入"
        visible={isShowImportModal}
        centered
        destroyOnClose
        maskClosable={false}
        okText="导入"
        onCancel={() => {
          setIsShowImportModal(false);
        }}
        onOk={handleOkEvent}
      >
        <div styleName="upload-area">
          {/* eslint-disable-next-line  */}
          <Upload {...uploadProps} ref={uploadRef}>
            {uploadFile ? (
              <div styleName="upload-success">
                <span styleName="upload-excel" />
                {uploadFile.name}
                <a
                  onClick={(e) => {
                    e.stopPropagation();
                    uploadRef.current.clearInput();
                    setUploadFile(null);
                  }}
                >
                  <Icon type="close" />
                </a>
              </div>
            ) : (
              <div styleName="upload-content">
                {!error && (
                  <div>
                    <img src={img} alt="点我上传" style={{ marginBottom: '8px' }} />
                    <div>
                      <Button type="primary">点我上传</Button>
                    </div>
                  </div>
                )}
                {error && (
                  <div>
                    <div styleName="upload-error">{errorMsg}</div>
                    <Button type="primary" ghost>
                      重新上传
                    </Button>
                  </div>
                )}
              </div>
            )}
          </Upload>
          <div styleName="upload-font">
            <div>
              模板于 2019-07-31 18:00 更新，请
              <span styleName="download-text" onClick={handleDownloadFile}>
                下载最新Excel模板.xls
              </span>
            </div>
            <div>文件大小请控制在20M以内；请不要对模板的格式进行修改</div>
          </div>
        </div>
      </Modal>
    </>
  );
};

ImportModal.defaultProps = {
  className: '',
};

ImportModal.propTypes = {
  className: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
  isCheckOut: PropTypes.bool.isRequired,
};

export default connect((state, { account: { isCheckOut } }) => ({ isCheckOut }))(ImportModal);
