import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import SuperTable from '@/SuperTable';
// eslint-disable-next-line
import getColumns from './getColumns';
import './index.less';

const Table = (props) => {
  const { cardList, selectedRows, selectedRowKeys, dispatch, loading } = props;
  const columns = getColumns(props);
  const rowSelection = {
    selectedRows,
    selectedRowKeys,
    columnWidth: '40px',
    onChange: (keys, rows) => {
      dispatch({
        type: 'setState',
        payload: {
          selectedRowKeys: keys,
          selectedRows: rows,
        },
      });
    },
    getCheckboxProps: (record) => {
      return {
        disabled: record.key === record.maxlength,
        style: {
          display: record.key === record.maxlength ? 'none' : 'block',
        },
      };
    },
  };
  const handleOnRow = (record) => {
    return {
      onDoubleClick: () => {
        if (record.key !== record.maxlength && window.inAuth(158)) {
          dispatch({ type: 'openDetailByRecordId', payload: record });
        }
      },
    };
  };
  return (
    <SuperTable
      className="card-table"
      id="card-table"
      idName="cardTable"
      loading={loading}
      rowSelection={rowSelection}
      columns={columns}
      scroll={{ x: '100%' }}
      dataSource={cardList}
      rowKey={(record) => record.fixedAssetId}
      pagination={false}
      bordered
      onRow={handleOnRow}
      dragCell
      minWidthCount={1130}
    />
  );
};

Table.propTypes = {
  cardList: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired,
};

export default connect(
  (
    { cardList, selectedRows, selectedRowKeys, loading, columnsData },
    { account: { isCheckOut } },
  ) => ({
    cardList,
    selectedRows,
    selectedRowKeys,
    loading,
    columnsData,
    isCheckOut,
  }),
)(Table);
