import React, { useEffect, useState } from 'react';
import { Col, Input, Select, Form } from 'antd';
import services from '../../services';

const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 14 },
};

const { Option } = Select;

export default (props) => {
  const { form, type, changeDetail } = props;
  const { getFieldDecorator } = form;
  const [monthDepreciate, setMonthDepreciate] = useState('');
  const [totalDepreciate, setTotalDepreciate] = useState('');
  const [isMonth, setIsMonth] = useState(1);
  useEffect(() => {
    setMonthDepreciate(changeDetail.monthDepreciate);
    setTotalDepreciate(changeDetail.totalDepreciate);
  }, [changeDetail]);
  const handleSelectChange = (e) => {
    const params = {
      ageLimit: changeDetail.ageLimit,
      buyDate: changeDetail.buyDate,
      depreciationMethod: e,
      initDepreciation: changeDetail.totalDepreciate,
      originalValue: changeDetail.originalValue,
      remainingRatio: changeDetail.remainingRatio,
      // isInit: changeDetail.isInit,
      isInit: 1, // 除拆分外isInit都为1
      // addDate: changeDetail.addDate,
      assetTypeId: changeDetail.assetTypeId,
    };
    services.depreciationCalculate(params).then((res) => {
      setMonthDepreciate(res.monthDepreciate);
      setTotalDepreciate(res.totalDepreciate);
    });
  };
  const numberChange = (e, integer, flag = true) => {
    let { value } = e.target;
    if (flag) {
      value = e.target.value.replace(/[^\d.]+/g, '');
      value = value.replace(/^\./g, '');
      value = value.replace(/\.{2,}/g, '.');
      value = value.split('.').length > 2 ? value.substring(-1, value.length - 1) : value;
    } else {
      value = e.target.value.replace(/[^\d]+/g, '');
    }
    const [valT, valY] = value.split('.');
    let maxZero = '';
    for (let i = 0; i < integer; i += 1) {
      maxZero += '0';
    }
    const max = 1 + maxZero - 1;
    if (valT > max) {
      e.target.value = valT.substring(0, integer);
    } else if (valY) {
      e.target.value = value.substring(0, valT.length + 3);
    } else {
      e.target.value = value;
    }
    if (e.target.id === 'remainingRatio' && Number(e.target.value) > 100) {
      e.target.value = 100;
    }
    const params = {
      ageLimit:
        //  eslint-disable-next-line
        (e.target.id === 'ageLimit'
          ? isMonth === 1
            ? e.target.value
            : e.target.value * 12
          : '') || changeDetail.ageLimit,
      buyDate: changeDetail.buyDate,
      depreciationMethod: changeDetail.depreciationMethod,
      initDepreciation: changeDetail.totalDepreciate,
      originalValue: changeDetail.originalValue,
      remainingRatio:
        (e.target.id === 'remainingRatio' && e.target.value) || changeDetail.remainingRatio,
      // isInit: e.target.id === 'ageLimit' ? 1 : changeDetail.isInit,
      isInit: 1, // 除拆分外isInit都为1
      // addDate: changeDetail.addDate,
      assetTypeId: changeDetail.assetTypeId,
    };
    if (e.target.id === 'remainingRatio' && e.target.value === '') {
      return;
    }
    if (e.target.id === 'ageLimit' && e.target.value === '') {
      return;
    }
    services.depreciationCalculate(params).then((res) => {
      setMonthDepreciate(res.monthDepreciate);
    });
  };
  const handleMonthChange = async (e) => {
    await setIsMonth(e);
    form.setFieldsValue({
      isMonth: e,
    });
    const ageLimit = form.getFieldValue('ageLimit');
    const params = {
      ageLimit: e === 1 ? ageLimit : ageLimit * 12,
      buyDate: changeDetail.buyDate,
      depreciationMethod: changeDetail.depreciationMethod,
      initDepreciation: changeDetail.totalDepreciate,
      originalValue: changeDetail.originalValue,
      remainingRatio:
        (e.target && e.target.id === 'remainingRatio' && e.target.value) ||
        changeDetail.remainingRatio,
      isInit: e.target && e.target.id === 'ageLimit' ? 1 : changeDetail.isInit,
      assetTypeId: changeDetail.assetTypeId,
      // addDate: changeDetail.addDate,
    };
    services.depreciationCalculate(params).then((res) => {
      setMonthDepreciate(res.monthDepreciate);
      setTotalDepreciate(res.totalDepreciate);
    });
  };
  return {
    content: (
      <>
        <Col span={6}>
          <span>原值：{changeDetail.originalValue}</span>
        </Col>
        <Col span={6}>
          <span>税额：{changeDetail.tax}</span>
        </Col>
        <Col span={6}>
          <span>资产净值：{changeDetail.netWorth}</span>
        </Col>
      </>
    ),
    changeContent: (
      <>
        <Col span={12}>
          <span>
            折旧方法：
            {/*  eslint-disable-next-line */}
            {changeDetail.depreciationMethod === 1
              ? '年限平均法'
              : changeDetail.depreciationMethod === 2
              ? '双倍余额递减法'
              : '年数总和法'}
          </span>
        </Col>
        <Col span={12}>
          <span>
            {type === '3' ? (
              // eslint-disable-next-line
              <Form.Item {...formItemLayout} label="折旧方法">
                {getFieldDecorator('depreciationMethod', {
                  initialValue: changeDetail.depreciationMethod,
                })(
                  <Select onChange={handleSelectChange}>
                    <Option value={1}>年限平均法</Option>
                    <Option value={2}>双倍余额递减法</Option>
                    <Option value={3}>年数总和法</Option>
                  </Select>,
                )}
              </Form.Item>
            ) : (
              `折旧方法：${
                // eslint-disable-next-line
                changeDetail.depreciationMethod === 1
                  ? '年限平均法'
                  : changeDetail.depreciationMethod === 2
                  ? '双倍余额递减法'
                  : '年数总和法'
              }`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>原值（价税合计）：{changeDetail.taxTotal}</span>
        </Col>
        <Col span={12}>
          <span>原值（价税合计）：{changeDetail.taxTotal}</span>
        </Col>
        <Col span={12}>
          <span>累计折旧：{changeDetail.totalDepreciate}</span>
        </Col>
        <Col span={12}>
          <span>累计折旧：{totalDepreciate}</span>
        </Col>
        <Col span={12}>
          <span>残值率：{changeDetail.remainingRatio}%</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '5' ? (
              // eslint-disable-next-line
              <Form.Item {...formItemLayout} label="残值率">
                {getFieldDecorator('remainingRatio', {
                  initialValue: changeDetail.remainingRatio,
                })(<Input addonAfter="%" onChange={(e) => numberChange(e, 3, false)} />)}
              </Form.Item>
            ) : (
              `残值率：${changeDetail.remainingRatio}%`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>预计使用月数：{changeDetail.ageLimit}</span>
        </Col>
        <Col span={12}>
          <span>
            {type === '4' ? (
              <>
                {getFieldDecorator('isMonth', {
                  initialValue: isMonth,
                })(<Input type="hidden" />)}
                <Form.Item labelCol={{ span: 8 }} wrapperCol={{ span: 14 }} label="预计使用月数">
                  {getFieldDecorator('ageLimit', {
                    initialValue: changeDetail.ageLimit,
                  })(
                    <Input
                      onChange={(e) => numberChange(e, 5, false)}
                      addonAfter={
                        <Select
                          style={{ width: '74px' }}
                          defaultValue={isMonth}
                          onChange={handleMonthChange}
                        >
                          <Option key="1" value={1}>
                            个月
                          </Option>
                          <Option key="2" value={2}>
                            年
                          </Option>
                        </Select>
                      }
                    />,
                  )}
                </Form.Item>
              </>
            ) : (
              `预计使用月数：${changeDetail.ageLimit}`
            )}
          </span>
        </Col>
        <Col span={12}>
          <span>月折旧额：{changeDetail.monthDepreciate}</span>
        </Col>
        <Col span={12}>
          <span>月折旧额：{monthDepreciate}</span>
        </Col>
        {type === '3' && (
          <>
            {getFieldDecorator('remainingRatio', {
              initialValue: changeDetail.remainingRatio,
            })(<Input type="hidden" />)}
            {getFieldDecorator('ageLimit', {
              initialValue: changeDetail.ageLimit,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 2,
            })(<Input type="hidden" />)}
          </>
        )}
        {type === '4' && (
          <>
            {getFieldDecorator('remainingRatio', {
              initialValue: changeDetail.remainingRatio,
            })(<Input type="hidden" />)}
            {getFieldDecorator('depreciationMethod', {
              initialValue: changeDetail.depreciationMethod,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 4,
            })(<Input type="hidden" />)}
          </>
        )}
        {type === '5' && (
          <>
            {getFieldDecorator('depreciationMethod', {
              initialValue: changeDetail.depreciationMethod,
            })(<Input type="hidden" />)}
            {getFieldDecorator('ageLimit', {
              initialValue: changeDetail.ageLimit,
            })(<Input type="hidden" />)}
            {getFieldDecorator('changeType', {
              initialValue: 5,
            })(<Input type="hidden" />)}
          </>
        )}
        <>
          {getFieldDecorator('assetCode', {
            initialValue: changeDetail.assetCode,
          })(<Input type="hidden" />)}
          {getFieldDecorator('assetTypeId', {
            initialValue: changeDetail.assetTypeId,
          })(<Input type="hidden" />)}
          {getFieldDecorator('isInit', {
            initialValue: changeDetail.isInit,
          })(<Input type="hidden" />)}
          {getFieldDecorator('quantity', {
            initialValue: changeDetail.quantity,
          })(<Input type="hidden" />)}
          {getFieldDecorator('originalValue', {
            initialValue: changeDetail.originalValue,
          })(<Input type="hidden" />)}
          {getFieldDecorator('tax', {
            initialValue: changeDetail.tax,
          })(<Input type="hidden" />)}
          {getFieldDecorator('taxTotal', {
            initialValue: changeDetail.taxTotal,
          })(<Input type="hidden" />)}
          {getFieldDecorator('totalDepreciate', {
            initialValue: changeDetail.totalDepreciate,
          })(<Input type="hidden" />)}
          {getFieldDecorator('useDeptId', {
            initialValue: changeDetail.useDeptId,
          })(<Input type="hidden" />)}
          {getFieldDecorator('useProjectId', {
            initialValue: changeDetail.useProjectId,
          })(<Input type="hidden" />)}
        </>
      </>
    ),
  };
};
