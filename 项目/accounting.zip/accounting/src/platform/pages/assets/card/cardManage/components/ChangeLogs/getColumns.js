import React from 'react';
import { superLayer } from 'layer';
import moment from 'moment';
import { util } from 'nuijs';
import TableCell from '@/TableCell';

export default (props) => {
  const {
    dispatch,
    datail: { assetId },
  } = props;
  const handleClick = (data) => {
    superLayer('/voucher/record', {
      data: {
        voucherId: data.changeVoucherId,
        isDetail: 1,
        title: '记账凭证',
        disableCrossPeriod: true,
        isBillManage: true,
      },
      onSave(res) {
        this.saveData = res;
      },
      onDestroy() {
        if (this.saveData) {
          dispatch({ type: 'getDetailByRecordId', payload: { assetId } });
        }
        this.saveData = undefined;
      },
    });
  };
  return [
    {
      title: '序号',
      dataIndex: 'index',
      align: 'center',
      width: '4%',
      render: (text) => {
        // eslint-disable-next-line
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '变动期间',
      dataIndex: 'accountPeriod',
      align: 'center',
      width: '7%',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '变动类别',
      dataIndex: 'changeType',
      align: 'center',
      width: '10%',
      render: (text) => {
        switch (text) {
          case 1:
            return <TableCell>原值变动</TableCell>;
          case 2:
            return <TableCell>折旧方法调整</TableCell>;
          case 3:
            return <TableCell>累计折旧调整</TableCell>;
          case 4:
            return <TableCell>预计使用年限调整</TableCell>;
          case 5:
            return <TableCell>残值率调整</TableCell>;
          case 6:
            return <TableCell>清理固定资产</TableCell>;
          case 7:
            return <TableCell>资产类型变动</TableCell>;
          case 8:
            return <TableCell>部门变动</TableCell>;
          case 9:
            return <TableCell>项目变动</TableCell>;
          case 10:
            return <TableCell>基本信息修改</TableCell>;
          case 11:
            return <TableCell>新增</TableCell>;
          case 12:
            return <TableCell>拆分</TableCell>;
          default:
            return '';
        }
      },
    },
    {
      title: '变动内容',
      dataIndex: 'content',
      align: 'left',
      width: '22%',
      render: (text, record) => {
        switch (record.changeType) {
          case 1:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>原值变动前：{util.toFixed(item.originalValue, 2)}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>原值变动后：{util.toFixed(item.originalValue, 2)}</TableCell>
                </div>
              );
            });
          case 2:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>
                      折旧方法变动前：
                      {/* eslint-disable-next-line */}
                      {item.depreciationMethod === 1
                        ? '平均年限法'
                        : item.depreciationMethod === 2
                        ? '双倍余额递减法'
                        : '年数总和法'}
                    </TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>
                    折旧方法变动后：
                    {/* eslint-disable-next-line */}
                    {item.depreciationMethod === 1
                      ? '平均年限法'
                      : item.depreciationMethod === 2
                      ? '双倍余额递减法'
                      : '年数总和法'}
                  </TableCell>
                </div>
              );
            });
          case 3:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>累计折旧变动前：{util.toFixed(item.totalDepreciate, 2)}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>累计折旧变动后：{util.toFixed(item.totalDepreciate, 2)}</TableCell>
                </div>
              );
            });
          case 4:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>预计使用年限变动前：{item.ageLimit}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>预计使用年限变动后：{item.ageLimit}</TableCell>
                </div>
              );
            });
          case 5:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>残值率变动前：{item.remainingRatio}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>残值率变动后：{item.remainingRatio}</TableCell>
                </div>
              );
            });
          case 6:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>清理原值（价税合计）前：{util.toFixed(item.taxTotal, 2)}</TableCell>
                    <TableCell>
                      清理期初累计折旧前：{util.toFixed(item.totalDepreciate, 2)}
                    </TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>清理原值（价税合计）后：{util.toFixed(item.taxTotal, 2)}</TableCell>
                  <TableCell>清理期初累计折旧后：{util.toFixed(item.totalDepreciate, 2)}</TableCell>
                </div>
              );
            });
          case 7:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>资产类型变动前：{item.assetTypeName}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>资产类型变动后：{item.assetTypeName}</TableCell>
                </div>
              );
            });
          case 8:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>部门变动前：{item.deptName}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>部门变动后：{item.deptName}</TableCell>
                </div>
              );
            });
          case 9:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>项目变动前：{item.projectName}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>项目变动后：{item.projectName}</TableCell>
                </div>
              );
            });
          case 10:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>修改前资产名称：{item.assetName}</TableCell>
                    <TableCell>修改前规格型号：{item.assetModel}</TableCell>
                    <TableCell>修改前数量：{item.quantity}</TableCell>
                    <TableCell>修改前计量单位：{item.unit}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>修改后资产名称：{item.assetName}</TableCell>
                  <TableCell>修改后规格型号：{item.assetModel}</TableCell>
                  <TableCell>修改后数量：{item.quantity}</TableCell>
                  <TableCell>修改后计量单位：{item.unit}</TableCell>
                </div>
              );
            });
          case 11:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>新增原值（价税合计）：{util.toFixed(item.taxTotal, 2)}</TableCell>
                    <TableCell>新增累计折旧：{util.toFixed(item.totalDepreciate, 2)}</TableCell>
                  </div>
                );
              }
              return '';
            });
          case 12:
            return record.assetChangeRecordLineBOList.map((item, index) => {
              const key = index;
              if (item.type === 0) {
                return (
                  <div key={key}>
                    <TableCell>拆分前数量：{item.quantity}</TableCell>
                    <TableCell>拆分前原值：{util.toFixed(item.originalValue, 2)}</TableCell>
                    <TableCell>拆分前累计折旧：{util.toFixed(item.totalDepreciate, 2)}</TableCell>
                  </div>
                );
              }
              return (
                <div key={key}>
                  <TableCell>拆分后数量：{item.quantity}</TableCell>
                  <TableCell>拆分后原值：{util.toFixed(item.originalValue, 2)}</TableCell>
                  <TableCell>拆分后累计折旧：{util.toFixed(item.totalDepreciate, 2)}</TableCell>
                </div>
              );
            });
          default:
            return '';
        }
      },
    },
    {
      title: '变动后月折旧额',
      dataIndex: 'desp',
      align: 'right',
      width: '12%',
      render: (text, record) => {
        let total = 0;
        record.assetChangeRecordLineBOList.forEach((item) => {
          if (item.type === 1) {
            total += Number(item.monthDepreciate || 0);
          }
        });
        return <TableCell type="number">{total}</TableCell>;
      },
    },
    {
      title: '备注',
      dataIndex: 'remark',
      align: 'center',
      width: '11%',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '凭证号',
      dataIndex: 'changeVoucherCode',
      align: 'center',
      width: '11%',
      render: (text, record) => {
        return text ? (
          <a
            onClick={() => {
              handleClick(record);
            }}
            style={{ color: '#008CFF' }}
          >
            <TableCell>{text}</TableCell>
          </a>
        ) : (
          ''
        );
      },
    },
    {
      title: '操作时间',
      dataIndex: 'createTime',
      align: 'center',
      width: '11%',
      render: (text) => {
        return <TableCell>{moment(text).format('YYYY-MM-DD')}</TableCell>;
      },
    },
    {
      title: '操作人',
      dataIndex: 'addUser',
      align: 'center',
      width: '12%',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
  ];
};
