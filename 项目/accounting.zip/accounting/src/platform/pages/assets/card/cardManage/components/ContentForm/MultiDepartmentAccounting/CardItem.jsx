import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import { Form, Select, Row, Col, Modal } from 'antd';
import NumberInput from '@/NumberInput';
import './index.less';

const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

const { Option } = Select;

const CardItem = ({
  form,
  getSubjectList,
  useProjectsData,
  useDepartmentsData,
  index,
  onDelete,
  data,
  dataSource,
  disabled,
  dispatch,
}) => {
  const { getFieldDecorator, setFieldsValue } = form;
  const handleScaleChange = (e, i) => {
    const changeData = JSON.parse(JSON.stringify(dataSource));
    const item = changeData.find(({ key }) => {
      return key === i + 1;
    });
    changeData.splice(i, 1, { ...item, scale: e });
    dispatch({ type: 'setState', payload: { dataSource: changeData } });
  };
  const handleFilter = (inputValue, optionValue) => {
    return optionValue.props.children.indexOf(inputValue) !== -1;
  };
  const handleDepartSelect = (e, i) => {
    const selectData = JSON.parse(JSON.stringify(dataSource));
    const item = selectData.find(({ key }) => {
      return key === i + 1;
    });
    if (
      selectData.some(({ department }) => {
        return department === e;
      })
    ) {
      Modal.warning({
        title: '所选部门已存在，请重试！',
        centered: true,
        width: 260,
        onOk: () => {
          setFieldsValue({
            [`department_${i}`]: undefined,
          });
          selectData.splice(i, 1, { ...item, department: undefined });
          dispatch({ type: 'setState', payload: { dataSource: selectData } });
        },
      });
    }
    selectData.splice(i, 1, { ...item, department: e });
    dispatch({ type: 'setState', payload: { dataSource: selectData } });
  };
  const handleSelectChange = (e, i, type) => {
    const selectData = JSON.parse(JSON.stringify(dataSource));
    const item = selectData.find(({ key }) => {
      return key === i + 1;
    });
    selectData.splice(i, 1, { ...item, [type]: e });
    dispatch({ type: 'setState', payload: { dataSource: selectData } });
  };
  return (
    <div styleName="wrapper-item">
      <p>部门{index + 1}</p>
      <Row>
        <Col span={8}>
          <Form.Item label="部门" {...formItemLayout}>
            {getFieldDecorator(`department_${index}`, {
              initialValue: data.department,
              rules: [
                {
                  required: true,
                  message: '请输入',
                },
              ],
            })(
              <Select
                placeholder="部门名称/编号"
                showSearch
                showArrow={false}
                notFoundContent={null}
                filterOption={handleFilter}
                onSelect={(e) => {
                  handleDepartSelect(e, index);
                }}
                disabled={disabled}
              >
                {useDepartmentsData.map((item) => {
                  return (
                    <Option key={item.id} value={item.id}>
                      {`${item.code} ${item.name}`}
                    </Option>
                  );
                })}
              </Select>,
            )}
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="费用科目" {...formItemLayout}>
            {getFieldDecorator(`costSubject_${index}`, {
              initialValue: data.costSubject,
              rules: [
                {
                  required: true,
                  message: '请选择',
                },
              ],
            })(
              <Select
                placeholder="请选择"
                onSelect={(e) => {
                  handleSelectChange(e, index, 'costSubject');
                }}
              >
                {getSubjectList.map((item) => {
                  return (
                    <Option key={item.subjectId} value={item.subjectId}>
                      {`${item.subjectCode} ${item.subjectName}`}
                    </Option>
                  );
                })}
              </Select>,
            )}
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="分摊比例" {...formItemLayout}>
            {getFieldDecorator(`scale_${index}`, {
              initialValue: data.scale,
              rules: [
                {
                  required: true,
                  message: '请输入',
                },
                {
                  validator: (rule, value, callback) => {
                    const newData = JSON.parse(JSON.stringify(dataSource));
                    const sum = newData
                      .filter(({ key }) => key !== index + 1)
                      .reduce((acc, { scale }) => acc + scale, 0);
                    console.log(sum);
                    if (sum + Number(value) > 100) {
                      callback('分摊比例超过100%，请输入正确的分摊比例');
                    }
                    callback();
                  },
                },
              ],
            })(
              <NumberInput
                suffix="%"
                precision={2}
                min={0}
                max={100}
                onChange={(e) => {
                  handleScaleChange(e, index);
                }}
              />,
            )}
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="项目" {...formItemLayout}>
            {getFieldDecorator(`project_${index}`, {
              initialValue: data.project,
            })(
              <Select
                placeholder="请选择"
                onSelect={(e) => {
                  handleSelectChange(e, index, 'project');
                }}
                disabled={disabled}
              >
                {useProjectsData.map((item) => {
                  return (
                    <Option key={item.id} value={item.id}>
                      {`${item.code} ${item.name}`}
                    </Option>
                  );
                })}
              </Select>,
            )}
          </Form.Item>
        </Col>
      </Row>
      {index > 1 && !disabled && (
        <i
          className="iconfont icon-shanchu"
          onClick={() => {
            onDelete(index);
          }}
        />
      )}
    </div>
  );
};

CardItem.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  data: PropTypes.objectOf(PropTypes.any).isRequired,
  getSubjectList: PropTypes.arrayOf(PropTypes.any).isRequired,
  useProjectsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
  index: PropTypes.number.isRequired,
  onDelete: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
  disabled: PropTypes.bool.isRequired,
};

export default connect(({ getSubjectList, useProjectsData, useDepartmentsData, dataSource }) => ({
  getSubjectList,
  useProjectsData,
  useDepartmentsData,
  dataSource,
}))(CardItem);
