import { BaseEffects } from 'effects';
import { message } from 'antd';
import $data from 'data';
import React from 'react';
import { superLayer } from 'layer';
import { store } from 'nuomi';
import services from '../services';
import cardManage from '../cardManage/index';
import Confirm from '../components/More/Confirm';

export default class Effcts extends BaseEffects {
  // 更新state
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  }

  // 初始化
  async init() {
    await this.initPeriod();
    await this.queryTreeData();
    await this.queryCardList();
    // await Promise.all([this.initPeriod(), this.queryTreeData(), this.queryCardList()]);
    this.getUseList();
    this.setState({
      componentKey: Date.now(),
    });
  }

  // 获取部门信息和员工信息
  async getAllInfo() {
    const data = await Promise.all([this.useDepartmentsData(), this.useProjectsData()]);
    const setData = {};
    if (data[0]) {
      setData.useDepartmentsData = [].concat(data[0]);
      $data('useDepartmentsData', setData.useDepartmentsData);
    }
    if (data[1]) {
      setData.useProjectsData = [].concat(data[1]);
      $data('useProjectsData', setData.useProjectsData);
    }
    this.setState(setData);
  }

  // 获取表头所有数据和显示的表头数据
  async queryTreeData() {
    const data = await services.queryTreeData();
    const treeData = [];
    const keys = [];
    const columnsData = [];
    data.forEach((val, key) => {
      const index = keys.indexOf(val.contents);
      if (index === -1) {
        treeData.push({
          name: val.contents,
          columnName: val.contents,
          key: keys.length,
          children: [{ ...val, key }],
        });
        keys.push(val.contents);
      } else {
        treeData[index].children.push({ ...val, key });
      }
      if (val.isShow === 1) {
        columnsData.push({ ...val, key });
      }
    });
    this.setState({
      treeData,
      columnsData,
    });
  }

  // 重置表格数据
  async reset() {
    await this.setState({
      selectedRows: [],
      selectedRowKeys: [],
    });
  }

  // 获取卡片列表
  queryCardList = async (datas) => {
    const {
      account: { accountId },
    } = store.getState();
    const initData =
      JSON.parse(window.localStorage.getItem(`assets_card_search_info_${accountId}`)) || {};
    if (initData.isStop) {
      if (initData.isStop.length > 1) {
        initData.isStop = '';
      } else {
        const data = initData.isStop[0];
        initData.isStop = data;
      }
    }
    if (initData.isClear) {
      if (initData.isClear.length > 1) {
        initData.isClear = '';
      } else {
        const data = initData.isClear[0];
        initData.isClear = data;
      }
    }
    await this.reset();
    const newDatas = { ...initData, ...datas };
    if (newDatas && newDatas.searchKey) {
      newDatas.searchKey = this.Trim(newDatas.searchKey);
    }
    newDatas.sortField = 'assetCode';
    const { params } = this.getState();
    this.setState({
      loading: true,
      // 重置数据
      selectedRows: [],
      selectedRowKeys: [],
    });
    try {
      const res = await services.queryCardList({ ...params, ...newDatas });
      const data = [];
      res.fixedAssetListBOs.forEach((trem, index) => {
        data.push({ ...trem, key: index });
      });
      if (data.length) {
        data.push({ ...res.assetTotal, key: res.fixedAssetListBOs.length });
      }
      const maxlength = data.length;
      data.map((item, index) => {
        const trem = item;
        trem.totalDepreciate = Number(trem.totalDepreciate) + Number(trem.thisMonthDepreciate);
        trem.maxlength = maxlength;
        trem.key = index + 1;
        return trem;
      });
      this.setState({
        cardList: data,
        params,
      });
    } finally {
      this.setState({
        loading: false,
      });
    }
  };

  Trim = (str) => {
    return str.replace(/(^\s*)|(\s*$)/g, '');
  };

  // 获取 资产类别
  typeList = async (fig) => {
    const res = await services.typeList();
    if (fig) {
      this.setState({
        typeList: res,
      });
    }
    return res;
  };

  // 获取 部门数据
  useDepartmentsData = async () => {
    const res = await services.getDeptList();
    return res;
  };

  // 获取 项目数据
  useProjectsData = async () => {
    const res = await services.getProjectList();
    return res;
  };

  // 查询科目列表
  getSubjectList = async () => {
    const res = await services.getSubjectList();
    return res;
  };

  // 详情初始话
  async initDetail() {
    await this.initPeriod();
  }

  // 一起获取 资产类别 部门数据 项目数据 科目数据
  async getUseList(fig) {
    // 资产类别和科目数据会发生变化需要重新获取
    const data = await Promise.all([
      this.useDepartmentsData(),
      this.useProjectsData(),
      this.typeList(),
      this.getSubjectList(),
    ]);

    const setData = {};
    if (data[0]) {
      setData.useDepartmentsData = [].concat(data[0]);
      $data('useDepartmentsData', setData.useDepartmentsData);
    }
    if (data[1]) {
      setData.useProjectsData = [].concat(data[1]);
      $data('useProjectsData', setData.useProjectsData);
    }
    if (data[2]) {
      setData.typeList = [].concat(data[2]);
      $data('typeList', setData.typeList);
    }
    if (data[3]) {
      setData.getSubjectList = [].concat(data[3]);
      $data('getSubjectList', setData.getSubjectList);
    }
    // 需要
    if (fig && this.nuomiProps.data.datail) {
      setData.datail = this.nuomiProps.data.datail;
      setData.type = this.nuomiProps.data.type;
    }
    this.setState(setData);
  }

  // 获取详情的变动信息
  queryChangeDetail = async (parmas) => {
    const data = await services.getUpdateDetail({ assetId: parmas.record.fixedAssetId });
    this.setState({
      changeDetail: data,
    });
  };

  // 恢复
  recover = async (params) => {
    await services.recover(params);
    message.success('恢复成功');
    this.queryCardList();
  };

  // 清理
  clear = async (params) => {
    const data = await services.clear(params);
    if (data.fixedAssetDOs.length <= 0) {
      message.success(`成功清理${data.successSize}张固定资产卡片`);
      this.queryCardList();
    } else {
      // 其他制度，本期如果有折旧或变动，是可以清理的；本期之后如果有折旧或变动，就不能清理，提示这个
      // 政府制度，本期如果有折旧或变动，是不可以清理的；本期之后如果有折旧或变动，也不能清理，提示语要根据是当前期间，还是当前期间之后
      const isZhengFu = inAuth([14, 15], 'accounting');

      Confirm({
        title: '清理结果',
        children: data.fixedAssetDOs.length > 0 && (
          // eslint-disable-next-line
          <>
            <p>
              以下卡片在清理期间（{data.period}）{isZhengFu ? '或清理期间' : ''}
              后已计提折旧或已有变动，无法清理：
            </p>
            {data.fixedAssetDOs.map((item) => {
              return <p key={item.assetCode}>{item.assetCode}</p>;
            })}
            <p>请切换所选期间重试，或查看卡片变动记录。</p>
          </>
        ),
        errorMsg: `成功清理${data.successSize}张固定资产卡片，${data.failSize}张清理失败。`,
        handleOk: () => {
          this.queryCardList();
        },
      });
    }
  };

  // 变动
  change = async (params) => {
    await services.change(params);
    message.success('操作成功！');
    this.setState({
      isShowChangeModal: false,
    });
    if (params.assetCardChangeRequest.changeType === 12) {
      this.queryCardList({ sortField: 'assetCode' });
    } else {
      this.queryCardList();
    }
  };

  // 初始化自定义表格
  initAssetCardColumn = async () => {
    await services.initAssetCardColumn();
    message.success('恢复成功！');
    this.setState({
      isShowCustomColumns: false,
    });
    this.queryTreeData();
    this.queryCardList();
  };

  // 更新自定义显示列
  upDateAssetCardColumn = async (params) => {
    await services.upDateAssetCardColumn(params);
    message.success('操作成功！');
    this.setState({
      isShowCustomColumns: false,
    });
    this.queryTreeData();
    this.queryCardList();
  };

  layers = (data) => {
    const that = this;
    superLayer(cardManage, {
      data: {
        title: '新增卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'card',
        datail: data,
        disableCrossPeriod: true,
      },
      zIndex: 9,
      className: 'card-manage-layer',
      onDestroy() {
        that.queryCardList();
      },
    });
  };

  // 根据行内容打开详情
  openDetailByRecordId = async (record) => {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      this.layers({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };

  getDetailByRecordId = async (params) => {
    try {
      const res = await services.getLifeRecord(params);
      this.setState({
        datail: { ...res, ...params, ...{ fixedAssetId: params.assetId } },
      });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };
}
