import React from 'react';
import PropTypes from 'prop-types';
import { Form, Select, Button, Checkbox } from 'antd';

const { Option } = Select;

const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};
let getList = false;

const Contents = (props) => {
  const {
    setValue,
    setDisabled,
    setPopVisible,
    value,
    onSearch,
    useDepartmentsData,
    useProjectsData,
    typeList,
    dispatch,
    accountId,
  } = props;
  if (!getList) {
    getList = true;
    dispatch({ type: 'getUseList' });
  }
  const {
    form: { getFieldDecorator, validateFields, resetFields },
  } = props;
  const { localStorage } = window;
  const initData = JSON.parse(localStorage.getItem(`assets_card_search_info_${accountId}`)) || {};
  const setText = (obj, flag) => {
    let text = '';
    let params = {};
    params = {
      ...params,
      ...obj,
    };
    Object.keys(obj).forEach((key) => {
      if (key === 'isStop' && obj[key]) {
        const assetStatusText = [];
        obj[key].forEach((val) => {
          if (val === 0) {
            assetStatusText.push('启用中');
          }
          if (val === 1) {
            assetStatusText.push('已停用');
          }
        });
        text += `资产状态：${assetStatusText.join(',')}；`;
      }
      if (key === 'isClear' && obj[key]) {
        const clearUpStatusText = [];
        obj[key].forEach((val) => {
          if (val === 1) {
            clearUpStatusText.push('已清理');
          }
          if (val === 0) {
            clearUpStatusText.push('未清理');
          }
        });
        text += `清理状态：${clearUpStatusText.join(',')}；`;
      }
      if (key === 'assetTypeId' && obj[key]) {
        let assetCategoryText = '';
        typeList.forEach((data) => {
          if (data.assetTypeId === obj[key]) {
            assetCategoryText = data.assetTypeName;
          }
        });
        text += `资产类别：${assetCategoryText};`;
      }
      if (key === 'useDeptId' && obj[key]) {
        let useDepartmentsText = '';
        useDepartmentsData.forEach((data) => {
          if (data.id === obj[key]) {
            useDepartmentsText = `${data.code} ${data.name}`;
          }
        });
        text += `使用部门：${useDepartmentsText}；`;
      }
      if (key === 'useProjectId' && obj[key]) {
        let useProjectsText = '';
        useProjectsData.forEach((data) => {
          if (data.id === obj[key]) {
            useProjectsText = `${data.code} ${data.name}`;
          }
        });
        text += `使用项目：${useProjectsText}；`;
      }
    });
    setValue(text);
    if (text) {
      setDisabled(true);
      params.searchKey = '';
    } else {
      setDisabled(false);
      params.searchKey = flag ? '' : value;
    }
    onSearch(params);
  };
  const handleSubmit = () => {
    validateFields((errors, values) => {
      if (errors) return;
      setText(values);
      // 缓存用户选择得搜索条件
      const newValues = { ...values };
      delete newValues.assetTypeId;
      delete newValues.useProjectId;
      delete newValues.useDeptId;
      localStorage.setItem(`assets_card_search_info_${accountId}`, JSON.stringify(newValues));
      setPopVisible(false);
    });
  };
  const handleReset = () => {
    setValue('');
    resetFields();
    setText({}, true);
    // 缓存用户选择得搜索条件
    localStorage.setItem(`assets_card_search_info_${accountId}`, JSON.stringify({}));
  };
  return (
    <Form className="content-form">
      {/* eslint-disable-next-line */}
      <Form.Item label="资产状态" {...formItemLayout}>
        {getFieldDecorator('isStop', {
          initialValue: initData && initData.isStop,
        })(
          <Checkbox.Group>
            <Checkbox value={0}>启用中</Checkbox>
            <Checkbox value={1}>已停用</Checkbox>
          </Checkbox.Group>,
        )}
      </Form.Item>
      {/* eslint-disable-next-line */}
      <Form.Item label="清理状态" {...formItemLayout}>
        {getFieldDecorator('isClear', {
          initialValue: initData && initData.isClear,
        })(
          <Checkbox.Group>
            <Checkbox value={1}>已清理</Checkbox>
            <Checkbox value={0}>未清理</Checkbox>
          </Checkbox.Group>,
        )}
      </Form.Item>
      {/* eslint-disable-next-line */}
      <Form.Item label="资产类别" {...formItemLayout}>
        {getFieldDecorator('assetTypeId', {
          initialValue: initData && initData.assetTypeId,
        })(
          <Select>
            {typeList.map((item) => {
              return (
                <Option key={item.assetTypeId} value={item.assetTypeId} style={{ minHeight: 32 }}>
                  {item.assetTypeName}
                </Option>
              );
            })}
          </Select>,
        )}
      </Form.Item>
      {/* eslint-disable-next-line */}
      <Form.Item label="使用部门" {...formItemLayout}>
        {getFieldDecorator('useDeptId', {
          initialValue: initData && initData.useDeptId,
        })(
          <Select>
            {useDepartmentsData.map((item) => {
              return (
                <Option key={item.id} value={item.id}>
                  {`${item.code} ${item.name}`}
                </Option>
              );
            })}
          </Select>,
        )}
      </Form.Item>
      {/* eslint-disable-next-line */}
      <Form.Item label="使用项目" {...formItemLayout}>
        {getFieldDecorator('useProjectId', {
          initialValue: initData && initData.useProjectId,
        })(
          <Select>
            {useProjectsData.map((item) => {
              return (
                <Option key={item.id} value={item.id}>
                  {`${item.code} ${item.name}`}
                </Option>
              );
            })}
          </Select>,
        )}
      </Form.Item>
      <Form.Item style={{ textAlign: 'center', marginBottom: '0px' }}>
        <Button type="primary" ghost onClick={handleReset}>
          重置
        </Button>
        <Button type="primary" className="e-ml10" onClick={handleSubmit}>
          确定
        </Button>
      </Form.Item>
    </Form>
  );
};

Contents.propTypes = {
  setValue: PropTypes.func.isRequired,
  setDisabled: PropTypes.func.isRequired,
  setPopVisible: PropTypes.func.isRequired,
  value: PropTypes.string.isRequired,
  onSearch: PropTypes.func.isRequired,
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  useProjectsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  typeList: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  accountId: PropTypes.string.isRequired,
};

export default Form.create()(Contents);
