import React from 'react';
import TableCell from '@/TableCell';
import { SearchSelect } from '@/selects';

export default (props) => {
  const { getSubjectList, onChange, onText } = props;
  return [
    {
      title: '项目',
      dataIndex: 'assetTypeName',
      width: 98,
      align: 'center',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '费用科目',
      dataIndex: 'costSubject',
      width: 178,
      align: 'center',
      render: (text) => {
        return <TableCell>{onText(text)}</TableCell>;
      },
      editable: true,
      editRender: (data, record) => {
        return (
          <SearchSelect
            showSearch
            isRightValue
            onChange={(val) => {
              const obj = { ...record, ...{ costSubject: val } };
              onChange(obj);
            }}
            defaultOpen
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
    {
      title: '折旧科目',
      dataIndex: 'depreciationSubject',
      width: 178,
      align: 'center',
      render: (text) => {
        return <TableCell>{onText(text)}</TableCell>;
      },
      editable: true,
      editRender: (data, record) => {
        return (
          <SearchSelect
            showSearch
            defaultText="children"
            isRightValue
            onChange={(val) => {
              const obj = { ...record, ...{ depreciationSubject: val } };
              onChange(obj);
            }}
            defaultOpen
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
    {
      title: '固定资产科目',
      dataIndex: 'fixedAssetSubject',
      width: 178,
      align: 'center',
      render: (text) => {
        return <TableCell>{onText(text)}</TableCell>;
      },
      editable: true,
      editRender: (data, record) => {
        return (
          <SearchSelect
            showSearch
            isRightValue
            defaultText="children"
            onChange={(val) => {
              const obj = { ...record, ...{ fixedAssetSubject: val } };
              onChange(obj);
            }}
            defaultOpen
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
    {
      title: '税额科目',
      dataIndex: 'taxSubject',
      width: 178,
      align: 'center',
      render: (text) => {
        return <TableCell>{onText(text)}</TableCell>;
      },
      editable: true,
      editRender: (data, record) => {
        return (
          <SearchSelect
            showSearch
            defaultText="children"
            isRightValue
            onChange={(val) => {
              const obj = { ...record, ...{ taxSubject: val } };
              onChange(obj);
            }}
            defaultOpen
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
  ];
};
