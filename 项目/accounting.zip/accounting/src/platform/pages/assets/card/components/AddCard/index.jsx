import React from 'react';
import PropTypes from 'prop-types';
import { Button, message } from 'antd';
import { connect } from 'nuomi';
import { superLayer } from 'layer';
import cardManage from '../../cardManage';
import services from '../../services';

const { inAuth } = window;

const AddCard = (props) => {
  const { dispatch, isCheckOut } = props;
  const handleAddEvent = async () => {
    try {
      const res = await services.getAddParams();
      superLayer(cardManage, {
        data: {
          title: '新增卡片',
          type: 0, // 0 为新增 1 为详情 2为编辑 3为修改
          pageType: 'card',
          datail: res,
          disableCrossPeriod: true,
        },
        className: 'card-manage-layer',
        onDestroy() {
          dispatch({ type: 'queryCardList' });
        },
      });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };
  return (
    <>
      {inAuth(160) && (
        <Button disabled={isCheckOut} type="primary" onClick={handleAddEvent}>
          新增
        </Button>
      )}
    </>
  );
};

AddCard.propTypes = {
  isCheckOut: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect((state, { account: { isCheckOut } }) => ({ isCheckOut }))(AddCard);
