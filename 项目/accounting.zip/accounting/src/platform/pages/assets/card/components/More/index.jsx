import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Dropdown, Menu, Icon, Button, message } from 'antd';
import { getGuideType } from 'utils';
import ExportButton from '@/buttons/ExportButton';
import CustomColumns from '@/CustomizeColumns';
import ClearupModal from './ClearupModal';
import StopModal from './StopModal';
import services from '../../services';
import ImportModal from '../ImportModal';

const { inAuth } = window;
const More = (props) => {
  const {
    selectedRows,
    dispatch,
    isShowClearUpModal,
    isShowStopModal,
    isCheckOut,
    treeData,
    columnsData,
  } = props;
  const [visible, setVisible] = useState(false);
  const handleClearEvent = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要清理的卡片');
      return;
    }
    const data = [];
    selectedRows.forEach((item) => {
      if (item.isClear === 0) {
        data.push(item);
      }
    });

    if (data.length <= 0) {
      message.warning('所选卡片均已清理');
      return;
    }
    // 暂时不需要定义为敏感操作
    // backupCheck({}, () => {
    //   dispatch({ type: 'setState', payload: { isShowClearUpModal: true } });
    // });
    dispatch({ type: 'setState', payload: { isShowClearUpModal: true } });
  };
  const handleStopEvent = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要停用的卡片');
      return;
    }
    const list = [];
    selectedRows.forEach((item) => {
      if (item.isStop === 0) {
        list.push(item);
        return item;
      }
      return true;
    });
    if (list.length === 0) {
      message.warning('所选卡片均已停用');
      return;
    }
    dispatch({ type: 'setState', payload: { isShowStopModal: true } });
  };

  // 修改卡片启用状态
  const setCard = async (data, type, cbk) => {
    const datas = {
      ...data,
      fixedAssetId: [],
    };
    selectedRows.forEach((item) => {
      if (item.isStop === (type === '停用' ? 0 : 1)) {
        datas.fixedAssetId.push(item.fixedAssetId);
      }
    });
    try {
      const res = await services.disableOrEnableCard(datas);
      const { failSize, successSize } = res;
      message.success(`${type}成功${successSize}条,${type}失败${failSize}条。`);
      dispatch({ type: 'queryCardList' });
      if (cbk) {
        cbk();
      }
    } catch (e) {
      message.error(e.message || `${type}失败`);
    }
  };

  const handleStartEvent = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要启用的卡片');
      return;
    }
    if (
      selectedRows.every((item) => {
        return item.isStop === 0;
      })
    ) {
      message.warning('所选卡片均已启用');
      return;
    }
    setCard({ type: '0' }, '启用');
  };
  const handleInitColumns = () => {
    dispatch({ type: 'initAssetCardColumn' });
  };
  const handleUpdateColumns = (params) => {
    dispatch({ type: 'upDateAssetCardColumn', payload: { defineColumnBOs: params } });
  };
  const menu = (
    <Menu
      onClick={() => {
        setVisible(false);
      }}
    >
      {inAuth(159) && (
        <Menu.Item
          style={
            getGuideType() && sessionStorage.getItem('guideoption') === '11'
              ? {
                  background: '#008cff',
                }
              : {}
          }
        >
          <Button
            disabled={isCheckOut}
            onClick={handleClearEvent}
            style={
              getGuideType() && sessionStorage.getItem('guideoption') === '11'
                ? {
                    color: '#ffffff',
                  }
                : {}
            }
          >
            清理
          </Button>
        </Menu.Item>
      )}
      {inAuth(159) && (
        <Menu.Item>
          <Button disabled={isCheckOut} onClick={handleStopEvent}>
            停用
          </Button>
        </Menu.Item>
      )}
      {inAuth(159) && (
        <Menu.Item>
          <Button disabled={isCheckOut} onClick={handleStartEvent}>
            启用
          </Button>
        </Menu.Item>
      )}
      {inAuth(158) && (
        <Menu.Item>
          <CustomColumns
            treeData={treeData}
            columnsData={columnsData}
            initColumns={handleInitColumns}
            updateColumns={handleUpdateColumns}
            fixedField="资产编码"
          />
        </Menu.Item>
      )}
      {inAuth(160) && (
        <Menu.Item>
          <ImportModal />
        </Menu.Item>
      )}
      {inAuth(162) && (
        <Menu.Item>
          <ExportButton url="fixedasset/export" />
        </Menu.Item>
      )}
    </Menu>
  );
  return (
    <>
      <Dropdown
        overlayClassName="card-more"
        visible={visible}
        className="e-ml12"
        overlay={menu}
        trigger={['click']}
        onVisibleChange={(e) => {
          if (getGuideType() && sessionStorage.getItem('guideoption') === '11') {
            setVisible(true);
            return;
          }
          setVisible(e);
        }}
      >
        <Button type="primary" ghost style={{ width: 80 }} className="ui-bor-blue newGuide11">
          更多 <Icon type="down" />
        </Button>
      </Dropdown>
      {isShowClearUpModal && <ClearupModal />}
      {isShowStopModal && <StopModal setCard={setCard} />}
    </>
  );
};

More.propTypes = {
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  treeData: PropTypes.arrayOf(PropTypes.any).isRequired,
  columnsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  isShowClearUpModal: PropTypes.bool.isRequired,
  isShowStopModal: PropTypes.bool.isRequired,
  isCheckOut: PropTypes.bool.isRequired,
};
export default connect(
  (
    { selectedRows, isShowClearUpModal, isShowStopModal, treeData, columnsData },
    { account: { isCheckOut } },
  ) => ({
    selectedRows,
    isShowClearUpModal,
    isShowStopModal,
    treeData,
    columnsData,
    isCheckOut,
  }),
)(More);
