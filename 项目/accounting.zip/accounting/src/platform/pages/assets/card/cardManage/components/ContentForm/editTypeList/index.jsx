import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, message } from 'antd';
import { connect } from 'nuomi';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';
import services from '../../../../services';

class EditType extends Component {
  constructor(props) {
    super(props);
    const subjectListObj = {};
    props.getSubjectList.forEach((val) => {
      subjectListObj[val.subjectId] = val;
    });

    let datails = { ...props.datail };
    if (!datails.assetTypeId) {
      datails = { ...datails, ...props.typeList[0] };
    }

    this.state = {
      typeList: props.typeList, // 数据列表
      subjectListObj, // 科目对象列表
      datails, // 当前选择的类型
    };
  }

  // 修改数据列表
  onChange = (data) => {
    const { typeList, datails } = this.state;
    const setData = {
      typeList: [],
    };
    setData.typeList = typeList.map((item) => {
      if (item.assetTypeId === data.assetTypeId) {
        if (datails.assetTypeId === data.assetTypeId) {
          setData.datails = { ...datails, ...data };
        }
        return { ...item, ...data };
      }
      return item;
    });
    this.setState(setData);
  };

  // 获取科目名称
  onText = (id) => {
    const { subjectListObj } = this.state;
    const data = subjectListObj[id] || {};
    return `${data.subjectCode || ''} ${data.subjectName || ''}`;
  };

  render() {
    const { getSubjectList, datail, visible, setVisible, dispatch, form } = this.props;
    const { typeList, datails } = this.state;
    const columns = getColumns({
      onChange: this.onChange,
      getSubjectList,
      onText: this.onText,
    });
    return (
      <Modal
        title="默认入账科目设置"
        centered
        maskClosable={false}
        width={868}
        visible={visible}
        onOk={async () => {
          // 更新数据
          try {
            const params = JSON.parse(JSON.stringify(typeList));
            params.map((item) => {
              const trem = item;
              delete trem.assetTypeName;
              delete trem.clearSubject;
              delete trem.ageLimit;
              return trem;
            });
            await services.changeAssetTypeSubject(params);
            if (datail !== datails) {
              form.setFieldsValue({
                costSubject: getSubjectList.some((item) => {
                  return item.subjectId === datails.costSubject;
                })
                  ? datails.costSubject
                  : '',
                fixedAssetSubject: getSubjectList.some((item) => {
                  return item.subjectId === datails.fixedAssetSubject;
                })
                  ? datails.fixedAssetSubject
                  : '',
                taxSubject: getSubjectList.some((item) => {
                  return item.subjectId === datails.taxSubject;
                })
                  ? datails.taxSubject
                  : '',
                depreciationSubject: getSubjectList.some((item) => {
                  return item.subjectId === datails.depreciationSubject;
                })
                  ? datails.depreciationSubject
                  : '',
              });
            }
            dispatch({
              type: 'updateState',
              payload: {
                typeList,
              },
            });
            setVisible(false);
            message.success('默认入账科目设置成功');
          } catch (e) {
            message.error(e.message || `默认入账科目设置失败`);
          }
        }}
        onCancel={() => {
          // 关闭弹层
          setVisible(false);
        }}
      >
        <div style={{ height: '300px' }}>
          <SuperTable
            idName="assetTypeId"
            columns={columns}
            rowSelection={null}
            rowKey={(record) => record.assetTypeId}
            pagination={false}
            dataSource={typeList}
            bordered
          />
        </div>
      </Modal>
    );
  }
}

EditType.propTypes = {
  getSubjectList: PropTypes.arrayOf(PropTypes.any).isRequired,
  typeList: PropTypes.arrayOf(PropTypes.any).isRequired,
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
  visible: PropTypes.bool.isRequired,
  setVisible: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ typeList, getSubjectList, datail }) => ({
  typeList,
  getSubjectList,
  datail,
}))(EditType);
