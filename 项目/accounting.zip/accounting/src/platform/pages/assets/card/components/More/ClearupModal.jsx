import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Input } from 'antd';
import './index.less';
import { util } from 'nuijs';

const ClearupModal = (props) => {
  const { isShowClearUpModal, dispatch, selectedRows, query } = props;
  const { endDate } = query;
  const [remark, setRemark] = useState('');
  let totalOriginalValue = 0;
  let totalDetpreciate = 0;
  let lengths = 0;
  const assetIds = [];
  selectedRows.forEach((item) => {
    if (item.isClear === 0) {
      lengths += 1;
      const originalValue = Number(String(item.originalValue).replace(/,/g, ''));
      const detpreciateValue = Number(String(item.totalDepreciate).replace(/,/g, ''));
      totalOriginalValue += originalValue;
      totalDetpreciate += detpreciateValue;
      assetIds.push(item.fixedAssetId);
    }
  });
  const handleCancel = () => {
    dispatch({
      type: 'setState',
      payload: {
        isShowClearUpModal: false,
      },
    });
  };
  const handleOk = () => {
    dispatch({
      type: 'clear',
      payload: {
        assetIds,
        remark,
      },
    });
    handleCancel();
  };
  const handleChange = (e) => {
    setRemark(e.target.value.length > 200 ? e.target.value.splice(0, 200) : e.target.value);
  };
  return (
    <Modal
      title="温馨提示"
      visible={isShowClearUpModal}
      onCancel={handleCancel}
      onOk={handleOk}
      centered
      maskClosable={false}
      width={440}
      wrapClassName="clearup-modal"
    >
      <div className="tips">清理当期依然需要计提折旧，请先折旧再进行清理</div>
      <div className="content">
        <div className="title">你确定要清理所选的{lengths}张固定资产卡片？</div>
        <div className="main">
          <span>清理期间：{endDate}</span>
          <span>清理原值共计：{util.toFixed(totalOriginalValue, 2)}</span>
          <span>清理累计折旧共计：{util.toFixed(totalDetpreciate, 2)}</span>
        </div>
        <Input.TextArea
          placeholder="请输入清理原因(200字以内)"
          rows={4}
          value={remark}
          onChange={handleChange}
          maxLength={200}
        />
        <div className="clearup-footer">清理完成后可在卡片变动记录中查看</div>
      </div>
    </Modal>
  );
};

ClearupModal.propTypes = {
  isShowClearUpModal: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ isShowClearUpModal, selectedRows, query }) => ({
  isShowClearUpModal,
  selectedRows,
  query,
}))(ClearupModal);
