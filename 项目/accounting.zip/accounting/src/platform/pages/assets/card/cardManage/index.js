import React from 'react';
import Main from './components';
import Effetcs from './effects';

export default {
  render() {
    // eslint-disable-next-line
    return <Main {...this.data} />;
  },
  state: {
    // 固定资产类别集合
    typeList: [],
    // 使用部门数据
    useDepartmentsData: [],
    // 使用项目数据
    useProjectsData: [],
    // 使用科目
    getSubjectList: [],
    // 详情
    datail: {},
    // 多部门设置数据
    dataSource: [
      { key: 1, department: undefined, project: undefined, costSubject: undefined, scale: 100 },
      { key: 2, department: undefined, project: undefined, costSubject: undefined, scale: 0 },
    ],
  },
  effects() {
    return new Effetcs(this);
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  onInit() {
    this.store.dispatch({ type: 'getUseList', payload: true });
    this.store.dispatch({ type: 'initDetail' });
  },
};
