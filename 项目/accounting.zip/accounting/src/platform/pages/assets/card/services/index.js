import { util } from 'nuijs';

export default util.createRequest({
  // 固定资产卡片列表
  queryCardList: 'fixedasset/card/getList',
  // 固定资产卡片表头列表
  queryTreeData: 'fixedasset/difineColumn/getAllAssetCardColumn:post',
  // 获取固定资产类别集合
  typeList: 'fixedasset/type/getList',
  // 查询账套的部门数据
  getDeptList: 'fixedasset/card/getDeptList',
  // 查询账套的项目数据
  getProjectList: 'fixedasset/card/getProjectList',
  // 查询科目列表
  getSubjectList: 'fixedasset/card/getSubjectList',
  // 新增卡片钱 准备接口
  getAddParams: 'fixedasset/card/getAddParams',
  // 新增卡片
  addAssetCard: 'fixedasset/card/addAssetCard:postJSON',
  // 查询固定资产详情及其变动、禁用、启用记录
  getLifeRecord: 'fixedasset/card/getLifeRecord:post',
  // 跳转修改、编辑、变动页面所需的数据
  getUpdateDetail: 'fixedasset/card/getUpdateDetail:post',
  // 固定资产更新或者编辑接口
  editorUpdate: 'fixedasset/editor/update:postJSON',
  // 删除卡片
  cardDelete: 'fixedasset/card/delete:postJSON',
  // 计算当前的固定资产
  depreciationCalculate: 'fixedasset/card/depreciationCalculate:post',
  // 最新的计算公式
  newDepreciationCalculate: 'fixedasset/card/addOrEditCalculate:post',
  // 启用和停用
  disableOrEnableCard: 'fixedasset/fixedAssetAbleRecord/disableOrEnableCard:postJSON',
  // 修改固定资产类型默认科目
  changeAssetTypeSubject: 'fixedasset/type/changeAssetTypeSubject:postJSON',
  // queryColumnsData: 'fixedasset/difineColumn/getAssetCardColumn:post',
  // 查询导入成功后的结果
  queryImportResult: 'fixedasset/importResult:post',
  // 恢复
  recover: 'fixedasset/fixedAssetPeriod/delete:post',
  // 清理
  clear: 'fixedasset/fixedAssetPeriod/clear:postJSON',
  // 变动
  change: 'fixedasset/fixedAssetChangeRecord/change:postJSON',
  // 初始话自定义表格
  initAssetCardColumn: 'fixedasset/difineColumn/initAssetCardColumn:post',
  // 更改自定义显示列
  upDateAssetCardColumn: 'fixedasset/difineColumn/upDateAssetCardColumn:postJSON',
});
