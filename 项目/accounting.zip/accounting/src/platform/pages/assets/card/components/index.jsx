import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Left, Center, Title, Right, Head, Content, Layout } from '@/Layout';
import More from './More';
import Table from './Tables';
// import ImportModal from './ImportModal';
import SearchMore from './SearchMore';
import ChangeModal from './ChangeModal';
import AddCard from './AddCard';
import DeleteCard from './DeleteCard';
import '../styles/index.less';

// 卡片管理 模块
const Main = (props) => {
  const { dispatch, componentKey } = props;
  return (
    <Layout className="card-content">
      <div className="new-card">
        <Head>
          <Left>
            <SearchMore
              key={componentKey}
              onSearch={(params) => {
                const newParams = { ...params };
                if (newParams.isStop) {
                  if (newParams.isStop.length > 1) {
                    newParams.isStop = '';
                  } else {
                    const data = newParams.isStop[0];
                    newParams.isStop = data;
                  }
                }
                if (newParams.isClear) {
                  if (newParams.isClear.length > 1) {
                    newParams.isClear = '';
                  } else {
                    const data = newParams.isClear[0];
                    newParams.isClear = data;
                  }
                }
                dispatch({ type: 'queryCardList', payload: { ...newParams } });
              }}
            />
          </Left>
          <Center>
            <Title />
          </Center>
          <Right>
            <AddCard />
            {/* <ImportModal className="e-ml12" /> */}
            <DeleteCard />
            {(window.inAuth(159) || window.inAuth(158) || window.inAuth(160)) && <More />}
          </Right>
        </Head>
        <Content id="card">
          <Table />
        </Content>
      </div>
      <ChangeModal />
    </Layout>
  );
};

Main.defaultProps = {
  componentKey: undefined,
};

Main.propTypes = {
  componentKey: PropTypes.number,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ componentKey }) => ({
  componentKey,
}))(Main);
