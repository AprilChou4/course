import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Input } from 'antd';
import './index.less';

const ClearupModal = (props) => {
  const { isShowStopModal, dispatch, selectedRows, setCard, query } = props;
  const [remark, setRemark] = useState('');
  const handleCancel = () => {
    dispatch({
      type: 'setState',
      payload: {
        isShowStopModal: false,
      },
    });
  };
  const handleOk = () => {
    setCard({ remark, type: '1' }, '停用', () => {
      handleCancel();
    });
  };
  const handleChange = (e) => {
    setRemark(e.target.value.length > 200 ? e.target.value.splice(0, 200) : e.target.value);
  };
  return (
    <Modal
      title="温馨提示"
      visible={isShowStopModal}
      onCancel={handleCancel}
      onOk={handleOk}
      centered
      maskClosable={false}
      width={440}
      wrapClassName="clearup-modal"
    >
      <div className="content" style={{ marginTop: 0 }}>
        <div className="clearup-tips">停用当期依然需要计提折旧，请先折旧再进行停用</div>
        <div className="title">你确定要停用所选的{selectedRows.length}张固定资产卡片？</div>
        <div className="main">
          <span>停用期间：{query.endDate}</span>
        </div>
        <Input.TextArea
          placeholder="请输入停用原因(200字以内)"
          rows={4}
          value={remark}
          onChange={handleChange}
          maxLength={200}
        />
        <div className="main-footer">启用当期不需要计提折旧，次月开始计提折旧</div>
      </div>
    </Modal>
  );
};

ClearupModal.propTypes = {
  isShowStopModal: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  setCard: PropTypes.func.isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ isShowStopModal, selectedRows, query }) => ({
  isShowStopModal,
  selectedRows,
  query,
}))(ClearupModal);
