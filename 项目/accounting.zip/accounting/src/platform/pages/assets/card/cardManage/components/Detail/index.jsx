import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { PageHeader, Row, Col, Checkbox } from 'antd';
import { util } from 'nuijs';
import TableCell from '@/TableCell';
import Item from './item';
import './index.less';

const Detail = (props) => {
  const { datail } = props;
  const depreciationMethod = {
    '1': '年限平均法',
    '2': '双倍余额递减法',
    '3': '年数总和法',
  };
  return (
    <div styleName="card-detail">
      <PageHeader title="基本信息" />
      <Row>
        <Col span={8}>
          <TableCell>资产编码：{datail.assetCode}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>资产名称：{datail.assetName}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>规格型号：{datail.assetModel}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>资产类别：{datail.assetTypeName}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>数量：{datail.quantity}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>计量单位：{datail.unit}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>入账期间：{datail.addDate}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>开始使用日期：{datail.buyDate}</TableCell>
        </Col>
        {datail.useDeptName && (
          <Col span={8}>
            <TableCell>使用部门：{datail.useDeptName}</TableCell>
          </Col>
        )}
        {datail.useProjectName && (
          <Col span={8}>
            <TableCell>使用项目：{datail.useProjectName}</TableCell>
          </Col>
        )}
        {/* 4.2.1.1版本多部门核算不上 */}
        {/* {!!datail.isMultipleDept && (
          <Col span={8}>
            <Checkbox disabled checked>
              多部门核算
            </Checkbox>
          </Col>
        )} */}
      </Row>
      {/* {!!datail.isMultipleDept &&
        datail.depts.map((item, i) => {
          const key = i;
          const data = {
            costSubject: item.costSubjectName,
            department: `${item.useDeptCode} ${item.useDeptName}`,
            project: `${item.useProjectCode || ''} ${item.useProjectName || ''}`,
            scale: item.shareScale,
          };
          return <Item index={i} data={data} key={key} />;
        })}  */}
      <PageHeader title="财务信息" />
      <Row>
        <Col span={8}>
          <TableCell>原值：{util.toFixed(datail.originalValue, 2)}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>税额：{util.toFixed(datail.tax, 2)}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>原值（价税合计）：{util.toFixed(datail.taxTotal, 2)}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>折旧方法：{depreciationMethod[datail.depreciationMethod]}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>预计使用月数：{datail.ageLimit}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>残值率：{datail.remainingRatio}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>期初累计折旧：{util.toFixed(datail.totalDepreciate, 2)}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>资产净值：{util.toFixed(datail.netWorth, 2)}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>
            月折旧额：{util.toFixed(datail.monthDepreciate, 2)}
            <Checkbox disabled checked={!!datail.isLocked} style={{ marginLeft: '104px' }}>
              折旧锁定
            </Checkbox>
          </TableCell>
        </Col>
      </Row>
      <Row>
        <Col span={8}>
          <TableCell>备注：{datail.remark}</TableCell>
        </Col>
      </Row>
      <PageHeader title="入账科目" />
      <Row>
        <Col span={8}>
          <TableCell>费用科目：{datail.costSubjectName}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>
            <TableCell>固定资产科目：{datail.fixedAssetSubjectName}</TableCell>
          </TableCell>
        </Col>
        <Col span={8}>
          <TableCell>税额科目：{datail.taxSubjectName}</TableCell>
        </Col>
        <Col span={8}>
          <TableCell>折旧科目：{datail.depreciationSubjectName}</TableCell>
        </Col>
      </Row>
    </div>
  );
};

Detail.propTypes = {
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ datail }) => ({ datail }))(Detail);
