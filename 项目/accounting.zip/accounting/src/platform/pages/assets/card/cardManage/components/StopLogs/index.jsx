import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';

const StopLogs = (props) => {
  const columns = getColumns(props);
  const { datail } = props;
  const { fixedAssetAbles } = datail;
  return (
    <SuperTable
      columns={columns}
      dataSource={fixedAssetAbles.map((item, index) => {
        const trem = item;
        trem.index = index + 1;
        return trem;
      })}
      rowKey={(record, index) => record.id || index}
      pagination={false}
      bordered
    />
  );
};

StopLogs.propTypes = {
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ datail }) => ({ datail }))(StopLogs);
