import React from 'react';
import TableCell from '@/TableCell';
import { SearchSelect } from '@/selects';

export default (props) => {
  const { getSubjectList, onChange } = props;
  return [
    {
      title: '项目',
      dataIndex: 'assetTypeName',
      width: 98,
      align: 'center',
      render: (text) => {
        return <TableCell>{text || '未选择类别'}</TableCell>;
      },
    },
    {
      title: '费用科目',
      dataIndex: 'costSubject',
      width: 178,
      align: 'center',
      // render: (text) => {
      //   return <TableCell>{onText(text)}</TableCell>;
      // },
      // editable: true,
      render: (data, record) => {
        return (
          <SearchSelect
            // isBigData
            filter="children"
            defaultText={
              getSubjectList.some((item) => {
                return item.subjectId === data;
              })
                ? data
                : ''
            }
            onChange={(val) => {
              const obj = { ...record, ...{ costSubject: val } };
              onChange(obj);
            }}
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
    {
      title: '折旧科目',
      dataIndex: 'depreciationSubject',
      width: 178,
      align: 'center',
      // render: (text) => {
      //   return <TableCell>{onText(text)}</TableCell>;
      // },
      // editable: true,
      render: (data, record) => {
        return (
          <SearchSelect
            // isBigData
            defaultText={
              getSubjectList.some((item) => {
                return item.subjectId === data;
              })
                ? data
                : ''
            }
            filter="children"
            onChange={(val) => {
              const obj = { ...record, ...{ depreciationSubject: val } };
              onChange(obj);
            }}
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
    {
      title: '固定资产科目',
      dataIndex: 'fixedAssetSubject',
      width: 178,
      align: 'center',
      // render: (text) => {
      //   return <TableCell>{onText(text)}</TableCell>;
      // },
      // editable: true,
      render: (data, record) => {
        return (
          <SearchSelect
            // isBigData
            filter="children"
            defaultText={
              getSubjectList.some((item) => {
                return item.subjectId === data;
              })
                ? data
                : ''
            }
            onChange={(val) => {
              const obj = { ...record, ...{ fixedAssetSubject: val } };
              onChange(obj);
            }}
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
    {
      title: '税额科目',
      dataIndex: 'taxSubject',
      width: 178,
      align: 'center',
      // render: (text) => {
      //   return <TableCell>{onText(text)}</TableCell>;
      // },
      // editable: true,
      render: (data, record) => {
        return (
          <SearchSelect
            // isBigData
            defaultText={
              getSubjectList.some((item) => {
                return item.subjectId === data;
              })
                ? data
                : ''
            }
            filter="children"
            onChange={(val) => {
              const obj = { ...record, ...{ taxSubject: val } };
              onChange(obj);
            }}
            style={{ width: '100%' }}
            type="subject"
            dataSource={getSubjectList}
          />
        );
      },
    },
  ];
};
