import React, { useState, useRef, useEffect } from 'react';
import { Input, Popover } from 'antd';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import Form from './Form';
import './index.less';

const SearchMore = (props) => {
  const { onSearch, typeList, useDepartmentsData, useProjectsData, accountId } = props;
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState('');
  const [isDisabled, setIsDisabled] = useState(false);
  const form = useRef(null);
  const { localStorage } = window;
  const setText = (obj) => {
    let text = '';
    Object.keys(obj || {}).forEach((key) => {
      if (key === 'isStop' && obj[key]) {
        const assetStatusText = [];
        obj[key].forEach((val) => {
          if (val === 0) {
            assetStatusText.push('启用中');
          }
          if (val === 1) {
            assetStatusText.push('已停用');
          }
        });
        text += `资产状态：${assetStatusText.join(',')}；`;
      }
      if (key === 'isClear' && obj[key]) {
        const clearUpStatusText = [];
        obj[key].forEach((val) => {
          if (val === 1) {
            clearUpStatusText.push('已清理');
          }
          if (val === 0) {
            clearUpStatusText.push('未清理');
          }
        });
        text += `清理状态：${clearUpStatusText.join(',')}；`;
      }
      if (key === 'assetTypeId' && obj[key]) {
        let assetCategoryText = '';
        typeList.forEach((data) => {
          if (data.assetTypeId === obj[key]) {
            assetCategoryText = data.assetTypeName;
          }
        });
        text += `资产类别：${assetCategoryText};`;
      }
      if (key === 'useDeptId' && obj[key]) {
        let useDepartmentsText = '';
        useDepartmentsData.forEach((data) => {
          if (data.id === obj[key]) {
            useDepartmentsText = `${data.code} ${data.name}`;
          }
        });
        text += `使用部门：${useDepartmentsText}；`;
      }
      if (key === 'useProjectId' && obj[key]) {
        let useProjectsText = '';
        useProjectsData.forEach((data) => {
          if (data.id === obj[key]) {
            useProjectsText = `${data.code} ${data.name}`;
          }
        });
        text += `使用项目：${useProjectsText}；`;
      }
    });
    setValue(text);
    if (
      localStorage.getItem(`assets_card_search_info_${accountId}`) !== '{}' &&
      localStorage.getItem(`assets_card_search_info_${accountId}`) !== null
    ) {
      setIsDisabled(true);
    }
  };
  useEffect(() => {
    setText(JSON.parse(localStorage.getItem(`assets_card_search_info_${accountId}`)) || {});
  }, [localStorage.getItem(`assets_card_search_info_${accountId}`)]);

  // const onSearch = (params) => {
  //   dispatch({ type: 'queryCardList', payload: { ...params } });
  // };
  const handleVisibleChange = (e) => {
    if (!e) {
      setVisible(e);
    }
  };
  const showPopover = () => {
    setVisible(true);
  };
  const handleOnSearch = (e) => {
    let params = {};
    const initData = JSON.parse(localStorage.getItem(`assets_card_search_info_${accountId}`)) || {};
    params.searchKey = e;
    if (form.current) {
      form.current.validateFields((errors, values) => {
        if (errors) return;
        params.searchKey = Object.keys(values).some((item) => {
          return !!values[item];
        })
          ? ''
          : params.searchKey;
        params = {
          ...params,
          ...values,
        };
      });
    }
    if (
      localStorage.getItem(`assets_card_search_info_${accountId}`) !== '{}' &&
      localStorage.getItem(`assets_card_search_info_${accountId}`) !== null
    ) {
      params.searchKey = '';
      params = { ...params, ...initData };
    }
    onSearch(params);
  };
  return (
    <span className="card-search">
      <Popover
        placement="bottomLeft"
        trigger="click"
        visible={visible}
        content={
          <Form
            // eslint-disable-next-line
            {...props}
            setPopVisible={setVisible}
            setValue={setValue}
            setDisabled={setIsDisabled}
            ref={form}
            value={value}
          />
        }
        onVisibleChange={handleVisibleChange}
        overlayClassName="search-popover"
      >
        <Input.Search
          onChange={(e) => {
            if (!e.target.value) {
              setIsDisabled(false);
              form.current && form.current.resetFields();
              localStorage.setItem(`assets_card_search_info_${accountId}`, JSON.stringify({}));
              onSearch({ searchKey: '' });
            }
            setValue(e.target.value);
          }}
          className="search-more"
          prefix={<i onClick={showPopover}>更多条件</i>}
          enterButton
          allowClear
          placeholder="请输入资产名称或编码"
          value={value}
          readOnly={isDisabled}
          onSearch={handleOnSearch}
          title={value}
        />
      </Popover>
    </span>
  );
};

SearchMore.defaultProps = {
  useDepartmentsData: [],
  useProjectsData: [],
  typeList: [],
  accountId: '',
};

SearchMore.propTypes = {
  onSearch: PropTypes.func.isRequired, // 搜索的回调函数
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any), // 使用部门的数据
  useProjectsData: PropTypes.arrayOf(PropTypes.any), // 使用项目的数据
  typeList: PropTypes.arrayOf(PropTypes.any), // 使用项目的数据
  accountId: PropTypes.string,
};

export default connect(
  ({ useDepartmentsData, useProjectsData, typeList }, { account: { accountId } }) => ({
    useDepartmentsData,
    useProjectsData,
    typeList,
    accountId,
  }),
)(SearchMore);
// export default SearchMore;
