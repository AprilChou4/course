import React, { useState } from 'react';
import PropTypes from 'prop-types';

const Confirm = (props) => {
  const [show, setShow] = useState(false);
  const { children, errorMsg } = props;
  const hanldeClick = () => {
    setShow(!show);
  };
  return (
    <>
      <div className="header">
        <i
          className="iconfont icon-difengxian"
          style={{ color: '#F6A327', fontSize: '14px', marginRight: '12px' }}
        />
        {errorMsg}
      </div>
      {children ? (
        <div className="content">
          <div className="title">
            <span>详细原因</span>
            <span onClick={hanldeClick} style={{ fontSize: '13px' }}>
              {!show ? '展开' : '收起'}
              <i
                className={`iconfont icon-${show ? 'up2' : 'down2'}`}
                style={{ fontSize: '13px' }}
              />
            </span>
          </div>
          {show && <div className="main">{children}</div>}
        </div>
      ) : (
        ''
      )}
    </>
  );
};

Confirm.defaultProps = {
  children: null,
};

Confirm.propTypes = {
  // eslint-disable-next-line
  children: PropTypes.any,
  errorMsg: PropTypes.string.isRequired,
};

export default Confirm;
