import React from 'react';
import moment from 'moment';
import TableCell from '@/TableCell';

export default () => {
  return [
    {
      title: '序号',
      dataIndex: 'index',
      align: 'center',
      width: '4%',
      render: (text) => {
        // eslint-disable-next-line
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '停用日期',
      dataIndex: 'accountPeriod',
      align: 'center',
      width: '11%',
      render: (text, record) => {
        if (record.isStop) {
          return <TableCell>{text}</TableCell>;
        }
        return '';
      },
    },
    {
      title: '启用日期',
      dataIndex: 'accountPeriod1',
      align: 'center',
      width: '11%',
      render: (text, record) => {
        if (!record.isStop) {
          return <TableCell>{record.accountPeriod}</TableCell>;
        }
        return '';
      },
    },
    {
      title: '累计停用月数',
      dataIndex: 'disabledMonth',
      align: 'center',
      width: '11%',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '停启用原因',
      dataIndex: 'remark',
      align: 'left',
      width: '40%',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '操作时间',
      dataIndex: 'createTime',
      align: 'center',
      width: '11%',
      render: (text) => {
        return <TableCell>{moment(text).format('YYYY-MM-DD')}</TableCell>;
      },
    },
    {
      title: '操作人',
      dataIndex: 'operator',
      align: 'center',
      width: '12%',
      render: (text) => {
        return <TableCell>{text}</TableCell>;
      },
    },
  ];
};
