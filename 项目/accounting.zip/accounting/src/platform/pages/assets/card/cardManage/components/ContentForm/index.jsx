import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { PageHeader, Row, Col, Input, Select, Checkbox, DatePicker, message, Form } from 'antd';
import { connect } from 'nuomi';
import moment from 'moment';
import { util } from 'nuijs';
import { ConfirmModal } from '@/modal';
import services from '../../../services';
import EditType from './editTypeList';
import initPeriod from '../../../../../../../public/initPeriod';
import './index.less';
import MultiDepartmentAccounting from './MultiDepartmentAccounting/index';

class ContentForm extends Component {
  constructor(props) {
    super(props);
    const { datail } = props;
    this.totalDepreciateFig = true;
    this.state = {
      visible: false,
      taxTotal: datail.taxTotal,
      netWorth: {
        monthDepreciation: '0.00',
        netWorth: '0.00',
      },
      isChecked: false,
      isInit: 0,
      isMultipleDept: datail.isMultipleDept === 1 || false,
      showMultiDepartmentAccounting: false,
      isDisableTotalDepreciate: false,
    };

    this.isGovernment = inAuth([14, 15], 'accounting');
  }

  componentDidMount() {
    const { datail, dispatch } = this.props;
    if (datail.monthDepreciate) {
      this.setNetWorth({
        monthDepreciation: datail.monthDepreciate,
        netWorth: datail.netWorth,
      });
    }

    if (datail.isInit) {
      this.setState({
        isInit: datail.isInit,
      });
    }
    if (datail.isMultipleDept) {
      const data = [];
      datail.depts.forEach((item, i) => {
        data.push({
          key: i + 1,
          costSubject: item.costSubject,
          project: item.useProjectId,
          scale: item.shareScale,
          department: item.useDeptId,
        });
      });
      dispatch({ type: 'setState', payload: { dataSource: data } });
      this.setState({
        showMultiDepartmentAccounting: true,
      });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const { datail } = nextProps;
    const { dispatch } = this.props;
    const { isReset } = datail;
    if (isReset) {
      this.setState(
        {
          taxTotal: '0.00',
          netWorth: {
            monthDepreciation: '0.00',
            netWorth: '0.00',
          },
          isChecked: false,
        },
        () => {
          const params = { ...datail };
          params.isReset = false;
          dispatch({ type: 'setState', payload: { datail: { ...params } } });
        },
      );
    }
  }

  typeListObj = (data) => {
    const { typeList } = this.props;
    let datas = typeList[0];
    if (data.assetTypeId) {
      typeList.forEach((val) => {
        if (val.assetTypeId === data.assetTypeId) {
          datas = val;
        }
      });
    }
    return datas;
  };

  setVisible = (fig) => {
    this.setState({
      visible: fig,
    });
  };

  setTaxTotal = (data) => {
    this.setState({
      taxTotal: data,
    });
  };

  setNetWorth = (data) => {
    this.setState({
      netWorth: data,
    });
  };

  // 计算固定资产
  servicesdepre = async (data) => {
    const newData = { ...data };
    const { form } = this.props;
    const { totalDepreciateFig } = this;
    const isMonth = form.getFieldValue('isMonth');
    if (isMonth === 2) {
      newData.ageLimit *= 12;
    } else {
      newData.ageLimit = data.ageLimit;
    }

    try {
      const res = await services.newDepreciationCalculate(newData);
      this.setNetWorth({
        monthDepreciation: res.monthDepreciate,
        netWorth: res.netWorth,
      });

      if (totalDepreciateFig) {
        form.setFieldsValue({
          totalDepreciate: res.initDepreciation,
        });
      }
    } catch (e) {
      message.error(e.message || `计算固定资产失败`);
    }
  };

  depreciationCalculate = (e, id) => {
    const { form } = this.props;
    const { totalDepreciateFig } = this;
    // 当累计折旧有输入的时候，更改type为1
    if (id === 'totalDepreciate') {
      this.numberChange(e, 9);
      this.setState({
        isInit: 1,
      });
    }
    if (id === 'totalDepreciate' && totalDepreciateFig) {
      this.totalDepreciateFig = false;
    }
    let values = '';
    let fig = true;
    if (
      id === 'buyDate' ||
      id === 'addDate' ||
      id === 'depreciationMethod' ||
      id === 'assetTypeId'
    ) {
      values = e;
    } else {
      values = e.target.value;
      if (id === 'remainingRatio') {
        e.target.value = e.target.value.replace(/[^\d]+/g, '');
        if (e.target.value > 100) {
          e.target.value = 100;
        }
        values = e.target.value;
      }
    }
    const formData = form.getFieldsValue([
      'buyDate',
      'originalValue',
      'ageLimit',
      'depreciationMethod',
      'remainingRatio',
      'totalDepreciate',
      'isInit',
      'addDate',
      'assetTypeId',
    ]);
    if (id !== 'assetTypeId') {
      formData[id] = values;
    }
    formData.buyDate = formData.buyDate && moment(formData.buyDate).format('YYYYMM');
    formData.addDate = formData.addDate && moment(formData.addDate).format('YYYYMM');
    Object.keys(formData).forEach((val) => {
      const v = formData[val];
      if (!v && v !== 0 && val !== 'totalDepreciate') {
        fig = false;
      }
    });
    if (fig) {
      formData.initDepreciation = formData.totalDepreciate || 0;
      delete formData.totalDepreciate;
      this.servicesdepre(formData);
    }
  };

  numberLimt = (e) => {
    const value = e.target.value.replace(/[^\d+]+/g, '');
    e.target.value = value;
  };

  numberChange = (e, integer, flag = true) => {
    const { form } = this.props;
    let { value } = e.target;
    if (flag) {
      value = e.target.value.replace(/[^\d.]+/g, '');
      value = value.replace(/^\./g, '');
      value = value.replace(/\.{2,}/g, '.');
      value = value.split('.').length > 2 ? value.substring(-1, value.length - 1) : value;
    } else {
      value = e.target.value.replace(/[^\d]+/g, '');
    }
    const [valT, valY] = value.split('.');
    let maxZero = '';
    for (let i = 0; i < integer; i += 1) {
      maxZero += '0';
    }
    const max = 1 + maxZero - 1;
    if (valT > max) {
      e.target.value = valT.substring(0, integer);
    } else if (valY) {
      e.target.value = value.substring(0, valT.length + 3);
    } else {
      e.target.value = value;
    }
    if (e.target.id === 'originalValue' || e.target.id === 'tax') {
      const originalValue = Number(
        (e.target.id === 'originalValue' ? e.target.value : form.getFieldValue('originalValue')) ||
          0,
      );
      const tax = Number((e.target.id === 'tax' ? e.target.value : form.getFieldValue('tax')) || 0);
      this.setTaxTotal(util.toFixed(originalValue + tax, 2));
      form.setFieldsValue({
        taxTotal: util.toFixed(originalValue + tax, 2),
      });
    }
    if (e.target.id === 'quantity' && e.target.value === '0') {
      e.target.value = '';
    }
    if (e.target.id === 'originalValue') {
      const calcValue =
        e.target.value - (e.target.value * form.getFieldValue('remainingRatio')) / 100;
      if (form.getFieldValue('totalDepreciate') > calcValue) {
        form.setFields({
          totalDepreciate: {
            value: form.getFieldValue('totalDepreciate'),
            errors: [
              {
                message: '期初累计折旧不能大于原值-残值',
              },
            ],
          },
        });
      } else {
        form.setFields({
          totalDepreciate: {
            value: form.getFieldValue('totalDepreciate'),
          },
        });
      }
    }
    if (e.target.id === 'originalValue' || e.target.id === 'ageLimit') {
      this.depreciationCalculate(e, e.target.id);
    }
  };

  assetTypeChange = (data) => {
    const { form, getSubjectList } = this.props;
    const datas = this.typeListObj({ assetTypeId: data });

    if (this.isGovernment) {
      if (['文物和陈列品', '图书、档案', '动植物'].includes(datas.assetTypeName)) {
        this.setState({ isDisableTotalDepreciate: true });
        form.setFieldsValue({ totalDepreciate: '0' });
      } else {
        this.setState({ isDisableTotalDepreciate: false });
      }
    }

    form.setFieldsValue(
      {
        ageLimit: (datas.ageLimit || 0) * 12 || 1,
        fixedAssetSubject: getSubjectList.some((item) => {
          return item.subjectId === datas.fixedAssetSubject;
        })
          ? datas.fixedAssetSubject
          : '',
        costSubject: getSubjectList.some((item) => {
          return item.subjectId === datas.costSubject;
        })
          ? datas.costSubject
          : '',
        taxSubject: getSubjectList.some((item) => {
          return item.subjectId === datas.taxSubject;
        })
          ? datas.taxSubject
          : '',
        depreciationSubject: getSubjectList.some((item) => {
          return item.subjectId === datas.depreciationSubject;
        })
          ? datas.depreciationSubject
          : '',
      },
      () => {
        this.depreciationCalculate('', 'assetTypeId');
      },
    );
  };

  render() {
    const {
      visible,
      taxTotal,
      netWorth,
      isInit,
      isChecked,
      isMultipleDept,
      showMultiDepartmentAccounting,
    } = this.state;
    const {
      form,
      currentDate,
      typeList,
      useDepartmentsData,
      useProjectsData,
      getSubjectList,
      datail = {},
      style,
      query,
      type,
      period,
      dispatch,
    } = this.props;
    const { getFieldDecorator } = form;
    const { Option } = Select;
    const { MonthPicker } = DatePicker;
    const formItemLayout = {
      labelCol: { span: 7 },
      wrapperCol: { span: 16 },
    };
    const FormItem = Form.Item;
    // 入账科目信息
    const typeListData = this.typeListObj(datail) || {};
    const handleCheckChange = (e) => {
      const { setFieldsValue } = form;
      setFieldsValue({
        isLocked: e.target.checked ? 1 : 0,
      });
      this.setState({
        isChecked: e.target.checked,
      });
    };
    const handleBlur = () => {
      const assetCode = form.getFieldValue('assetCode');
      if (assetCode.length < 6) {
        const code = [0, 0, 0, 0, 0, 0];
        form.setFieldsValue({
          assetCode: code.splice(0, 6 - assetCode.length).join('') + assetCode,
        });
      }
    };
    const handleOriginValue = (e) => {
      let { value } = e.target;
      value = value.replace(/^0{2,}/g, '0');
      form.setFieldsValue({
        originalValue: value,
      });
    };
    const handleSelectChange = (e) => {
      form.setFieldsValue({
        isMonth: e,
      });
      const value = form.getFieldValue('ageLimit');
      const params = {
        target: {
          value,
        },
      };
      this.depreciationCalculate(params, 'ageLimit');
    };
    const disabledDate =
      moment(currentDate).add(1, 'years').format('YYYY-MM') > period[period.length - 1]
        ? moment(currentDate).add(1, 'years').format('YYYY-MM')
        : period[period.length - 1];
    const checkPriod = (e, lastValue) => {
      if (!period.includes(e) && e > period[0]) {
        ConfirmModal({
          title: '所选期间尚未开账，是否确认开账',
          centered: true,
          width: 360,
          onOk: () => {
            initPeriod(undefined, e, (layerInst) => {
              layerInst.hide();
              const newParams = [...period];
              newParams.push(e);
              dispatch({ type: 'account/updateState', payload: { period: newParams } });
            });
          },
          onCancel: () => {
            form.setFieldsValue({ addDate: lastValue });
          },
        });
      }
    };
    const handleTimeChange = (e) => {
      if (!e) {
        return;
      }
      const value = moment(e).format('YYYY-MM');
      const lastValue = form.getFieldValue('addDate');
      checkPriod(value, lastValue);
      const buyDate = moment(form.getFieldValue('buyDate')).format('YYYY-MM');
      if (value < buyDate) {
        form.setFieldsValue({ buyDate: e });
      }
      this.depreciationCalculate(e, 'addDate');
    };
    const handleDepartmentAccounting = (e) => {
      this.setState({
        showMultiDepartmentAccounting: !showMultiDepartmentAccounting,
      });
      form.setFieldsValue({ isMultipleDept: e.target.checked });
      if (e.target.checked) {
        this.setState({
          isMultipleDept: true,
        });
      } else {
        this.setState({
          isMultipleDept: false,
        });
      }
    };

    return (
      <Form styleName="content-form" style={style} id="card-management-form">
        <PageHeader title="基本信息" />
        <Row>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="资产编码" {...formItemLayout}>
              {getFieldDecorator('assetCode', {
                initialValue: datail.assetCode,
                rules: [
                  {
                    required: true,
                    message: '请输入资产编码',
                  },
                ],
              })(
                <Input
                  placeholder="请输入"
                  disabled={datail.bottonState === 0}
                  onChange={(e) => {
                    this.numberLimt(e);
                  }}
                  maxLength={6}
                  onBlur={handleBlur}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="资产名称" {...formItemLayout}>
              {getFieldDecorator('assetName', {
                initialValue: datail.assetName,
                rules: [
                  {
                    required: true,
                    message: '请输入资产名称',
                  },
                  {
                    max: 100,
                    message: '长度不能大于100',
                  },
                ],
              })(
                <Input
                  onChange={(e) => {
                    if (/^\s/.test(e.target.value)) {
                      e.target.value = e.target.value.replace(/^\s/g, '');
                    }
                  }}
                  placeholder="请输入"
                  autoComplete="off"
                  maxLength={100}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="规格型号" {...formItemLayout}>
              {getFieldDecorator('assetModel', {
                initialValue: datail.assetModel,
                rules: [
                  {
                    max: 100,
                    message: '长度不能大于100',
                  },
                ],
              })(<Input placeholder="请输入" />)}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="资产类别" {...formItemLayout}>
              {getFieldDecorator('assetTypeId', {
                initialValue: datail.assetTypeId || typeList[0].assetTypeId,
                rules: [],
              })(
                <Select
                  placeholder="请选择"
                  onChange={this.assetTypeChange}
                  disabled={datail.bottonState === 0}
                >
                  {typeList.map((item) => {
                    return (
                      <Option
                        key={item.assetTypeId}
                        value={item.assetTypeId}
                        style={{ minHeight: 32 }}
                      >
                        {item.assetTypeName}
                      </Option>
                    );
                  })}
                </Select>,
                // <Select placeholder="请选择" />
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="数量" {...formItemLayout}>
              {getFieldDecorator('quantity', {
                initialValue: datail.quantity || 1,
                rules: [
                  {
                    required: true,
                    message: '请输入数量',
                  },
                ],
              })(
                <Input
                  placeholder="请输入数量"
                  onChange={(e) => {
                    this.numberChange(e, 9, false);
                  }}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="计量单位" {...formItemLayout}>
              {getFieldDecorator('unit', {
                initialValue: datail.unit,
                rules: [],
              })(<Input placeholder="请输入" maxLength={10} />)}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="入账期间" {...formItemLayout}>
              {getFieldDecorator('addDate', {
                initialValue: moment(
                  datail.addDate
                    ? moment(
                        `${String(datail.addDate).slice(0, 4)}-${String(datail.addDate).slice(
                          4,
                          8,
                        )}`,
                      )
                    : query.endDate,
                ),
                rules: [
                  {
                    required: true,
                    message: '请输入入账期间',
                  },
                ],
              })(
                <MonthPicker
                  disabledDate={(date) => {
                    const tmp = moment(date).format('YYYY-MM');
                    return tmp > disabledDate;
                  }}
                  disabled={type === 3}
                  style={{ width: '100%' }}
                  onChange={handleTimeChange}
                />,
              )}
              {/* {datail.addDate || query.endDate} */}
              <Input name="addDate" value={datail.useProjectId} type="hidden" />
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="开始使用日期" {...formItemLayout}>
              {getFieldDecorator('buyDate', {
                initialValue: datail.buyDate
                  ? moment(
                      `${String(datail.buyDate).slice(0, 4)}-${String(datail.buyDate).slice(4, 8)}`,
                    )
                  : moment(datail.currentDate),
                rules: [
                  {
                    required: true,
                    message: '请输入开始使用日期',
                  },
                ],
              })(
                <MonthPicker
                  disabled={datail.bottonState === 0}
                  style={{ width: '100%' }}
                  onChange={(e) => this.depreciationCalculate(e, 'buyDate')}
                  disabledDate={(date) => {
                    const tmp = moment(date).format('YYYY-MM');
                    return tmp > moment(form.getFieldValue('addDate')).format('YYYY-MM');
                  }}
                />,
              )}
            </FormItem>
          </Col>
          {useDepartmentsData.length > 0 && (
            <Col span={8}>
              {/* eslint-disable-next-line */}
              <FormItem label="使用部门" {...formItemLayout}>
                {getFieldDecorator('useDeptId', {
                  initialValue: datail.useDeptId,
                  rules: [],
                })(
                  <Select
                    placeholder="请选择"
                    disabled={datail.bottonState === 0 || isMultipleDept}
                  >
                    {useDepartmentsData.map((item) => {
                      return (
                        <Option key={item.id} value={item.id}>
                          {`${item.code} ${item.name}`}
                        </Option>
                      );
                    })}
                  </Select>,
                )}
              </FormItem>
            </Col>
          )}
          {useProjectsData.length > 0 && (
            <Col span={8}>
              {/* eslint-disable-next-line */}
              <FormItem label="使用项目" {...formItemLayout}>
                {getFieldDecorator('useProjectId', {
                  initialValue: datail.useProjectId,
                  rules: [],
                })(
                  <Select
                    placeholder="请选择"
                    disabled={datail.bottonState === 0 || isMultipleDept}
                  >
                    {useProjectsData.map((item) => {
                      return (
                        <Option key={item.id} value={item.id}>
                          {`${item.code} ${item.name}`}
                        </Option>
                      );
                    })}
                  </Select>,
                )}
              </FormItem>
            </Col>
          )}
          {/* 4.2.1.1 版本不上多部门核算 */}
          {/* {useDepartmentsData.length >= 2 && (
            <Col span={8}>
              <FormItem labelCol={{ span: 0 }} wrapperCol={{ offset: 7 }}>
                {getFieldDecorator('isMultipleDept', {
                  initialValue: datail.isMultipleDept === 1 || false,
                })(
                  <Checkbox
                    checked={form.getFieldValue('isMultipleDept')}
                    onChange={handleDepartmentAccounting}
                    disabled={datail.bottonState === 0}
                  >
                    多部门核算
                  </Checkbox>,
                )}
              </FormItem>
            </Col>
          )} */}
        </Row>
        {showMultiDepartmentAccounting && (
          <Row>
            <MultiDepartmentAccounting form={form} disabled={datail.bottonState === 0} />
          </Row>
        )}

        <PageHeader title="财务信息" />
        <Row>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="原值" {...formItemLayout}>
              {getFieldDecorator('originalValue', {
                initialValue: datail.originalValue,
                rules: [
                  {
                    required: true,
                    message: '请输入原值',
                  },
                  {
                    validator: (rule, val, callback) => {
                      const value = util.toFixed(val, 2);
                      if (value === '0.00' && value !== '') {
                        callback('原值不能为0');
                      }
                      callback();
                    },
                  },
                ],
              })(
                <Input
                  disabled={datail.bottonState === 0}
                  placeholder="请输入"
                  onChange={(e) => {
                    this.numberChange(e, 9);
                  }}
                  onBlur={handleOriginValue}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="税额" {...formItemLayout}>
              {getFieldDecorator('tax', {
                initialValue: datail.tax,
                rules: [],
              })(
                <Input
                  disabled={datail.bottonState === 0}
                  placeholder="请输入"
                  onChange={(e) => {
                    this.numberChange(e, 9);
                  }}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="原值（价税合计）" {...formItemLayout}>
              {getFieldDecorator('taxTotal', {
                initialValue: datail.taxTotal,
                rules: [],
              })(<Input type="hidden" placeholder="请输入" />)}
              <span style={{ paddingLeft: '10px' }}>{taxTotal || '0.00'}</span>
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="折旧方法" {...formItemLayout}>
              {getFieldDecorator('depreciationMethod', {
                initialValue: datail.depreciationMethod || 1,
                rules: [
                  {
                    required: true,
                    message: '请选择',
                  },
                ],
              })(
                <Select
                  disabled={datail.bottonState === 0}
                  placeholder="请选择"
                  onChange={(e) => this.depreciationCalculate(e, 'depreciationMethod')}
                >
                  <Option value={1}>年限平均法</Option>
                  <Option value={2}>双倍余额递减法</Option>
                  <Option value={3}>年数总和法</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {getFieldDecorator('isMonth', {})(<Input type="hidden" />)}
            {/* eslint-disable-next-line */}
            <FormItem label="预计使用月数" {...formItemLayout}>
              {getFieldDecorator('ageLimit', {
                initialValue: datail.ageLimit || (typeListData.ageLimit || 0) * 12 || 1,
                rules: [
                  {
                    required: true,
                    message: '请填写预计使用月数',
                  },
                  {
                    validator(rule, val, callback) {
                      const value = util.toFixed(val, 2);
                      if (value === '0.00' && value !== '') {
                        callback('预计使用月数不能为0');
                      }
                      callback();
                    },
                  },
                ],
              })(
                <Input
                  disabled={datail.bottonState === 0}
                  placeholder="请输入"
                  onChange={(e) => {
                    this.numberChange(e, 5, false);
                  }}
                  addonAfter={
                    <Select
                      disabled={datail.bottonState === 0}
                      style={{ width: '74px' }}
                      defaultValue={1}
                      onChange={handleSelectChange}
                    >
                      <Option value={1}>个月</Option>
                      <Option value={2}>年</Option>
                    </Select>
                  }
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="残值率" {...formItemLayout}>
              {getFieldDecorator('remainingRatio', {
                initialValue: (function a(isGovernment) {
                  if (isGovernment) return '0';
                  return datail.remainingRatio !== undefined &&
                    datail.remainingRatio !== null &&
                    datail.remainingRatio !== ''
                    ? datail.remainingRatio
                    : 5;
                })(this.isGovernment),
                rules: [
                  {
                    required: true,
                    message: '请输入',
                  },
                ],
              })(
                <Input
                  disabled={datail.bottonState === 0 || this.isGovernment}
                  suffix="%"
                  placeholder="请输入"
                  onChange={(e) => this.depreciationCalculate(e, 'remainingRatio')}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {getFieldDecorator('isInit', { initialValue: isInit })(<Input type="hidden" />)}
            {/* eslint-disable-next-line */}
            <FormItem label="期初累计折旧" {...formItemLayout}>
              {getFieldDecorator('totalDepreciate', {
                initialValue: this.state.isDisableTotalDepreciate ? '0' : datail.totalDepreciate,
                rules: [
                  {
                    required: true,
                    message: '请输入',
                  },
                  {
                    validator(rule, val, callback) {
                      const value =
                        form.getFieldValue('originalValue') -
                        (form.getFieldValue('originalValue') *
                          form.getFieldValue('remainingRatio')) /
                          100;
                      if (val > value) {
                        callback('期初累计折旧不能大于原值-残值');
                      }
                      callback();
                    },
                  },
                ],
              })(
                <Input
                  disabled={datail.bottonState === 0 || this.state.isDisableTotalDepreciate}
                  placeholder="请输入"
                  onChange={(e) => this.depreciationCalculate(e, 'totalDepreciate')}
                />,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="资产净值" {...formItemLayout}>
              {netWorth.netWorth}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="月折旧额" {...formItemLayout}>
              {getFieldDecorator('isLocked', {
                initialValue: (datail && !!datail.isLocked) || isChecked ? 1 : 0,
              })(
                <>
                  <Col span={12}> {netWorth.monthDepreciation}</Col>
                  <Col span={12}>
                    <Checkbox
                      defaultChecked={(datail && !!datail.isLocked) || isChecked}
                      onChange={handleCheckChange}
                    >
                      折旧锁定
                    </Checkbox>
                  </Col>
                </>,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem label="备注" {...formItemLayout}>
              {getFieldDecorator('remark', {
                initialValue: datail.remark || '',
              })(<Input maxLength={999} />)}
            </FormItem>
          </Col>
        </Row>
        <PageHeader title="入账科目" />
        <Row>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="费用科目" {...formItemLayout}>
              {getFieldDecorator('costSubject', {
                // eslint-disable-next-line
                initialValue: datail.costSubject
                  ? getSubjectList.some((item) => {
                      return item.subjectId === datail.costSubject;
                    })
                    ? datail.costSubject
                    : ''
                  : getSubjectList.some((item) => {
                      return item.subjectId === typeListData.costSubject;
                    })
                  ? typeListData.costSubject
                  : '',
                rules: [
                  {
                    required: true,
                    message: '请选择',
                  },
                ],
              })(
                <Select
                  placeholder="请选择"
                  showSearch
                  optionFilterProp="children"
                  disabled={isMultipleDept}
                >
                  {getSubjectList.map((item) => {
                    return (
                      <Option key={item.subjectId} value={item.subjectId}>
                        {`${item.subjectCode} ${item.subjectName}`}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="固定资产科目" {...formItemLayout}>
              {getFieldDecorator('fixedAssetSubject', {
                // eslint-disable-next-line
                initialValue: datail.fixedAssetSubject
                  ? getSubjectList.some((item) => {
                      return item.subjectId === datail.fixedAssetSubject;
                    })
                    ? datail.fixedAssetSubject
                    : ''
                  : getSubjectList.some((item) => {
                      return item.subjectId === typeListData.fixedAssetSubject;
                    })
                  ? typeListData.fixedAssetSubject
                  : '',
                rules: [
                  {
                    required: true,
                    message: '请选择',
                  },
                ],
              })(
                <Select placeholder="请选择" showSearch optionFilterProp="children">
                  {getSubjectList.map((item) => {
                    return (
                      <Option key={item.subjectId} value={item.subjectId}>
                        {`${item.subjectCode} ${item.subjectName}`}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="税额科目" {...formItemLayout}>
              {getFieldDecorator('taxSubject', {
                // eslint-disable-next-line
                initialValue: datail.taxSubject
                  ? getSubjectList.some((item) => {
                      return item.subjectId === datail.taxSubject;
                    })
                    ? datail.taxSubject
                    : ''
                  : getSubjectList.some((item) => {
                      return item.subjectId === typeListData.taxSubject;
                    })
                  ? typeListData.taxSubject
                  : '',
                rules: [
                  {
                    required: true,
                    message: '请选择',
                  },
                ],
              })(
                <Select placeholder="请选择" showSearch optionFilterProp="children">
                  {getSubjectList.map((item) => {
                    return (
                      <Option key={item.subjectId} value={item.subjectId}>
                        {`${item.subjectCode} ${item.subjectName}`}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            {/* eslint-disable-next-line */}
            <FormItem label="折旧科目" {...formItemLayout}>
              {getFieldDecorator('depreciationSubject', {
                // eslint-disable-next-line
                initialValue: datail.depreciationSubject
                  ? getSubjectList.some((item) => {
                      return item.subjectId === datail.depreciationSubject;
                    })
                    ? datail.depreciationSubject
                    : ''
                  : getSubjectList.some((item) => {
                      return item.subjectId === typeListData.depreciationSubject;
                    })
                  ? typeListData.depreciationSubject
                  : '',
                rules: [
                  {
                    required: true,
                    message: '请选择',
                  },
                ],
              })(
                <Select placeholder="请选择" showSearch optionFilterProp="children">
                  {getSubjectList.map((item) => {
                    return (
                      <Option key={item.subjectId} value={item.subjectId}>
                        {`${item.subjectCode} ${item.subjectName}`}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </FormItem>
          </Col>
          <Col span={16} style={{ textAlign: 'right', lineHeight: '36px' }}>
            <a onClick={() => this.setVisible(true)}>默认入账科目设置</a>
          </Col>
        </Row>
        {visible && <EditType visible={visible} setVisible={this.setVisible} form={form} />}
      </Form>
    );
  }
}

ContentForm.defaultProps = {
  style: null,
};
ContentForm.propTypes = {
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
  typeList: PropTypes.arrayOf(PropTypes.any).isRequired,
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  useProjectsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  getSubjectList: PropTypes.arrayOf(PropTypes.any).isRequired,
  period: PropTypes.arrayOf(PropTypes.string).isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  type: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
  currentDate: PropTypes.string.isRequired,
  style: PropTypes.objectOf(PropTypes.any),
};

export default Form.create()(
  connect(
    (
      { typeList, useDepartmentsData, useProjectsData, getSubjectList, datail, query, type },
      { account: { period } },
    ) => ({
      typeList,
      useDepartmentsData,
      useProjectsData,
      getSubjectList,
      datail,
      query,
      type,
      period,
    }),
  )(ContentForm),
);
