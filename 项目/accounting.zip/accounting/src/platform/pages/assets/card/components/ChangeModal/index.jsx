import React, { useState, useEffect } from 'react';
import { connect } from 'nuomi';
import { message, Modal, Tabs } from 'antd';
import ChangeContent from './ChangeContent';
import services from '../../services';
import './index.less';

const { TabPane } = Tabs;
const tabData = [
  '原值变动',
  '累计折旧调整',
  '折旧方法调整',
  '使用年限调整',
  '残值率调整',
  '类别变动',
  '部门变动',
  '项目变动',
  '拆分',
];
const ChangeModal = (props) => {
  const { isShowChangeModal, dispatch, changeDetail, query } = props;
  const [tabKey, setTabKey] = useState('1');
  const [codeData, setCodeData] = useState({});
  useEffect(() => {
    setTabKey('1');
  }, [isShowChangeModal]);
  const hideChangeModal = () => {
    dispatch({ type: 'setState', payload: { isShowChangeModal: false } });
  };
  return (
    isShowChangeModal && (
      <Modal
        maskClosable={false}
        centered
        footer={null}
        wrapClassName="card-change"
        visible={isShowChangeModal}
        title="资产变动"
        width={960}
        onCancel={() => {
          hideChangeModal();
        }}
      >
        <Tabs
          activeKey={tabKey}
          tabPosition="left"
          animated={false}
          onChange={(e) => {
            if (e === '9') {
              if (!changeDetail.quantity || changeDetail.quantity <= 1) {
                message.error('数量小于2不可拆分！');
                return;
              }
              services.getAddParams().then((res) => {
                setCodeData(res);
              });
            }
            setTabKey(e);
          }}
        >
          {tabData.map((item, index) => {
            const i = `${index + 1}`;
            return (
              <TabPane key={i} tab={item}>
                {tabKey === i && (
                  <ChangeContent
                    codeData={codeData}
                    // eslint-disable-next-line
                    {...props}
                    type={tabKey}
                    hideChangeModal={hideChangeModal}
                    changeDetail={changeDetail}
                    query={query}
                  />
                )}
              </TabPane>
            );
          })}
        </Tabs>
      </Modal>
    )
  );
};

export default connect(
  ({ isShowChangeModal, changeDetail, query, typeList, useDepartmentsData, useProjectsData }) => ({
    isShowChangeModal,
    changeDetail,
    query,
    typeList,
    useDepartmentsData,
    useProjectsData,
  }),
)(ChangeModal);
