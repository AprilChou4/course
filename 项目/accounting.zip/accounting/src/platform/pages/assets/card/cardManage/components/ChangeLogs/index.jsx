import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Table } from 'antd';
import getColumns from './getColumns';

const ChangeLogs = (props) => {
  const columns = getColumns(props);
  const { datail } = props;
  const { assetChangeRecordResponses } = datail;
  const [scrollY, setScrollY] = useState(null);
  let timer = null;
  const changeY = () => {
    const content = document.querySelector('.change-logs-body');
    const head = document.querySelector('.change-logs-body .ant-table-thead');
    const height = content ? content.clientHeight : null;
    const headHeight = head ? head.clientHeight : null;
    const y = height && headHeight ? height - headHeight - 20 : null;
    timer = null;
    setScrollY(y);
  };
  const onResize = () => {
    if (!timer) {
      timer = setTimeout(() => {
        changeY();
      }, 400);
    } else {
      clearTimeout(timer);
      timer = null;
    }
    changeY();
  };
  useEffect(() => {
    onResize();
    window.addEventListener('resize', onResize, false);
    return () => {
      window.removeEventListener('resize', onResize, false);
    };
  }, []);
  return (
    <Table
      className="ant-supertable"
      columns={columns}
      dataSource={assetChangeRecordResponses.map((item, index) => {
        const trem = item;
        trem.index = index + 1;
        return trem;
      })}
      rowKey={(record, index) => record.id || index}
      pagination={false}
      bordered
      scroll={{ y: scrollY }}
    />
  );
};

ChangeLogs.propTypes = {
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ datail }) => ({ datail }))(ChangeLogs);
