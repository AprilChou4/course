import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { Button, message } from 'antd';
import moment from 'moment';
import './index.less';
import services from '../../../services';

const Footer = (props) => {
  const [firstClick, setFirstClick] = useState(false);
  const { dispatch, type, form, nuomiProps, pageType, datail, dataSource } = props;
  const { self } = nuomiProps;
  const handleCancel = () => {
    self.destroy();
  };

  const addAssetCard = async (data, vType) => {
    setFirstClick(true);
    const option = { ...data };
    let name = '新增';
    let url = 'addAssetCard';
    if (datail.fixedAssetId) {
      url = 'editorUpdate';
      name = datail.bottonState === 1 ? '编辑' : '修改';
      option.fixedAssetId = datail.fixedAssetId;
      option.lock = datail.bottonState === 1;
    }
    try {
      setFirstClick(true);
      await services[url](option);
      message.success(`${name}成功`);
      if (vType) {
        // 当编辑时关闭弹窗
        if (datail.bottonState === 1 && String(option.addDate) !== String(datail.addDate)) {
          self.destroy();
        }
        vType === 2 && form.contentForm.resetFields();
        const params = { ...datail };
        if (vType === 2) {
          params.isReset = true;
        } else {
          params.isReset = false;
        }
        if (!option.fixedAssetId) {
          const formData = await services.getAddParams();
          form.contentForm.setFieldsValue({
            assetCode: formData.assetCode,
          });
          dispatch({ type: 'setState', payload: { datail: { ...params } } });
        }
      } else {
        self.destroy();
      }
    } catch (e) {
      // message.error(e.message || `${name}失败`);
    } finally {
      setFirstClick(false);
    }
  };

  const handleSave = (flag) => {
    if (firstClick) {
      return;
    }
    form.contentForm.validateFields((errors, values) => {
      console.log(values);
      if (!errors) {
        const data = { ...values };
        data.buyDate = moment(data.buyDate).format('YYYYMM');
        data.addDate = moment(data.addDate).format('YYYYMM');
        if (data.isMonth === 2) {
          data.ageLimit *= 12;
        }
        // 多部门核算4.2.1.1 版本不上=============================
        // if (data.isMultipleDept) {
        //   Object.keys(data).forEach((key) => {
        //     if (key.includes('_')) {
        //       delete data[key];
        //     }
        //   });
        //   data.depts = [];
        //   dataSource.forEach((item) => {
        //     console.log(item);
        //     data.depts.push({
        //       costSubject: item.costSubject,
        //       shareScale: item.scale,
        //       useDeptId: item.department,
        //       useProjectId: item.project,
        //     });
        //   });
        // }
        // data.isMultipleDept = data.isMultipleDept ? 1 : 0;
        delete data.isMonth;
        addAssetCard(data, flag);
      }
    });
  };
  return (
    <div className="footer">
      <div className="notes">
        <span>录入日期：{datail.currentDate || datail.addDate} </span>
        <span>录入人：{datail.creator || datail.addUser}</span>
      </div>
      {type === 0 && (
        <span>
          <Button onClick={handleCancel}>取消</Button>
          <Button
            className="e-m116"
            onClick={() => {
              handleSave(1);
            }}
          >
            保存并复制
          </Button>
          <Button
            className="e-m116"
            onClick={() => {
              handleSave(2);
            }}
          >
            保存并继续
          </Button>
          <Button
            type="primary"
            className="e-m116"
            onClick={() => {
              handleSave();
            }}
          >
            保存
          </Button>
        </span>
      )}
      {type === 1 && pageType === 'card' && (
        <span>
          {window.inAuth(159) && (
            <Button
              type="primary"
              onClick={async () => {
                try {
                  const getDatail = await services.getUpdateDetail({
                    assetId: datail.assetId,
                  });
                  dispatch({
                    type: 'updateState',
                    payload: {
                      datail: { ...datail, ...getDatail },
                      type: datail.bottonState === 1 ? 2 : 3,
                    },
                  });
                } catch (e) {
                  // message.error(e.message || '新增失败');
                }
              }}
            >
              {datail.bottonState === 1 ? '编辑' : '修改'}
            </Button>
          )}
        </span>
      )}
      {(type === 2 || type === 3) && (
        <span>
          <Button onClick={handleCancel}>取消</Button>
          <Button type="primary" onClick={handleSave}>
            保存
          </Button>
        </span>
      )}
    </div>
  );
};

Footer.propTypes = {
  dispatch: PropTypes.func.isRequired,
  type: PropTypes.number.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  pageType: PropTypes.string.isRequired,
  datail: PropTypes.objectOf(PropTypes.any).isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
  nuomiProps: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ type, datail, dataSource }) => ({ type, datail, dataSource }))(
  withNuomi(Footer),
);
