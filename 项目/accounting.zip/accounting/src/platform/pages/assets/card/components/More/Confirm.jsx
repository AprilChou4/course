import React from 'react';
import SuperModal from '@/modal/SuperModal';
import Content from './Content';
import './index.less';

const Confirm = (props) => {
  const { title, handleOk, width, onCancel } = props;
  return SuperModal({
    className: 'common-confirm',
    title,
    // eslint-disable-next-line
    content: <Content {...props} />,
    centered: true,
    okText: '知道了',
    zIndex: 99999,
    width: width || 460,
    onOk: () => {
      handleOk && handleOk();
    },
    onCancel: () => {
      onCancel && onCancel();
    },
  });
};

export default Confirm;
