import React from 'react';
import PropTypes from 'prop-types';
import { Button, message, Icon } from 'antd';
import { connect } from 'nuomi';
import services from '../../services';
import Confirm from '../More/Confirm';
import { ConfirmModal } from '@/modal';

const DeleteCard = (props) => {
  const { selectedRows, selectedRowKeys, dispatch, isCheckOut } = props;
  const handleDelete = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要删除的卡片');
      return;
    }
    ConfirmModal({
      centered: true,
      title: '你确定要删除所选的固定资产卡片？',
      icon: <Icon type="exclamation-circle" theme="filled" />,
      okText: '确定',
      cancelText: '取消',
      onOk: async () => {
        try {
          const res = await services.cardDelete({ assetIds: selectedRowKeys });
          if (res.fixedAssetDOs && res.fixedAssetDOs.length <= 0) {
            message.success(`成功删除${res.successSize}张固定资产卡片`);
            dispatch({ type: 'queryCardList', payload: { sortField: 'assetCode' } });
          } else {
            Confirm({
              title: '删除结果',
              errorMsg: `成功删除${res.successSize}张固定资产卡片，${res.failSize}张删除失败。`,
              children: res.failSize && (
                <>
                  <p>以下固定资产卡片已生成凭证，无法删除：</p>
                  {res.fixedAssetDOs.map((val) => (
                    <p key={val.assetCode}>{val.assetCode}</p>
                  ))}
                </>
              ),
              handleOk: () => {
                dispatch({ type: 'queryCardList', payload: { sortField: 'assetCode' } });
              },
            });
          }
        } catch (e) {
          message.error(e.message || `删除失败`);
        }
      },
      maskClosable: false,
    });
  };
  return (
    <>
      {window.inAuth(159) && (
        <Button
          disabled={isCheckOut}
          type="primary"
          ghost
          className="e-ml12"
          onClick={handleDelete}
        >
          删除
        </Button>
      )}
    </>
  );
};

DeleteCard.propTypes = {
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  isCheckOut: PropTypes.bool.isRequired,
};
export default connect(({ selectedRows, selectedRowKeys }, { account: { isCheckOut } }) => ({
  selectedRows,
  selectedRowKeys,
  isCheckOut,
}))(DeleteCard);
