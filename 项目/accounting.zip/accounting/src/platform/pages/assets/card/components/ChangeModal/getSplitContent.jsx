import React, { useState } from 'react';
import { Row, Col, Input, Form } from 'antd';
import { util } from 'nuijs';
import services from '../../services';

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};

export default (props) => {
  const { form, changeDetail, query, codeData } = props;
  const { getFieldDecorator, getFieldValue, setFields } = form;
  const [taxTotal, setTotalTax] = useState('');
  const [type, setType] = useState(0);
  const [monthDepreciate, setMonthDepreciate] = useState('');
  const [netWorth, setNetWorth] = useState('');
  const setTaxTotal = (data) => {
    setTotalTax(data);
    form.setFieldsValue({
      taxTotal: data,
    });
  };
  const numberChange = (e, integer, flag = true) => {
    let { value } = e.target;
    if (flag) {
      value = e.target.value.replace(/[^\d.]+/g, '');
      value = value.replace(/^\./g, '');
      value = value.replace(/\.{2,}/g, '.');
      value = value.split('.').length > 2 ? value.substring(-1, value.length - 1) : value;
    } else {
      value = e.target.value.replace(/[^\d]+/g, '');
    }
    const [valT, valY] = value.split('.');
    let maxZero = '';
    for (let i = 0; i < integer; i += 1) {
      maxZero += '0';
    }
    const max = 1 + maxZero - 1;
    if (valT > max) {
      e.target.value = valT.substring(0, integer);
    } else if (valY) {
      e.target.value = value.substring(0, valT.length + 3);
    } else {
      e.target.value = value;
    }
    if (e.target.id !== 'quantity' && !form.getFieldValue('quantity')) {
      e.target.value = '';
      return;
    }
    if (e.target.id === 'quantity' && e.target.value >= changeDetail.quantity) {
      e.target.value = changeDetail.quantity - 1;
    }
    if (e.target.id === 'quantity') {
      if (e.target.value === '0') {
        e.target.value = '';
        form.resetFields();
      } else {
        const rate = e.target.value / changeDetail.quantity;
        form.setFieldsValue({
          originalValue: util.toFixed(changeDetail.originalValue * rate, 2),
          tax: util.toFixed(changeDetail.tax * rate, 2),
          totalDepreciate: util.toFixed(changeDetail.totalDepreciate * rate, 2),
          taxTotal: util.toFixed(changeDetail.originalValue * rate + changeDetail.tax * rate, 2),
        });
        setTotalTax(util.toFixed(changeDetail.originalValue * rate + changeDetail.tax * rate, 2));
        setMonthDepreciate(util.toFixed(changeDetail.monthDepreciate * rate, 2));
        setNetWorth(util.toFixed(changeDetail.netWorth * rate, 2));
      }
    }
    if (e.target.id === 'originalValue' && e.target.value > changeDetail.originalValue) {
      e.target.value = changeDetail.originalValue;
    }
    if (e.target.id === 'tax' && e.target.value > changeDetail.tax) {
      e.target.value = changeDetail.tax;
    }
    if (e.target.id === 'totalDepreciate' && e.target.value > changeDetail.totalDepreciate) {
      e.target.value = changeDetail.totalDepreciate;
    }
    if (e.target.id === 'totalDepreciate' && e.target.value !== changeDetail.totalDepreciate) {
      setType(1);
      form.setFieldsValue({
        isInit: 1,
      });
    }
    if (e.target.id === 'originalValue' || e.target.id === 'tax') {
      const originalValue = Number(
        (e.target.id === 'originalValue' ? e.target.value : form.getFieldValue('originalValue')) ||
          0,
      );
      const tax = Number((e.target.id === 'tax' ? e.target.value : form.getFieldValue('tax')) || 0);
      setTaxTotal(util.toFixed(originalValue + tax, 2));
    }
    if (e.target.id === 'originalValue') {
      const calcValue = e.target.value - (e.target.value * changeDetail.remainingRatio) / 100;
      if (getFieldValue('totalDepreciate') > calcValue) {
        setFields({
          totalDepreciate: {
            value: getFieldValue('totalDepreciate'),
            errors: [
              {
                message: '期初累计折旧不能大于原值-残值',
              },
            ],
          },
        });
      } else {
        setFields({
          totalDepreciate: {
            value: getFieldValue('totalDepreciate'),
          },
        });
      }
    }
    if (
      e.target.id === 'originalValue' ||
      e.target.id === 'initDepreciation' ||
      e.target.id === 'totalDepreciate'
    ) {
      let targetValue = e.target.value;
      if (!targetValue) {
        targetValue = '0';
      }
      const params = {
        ageLimit: changeDetail.ageLimit,
        buyDate: changeDetail.buyDate,
        depreciationMethod: changeDetail.depreciationMethod,
        initDepreciation:
          e.target.id === 'totalDepreciate' ? targetValue : getFieldValue('totalDepreciate'),
        originalValue:
          e.target.id === 'originalValue' ? targetValue : getFieldValue('originalValue'),
        remainingRatio: changeDetail.remainingRatio,
        isInit: getFieldValue('isInit'),
        assetTypeId: changeDetail.assetTypeId,
        // addDate: changeDetail.addDate,
      };
      services.depreciationCalculate(params).then((res) => {
        setMonthDepreciate(res.monthDepreciate);
        setNetWorth(res.netWorth);
      });
    }
  };
  const numberLimt = (e) => {
    const value = e.target.value.replace(/[^\d+]+/g, '');
    e.target.value = value;
  };
  const handleBlur = () => {
    const assetCode = form.getFieldValue('assetCode');
    if (assetCode.length < 6) {
      const code = [0, 0, 0, 0, 0, 0];
      form.setFieldsValue({
        assetCode: code.splice(0, 6 - assetCode.length).join('') + assetCode,
      });
    }
  };
  return {
    changeContent: (
      <>
        <Row>
          <Col span={8}>
            <span className="change-title">拆分前</span>
          </Col>
          <Col span={8}>
            <span className="change-title">拆分出</span>
          </Col>
          <Col span={8}>
            <span className="change-title">拆分后</span>
          </Col>
        </Row>
        <Row>
          <Col span={8}>
            <span>原卡片</span>
          </Col>
          <Col span={8}>
            <span>
              <Form.Item labelCol={{ span: 6 }} wrapperCol={{ span: 14 }} label="资产编码">
                {getFieldDecorator('assetCode', {
                  initialValue: codeData.assetCode,
                })(<Input maxLength={6} onChange={(e) => numberLimt(e)} onBlur={handleBlur} />)}
              </Form.Item>
            </span>
          </Col>
          <Col span={8}>
            <span>原卡片</span>
          </Col>
        </Row>
        <Row>
          <Col span={8}>
            <span>数量：{changeDetail.quantity}</span>
          </Col>
          <Col span={8}>
            <span>
              {/* eslint-disable-next-line */}
              <Form.Item {...formItemLayout} label="数量">
                {getFieldDecorator('quantity', {
                  initialValue: undefined,
                })(<Input onChange={(e) => numberChange(e, 9, false)} />)}
              </Form.Item>
            </span>
          </Col>
          <Col span={8}>
            <span>数量：{changeDetail.quantity - (getFieldValue('quantity') || 0)}</span>
          </Col>
        </Row>
        <Row>
          <Col span={8}>
            <span>原值：{changeDetail.originalValue}</span>
          </Col>
          <Col span={8}>
            <span>
              {/*  eslint-disable-next-line */}
              <Form.Item {...formItemLayout} label="原值">
                {getFieldDecorator(
                  'originalValue',
                  {},
                )(<Input onChange={(e) => numberChange(e, 9)} />)}
              </Form.Item>
            </span>
          </Col>
          <Col span={8}>
            <span>
              原值：
              {util.toFixed(changeDetail.originalValue - (getFieldValue('originalValue') || 0), 2)}
            </span>
          </Col>
        </Row>
        <Row>
          <Col span={8}>
            <span>税额：{changeDetail.tax}</span>
          </Col>
          <Col span={8}>
            <span>
              {/*  eslint-disable-next-line */}
              <Form.Item {...formItemLayout} label="税额">
                {getFieldDecorator('tax', {})(<Input onChange={(e) => numberChange(e, 9)} />)}
              </Form.Item>
            </span>
          </Col>
          <Col span={8}>
            <span>税额：{util.toFixed(changeDetail.tax - (getFieldValue('tax') || 0), 2)}</span>
          </Col>
        </Row>
        <Col span={8}>
          <span>原值（价税合计）：{changeDetail.taxTotal}</span>
        </Col>
        <Col span={8}>
          <span>原值（价税合计）：{taxTotal}</span>
          {getFieldDecorator('taxTotal', { initialValue: taxTotal })(<Input type="hidden" />)}
        </Col>
        <Col span={8}>
          <span>
            原值（价税合计）：
            {util.toFixed(changeDetail.taxTotal - taxTotal, 2)}
          </span>
        </Col>
        <Row>
          <Col span={8}>
            <span>累计折旧：{changeDetail.totalDepreciate}</span>
          </Col>
          <Col span={8}>
            <span>
              {getFieldDecorator('isInit', {
                initialValue: type,
              })(<Input type="hidden" />)}
              {/* eslint-disable-next-line */}
              <Form.Item {...formItemLayout} label="累计折旧">
                {getFieldDecorator('totalDepreciate', {
                  rules: [
                    {
                      validator(rule, val, callback) {
                        const value =
                          form.getFieldValue('originalValue') -
                          (form.getFieldValue('originalValue') * changeDetail.remainingRatio) / 100;
                        if (val > value) {
                          callback('期初累计折旧不能大于原值-残值');
                        }
                        callback();
                      },
                    },
                  ],
                })(<Input onChange={(e) => numberChange(e, 9)} />)}
              </Form.Item>
            </span>
          </Col>
          <Col span={8}>
            <span>
              累计折旧：
              {util.toFixed(
                changeDetail.totalDepreciate - (getFieldValue('totalDepreciate') || 0),
                2,
              )}
            </span>
          </Col>
        </Row>
        <Row>
          <Col span={8}>
            <span>资产净值：{changeDetail.netWorth}</span>
          </Col>
          <Col span={8}>
            <span>资产净值：{netWorth}</span>
          </Col>
          <Col span={8}>
            <span>资产净值：{util.toFixed(changeDetail.netWorth - netWorth, 2)}</span>
          </Col>
        </Row>
        <Row>
          <Col span={8}>
            <span>月折旧额：{changeDetail.monthDepreciate}</span>
          </Col>
          <Col span={8}>
            <span>月折旧额：{monthDepreciate}</span>
          </Col>
          <Col span={8}>
            <span>
              月折旧额：
              {util.toFixed(changeDetail.monthDepreciate - monthDepreciate, 2)}
            </span>
          </Col>
        </Row>
        <Col span={8} offset={8}>
          <span>变动期间：{query.endDate}</span>
        </Col>
        <>
          {getFieldDecorator('ageLimit', {
            initialValue: changeDetail.ageLimit,
          })(<Input type="hidden" />)}
          {getFieldDecorator('assetTypeId', {
            initialValue: changeDetail.assetTypeId,
          })(<Input type="hidden" />)}
          {getFieldDecorator('changeType', {
            initialValue: changeDetail.changeType,
          })(<Input type="hidden" />)}
          {getFieldDecorator('depreciationMethod', {
            initialValue: changeDetail.depreciationMethod,
          })(<Input type="hidden" />)}
          {getFieldDecorator('remainingRatio', {
            initialValue: changeDetail.remainingRatio,
          })(<Input type="hidden" />)}
        </>
      </>
    ),
  };
};
