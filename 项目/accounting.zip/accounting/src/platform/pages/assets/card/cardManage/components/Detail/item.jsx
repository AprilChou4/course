import React from 'react';
import { Row, Col } from 'antd';
import PropTypes from 'prop-types';
import './index.less';

const Item = ({ index, data }) => {
  return (
    <div styleName="wrapper-item">
      <p>部门{index + 1}</p>
      <Row>
        <Col span={8}>
          <span>部门：{data.department}</span>
        </Col>
        <Col span={8}>
          <span>费用科目：{data.costSubject}</span>
        </Col>
        <Col span={8}>
          <span>分摊比例：{data.scale}</span>
        </Col>
        {!!data.project && (
          <Col span={8}>
            <span>项目：{data.project}</span>
          </Col>
        )}
      </Row>
    </div>
  );
};

Item.propTypes = {
  index: PropTypes.number.isRequired,
  data: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default Item;
