import React, { useRef } from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import './index.less';
import CardItem from './CardItem';

const MultiDepartmentAccounting = ({ form, dataSource, dispatch, disabled }) => {
  const card = document.querySelector('#card-management-form');
  const wrapper = useRef(null);
  const handleAddDepartment = () => {
    const sum = dataSource.reduce((acc, { scale }) => acc + scale, 0);
    const newData = [
      ...dataSource,
      {
        key: dataSource.length + 1,
        department: undefined,
        project: undefined,
        costSubject: undefined,
        scale: 100 - sum,
      },
    ];
    dispatch({ type: 'setState', payload: { dataSource: newData } });
    card.scrollTo(0, wrapper.current.offsetHeight);
  };
  const handleDelete = (i) => {
    const data = JSON.parse(JSON.stringify(dataSource));
    data.splice(i, 1);
    dispatch({ type: 'setState', payload: { dataSource: data } });
  };
  return (
    <div styleName="wrapper" ref={wrapper}>
      {dataSource.map((item, index) => {
        const { key } = item;
        return (
          <CardItem
            key={key}
            form={form}
            index={index}
            onDelete={handleDelete}
            data={item}
            disabled={disabled}
          />
        );
      })}
      {!disabled && (
        <div styleName="wrapper-footer">
          <span onClick={handleAddDepartment}>
            <i className="iconfont icon-jia" />
            新增部门
          </span>
        </div>
      )}
    </div>
  );
};

MultiDepartmentAccounting.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  disabled: PropTypes.bool.isRequired,
};

export default connect(({ dataSource }) => ({
  dataSource,
}))(MultiDepartmentAccounting);
