import React from 'react';
import Main from './components';
import Effects from './effects';

export default {
  render() {
    return <Main />;
  },
  state: {
    // 列表数据
    cardList: [],
    // 表头数据
    columnsData: [],
    loading: false,
    // 自定义列表的全部数据
    treeData: [],
    // 搜索条件
    searchParams: {},
    // 使用部门数据
    useDepartmentsData: [],
    // 使用项目数据
    useProjectsData: [],
    // 选中的数据
    selectedRows: [],
    selectedRowKeys: [],
    // 是否显示清理
    isShowClearUpModal: false,
    // 是否显示停用
    isShowStopModal: false,
    // 是否显示自定义显示列
    isShowCustomColumns: false,
    // 是否显示变动模态框
    isShowChangeModal: false,
    // 固定资产类别集合
    typeList: [],
    // 使用科目
    getSubjectList: [],
    // 筛选条件
    params: {},
    // 变动的详情数据
    changeDetail: {},
    componentKey: undefined,
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  effects() {
    return new Effects(this);
  },
  onInit() {
    this.store.dispatch({ type: 'init' });
  },
};
