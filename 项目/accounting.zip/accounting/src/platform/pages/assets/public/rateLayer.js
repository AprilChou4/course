import { request, layer } from 'nuijs';
import './style/rateLayer.less';
/* eslint-disable */
export default function (data, callback) {
  let _vchError = false;
  let _auto;
  let _res;
  let _go_vchs = false;
  let _vchMessage = '';
  layer({
    template: `<p class="ui-schedule">
                    <em class="f-tac">正在处理文件数据 <b class="dot-box">... <i class="dot-cover"></i></b></em>
                    <font>
                        <i>
                        <b></b>
                        </i>
                    </font>
                    <span class="f-tal">当前文件上传进度为<b> <i>0</i>%</b> 请耐心等待</span>
                </p>`,
    id: 'rateLayer',
    under: data.under,
    data,
    onInit(self) {
      const _this = this;
      let _size = 0;
      if (_vchError) {
        _this.element.find('.layer-button-cancel').css({ visibility: 'visible' });
        _this.element.find('p').addClass('sch_error');
        _this.element
          .find('p')
          .find('em')
          .html('<i class="iconfont e-pr5">&#xe64b;</i>文件数据处理失败');
        _this.element
          .find('p')
          .find('span')
          .html(
            `抱歉，您导入的账套数据处理失败，失败原因为“${_vchMessage}”,请重新导入或者联系管理员`,
          );
        return false;
      }
      _auto = setInterval(function () {
        _size++;
        if (_size > 99) {
          clearInterval(_auto);
          if (_go_vchs) {
            _go_vchs = false;
            callback(_res);
            layer.hide('rateLayer');
          } else {
            _go_vchs = true;
          }
          return false;
        }
        if (_go_vchs) {
          clearInterval(_auto);
          var uto = setInterval(function () {
            _size++;
            if (_size > 99) {
              clearInterval(uto);
              callback(_res);
              layer.hide('rateLayer');
            }
            _this.element
              .find('p')
              .find('font')
              .find('i')
              .find('b')
              .css({ marginLeft: `${_size - 100}%` });
            _this.element.find('p').find('span').find('i').text(_size);
          }, 3);
        }

        _this.element
          .find('p')
          .find('font')
          .find('i')
          .find('b')
          .css({ marginLeft: `${_size - 100}%` });
        _this.element.find('p').find('span').find('i').text(_size);
      }, data.time || 300);
      _this._urls();
    },
    _urls() {
      const _this = this;
      const _data = data;
      var _uat = setInterval(function () {
        request[data.type || 'get'](
          data.url || 'cloud/forwardInterface/getImportTaskStatus',
          { taskId: _data.taskId },
          function (res) {
            _res = res;
            if (res.status == 200) {
              let status;
              if (data.field && data.values) {
                status = data.values[res.data[data.field]];
              } else {
                status = res.data.status;
              }
              if (status == 'processing') {
                // 等待
              } else if (status == 'success') {
                // 成功
                clearInterval(_uat);
                if (_go_vchs) {
                  callback(_res);
                  layer.hide('rateLayer');
                  _go_vchs = false;
                } else {
                  _go_vchs = true;
                }
              } else {
                // 失败
                clearInterval(_uat);
                clearInterval(_auto);
                _vchError = true;
                let errorMsg = '';
                if (res.data.reasonList && res.data.reasonList.length > 0) {
                  errorMsg = '具体原因请关闭查看';
                }
                // res.data.reasonList.forEach((item) => {
                //   errorMsg += item;
                // });
                _vchMessage =
                  res.data.message || res.data.failMessage || errorMsg || '文件数据处理失败1';
                callback(_res);
                layer.reset('rateLayer');
              }
            } else {
              clearInterval(_uat);
              clearInterval(_auto);
              _vchError = true;
              _vchMessage = res.message || '文件数据处理失败';
              layer.reset('rateLayer');
            }
          },
          null,
        );
      }, 3000);
    },
    close: {
      enable: false,
    },
    title: null,
    width: 420,
    height: 180,
    cancel: {
      enable: true,
      text: '关闭',
    },
  });
}
