import { util } from 'nuijs';

export default util.createRequest({
  queryTreeData: 'fixedasset/difineColumn/getAllDepreciationDetailsColumn:post',
  initDepreciationDetailsColumn: 'fixedasset/difineColumn/initDepreciationDetailsColumn:post',
  upDateColumn: 'fixedasset/difineColumn/upDateDepreciationDetailsColumn:postJSON',
  queryTableData: 'fixedasset/report/getAssetDetailList',
  queryDepartmentsData: 'fixedasset/card/getDeptList',
  queryProjecetData: 'fixedasset/card/getProjectList',
  queryTypeList: 'fixedasset/type/getList',
  // 查询固定资产详情及其变动、禁用、启用记录
  getLifeRecord: 'fixedasset/card/getLifeRecord:post',
});
