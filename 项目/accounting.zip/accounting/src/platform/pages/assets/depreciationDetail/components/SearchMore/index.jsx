import React, { useState, useRef } from 'react';
import { Input, Popover } from 'antd';
import PropTypes from 'prop-types';
import Form from './Form';
import './index.less';

const SearchMore = (props) => {
  const { onSearch } = props;
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState('');
  const [isDisabled, setIsDisabled] = useState(false);
  const form = useRef(null);
  const handleVisibleChange = (e) => {
    if (sessionStorage.getItem('guideoption') === '14' && e === false) {
      return;
    }
    if (!e) {
      setVisible(e);
    }
  };
  const showPopover = () => {
    setVisible(true);
  };
  const handleOnSearch = (e) => {
    let params = {};
    params.searchKey = e;
    form.current &&
      form.current.validateFields((errors, values) => {
        if (errors) return;
        params.searchKey = Object.keys(values).some((item) => {
          return !!values[item];
        })
          ? ''
          : params.searchKey;
        params = {
          ...params,
          ...values,
        };
      });
    onSearch(params);
  };
  return (
    <span className="e-ml12 my-stock-search">
      <Popover
        placement="bottomLeft"
        trigger="click"
        visible={visible}
        content={
          <Form
            // eslint-disable-next-line
            {...props}
            setPopVisible={setVisible}
            setValue={setValue}
            setDisabled={setIsDisabled}
            ref={form}
            value={value}
          />
        }
        onVisibleChange={handleVisibleChange}
        overlayClassName="my-search-popover"
      >
        <Input.Search
          onChange={(e) => {
            if (!e.target.value) {
              setIsDisabled(false);
              form.current && form.current.resetFields();
              form.current &&
                form.current.validateFields((errors, values) => {
                  onSearch({ searchKey: '', ...values });
                });
            }
            setValue(e.target.value);
          }}
          className="search-more"
          prefix={<i onClick={showPopover}>更多条件</i>}
          enterButton
          allowClear
          placeholder="请输入资产名称或编码"
          value={value}
          readOnly={isDisabled}
          onSearch={handleOnSearch}
          title={value}
        />
      </Popover>
    </span>
  );
};

SearchMore.defaultProps = {
  useDepartmentsData: [],
  useProjetcsData: [],
};

SearchMore.propTypes = {
  onSearch: PropTypes.func.isRequired, // 搜索的回调函数
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any), // 使用部门的数据
  useProjetcsData: PropTypes.arrayOf(PropTypes.any), // 使用项目的数据
};

export default SearchMore;
