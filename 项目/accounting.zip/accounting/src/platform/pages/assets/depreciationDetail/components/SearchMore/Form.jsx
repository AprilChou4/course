import React from 'react';
import PropTypes from 'prop-types';
import { Form, Select, Button, Checkbox } from 'antd';

const { Option } = Select;

const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};

const Content = (props) => {
  const {
    setValue,
    setDisabled,
    setPopVisible,
    value,
    onSearch,
    useDepartmentsData,
    useProjetcsData,
    typeList,
  } = props;
  const {
    form: { getFieldDecorator, validateFields, resetFields },
  } = props;
  const setText = (obj, flag) => {
    let text = '';
    let params = {};
    params = {
      ...params,
      ...obj,
    };
    Object.keys(obj).forEach((key) => {
      if (key === 'assetTypeId' && obj[key]) {
        let assetCategoryText = '';
        typeList.forEach((data) => {
          if (data.assetTypeId === obj[key]) {
            assetCategoryText = data.assetTypeName;
          }
        });
        text += `资产类别：${assetCategoryText}；`;
      }
      if (key === 'deptId' && obj[key]) {
        let useDepartmentsText = '';
        useDepartmentsData.forEach((data) => {
          if (data.id === obj[key]) {
            useDepartmentsText = data.name;
          }
        });
        text += `使用部门：${useDepartmentsText}；`;
      }
      if (key === 'projectId' && obj[key]) {
        let useProjetcsText = '';
        useProjetcsData.forEach((data) => {
          if (data.id === obj[key]) {
            useProjetcsText = data.name;
          }
        });
        text += `使用项目：${useProjetcsText}；`;
      }
      if (key === 'isShowEnabledAndNotCleared' && obj[key]) {
        text += `展示期间内全部已使用、未清理的固定资产；`;
      }
    });
    setValue(text);
    if (text) {
      setDisabled(true);
      params.searchKey = '';
    } else {
      setDisabled(false);
      params.searchKey = flag ? '' : value;
    }
    onSearch(params);
  };
  const handleSubmit = () => {
    validateFields((errors, values) => {
      if (errors) return;
      setText(values);
      setPopVisible(false);
    });
  };
  const handleReset = () => {
    setValue('');
    resetFields();
    setText({}, true);
  };
  return (
    <Form className="content-form">
      {/* eslint-disable-next-line */}
      <Form.Item label="资产类别" {...formItemLayout}>
        {getFieldDecorator(
          'assetTypeId',
          {},
        )(
          <Select>
            {typeList.map((item) => {
              return (
                <Option
                  key={item.assetTypeId}
                  value={item.assetTypeId}
                  style={{ minHeight: '32px' }}
                >
                  {item.assetTypeName}
                </Option>
              );
            })}
          </Select>,
        )}
      </Form.Item>
      {/* eslint-disable-next-line */}
      <Form.Item label="使用部门" {...formItemLayout}>
        {getFieldDecorator(
          'deptId',
          {},
        )(
          <Select>
            {useDepartmentsData.map((item) => {
              return (
                <Option key={item.id} value={item.id}>
                  {item.name}
                </Option>
              );
            })}
          </Select>,
        )}
      </Form.Item>
      {/* eslint-disable-next-line */}
      <Form.Item label="使用项目" {...formItemLayout}>
        {getFieldDecorator(
          'projectId',
          {},
        )(
          <Select>
            {useProjetcsData.map((item) => {
              return (
                <Option key={item.id} value={item.id}>
                  {item.name}
                </Option>
              );
            })}
          </Select>,
        )}
      </Form.Item>

      <Form.Item style={{ paddingLeft: '10px' }}>
        {getFieldDecorator(
          'isShowEnabledAndNotCleared',
          {},
        )(
          <Checkbox.Group>
            <Checkbox value={1}>展示期间内全部已使用、未清理的固定资产</Checkbox>
          </Checkbox.Group>,
        )}
      </Form.Item>
      <Form.Item style={{ textAlign: 'center', marginBottom: '0px' }}>
        <Button type="primary" ghost onClick={handleReset}>
          重置
        </Button>
        <Button type="primary" className="e-ml10" onClick={handleSubmit}>
          确定
        </Button>
      </Form.Item>
    </Form>
  );
};

Content.propTypes = {
  setValue: PropTypes.func.isRequired,
  setDisabled: PropTypes.func.isRequired,
  setPopVisible: PropTypes.func.isRequired,
  value: PropTypes.string.isRequired,
  onSearch: PropTypes.func.isRequired,
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  useProjetcsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  typeList: PropTypes.arrayOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default Form.create()(Content);
