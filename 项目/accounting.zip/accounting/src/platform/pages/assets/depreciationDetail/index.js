import React from 'react';
import Main from './components';
import Effects from './effects';

export default {
  render() {
    return <Main />;
  },
  state: {
    loading: false,
    tableData: [],
    // 表头数据
    columnsData: [],
    // 表头所有数据
    treeData: [],
    searchParams: {
      assetTypeId: undefined,
      deptId: undefined,
      endPeriod: undefined,
      isShowEnabledAndNotCleared: false,
      projectId: undefined,
      searchKey: undefined,
      startPeriod: undefined,
    },
    // 项目数据
    useProjetcsData: [],
    // 部门数据
    useDepartmentsData: [],
    // 资产列表数据
    typeList: [],
    componentKey: undefined,
  },
  effects() {
    return new Effects(this);
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  onInit() {
    this.store.dispatch({ type: 'init' });
  },
};
