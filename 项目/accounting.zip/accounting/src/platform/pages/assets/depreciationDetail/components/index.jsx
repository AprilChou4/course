import React from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import { Layout, Head, Center, Right, Content, Left, Title } from '@/Layout';
import Period from '@/Period';
import PrintButton from '@/buttons/PrintButton';
import ExportButton from '@/buttons/ExportButton';
import SearchMore from './SearchMore';
import Tables from './Tables';
import CustomColumns from '@/CustomizeColumns';

const Main = (props) => {
  const {
    columnsData,
    useProjetcsData,
    useDepartmentsData,
    typeList,
    dispatch,
    searchParams,
    componentKey,
    treeData,
  } = props;
  const handleInitColumns = async () => {
    await dispatch({ type: 'initDepreciationDetailsColumn' });
  };
  const handleUpdateColumns = async (params) => {
    await dispatch({
      type: 'upDateDepreciationDetailsColumn',
      payload: { defineColumnBOs: params },
    });
  };
  return (
    <Layout>
      <Head>
        <Left>
          <Period.Range
            className="newGuide13"
            limit
            onChange={() => {
              dispatch({ type: 'setSearchParams' });
              dispatch({ type: 'queryTableData' });
            }}
          />
          <span className="newGuide14" style={{ display: 'inline-block', verticalAlign: 'bottom' }}>
            <SearchMore
              key={componentKey}
              useProjetcsData={useProjetcsData}
              useDepartmentsData={useDepartmentsData}
              typeList={typeList}
              onSearch={(data) => {
                const newParams = { ...data };
                newParams.isShowEnabledAndNotCleared =
                  newParams.isShowEnabledAndNotCleared &&
                  newParams.isShowEnabledAndNotCleared[0] === 1
                    ? true
                    : undefined;
                dispatch({ type: 'setSearchParams', payload: { ...newParams } });
              }}
            />
          </span>
        </Left>
        <Center>
          <Title />
        </Center>
        <Right>
          {window.inAuth(174) && (
            <PrintButton params={searchParams} url="fixedasset/print/printAssetDetailList" />
          )}

          {window.inAuth(174) && (
            <ExportButton
              className="e-ml12"
              url="fixedasset/report/exportAssetDetailList"
              params={searchParams}
            />
          )}
          <CustomColumns
            type="primary"
            ghost
            className="e-ml12"
            columnsData={columnsData}
            treeData={treeData}
            initColumns={handleInitColumns}
            updateColumns={handleUpdateColumns}
            fixedField="资产编码"
          />
        </Right>
      </Head>
      <Content id="depreciation-detail">
        <Tables />
      </Content>
    </Layout>
  );
};

Main.defaultProps = {
  componentKey: undefined,
};

Main.propTypes = {
  columnsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  treeData: PropTypes.arrayOf(PropTypes.any).isRequired,
  useProjetcsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  useDepartmentsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  typeList: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  searchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  componentKey: PropTypes.any,
};

export default connect(
  ({
    columnsData,
    useProjetcsData,
    useDepartmentsData,
    typeList,
    searchParams,
    componentKey,
    treeData,
  }) => ({
    columnsData,
    useProjetcsData,
    useDepartmentsData,
    typeList,
    searchParams,
    componentKey,
    treeData,
  }),
)(Main);
