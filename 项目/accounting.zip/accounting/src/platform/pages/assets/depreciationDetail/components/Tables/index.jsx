import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';
import './index.less';

const Tables = (props) => {
  const { tableData, loading, dispatch } = props;
  const columns = getColumns(props);
  const handleRow = (record) => {
    return {
      onDoubleClick: () => {
        if (record.key !== record.maxlength && window.inAuth(171)) {
          dispatch({ type: 'openDetailById', payload: record });
        }
      },
    };
  };

  return (
    <SuperTable
      className="detail-table"
      loading={loading}
      dataSource={tableData}
      bordered
      pagination={false}
      columns={columns}
      scroll={{ x: '100%' }}
      rowKey={(record, index) => record.assetTypeId || index}
      onRow={handleRow}
      dragCell
      minWidthCount={1130}
      id="depreciationDetail"
    />
  );
};

Tables.propTypes = {
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  // eslint-disable-next-line react/no-unused-prop-types
  columnsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  loading: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ tableData, loading, columnsData }) => ({
  tableData,
  loading,
  columnsData,
}))(Tables);
