import React from 'react';
import { superLayer } from 'layer';
import moment from 'moment';
import { message } from 'antd';
import TableCell from '@/TableCell';
import services from '../../../card/services';
import cardManage from '../../../card/cardManage';

// todo 原值、税额、价税合计、资产净值、月折旧额、累计折旧,第一次碰到这些中的任何一个之前都合并
const mergeColumns = [
  'originalValue', // 原值
  'tax', // 税额
  'taxTotal', // 价税合计
  'netWorth', // 资产净值
  'monthDepreciate', // 月折旧额
  'totalDepreciate', // 累计折旧
  'thisMonthDepreciate',
  'endDepreciate',
  'yearDepreciate',
  'netValue',
];
export default (props) => {
  const { columnsData } = props;
  let mergeIndex = 0;
  const layers = (data) => {
    superLayer(cardManage, {
      data: {
        title: '查看卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'depreciationDetail',
        datail: data,
      },
      zIndex: 9,
      className: 'card-manage-layer',
    });
  };
  const openDetail = async (record) => {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      layers({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };
  columnsData.some((item, index) => {
    if (mergeColumns.includes(item.columnField)) {
      mergeIndex = index;
      return true;
    }
    return false;
  });
  const newColumns = [
    {
      title: '行次',
      dataIndex: 'key',
      align: 'center',
      width: 50,
      minWidth: 26,
      render: (text, record) => {
        if (record.key >= record.maxlength) {
          return {
            // eslint-disable-next-line
            children: <TableCell>合计</TableCell>,
            props: {
              colSpan: mergeIndex + 1,
            },
          };
        }
        return <TableCell>{text}</TableCell>;
      },
    },
  ];
  // 对于特殊字段值进行处理
  const transformText = (type, text, record) => {
    switch (type) {
      case 'assetCode': // 资产编号
        return (
          <a
            onClick={() => {
              if (window.inAuth(171)) {
                openDetail(record);
              }
            }}
          >
            <TableCell>{text}</TableCell>
          </a>
        );
      case 'isStop': // 启用状态
      case 'isClear': // 清理状态
      case 'isLocked': // 清理状态
        if (record.key < record.maxlength) {
          return text ? (
            <TableCell type="node">
              <span className="status status-error">
                {/* eslint-disable-next-line */}
                {type === 'isClear' ? '已清理' : type === 'isStop' ? '停用中' : '已锁定'}
              </span>
            </TableCell>
          ) : (
            <TableCell type="node">
              <span className="status status-success">
                {/* eslint-disable-next-line */}
                {type === 'isClear' ? '未清理' : type === 'isStop' ? '启用中' : '未锁定'}
              </span>
            </TableCell>
          );
        }
        return '';
      case 'ageLimit':
      case 'addDate':
      case 'accountPeriod':
      case 'buyDate':
      case 'quantity':
      case 'remainingRatio':
        return <TableCell>{text || ''}</TableCell>;
      case 'depreciationMethod': // 折旧状态
        if (text) {
          // eslint-disable-next-line
          return text === 1 ? (
            <TableCell>年限平均法</TableCell>
          ) : text === 2 ? (
            <TableCell>双倍余额递减法</TableCell>
          ) : (
            <TableCell>年数总和法</TableCell>
          );
        }
        return '';
      case 'createTime':
        return <TableCell>{text && moment(text).format('YYYY-MM-DD')}</TableCell>;
      default:
        return (
          <TableCell
            type={typeof text === 'number' ? 'number' : 'text'}
            showZero={typeof text === 'number'}
          >
            {text}
          </TableCell>
        );
    }
  };
  columnsData.forEach((item, index) => {
    newColumns.push({
      title: item.columnName,
      dataIndex: item.columnField,
      width: item.width,
      minWidth: 26,
      align: item.align,
      render: (text, record) => {
        if (index < mergeIndex) {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return transformText(item.columnField, text, record);
        }
        return transformText(item.columnField, text, record);
      },
    });
  });
  return newColumns;
};
