import { BaseEffects } from 'effects';
import { message } from 'antd';
import services from '../services';
import { superLayer } from '../../../../public/layer';
import cardManage from '../../card/cardManage';

export default class Effects extends BaseEffects {
  setState(data) {
    this.dispatch({
      type: 'updateSatet',
      payload: data,
    });
  }

  async init() {
    await this.initPeriod();
    await this.queryTreeData();
    await this.queryDepartmentsData();
    await this.queryProjecetData();
    await this.queryTypeList();
    await this.setSearchParams();
    this.setState({
      componentKey: Date.now(),
    });
  }

  // 获取表头数据
  async queryTreeData() {
    const data = await services.queryTreeData();
    const treeData = [];
    const keys = [];
    const columnsData = [];
    data.forEach((val, key) => {
      const index = keys.indexOf(val.contents);
      if (index === -1) {
        treeData.push({
          name: val.contents,
          columnName: val.contents,
          key: keys.length,
          children: [{ ...val, key }],
        });
        keys.push(val.contents);
      } else {
        treeData[index].children.push({ ...val, key });
      }
      if (val.isShow === 1) {
        columnsData.push({ ...val, key });
      }
    });
    this.setState({
      columnsData,
      treeData,
    });
  }

  // 获取列表数据
  async queryTableData() {
    await this.initPeriod();
    this.setState({
      loading: true,
    });
    const { query, searchParams } = this.getState();
    const newParmas = {
      ...searchParams,
    };
    newParmas.startPeriod = query.beginDate || query.startDate;
    newParmas.endPeriod = query.endDate;
    try {
      let data = await services.queryTableData(newParmas);
      if (data.length === 1) {
        data = [];
      }
      const maxlength = data.length;
      data.map((item, index) => {
        const trem = item;
        trem.key = index + 1;
        trem.maxlength = maxlength;
        return trem;
      });
      this.setState({
        tableData: data,
      });
    } catch (e) {
      console.log(e);
    } finally {
      this.setState({
        loading: false,
      });
    }
  }

  // 设置搜索条件
  async setSearchParams(params) {
    const { searchParams, query } = this.getState();
    const { beginDate, startDate, endDate } = query;
    const newParams = {
      ...searchParams,
      ...params,
      startPeriod: beginDate || startDate,
      endPeriod: endDate,
    };
    this.setState({
      searchParams: newParams,
    });
    this.queryTableData();
  }

  // 跟新自定义列表
  async upDateDepreciationDetailsColumn(params) {
    await services.upDateColumn(params);
    message.success('操作成功！');
    this.queryTreeData();
    this.queryTableData();
  }

  // 恢复自定义列表数据
  async initDepreciationDetailsColumn() {
    await services.initDepreciationDetailsColumn();
    message.success('恢复成功！');
    this.queryTreeData();
    this.queryTableData();
  }

  // 获取部门数据
  async queryDepartmentsData() {
    const data = await services.queryDepartmentsData();
    this.setState({
      useDepartmentsData: data,
    });
  }

  // 获取项目
  async queryProjecetData() {
    const data = await services.queryProjecetData();
    this.setState({
      useProjetcsData: data,
    });
  }

  // 获取资产类别数据
  async queryTypeList() {
    const data = await services.queryTypeList();
    this.setState({
      typeList: data,
    });
  }

  openCardManage(data) {
    this.initPeriod();
    superLayer(cardManage, {
      data: {
        title: '查看卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'depreciation',
        datail: data,
      },
      className: 'card-manage-layer',
    });
  }

  // 根据数据查看详情
  async openDetailById(record) {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      this.openCardManage({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  }
}
