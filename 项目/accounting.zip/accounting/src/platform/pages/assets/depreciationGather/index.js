import React from 'react';
import Main from './components';
import Effecs from './effects';

export default {
  render() {
    return <Main />;
  },
  state: {
    tableData: [],
    isInit: false,
    loading: false,
    searchParams: {
      endPeriod: undefined,
      startPeriod: undefined,
      isShowEnabledAndNotCleared: false,
      summaryMethod: '',
    },
  },
  effects() {
    return new Effecs(this);
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  onInit() {
    this.store.dispatch({ type: 'init' });
  },
};
