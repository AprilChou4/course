import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Layout, Content, Right, Center, Head, Title, Left } from '@/Layout';
import Period from '@/Period';
import PrintButton from '@/buttons/PrintButton';
import ExportButton from '@/buttons/ExportButton';
import SearchButton from '@/buttons/SearchButton';
import FormContent from './FormContent';
import Table from './Table';
import '../style/index.less';

const Main = (props) => {
  const { searchParams, dispatch, isInit } = props;
  const handleSearch = (e) => {
    dispatch({ type: 'setSearchParmas', payload: { ...e } });
    dispatch({ type: 'queryData' });
  };
  return (
    <Layout>
      <Head>
        <Left>
          <Period.Range
            limit
            onChange={() => {
              dispatch({ type: 'setSearchParmas' });
              dispatch({ type: 'queryData' });
            }}
          />
          {isInit && (
            <SearchButton
              className="e-ml12"
              onSearch={handleSearch}
              content={(data) => {
                return <FormContent {...data} />;
              }}
              onReset={() => {
                dispatch({
                  type: 'setState',
                  payload: {
                    searchParams: {
                      ...searchParams,
                      summaryMethod: '',
                      isShowEnabledAndNotCleared: false,
                    },
                  },
                });
              }}
            />
          )}
        </Left>
        <Center>
          <Title />
        </Center>
        <Right>
          {window.inAuth(178) && (
            <PrintButton url="fixedasset/print/printAssetSummaryList" params={searchParams} />
          )}
          {window.inAuth(178) && (
            <ExportButton
              className="e-ml12"
              url="fixedasset/report/exportAssetSummaryList"
              params={searchParams}
            />
          )}
        </Right>
      </Head>
      <Content>
        <Table />
      </Content>
    </Layout>
  );
};

Main.propTypes = {
  searchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  isInit: PropTypes.bool.isRequired,
};

export default connect(({ searchParams, isInit }) => ({ searchParams, isInit }))(Main);
