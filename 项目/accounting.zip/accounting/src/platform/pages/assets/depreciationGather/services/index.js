import { util } from 'nuijs';

export default util.createRequest({
  queryData: 'fixedasset/report/getAssetSummaryList',
});
