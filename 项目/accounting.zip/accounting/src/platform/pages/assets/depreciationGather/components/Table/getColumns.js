import React from 'react';
import TableCell from '@/TableCell';

export default ({ summaryMethod }) => {
  return [
    {
      title: '行次',
      dataIndex: 'key',
      align: 'center',
      width: 51,
      minWidth: 26,
      render: (text, record) => {
        if (record.key >= record.maxlength) {
          return {
            children: <TableCell>合计</TableCell>,
            props: {
              colSpan: 2,
            },
          };
        }
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: summaryMethod === 2 ? '部门名称' : summaryMethod === 3 ? '项目名称' : '资产类别',
      dataIndex: 'name',
      align: 'center',
      width: 278,
      minWidth: 26,
      render: (text, record) => {
        if (record.key >= record.maxlength) {
          return {
            props: {
              colSpan: 0,
            },
          };
        }
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '原值',
      dataIndex: 'originalValue',
      align: 'right',
      width: 139,
      minWidth: 26,
      render: (text) => {
        return (
          <TableCell type="number" showZero>
            {text}
          </TableCell>
        );
      },
    },
    {
      title: '期初累计折旧',
      dataIndex: 'initTotalDepreciate',
      align: 'right',
      width: 139,
      minWidth: 26,
      render: (text) => {
        return (
          <TableCell type="number" showZero>
            {text}
          </TableCell>
        );
      },
    },
    {
      title: '本期折旧额',
      dataIndex: 'thisMonthDepreciate',
      align: 'right',
      width: 139,
      minWidth: 26,
      render: (text) => {
        return (
          <TableCell type="number" showZero>
            {text}
          </TableCell>
        );
      },
    },
    {
      title: '本年累计折旧',
      dataIndex: 'yearTotalDepreciate',
      align: 'right',
      width: 139,
      minWidth: 26,
      render: (text) => {
        return (
          <TableCell type="number" showZero>
            {text}
          </TableCell>
        );
      },
    },
    {
      title: '期末累计折旧',
      dataIndex: 'balanceTotalDepreciate',
      align: 'right',
      width: 139,
      minWidth: 26,
      render: (text) => {
        return (
          <TableCell type="number" showZero>
            {text}
          </TableCell>
        );
      },
    },
    {
      title: '期末净值',
      dataIndex: 'balanceNetWorth',
      align: 'right',
      width: 139,
      minWidth: 26,
      render: (text) => {
        return (
          <TableCell type="number" showZero>
            {text}
          </TableCell>
        );
      },
    },
  ];
};
