import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';
import './index.less';

const Table = (props) => {
  const { tableData, loading } = props;
  return (
    <SuperTable
      className="gather-table"
      bordered
      loading={loading}
      pagination={false}
      dataSource={tableData}
      columns={getColumns(props)}
      scroll={{ x: '100%' }}
      rowKey={(record, index) => index + 1}
      dragCell
      minWidthCount={1130}
      id="depreciation-gather"
    />
  );
};

Table.propTypes = {
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  loading: PropTypes.bool.isRequired,
};

export default connect(({ tableData, loading, searchParams: { summaryMethod } }) => ({
  tableData,
  loading,
  summaryMethod,
}))(Table);
