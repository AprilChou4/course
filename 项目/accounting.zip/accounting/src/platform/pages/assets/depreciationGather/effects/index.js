import { BaseEffects } from 'effects';
import services from '../services';

export default class Effects extends BaseEffects {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  }

  async init() {
    await this.initPeriod();
    await this.setSearchParmas();
    await this.queryData();
    this.setState({
      isInit: true,
    });
  }

  async setSearchParmas(params) {
    const { query } = this.getState();
    const { endDate, startDate, beginDate } = query;
    const { searchParams } = this.getState();
    const newParams = {
      ...searchParams,
      ...params,
      startPeriod: beginDate || startDate,
      endPeriod: endDate,
    };
    this.setState({
      searchParams: newParams,
    });
  }

  async queryData() {
    const { searchParams } = this.getState();
    this.setState({
      loading: true,
    });
    try {
      let res = await services.queryData(searchParams);
      if (res.length <= 1) {
        res = [];
      }
      const maxlength = res.length;
      res.map((item, index) => {
        const trem = item;
        const key = index + 1;
        trem.key = key;
        trem.maxlength = maxlength;
        return trem;
      });
      this.setState({
        tableData: res,
      });
    } catch (e) {
      console.log(e);
    } finally {
      this.setState({
        loading: false,
      });
    }
  }
}
