import React from 'react';
import PropTypes from 'prop-types';
import { Form, Select, Checkbox } from 'antd';
import { connect } from 'nuomi';

const { Option } = Select;
const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 6 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 15 },
  },
};
const FormContent = (props) => {
  const { form, searchParams, dispatch } = props;
  const { getFieldDecorator } = form;
  const { summaryMethod, isShowEnabledAndNotCleared } = searchParams;
  return (
    <Form className="search-modal">
      {/* eslint-disable-next-line */}
      <Form.Item label="汇总维度" {...formItemLayout}>
        {getFieldDecorator('summaryMethod', {
          initialValue: summaryMethod || '',
        })(
          <Select>
            <Option value={1}>按资产类别</Option>
            <Option value={2}>按部门</Option>
            <Option value={3}>按项目</Option>
          </Select>,
        )}
      </Form.Item>
      <Form.Item style={{ paddingLeft: '46px' }}>
        {getFieldDecorator('isShowEnabledAndNotCleared', {
          initialValue: isShowEnabledAndNotCleared || false,
        })(
          <Checkbox
            checked={isShowEnabledAndNotCleared}
            onChange={(e) => {
              dispatch({
                type: 'setState',
                payload: {
                  searchParams: {
                    ...searchParams,
                    isShowEnabledAndNotCleared: e.target.checked,
                  },
                },
              });
            }}
          >
            展示期间内全部已使用、未清理的固定资产
          </Checkbox>,
        )}
      </Form.Item>
    </Form>
  );
};

FormContent.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  searchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ searchParams }) => ({ searchParams }))(FormContent);
