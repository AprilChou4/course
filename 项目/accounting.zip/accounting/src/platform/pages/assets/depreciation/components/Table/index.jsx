import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import EditableTable from '@/EditableTable2';
import getColumns from './getColumns';
import './index.less';

const Table = (props) => {
  const {
    selectedRowKeys,
    selectedRows,
    tableData,
    dispatch,
    loading,
    query,
    currentDate,
    columnsData,
  } = props;
  const columns = getColumns({ dispatch, tableData, columnsData });
  const rowSelection = {
    selectedRowKeys,
    selectedRows,
    columnWidth: '40px',
    onChange: (keys, rows) => {
      dispatch({
        type: 'setState',
        payload: {
          selectedRowKeys: keys,
          selectedRows: rows,
        },
      });
    },
    getCheckboxProps: (record) => {
      return {
        disabled: record.key === record.maxlength,
        style: {
          display: record.key === record.maxlength ? 'none' : 'block',
        },
      };
    },
  };
  const handleChange = (e) => {
    let { thisMonthDepreciate } = e;
    const { fixedAssetId } = e;
    const data = tableData.filter((item) => {
      return item.fixedAssetId === fixedAssetId;
    });
    if (Number(thisMonthDepreciate) === Number(data[0].thisMonthDepreciate)) {
      return;
    }
    if (thisMonthDepreciate === '') {
      thisMonthDepreciate = 0;
    }
    dispatch({
      type: 'updateThisMonthDepreciate',
      payload: {
        depreciation: thisMonthDepreciate,
        fixedAssetId,
        period: query.endDate,
      },
    });
  };
  const handleRow = (record) => {
    return {
      onDoubleClick: () => {
        if (record.key !== record.maxlength && window.inAuth(164)) {
          dispatch({ type: 'openDetailById', payload: record });
        }
      },
    };
  };
  return (
    <EditableTable
      className="depreciation-table"
      loading={loading}
      id="depreciation-table"
      idName="fixedAssetId"
      columns={columns}
      rowKey={(record, index) => record.fixedAssetId || index}
      dataSource={tableData}
      scroll={{ x: '100%' }}
      rowSelection={rowSelection}
      pagination={false}
      bordered
      enableEditTr={(record) => {
        if (record.key === tableData.length || record.isCreated || currentDate > query.endDate) {
          return false;
        }
        return true;
      }}
      onTdChange={handleChange}
      onRow={handleRow}
      dragCell
      minWidthCount={1130}
    />
  );
};
Table.propTypes = {
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  columnsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  currentDate: PropTypes.string.isRequired,
};
export default connect(
  (
    { selectedRowKeys, selectedRows, tableData, loading, query, columnsData },
    { account: { currentDate } },
  ) => ({
    selectedRowKeys,
    selectedRows,
    tableData,
    loading,
    query,
    columnsData,
    currentDate,
  }),
)(Table);
