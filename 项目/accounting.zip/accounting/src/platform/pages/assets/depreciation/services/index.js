import { util } from 'nuijs';

export default util.createRequest({
  buildDepreciationVoucher: 'fixedasset/voucher/buildDepreciationVoucher:postJSON',
  getDepreciationAssetList: 'fixedasset/voucher/getDepreciationAssetList',
  updateThisMonthDepreciate: 'fixedasset/voucher/updateThisMonthDepreciate:postJSON',
  lock: 'fixedasset/voucher/lock:post',
  unlock: 'fixedasset/voucher/unlock:post',
  isShowImportBtn: 'fixedasset/showImportButton:post',
  // 获取自定义显示列
  getDepreciationColumnList: 'fixedasset/difineColumn/getAllDepreciationAssetColumn',
  // 更新自定义显示列
  updateDepreciationColumnList: 'fixedasset/difineColumn/upDepreciationAssetColumn',
  // 恢复默认显示列
  initDepreciationColumnList: 'fixedasset/difineColumn/initDepreciationAssetColumn',
});
