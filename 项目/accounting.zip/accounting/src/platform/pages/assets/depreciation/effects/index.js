import React from 'react';
import { BaseEffects } from 'effects';
import { message } from 'antd';
import { superLayer } from 'layer';
import services from '../../voucher/services';
import cardManage from '../../card/cardManage';
import Confirm from '../../card/components/More/Confirm';

class Effects extends BaseEffects {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  }

  // 初始化
  async init() {
    await this.initPeriod();
    await this.getDepreciationColumnList();
    const { linkParams } = this.nuomiProps || {};
    if (linkParams) {
      this.dispatch({
        type: 'setState',
        payload: {
          title: linkParams.title,
          disableButton: linkParams.disableButton,
          query: {
            startDate: linkParams.startDate,
            endDate: linkParams.endDate,
          },
          isShowNew: linkParams.showNew,
        },
      });
    }
    this.setState({ isShowNew: inAuth([14, 15], 'accounting') });
    await this.queryDetailData();
  }

  // 重置数据
  async reset() {
    await this.setState({
      selectedRowKeys: [],
      selectedRows: [],
    });
  }

  // 获取表格数据
  async queryDetailData() {
    await this.reset();
    await this.isShowImportBtn();
    const { linkParams } = this.nuomiProps || {};
    const { endDateProps } = linkParams || {};
    const { query, isShowNew } = this.getState();
    const { endDate } = query;
    const params = {
      period: endDateProps || endDate,
      type: isShowNew ? 1 : 0,
    };
    this.setState({
      loading: true,
    });
    try {
      let res = await services.getDepreciationAssetList(params);
      if (res.length <= 1) {
        res = [];
      }
      const maxlength = res.length;
      res.map((item, index) => {
        const trem = item;
        trem.key = index + 1;
        trem.maxlength = maxlength;
        return trem;
      });
      this.setState({
        tableData: res,
      });
    } catch (e) {
      console.log(e);
    } finally {
      this.setState({
        loading: false,
      });
    }
  }

  // 生成凭证
  async createVoucher(params) {
    const { isShowNew } = this.getState();
    this.setState({
      voucherLoading: true,
    });
    const { query } = this.getState();
    const newParams = { ...params, ...{ period: query.endDate } };
    delete newParams.type;
    let data;
    try {
      const res = await services.checkVoucher({ ...newParams, type: isShowNew ? 1 : 0 });
      const { status, afterPeriodChangeOrClearAsset, afterPeriodHaveVoucherAsset } = res;
      if (status === 'fail') {
        Confirm({
          title: '提示',
          errorMsg: '生成凭证失败。详细原因如下：',
          children: (
            // eslint-disable-next-line
            <>
              {afterPeriodChangeOrClearAsset && afterPeriodChangeOrClearAsset.length > 0 && (
                <>
                  <p style={{ marginBottom: '0px' }}>
                    以下固定资产卡片在后续期间存在变动或者清理记录，当期不允许计提折旧：
                  </p>
                  <ul style={{ paddingLeft: '1em' }}>
                    {afterPeriodChangeOrClearAsset.map((item, key) => {
                      const i = key;
                      return <li key={i}>{item}</li>;
                    })}
                  </ul>
                </>
              )}
              {afterPeriodHaveVoucherAsset && afterPeriodHaveVoucherAsset.length > 0 && (
                <>
                  <p style={{ marginBottom: '0px' }}>以下固定资产卡片后续期间有凭证生成：</p>
                  <ul style={{ paddingLeft: '1em' }}>
                    {afterPeriodHaveVoucherAsset.map((item, key) => {
                      const i = key;
                      return <li key={i}>{item}</li>;
                    })}
                  </ul>
                </>
              )}
            </>
          ),
        });
        return;
      }
      data = await services.buildDepreciationVoucher({ ...newParams, type: isShowNew ? 1 : 0 });
    } catch (e) {
      console.log(e);
    } finally {
      this.setState({
        voucherLoading: false,
      });
    }

    const that = this;
    if (data) {
      if (Array.isArray(data)) {
        data = data.map((v) => {
          const item = v;
          item.isInitSerialize = 0;
          return v;
        });
      } else {
        data.isInitSerialize = 0;
      }
    } else {
      return;
    }

    superLayer('voucher/record', {
      data: {
        title: '生成凭证',
        assetId: data[0].assetIdList.join(','),
        disableCrossPeriod: true,
      },
      renderData() {
        return data;
      },
      onDestroy() {
        if (that.save) {
          const { type } = that.getState();
          if (type) {
            that.queryDetailData(type);
          } else {
            that.queryDetailData();
          }
        }
        that.save = undefined;
      },
      onSave(save) {
        that.save = save;
      },
    });
  }

  // 锁定
  async lock(params) {
    await services.lock(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 恢复默认计提折旧
  async covery(params) {
    await services.covery(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 取消锁定
  async unlock(params) {
    await services.unlock(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 修改本月折旧
  async updateThisMonthDepreciate(params) {
    await services.updateThisMonthDepreciate(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  openCardManage = (data) => {
    superLayer(cardManage, {
      data: {
        title: '查看卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'depreciation',
        datail: data,
      },
      className: 'card-manage-layer',
    });
  };

  // 根据数据查看详情
  async openDetailById(record) {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      this.openCardManage({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  }

  // 是否显示导入按钮
  async isShowImportBtn() {
    const { linkParams } = this.nuomiProps || {};
    const { endDateProps } = linkParams || {};
    const { query } = this.getState();
    const { endDate } = query;
    const params = {
      period: endDateProps || endDate,
    };
    const data = await services.isShowImportBtn(params);
    this.setState({
      showImportBtn: data.showButton,
    });
  }

  // 是否显示本月折旧额
  async isShowThisMonthDepreciation(params) {
    await this.setState({
      isShowNew: params,
    });
    const { linkParams } = this.nuomiProps || {};
    if (linkParams) {
      this.nuomiProps && this.nuomiProps.onChange(params);
    }
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 获取自定义显示列数据
  async getDepreciationColumnList() {
    const data = await services.getDepreciationColumnList();
    const treeData = [];
    const keys = [];
    const columnsData = [];
    data.forEach((val, key) => {
      const index = keys.indexOf(val.contents);
      if (index === -1) {
        treeData.push({
          name: val.contents,
          columnName: val.contents,
          key: keys.length,
          children: [{ ...val, key }],
        });
        keys.push(val.contents);
      } else {
        treeData[index].children.push({ ...val, key });
      }
      if (val.isShow === 1) {
        columnsData.push({ ...val, key });
      }
    });
    this.setState({
      treeData,
      columnsData,
    });
  }

  // 恢复默认列头
  async initDepreciationColumn() {
    await services.initDepreciationColumnList();
    message.success('恢复成功！');
    this.getDepreciationColumnList();
    this.queryDetailData();
  }

  // 更新自定义显示列
  async updateDepreciationColumn(params) {
    await services.updateDepreciationColumnList(params);
    message.success('操作成功！');
    this.setState({
      isShowCustomColumns: false,
    });
    this.getDepreciationColumnList();
    this.queryDetailData();
  }

  // 本月折旧额恢复默认
  async recoveryDefaultDepreciation(params) {
    const data = await services.recoveryDefaultDepreciation(params);
    const { failNum, afterPeriodChangeOrClearAsset, afterPeriodHaveVoucherAsset, failInfo } = data;
    if (failNum === 0) {
      message.success('恢复成功');
      this.queryDetailData();
    } else if (failNum === 1) {
      Confirm({
        title: null,
        errorMsg:
          afterPeriodChangeOrClearAsset && afterPeriodChangeOrClearAsset.length > 0
            ? afterPeriodChangeOrClearAsset[0]
            : afterPeriodHaveVoucherAsset && afterPeriodHaveVoucherAsset.length > 0
            ? afterPeriodHaveVoucherAsset[0]
            : failInfo[0],
      });
    } else {
      let msg = '';
      if (afterPeriodChangeOrClearAsset && afterPeriodChangeOrClearAsset.length > 0) {
        // eslint-disable-next-line
        msg = afterPeriodChangeOrClearAsset[0].split(',')[0];
      } else if (afterPeriodHaveVoucherAsset && afterPeriodHaveVoucherAsset.length > 0) {
        // eslint-disable-next-line
        msg = afterPeriodHaveVoucherAsset[0].split(',')[0];
      } else {
        // eslint-disable-next-line
        msg = failInfo[0].split(',')[0];
      }
      Confirm({
        title: null,
        errorMsg: `“${msg}”等${failNum}个卡片不支持恢复默认折旧`,
        children: (
          // eslint-disable-next-line
          <ul style={{ paddingLeft: '1em' }}>
            {afterPeriodChangeOrClearAsset && afterPeriodChangeOrClearAsset.length > 0 && (
              <>
                {/* <p style={{ marginBottom: '0px' }}>
                  以下卡片在后续期间存在变动或清理记录，不允许恢复默认折旧：
                </p> */}
                <>
                  {afterPeriodChangeOrClearAsset.map((item, key) => {
                    const i = key;
                    return <li key={i}>{item}</li>;
                  })}
                </>
              </>
            )}
            {afterPeriodHaveVoucherAsset && afterPeriodHaveVoucherAsset.length > 0 && (
              <>
                {/* <p style={{ marginBottom: '0px' }}>以下卡片已生成折旧凭证，请删除凭证后重试：</p> */}
                <>
                  {afterPeriodHaveVoucherAsset.map((item, key) => {
                    const i = key;
                    return <li key={i}>{item}</li>;
                  })}
                </>
              </>
            )}
            {failInfo && failInfo.length > 0 && (
              <>
                {/* <p style={{ marginBottom: '0px' }}>其他原因：</p> */}
                <>
                  {failInfo.map((item, key) => {
                    const i = key;
                    return <li key={i}>{item}</li>;
                  })}
                </>
              </>
            )}
          </ul>
        ),
        handleOk: () => {
          this.queryDetailData();
        },
        onCancel: () => {
          this.queryDetailData();
        },
      });
    }
  }
}

export default Effects;
