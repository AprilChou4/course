import React from 'react';
import { message } from 'antd';
import { superLayer } from 'layer';
import moment from 'moment';
import { util } from 'nuijs';
import TableCell from '@/TableCell';
import NumberInput from '@/NumberInput';
import cardManage from '../../../card/cardManage';
import services from '../../../card/services';
import './index.less';

// todo 原值、税额、价税合计、资产净值、月折旧额、累计折旧,第一次碰到这些中的任何一个之前都合并,之后暂不处理
const mergeColumns = [
  'originalValue', // 原值
  'tax', // 税额
  'taxTotal', // 价税合计
  'netWorth', // 资产净值
  'monthDepreciate', // 月折旧额
  'totalDepreciate', // 累计折旧
];

export default (props) => {
  const { dispatch, tableData, columnsData } = props;
  let mergeIndex = 0;
  columnsData.some((item, index) => {
    if (mergeColumns.includes(item.columnField)) {
      mergeIndex = index;
      return true;
    }
    return false;
  });
  const openCardManage = (data) => {
    superLayer(cardManage, {
      data: {
        title: '查看卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'depreciation',
        datail: data,
      },
      zIndex: 9,
      className: 'card-manage-layer',
    });
  };
  const openVoucher = (id) => {
    superLayer('voucher/record', {
      data: {
        voucherId: id,
        title: '记账凭证',
        disableCrossPeriod: true,
      },
      getVoucherIds: () => tableData.filter((v) => !!v.voucherId).map((v) => v.voucherId),
      onSave(data) {
        this.saveData = data;
      },
      onDestroy() {
        if (this.saveData) {
          dispatch({ type: 'queryDetailData', payload: 'accruedAsset' });
        }
        this.saveData = undefined;
      },
    });
  };
  // 查看详情
  const openDetail = async (record) => {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      openCardManage({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };
  // 对于特殊字段值进行处理
  const transformText = (type, text, record) => {
    switch (type) {
      case 'assetCode': // 资产编号
        return (
          // eslint-disable-next-line
          <a onClick={() => openDetail(record)}>
            <TableCell>{text}</TableCell>
          </a>
        );
      case 'isLocked': // 清理状态
        if (record.key < record.maxlength) {
          return text ? (
            <TableCell type="node">
              <span className="lock-tip lock-error">已锁定</span>
            </TableCell>
          ) : (
            <TableCell type="node">
              <span className="lock-tip">未锁定</span>
            </TableCell>
          );
        }
        return '';
      case 'ageLimit':
      case 'addDate':
      case 'accountPeriod':
      case 'buyDate':
      case 'quantity':
      case 'remainingRatio':
        return <TableCell>{text || ''}</TableCell>;
      case 'depreciationMethod': // 折旧状态
        if (text) {
          //   eslint-disable-next-line
          return text === 1 ? (
            <TableCell>年限平均法</TableCell>
          ) : text === 2 ? (
            <TableCell>双倍余额递减法</TableCell>
          ) : (
            <TableCell>年数总和法</TableCell>
          );
        }
        return '';
      case 'createTime':
        return <TableCell>{text && moment(text).format('YYYY-MM-DD')}</TableCell>;
      case 'voucherCode':
        return text ? (
          <a onClick={() => openVoucher(record.voucherId)}>
            <TableCell>{text}</TableCell>
          </a>
        ) : (
          ''
        );
      default:
        return (
          <TableCell
            type={typeof text === 'number' ? 'number' : 'text'}
            showZero={typeof text === 'number'}
          >
            {text}
          </TableCell>
        );
    }
  };
  const newColumns = [
    {
      title: '行次',
      dataIndex: 'key',
      align: 'center',
      width: 50,
      minWidth: 26,
      render: (text, record) => {
        if (record.key >= record.maxlength) {
          return {
            children: <TableCell>合计</TableCell>,
            props: {
              colSpan: mergeIndex + 1,
            },
          };
        }
        return <TableCell>{text}</TableCell>;
      },
    },
  ];
  columnsData.forEach((item, index) => {
    if (item.columnField === 'thisMonthDepreciate') {
      newColumns.push({
        title: item.columnName,
        dataIndex: item.columnField,
        width: item.width,
        align: item.align,
        editable: window.inAuth(165),
        minWidth: 26,
        onDoubleClick: (e) => {
          e.stopPropagation();
        },
        render: (text, record) => {
          if (index < mergeIndex) {
            if (record.key >= record.maxlength) {
              return {
                props: {
                  colSpan: 0,
                },
              };
            }
            return <TableCell>{util.toFixed(text, 2)}</TableCell>;
          }
          return <TableCell>{util.toFixed(text, 2)}</TableCell>;
        },
        editRender: (e) => {
          return (
            <NumberInput
              {...e}
              precision={2}
              min={0}
              max={9999999.99}
              styleName="number-input"
              onFocus={(event) => {
                event.target.setSelectionRange(0, event.target.value.length);
              }}
            />
          );
          // return <Input {...e} style={{ textAlign: 'right' }} onChange={handleChange} />;
        },
      });
    } else {
      newColumns.push({
        title: item.columnName,
        dataIndex: item.columnField,
        width: item.width,
        minWidth: 26,
        align: item.align,
        render: (text, record) => {
          if (index < mergeIndex) {
            if (record.key >= record.maxlength) {
              return {
                props: {
                  colSpan: 0,
                },
              };
            }
            return transformText(item.columnField, text, record);
          }
          return transformText(item.columnField, text, record);
        },
      });
    }
  });
  return newColumns;
};
