import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, message, Icon } from 'antd';
import { Layout, Content, Center, Right, Head, Left, Title } from '@/Layout';
import Period from '@/Period';
import More from './More';
import Table from './Table';
import { currentPeriodExtendOneYear } from '../../../billmanage/originalVocucher/common';
import initPeriod from '../../../../../public/initPeriod';
import { ConfirmModal } from '@/modal';
import ImportModal from './ImportModal';
import ShowNew from './showNew';
import '../styles/index.less';

// const CheckboxGroup = Checkbox.Group;

const Main = (props) => {
  const {
    dispatch,
    selectedRows,
    selectedRowKeys,
    currentYear,
    currentMonth,
    period,
    query,
    tableData,
    disableButton,
    voucherLoading,
    showImportBtn,
  } = props;
  const { endDate } = query;
  const newData = [...tableData];
  newData.splice(-1, 1);
  // const currentPeriod =
  //   currentMonth < 10 ? `${currentYear}-0${currentMonth}` : `${currentYear}-${currentMonth}`;
  const periods = currentPeriodExtendOneYear(period, currentYear, currentMonth);
  const createVoucher = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要生成凭证的卡片');
      return;
    }
    if (
      selectedRows.every((item) => {
        return item.isCreated;
      })
    ) {
      message.warning('所选卡片均已生成凭证');
      return;
    }
    dispatch({
      type: 'createVoucher',
      payload: { type: 4, fixedAssetIdList: selectedRowKeys },
    });
  };
  const handleLockEvent = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要操作的卡片');
      return;
    }
    if (
      selectedRows.every((item) => {
        return item.isLocked;
      })
    ) {
      message.warning('所选卡片均已锁定');
      return;
    }
    ConfirmModal({
      title:
        '锁定本月折旧后，下个月会按照手动修改的值继续计提折旧，直到提完折旧。想恢复系统自动计算的结果，可以取消锁定。',
      onOk: () => {
        dispatch({ type: 'lock', payload: { fixedAssetIds: selectedRowKeys.join(',') } });
      },
    });
    // let checkBox = null;
    // const isShowTips = window.localStorage.getItem('depreciationTips');
    // if (isShowTips !== '1') {
    //   Modal.warn({
    //     title:
    //       '锁定本月折旧后，下个月会按照手动修改的值继续计提折旧，直到提完折旧。想恢复系统自动计算的结果，可以取消锁定。',
    //     centered: true,
    //     width: 614,
    //     className: 'warn-tips',
    //     content: (
    //       <CheckboxGroup
    //         ref={(ref) => {
    //           checkBox = ref;
    //         }}
    //       >
    //         <Checkbox value={1}>下次不再提示</Checkbox>
    //       </CheckboxGroup>
    //     ),
    //     onOk: async () => {
    //       const {
    //         state: { value },
    //       } = checkBox;
    //       if (value.length >= 1) {
    //         window.localStorage.setItem('depreciationTips', 1);
    //       } else {
    //         window.localStorage.setItem('depreciationTips', 0);
    //       }
    //       dispatch({ type: 'lock', payload: { fixedAssetIds: selectedRowKeys.join(',') } });
    //     },
    //   });
    // } else {
    //   dispatch({ type: 'lock', payload: { fixedAssetIds: selectedRowKeys.join(',') } });
    // }
  };
  const checkPriod = (e) => {
    if (!period.includes(e.endDate)) {
      ConfirmModal({
        title: '所选期间尚未开账，是否确认开账',
        icon: <Icon type="exclamation-circle" theme="filled" />,
        centered: true,
        width: 360,
        onOk: () => {
          initPeriod(undefined, e.endDate, (layerInst) => {
            layerInst.hide();
            const newParams = [...period];
            newParams.push(e.endDate);
            dispatch({ type: 'account/updateState', payload: { period: newParams } });
            // dispatch({
            //   type: 'setState',
            //   payload: { query: { startDate: e.beginDate, endDate: e.endDate } },
            // });
            dispatch({ type: 'queryDetailData' });
          });
        },
        onCancel: () => {
          dispatch({
            type: 'setState',
            payload: {
              query: {
                startDate: endDate,
                endDate,
              },
            },
          });
        },
      });
    } else {
      // dispatch({
      //   type: 'setState',
      //   payload: { query: { startDate: e.beginDate, endDate: e.endDate } },
      // });
      dispatch({ type: 'queryDetailData', payload: 'accruedAsset' });
    }
  };
  const handlePriodChange = (e) => {
    if (
      newData.some((item) => {
        return !item.isCreated;
      }) &&
      e.endDate > query.endDate
    ) {
      ConfirmModal({
        title: '本月尚有未生成凭证的卡片，是否确定直接计提次月折旧？',
        icon: <Icon type="exclamation-circle" theme="filled" />,
        centered: true,
        width: 398,
        onOk: () => {
          checkPriod(e);
        },
        onCancel: () => {
          dispatch({
            type: 'setState',
            payload: {
              query: {
                startDate: endDate,
                endDate,
              },
            },
          });
        },
      });
    } else {
      checkPriod(e);
    }
  };
  return (
    <Layout>
      <div className="depreciation">
        <Head>
          <Left>
            <Period className="newGuide12" limit periods={periods} onChange={handlePriodChange} />
            {window.inAuth(164) && <ShowNew />}
          </Left>
          <Center>
            <Title />
          </Center>
          <Right>
            {window.inAuth(165) && (
              <Button
                disabled={disableButton || tableData.length < 1}
                type="primary"
                onClick={createVoucher}
                loading={voucherLoading}
              >
                生成凭证
              </Button>
            )}
            {window.inAuth(165) && (
              <Button
                style={{ width: '66px' }}
                type="primary"
                ghost
                className="e-ml12"
                disabled={tableData.length < 1 || disableButton}
                onClick={handleLockEvent}
              >
                锁定
              </Button>
            )}
            {showImportBtn && <ImportModal className="e-ml12" />}
            {(window.inAuth(164) || window.inAuth(165)) && <More disableButton={disableButton} />}
          </Right>
        </Head>
        <Content>
          <div styleName="depreciation">
            <Table />
          </div>
        </Content>
      </div>
    </Layout>
  );
};

Main.defaultProps = {
  disableButton: undefined,
  voucherLoading: undefined,
};

Main.propTypes = {
  dispatch: PropTypes.func.isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  currentYear: PropTypes.number.isRequired,
  currentMonth: PropTypes.number.isRequired,
  period: PropTypes.arrayOf(PropTypes.any).isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  disableButton: PropTypes.bool,
  voucherLoading: PropTypes.bool,
  showImportBtn: PropTypes.bool.isRequired,
};

export default connect(
  (
    { selectedRows, selectedRowKeys, query, tableData, voucherLoading, showImportBtn, columnsData },
    { account: { period, currentYear, currentMonth } },
  ) => ({
    selectedRows,
    selectedRowKeys,
    query,
    tableData,
    voucherLoading,
    showImportBtn,
    columnsData,
    period,
    currentYear,
    currentMonth,
  }),
)(Main);
