import React, { useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Icon, Modal, message } from 'antd';
import util from 'util';
import Upload from '@/Upload';
import img from './upload.png';
import './index.less';
import Confirm from '../../../card/components/More/Confirm';

const ImportModal = (props) => {
  const { className, dispatch, isShowNew } = props;
  const [isShowImportModal, setIsShowImportModal] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const uploadRef = useRef(null);
  const uploadProps = {
    accept: '.xlsx,.xls',
    url: 'fixedasset/importDepreciation',
    onChange: (e) => {
      const file = e.target.files[0];
      if (file) {
        if (!file.name.includes('.xlsx') && !file.name.includes('.xls')) {
          setErrorMsg(
            <>
              <Icon type="exclamation-circle" theme="filled" />
              文件格式错误，请检查后重新上传！
            </>,
          );
          setError(true);
          return false;
        }
        if (file.size > 20 * 1024 * 1024) {
          setErrorMsg(
            <>
              <Icon type="exclamation-circle" theme="filled" />
              文件过大，请将文件大小控制在20M内！
            </>,
          );
          setError(true);
          return false;
        }
        if (file.size <= 0) {
          setErrorMsg(
            <>
              <Icon type="exclamation-circle" theme="filled" />
              文件不可用，请检查后重新上传！
            </>,
          );
          setError(true);
          return false;
        }
        setUploadFile(file);
        setError(false);
        setErrorMsg('');
      }
      return true;
    },
    onError: (err) => {
      message.error(err && err.message);
    },
    onEnd: (res) => {
      if (res) {
        const { reasonList, firstRow, failAllRow, status } = res.data || {};
        if (status === 'fail') {
          // 失败时处理
          if (reasonList.length === 1) {
            setUploadFile(null);
            setErrorMsg(reasonList[0]);
            setError(true);
          } else if (reasonList.length > 1) {
            Confirm({
              title: '导入',
              children: (
                <>
                  {reasonList &&
                    reasonList.map((item, i) => {
                      // 超过9条特殊处理
                      if (i > 8) {
                        return <p key={item}>...</p>;
                      }
                      if (i > 9) {
                        return false;
                      }
                      if (i < 8) {
                        return <p key={item}>{item}</p>;
                      }
                      return false;
                    })}
                  <p>请重新上传。</p>
                </>
              ),
              errorMsg: ` 第${firstRow}行等${failAllRow}行内容不符合要求，请检查后重新上传`,
            });
            setUploadFile(null);
            setErrorMsg(` 第${firstRow}行等${failAllRow}行内容不符合要求，请检查后重新上传`);
            setError(true);
          }
        } else if (status === 'success') {
          // 成功时处理
          message.success('导入成功！');
          setIsShowImportModal(false);
          dispatch({ type: 'queryDetailData' });
        } else {
          message.error(res.data.message || '导入失败！');
          setIsShowImportModal(false);
          dispatch({ type: 'queryDetailData' });
        }
      }
    },
  };
  const reset = () => {
    setUploadFile(null);
    setError(false);
    setErrorMsg('');
  };
  const handleShowImportModal = () => {
    setIsShowImportModal(true);
    reset();
  };
  const handleOkEvent = async () => {
    await uploadRef.current.upload();
  };
  const handleDownloadFile = () => {
    util.submit(
      'fixedasset/downloadDepreciationTemplate',
      { type: isShowNew ? 1 : 0 },
      '_blank',
      'download',
    );
  };
  return (
    <>
      {window.inAuth(165) && (
        <Button className={className} type="primary" ghost onClick={handleShowImportModal}>
          导入
        </Button>
      )}
      <Modal
        width={600}
        title="导入"
        visible={isShowImportModal}
        centered
        destroyOnClose
        maskClosable={false}
        okText="导入"
        onCancel={() => {
          setIsShowImportModal(false);
        }}
        onOk={handleOkEvent}
      >
        <div styleName="upload-area">
          {/* eslint-disable-next-line */}
          <Upload {...uploadProps} ref={uploadRef}>
            {uploadFile ? (
              <div styleName="upload-success">
                <span styleName="upload-excel" />
                {uploadFile.name}
                <a
                  onClick={(e) => {
                    e.stopPropagation();
                    uploadRef.current.clearInput();
                    setUploadFile(null);
                  }}
                >
                  <Icon type="close" />
                </a>
              </div>
            ) : (
              <div styleName="upload-content">
                {!error && (
                  <div>
                    <img src={img} alt="点我上传" style={{ marginBottom: '8px' }} />
                    <div>
                      <Button type="primary">点我上传</Button>
                    </div>
                  </div>
                )}
                {error && (
                  <div>
                    <div styleName="upload-error">{errorMsg}</div>
                    <Button type="primary" ghost>
                      重新上传
                    </Button>
                  </div>
                )}
              </div>
            )}
          </Upload>
          <div styleName="upload-font">
            <div>
              <span> 支持20M内扩展名为.xls、.xlsx、.csv的文件，</span>
              <br />
              或使用
              <span styleName="download-text" onClick={handleDownloadFile}>
                计提折旧导入模板.xls
              </span>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
};

ImportModal.defaultProps = {
  className: '',
  isShowNew: false,
};

ImportModal.propTypes = {
  className: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
  isShowNew: PropTypes.bool,
};

export default connect(({ isShowNew }) => ({ isShowNew }))(ImportModal);
