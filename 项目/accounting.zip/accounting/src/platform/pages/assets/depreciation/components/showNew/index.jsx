import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Checkbox } from 'antd';

const ShowNew = (props) => {
  const { dispatch, isShowNew } = props;
  const handleChange = (e) => {
    dispatch({ type: 'isShowThisMonthDepreciation', payload: e.target.checked });
  };
  return (
    <>
      <Checkbox checked={isShowNew} onChange={handleChange} style={{ marginLeft: '20px' }}>
        展示本月新增的固定资产
      </Checkbox>
    </>
  );
};

ShowNew.propTypes = {
  dispatch: PropTypes.func.isRequired,
  isShowNew: PropTypes.bool.isRequired,
};

export default connect(({ isShowNew }) => ({ isShowNew }))(ShowNew);
