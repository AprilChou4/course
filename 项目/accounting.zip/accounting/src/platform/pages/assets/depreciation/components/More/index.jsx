import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Dropdown, Menu, Icon, Button, message, Modal } from 'antd';
import ExportButton from '@/buttons/ExportButton';
import PrintButton from '@/buttons/PrintButton';
import CustomColumns from '@/CustomizeColumns';
import { ConfirmModal } from '@/modal';
import './index.less';

const More = (props) => {
  const {
    selectedRows,
    dispatch,
    selectedRowKeys,
    tableData,
    disableButton,
    query,
    isShowNew,
    isCheckOut,
    currentDate,
    columnsData,
    treeData,
  } = props;
  const handleCnacelLocking = async () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要操作的卡片');
      return;
    }
    if (
      selectedRows.every((item) => {
        return !item.isLocked;
      })
    ) {
      message.warning('所选卡片均未锁定');
      return;
    }
    dispatch({ type: 'unlock', payload: { fixedAssetIds: selectedRowKeys.join(',') } });
  };
  const handleCoveryDepreciation = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要操作的卡片');
      return;
    }
    ConfirmModal({
      title: '你确定要恢复默认折旧吗？',
      centered: true,
      onOk: () => {
        dispatch({
          type: 'recoveryDefaultDepreciation',
          payload: { fixedAssetIdList: selectedRowKeys, period: query.endDate },
        });
      },
    });
  };
  const handleInitColumns = () => {
    dispatch({ type: 'initDepreciationColumn' });
  };
  const handleUpdateColumns = (params) => {
    dispatch({ type: 'updateDepreciationColumn', payload: { defineColumnBOs: params } });
  };
  const menu = (
    <Menu>
      {window.inAuth(165) && !isCheckOut && query.endDate >= currentDate && (
        <Menu.Item>
          <Button onClick={handleCoveryDepreciation}>恢复默认折旧</Button>
        </Menu.Item>
      )}
      {window.inAuth(165) && (
        <Menu.Item>
          <Button onClick={handleCnacelLocking}>取消锁定</Button>
        </Menu.Item>
      )}

      {window.inAuth(164) && (
        <Menu.Item>
          <PrintButton
            url="fixedasset/print/printDepreciationCard"
            params={{ period: query.endDate, type: isShowNew ? 1 : 0 }}
          />
        </Menu.Item>
      )}
      {window.inAuth(164) && (
        <Menu.Item>
          <ExportButton
            url="fixedasset/voucher/exportDepreciationAssetList"
            params={{ period: query.endDate, type: isShowNew ? 1 : 0 }}
          />
        </Menu.Item>
      )}
      {window.inAuth(164) && (
        <Menu.Item>
          <CustomColumns
            initColumns={handleInitColumns}
            updateColumns={handleUpdateColumns}
            columnsData={columnsData}
            treeData={treeData}
            fixedField="资产编码"
          />
        </Menu.Item>
      )}
    </Menu>
  );
  return (
    <>
      {tableData.length < 1 || disableButton ? (
        <Button type="primary" ghost style={{ width: 80, marginLeft: 12 }} disabled>
          更多 <Icon type="down" />
        </Button>
      ) : (
        <Dropdown
          overlayClassName="depreciation-more"
          className="e-ml12"
          overlay={menu}
          trigger={['click']}
        >
          <Button type="primary" ghost style={{ width: 80 }} className="ui-bor-blue">
            更多 <Icon type="down" />
          </Button>
        </Dropdown>
      )}
    </>
  );
};

More.defaultProps = {
  disableButton: undefined,
};

More.propTypes = {
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  disableButton: PropTypes.bool,
  isCheckOut: PropTypes.bool.isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  isShowNew: PropTypes.bool.isRequired,
  currentDate: PropTypes.string.isRequired,
  columnsData: PropTypes.arrayOf(PropTypes.any).isRequired,
  treeData: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default connect(
  (
    { selectedRows, selectedRowKeys, tableData, query, isShowNew, columnsData, treeData },
    { account: { isCheckOut, currentDate } },
  ) => ({
    selectedRows,
    selectedRowKeys,
    tableData,
    query,
    isShowNew,
    columnsData,
    treeData,
    isCheckOut,
    currentDate,
  }),
)(More);
