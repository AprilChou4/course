import React from 'react';
import Main from './components';
import Effects from './effects';

export default {
  render() {
    return <Main />;
  },
  state: {
    // 选中得id
    selectedRowKeys: [],
    // 选中的数据
    selectedRows: [],
    // 表格数据
    tableData: [],
    loading: false,
    voucherLoading: false,
    showImportBtn: false,
    // 是否展示本月新增的固定资产
    // eslint-disable-next-line no-unneeded-ternary
    isShowNew: false,
    // 是否展示自定义列
    isShowCustomColumns: false,
    // 选中的自定义列头
    columnsData: [],
    // 所有的自定义列头
    treeData: [],
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  effects() {
    return new Effects(this);
  },
  onInit() {
    this.store.dispatch({ type: 'init' });
  },
};
