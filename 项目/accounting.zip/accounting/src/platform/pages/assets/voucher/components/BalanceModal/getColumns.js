import React from 'react';
import TableCell from '@/TableCell';

export default () => {
  return [
    {
      title: '项目',
      dataIndex: 'project',
      width: 118,
      align: 'center',
      render: (text) => {
        // eslint-disable-next-line
        return <TableCell>{text}</TableCell>;
      },
    },
    {
      title: '固定资产卡片',
      dataIndex: 'card',
      width: 136,
      align: 'right',
      className: 'th-center',
      render: (text) => {
        return <TableCell type="number">{text}</TableCell>;
      },
    },
    {
      title: '总账',
      dataIndex: 'total',
      width: 136,
      align: 'right',
      className: 'th-center',
      render: (text) => {
        return <TableCell type="number">{text}</TableCell>;
      },
    },
    {
      title: '差额',
      dataIndex: 'difference',
      width: 136,
      align: 'right',
      className: 'th-center',
      render: (text) => {
        return <TableCell type="number">{text}</TableCell>;
      },
    },
  ];
};
