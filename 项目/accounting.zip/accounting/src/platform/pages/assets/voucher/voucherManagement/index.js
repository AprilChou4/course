import React from 'react';
import MainDetail from './components';
import Main from '../../depreciation/components';
import Effects from '../effects';

export default {
  render() {
    const {
      data: { type },
    } = this;
    return type !== 'accruedAsset' ? (
      // eslint-disable-next-line
      <div className="voucher-management">
        {/* eslint-disable-next-line */}
        <MainDetail {...this.data} />
      </div>
    ) : (
      <div className="voucher-management">
        {/* eslint-disable-next-line */}
        <Main {...this.data} />
      </div>
    );
  },
  state: {
    // 选中得id
    selectedRowKeys: [],
    // 选中的数据
    selectedRows: [],
    // 表格数据
    tableData: [],
    loading: false,
    type: undefined,
    showImportBtn: false,
    isShowNew: false,
    // 是否展示自定义列
    isShowCustomColumns: false,
    // 选中的自定义列头
    columnsData: [],
    // 所有的自定义列头
    treeData: [],
  },
  effects() {
    return new Effects(this);
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  onInit() {
    this.store.dispatch({ type: 'initDetail' });
  },
};
