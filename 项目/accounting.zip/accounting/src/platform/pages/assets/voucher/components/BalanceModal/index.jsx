import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal } from 'antd';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';
import './index.less';

const BalanceModal = (props) => {
  const { isShowBalanceModal, dispatch, balanceData, query } = props;
  const { endDate } = query;
  const columns = getColumns();
  return (
    <Modal
      visible={isShowBalanceModal}
      width={580}
      centered
      maskClosable={false}
      onCancel={() => {
        dispatch({ type: 'setState', payload: { isShowBalanceModal: false } });
      }}
      footer={null}
      wrapClassName="balance-modal"
      title="固定资产对账"
    >
      <div className="tips">固定资产卡片与总账不一致，请仔细核对</div>
      <SuperTable
        columns={columns}
        dataSource={balanceData}
        pagination={false}
        bordered
        rowKey={(record, index) => index + 1}
      />
      <div className="item">可检查本期（{endDate}）变动、清理、新增是否均生成凭证。</div>
    </Modal>
  );
};

BalanceModal.propTypes = {
  isShowBalanceModal: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  balanceData: PropTypes.arrayOf(PropTypes.any).isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ isShowBalanceModal, balanceData, query }) => ({
  isShowBalanceModal,
  balanceData,
  query,
}))(BalanceModal);
