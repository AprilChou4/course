/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Card, Button } from 'antd';
import { superLayer } from 'layer';
import VoucherManagement from '../../voucherManagement';

const ContentCard = (props) => {
  const {
    newAsset,
    changeAsset,
    clearAsset,
    accruedAsset,
    dispatch,
    query,
    vochuerLoading,
    accounting,
    isShowNew,
  } = props;

  const isZhengFu = inAuth([14, 15], 'accounting');

  const isCountry = inAuth([16], 'accounting');

  const CardData = [
    {
      title: '固定资产新增',
      type: 'newAsset',
      debit_title: '固定资产',
      credit_title: '银行存款',
      link_detail: 'findNewFixedAsset',
      link_detail_path: 'assets/find',
      link_detail_text: '清单',
      link_generate: 'createNewAssetVoucher',
      link_generate_disabled: !newAsset,
      vocuherType: 1,
    },
    {
      title: '固定资产变动',
      type: 'changeAsset',
      debit_title: '固定资产',
      credit_title: (() => {
        if (inAuth([6, 7], 'accounting')) return '应收款项';
        if (isZhengFu) return '银行存款';
        if (inAuth([16], 'accounting')) return '银行存款';
        return '应收账款';
      })(),
      link_detail: 'findChangedFixedAsset',
      link_detail_path: 'assets/find',
      link_detail_text: '清单',
      link_generate: 'createChangeAssetVoucher',
      link_generate_disabled: !changeAsset,
      vocuherType: 2,
    },
    {
      title: '固定资产清理',
      type: 'clearAsset',
      debit_title: isZhengFu ? ['资产处置费用', '固定资产累计折旧'] : ['固定资产清理', '累计折旧'],
      credit_title: '固定资产',
      link_detail: 'findClearFixedAsset',
      link_detail_path: 'assets/find',
      link_detail_text: '清单',
      link_generate: 'createClearAssetVoucher',
      link_generate_disabled: !clearAsset,
      vocuherType: 3,
    },
    {
      title: '计提折旧',
      type: 'accruedAsset',
      debit_title: isZhengFu ? '业务活动费用' : isCountry ? '待摊投资' : '管理费用',
      credit_title: isZhengFu ? '固定资产累计折旧' : '累计折旧',
      link_detail: '',
      link_detail_path: 'assets/depreciation',
      link_detail_text: '清单',
      link_generate: 'genDepreciationVoucher',
      link_generate_disabled: !accruedAsset,
      vocuherType: 4,
    },
  ];
  const linkGenetate = (type) => {
    dispatch({ type: 'setState', payload: { vochuerLoading: type } });
    dispatch({ type: 'createVoucher', payload: { type } });
  };
  const linkDetail = (data) => {
    if (window.inAuth(167)) {
      superLayer(VoucherManagement, {
        data: {
          ...data,
          isShowNew: data.vocuherType === 4 ? inAuth([14, 15], 'accounting') : false,
          endDate: query.endDate,
        },
        zIndex: 9,
        onChange(e) {
          dispatch({ type: 'updateFlagState', payload: e });
        },
        onDestroy() {
          dispatch({ type: 'validate' });
        },
      });
    }
  };
  return (
    <div className="ui-tmp">
      <div className="ui-tmp-rq">
        {CardData.map((item, key) => {
          const index = key;
          const newItem = [item.debit_title];
          const trem = item;
          typeof trem.debit_title === 'string' && (trem.debit_title = newItem);
          return (
            <Card className="ui-tmp-card e-ml0" title={<span>{trem.title}</span>} key={index}>
              <div className="f-lh24">
                <span>借：</span>
                <span className="f-dib w120 f-vat">
                  {trem.debit_title.map((title, k) => {
                    const i = k;
                    return (
                      <span key={i} className="f-dib w120">
                        {title}
                      </span>
                    );
                  })}
                </span>
                <a
                  className="f-cblue f-fr"
                  onClick={() => {
                    linkDetail(trem);
                  }}
                >
                  {trem.link_detail_text}
                </a>
              </div>
              <div className="f-lh24">
                <span>贷：</span>
                <span className="f-dib w120">{trem.credit_title}</span>
              </div>
              {window.inAuth(168) && (
                <div
                  className={trem.link_generate_disabled ? 'disable-btn ui-btn-rq' : 'ui-btn-rq'}
                >
                  {window.inAuth(168) && (
                    <Button
                      type="primary"
                      ghost
                      url={trem.link_generate}
                      onClick={() => {
                        linkGenetate(trem.vocuherType);
                      }}
                      disabled={trem.link_generate_disabled}
                      loading={vochuerLoading === trem.vocuherType}
                    >
                      生成凭证
                    </Button>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};
ContentCard.propTypes = {
  newAsset: PropTypes.bool.isRequired,
  changeAsset: PropTypes.bool.isRequired,
  clearAsset: PropTypes.bool.isRequired,
  accruedAsset: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  vochuerLoading: PropTypes.bool.isRequired,
  accounting: PropTypes.number.isRequired,
  isShowNew: PropTypes.bool.isRequired,
};
export default connect(
  (
    { newAsset, changeAsset, clearAsset, accruedAsset, query, vochuerLoading, isShowNew },
    { account: { accounting } },
  ) => ({
    newAsset,
    changeAsset,
    clearAsset,
    accruedAsset,
    query,
    vochuerLoading,
    isShowNew,
    accounting,
  }),
)(ContentCard);
