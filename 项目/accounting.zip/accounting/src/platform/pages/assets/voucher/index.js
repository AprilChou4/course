import React from 'react';
import Main from './components';
import Effects from './effects';

export default {
  render() {
    return <Main />;
  },
  state: {
    newAsset: false,
    changeAsset: false,
    clearAsset: false,
    accruedAsset: false,
    isShowBalanceModal: false,
    isLock: false,
    balanceData: [],
    vochuerLoading: false,
    isShowNew: false,
  },
  effects() {
    return new Effects(this);
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  onInit() {
    this.store.dispatch({ type: '$init' });
  },
};
