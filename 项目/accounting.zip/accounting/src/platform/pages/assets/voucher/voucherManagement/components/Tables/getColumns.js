import React from 'react';
import { superLayer } from 'layer';
import { message } from 'antd';
import TableCell from '@/TableCell';
import services from '../../../../card/services';
import cardManage from '../../../../card/cardManage';

export default (props) => {
  const { dispatch, type, tableData } = props;
  // const maxLength = tableData.length - 1;
  const openVoucher = (id) => {
    superLayer('voucher/record', {
      data: {
        voucherId: id,
        title: '记账凭证',
        disableCrossPeriod: true,
      },
      getVoucherIds: () => tableData.filter((v) => !!v.voucherId).map((v) => v.voucherId),
      onSave(data) {
        this.saveData = data;
      },
      onDestroy() {
        if (this.saveData) {
          dispatch({ type: 'queryDetailData', payload: type });
        }
      },
    });
  };
  // 查看详情
  const openCardManage = (data) => {
    superLayer(cardManage, {
      data: {
        title: '查看卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'voucher',
        datail: data,
      },
      zIndex: 9,
      className: 'card-manage-layer',
    });
  };
  const openDetail = async (record) => {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      openCardManage({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  };
  return {
    newAsset: [
      {
        title: '行次',
        dataIndex: 'key',
        align: 'center',
        width: 50,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 6,
              },
              // eslint-disable-next-line
              children: <TableCell>合计</TableCell>,
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '资产编码',
        dataIndex: 'assetCode',
        align: 'center',
        width: 92,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return (
            <a
              onClick={() => {
                openDetail(record);
              }}
            >
              <TableCell>{text}</TableCell>
            </a>
          );
        },
      },
      {
        title: '资产名称',
        dataIndex: 'assetName',
        align: 'left',
        width: 136,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '规格型号',
        dataIndex: 'assetModel',
        align: 'center',
        width: 110,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '开始使用日期',
        dataIndex: 'buyDate',
        align: 'center',
        width: 116,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '使用年限（月）',
        dataIndex: 'ageLimit',
        align: 'center',
        width: 116,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '原值',
        dataIndex: 'originalValue',
        align: 'right',
        width: 126,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '期初累计折旧',
        dataIndex: 'totalDepreciate',
        align: 'right',
        width: 126,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '月折旧额',
        dataIndex: 'monthDepreciate',
        align: 'right',
        width: 126,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '期初资产净值',
        dataIndex: 'netWorth',
        align: 'right',
        width: 126,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '凭证号',
        dataIndex: 'voucherCode',
        align: 'center',
        width: 122,
        minWidth: 26,
        render: (text, record) => {
          if (record.voucherId) {
            return (
              <a
                onClick={() => {
                  openVoucher(record.voucherId);
                }}
              >
                <TableCell>{text}</TableCell>
              </a>
            );
          }
          return '';
        },
      },
    ],
    changeAsset: [
      {
        title: '行次',
        dataIndex: 'key',
        align: 'center',
        width: 50,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 5,
              },
              children: <TableCell>合计</TableCell>,
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '资产编码',
        dataIndex: 'assetCode',
        align: 'center',
        width: 92,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return (
            <a
              onClick={() => {
                openDetail(record);
              }}
            >
              <TableCell>{text}</TableCell>
            </a>
          );
        },
      },
      {
        title: '资产名称',
        dataIndex: 'assetName',
        align: 'left',
        width: 136,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '规格型号',
        dataIndex: 'assetModel',
        align: 'center',
        width: 136,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '开始使用日期',
        dataIndex: 'buyDate',
        align: 'center',
        width: 100,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '变动前原值',
        dataIndex: 'originalValueBeforeChange',
        align: 'center',
        width: 114,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '变动前累计折旧',
        dataIndex: 'totalDepreciateBeforeChange',
        align: 'right',
        width: 148,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '变动后原值',
        dataIndex: 'originalValueAfterChange',
        align: 'center',
        width: 112,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '变动后累计折旧',
        dataIndex: 'totalDepreciateAfterChange',
        align: 'center',
        width: 100,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '凭证号',
        dataIndex: 'voucherCode',
        align: 'center',
        width: 106,
        minWidth: 26,
        render: (text, record) => {
          if (record.voucherId) {
            return (
              <a
                onClick={() => {
                  openVoucher(record.voucherId);
                }}
              >
                <TableCell>{text}</TableCell>
              </a>
            );
          }
          return '';
        },
      },
    ],
    clearAsset: [
      {
        title: '行次',
        dataIndex: 'key',
        align: 'center',
        width: 50,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 5,
              },
              children: <TableCell>合计</TableCell>,
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '资产编码',
        dataIndex: 'assetCode',
        align: 'center',
        width: 92,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return (
            <a
              onClick={() => {
                openDetail(record);
              }}
            >
              <TableCell>{text}</TableCell>
            </a>
          );
        },
      },
      {
        title: '资产名称',
        dataIndex: 'assetName',
        align: 'left',
        width: 136,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '规格型号',
        dataIndex: 'assetModel',
        align: 'center',
        width: 136,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '开始使用日期',
        dataIndex: 'buyDate',
        align: 'center',
        width: 100,
        minWidth: 26,
        render: (text, record) => {
          if (record.key >= record.maxlength) {
            return {
              props: {
                colSpan: 0,
              },
            };
          }
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '清理原值',
        dataIndex: 'clearedOriginalValue',
        align: 'right',
        width: 114,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '清理累计折旧',
        dataIndex: 'clearedTotalDepreciate',
        align: 'right',
        width: 148,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '资产净值',
        dataIndex: 'clearedNetWorth',
        align: 'right',
        width: 112,
        minWidth: 26,
        render: (text) => {
          return (
            <TableCell type="number" showZero>
              {text}
            </TableCell>
          );
        },
      },
      {
        title: '清理原因',
        dataIndex: 'remark',
        align: 'center',
        width: 100,
        minWidth: 26,
        render: (text) => {
          return <TableCell>{text}</TableCell>;
        },
      },
      {
        title: '凭证号',
        dataIndex: 'voucherCode',
        align: 'center',
        width: 106,
        minWidth: 26,
        render: (text, record) => {
          if (record.voucherId) {
            return (
              <a
                onClick={() => {
                  openVoucher(record.voucherId);
                }}
              >
                <TableCell>{text}</TableCell>
              </a>
            );
          }
          return '';
        },
      },
    ],
  };
};
