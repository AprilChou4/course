import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';
import './index.less';

const Tables = (props) => {
  const { tableData, selectedRowKeys, dispatch, selectedRows, loading, type } = props;
  const columns = type && getColumns(props)[type];
  const rowSelection = {
    selectedRowKeys,
    selectedRows,
    columnWidth: '54px',
    onChange: (keys, rows) => {
      dispatch({
        type: 'setState',
        payload: { selectedRows: rows, selectedRowKeys: keys },
      });
    },
    getCheckboxProps: (record) => {
      return {
        disabled: record.key === tableData.length,
        style: {
          display: record.key === tableData.length ? 'none' : 'block',
        },
      };
    },
  };
  const handleRow = (record) => {
    return {
      onDoubleClick: () => {
        if (record.key !== record.maxlength) {
          dispatch({ type: 'openDetailById', payload: record });
        }
      },
    };
  };
  return (
    <>
      {type && (
        <SuperTable
          loading={loading}
          className="voucher-detail"
          rowSelection={rowSelection}
          columns={columns}
          dataSource={tableData}
          pagination={false}
          scroll={{ x: 1130 }}
          rowKey={(record, index) =>
            type === 'changeAsset'
              ? record.assetChangeRecordId || index
              : record.fixedAssetId || index
          }
          bordered
          onRow={handleRow}
          dragCell
          minWidthCount={1130}
          id={`voucher-${type}`}
        />
      )}
    </>
  );
};

Tables.defaultProps = {
  type: '',
};

Tables.propTypes = {
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  loading: PropTypes.bool.isRequired,
  type: PropTypes.string,
};

export default connect(({ tableData, selectedRowKeys, selectedRows, loading, type }) => ({
  tableData,
  selectedRowKeys,
  selectedRows,
  loading,
  type,
}))(Tables);
