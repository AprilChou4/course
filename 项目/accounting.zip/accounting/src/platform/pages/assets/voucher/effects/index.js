import React from 'react';
import { BaseEffects } from 'effects';
import { superLayer } from 'layer';
import { message } from 'antd';
import services from '../services';
import cardManage from '../../card/cardManage';
import Confirm from '../../card/components/More/Confirm';

export default class Effects extends BaseEffects {
  setState(data) {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  }

  async $init() {
    await this.initPeriod();
    await this.validate();
  }

  async initDetail() {
    const {
      data: { type, endDate, isShowNew },
    } = this.nuomiProps;
    if (type === 'accruedAsset') {
      await this.getDepreciationColumnList();
      await this.isShowImportBtn();
    }
    // await this.initPeriod();
    this.setState({
      query: {
        startDate: endDate,
        endDate,
      },
    });
    await this.setState({ type, isShowNew });
    await this.queryDetailData(type);
  }

  async reset() {
    await this.setState({
      selectedRowKeys: [],
      selectedRows: [],
    });
  }

  async queryDetailData(type) {
    if (type === 'accruedAsset') {
      await this.isShowImportBtn();
    }
    await this.reset();
    const { query, isShowNew } = this.getState();
    const { endDate } = query;
    const params = {
      period: endDate,
    };
    this.setState({
      loading: true,
    });
    try {
      let res;
      switch (type) {
        case 'newAsset':
          res = await services.getNewAssetList(params);
          break;
        case 'changeAsset':
          res = await services.getChangedAssetList(params);
          break;
        case 'clearAsset':
          res = await services.getClearedAssetList(params);
          break;
        case 'accruedAsset':
          res = await services.getDepreciationAssetList({ ...params, type: isShowNew ? 1 : 0 });
          // this.nuomiProps.onChange(isShowNew);
          break;
        default:
          res = await services.getNewAssetList(params);
      }
      if (res.length <= 1) {
        res = [];
      }
      const maxlength = res.length;
      res.map((item, index) => {
        const trem = item;
        trem.key = index + 1;
        trem.maxlength = maxlength;
        return trem;
      });
      this.setState({
        tableData: res,
      });
    } catch (e) {
      console.log(e);
    } finally {
      this.setState({
        loading: false,
      });
    }
  }

  async tryJudgeAsset() {
    const { query } = this.getState();
    const { endDate } = query;
    const res = await services.tryJudgeAsset({ period: endDate });
    const { originalAmtResult, totalDepResult, result } = res;
    const item1 = {
      project: '原值',
      card: originalAmtResult.assetCardAmt,
      total: originalAmtResult.subjectBookAmt,
      difference: originalAmtResult.diffAmt,
    };
    const item2 = {
      project: '累计折旧',
      card: totalDepResult.assetCardAmt,
      total: totalDepResult.subjectBookAmt,
      difference: totalDepResult.diffAmt,
    };
    this.setState({
      balanceData: [item1, item2],
      isShowBalanceModal: !result,
    });
    if (result) {
      message.success('核对成功！');
    }
  }

  // 获取是否可以生成凭证
  async validate() {
    await this.initPeriod();
    const { query } = this.getState();
    const data = await services.validate({ period: query.endDate });
    this.setState({
      newAsset: data.newVoucherResult,
      changeAsset: data.changeVoucherResult,
      clearAsset: data.clearVoucherResult,
      accruedAsset: data.depreciateVoucherResult,
      isLock: data.isLock,
    });
  }

  // 生成凭证
  async createVoucher(params) {
    const voucherType = params.type;
    const { query } = this.getState();
    const newParams = { ...params, ...{ period: query.endDate } };
    delete newParams.type;
    let data;
    try {
      switch (voucherType) {
        case 1:
          data = await services.buildNewVoucher(newParams);
          break;
        case 2:
          data = await services.buildChangedVoucher(newParams);
          break;
        case 3:
          data = await services.buildClearedVoucher(newParams);
          break;
        case 4:
          // eslint-disable-next-line
          const res = await services.checkVoucher({ ...newParams, type: 1 });
          // eslint-disable-next-line
          const { status, afterPeriodChangeOrClearAsset, afterPeriodHaveVoucherAsset } = res;
          if (status === 'fail') {
            Confirm({
              title: '提示',
              errorMsg: '生成凭证失败。详细原因如下：',
              children: (
                // eslint-disable-next-line
                <>
                  {afterPeriodChangeOrClearAsset && afterPeriodChangeOrClearAsset.length > 0 && (
                    <>
                      <p style={{ marginBottom: '0px' }}>
                        以下固定资产卡片在后续期间存在变动或者清理记录，当期不允许计提折旧：
                      </p>
                      <ul style={{ paddingLeft: '1em' }}>
                        {afterPeriodChangeOrClearAsset.map((item, key) => {
                          const i = key;
                          return <li key={i}>{item}</li>;
                        })}
                      </ul>
                    </>
                  )}
                  {afterPeriodHaveVoucherAsset && afterPeriodHaveVoucherAsset.length > 0 && (
                    <>
                      <p style={{ marginBottom: '0px' }}>以下固定资产卡片后续期间有凭证生成：</p>
                      <ul style={{ paddingLeft: '1em' }}>
                        {afterPeriodHaveVoucherAsset.map((item, key) => {
                          const i = key;
                          return <li key={i}>{item}</li>;
                        })}
                      </ul>
                    </>
                  )}
                </>
              ),
            });
            return;
          }
          data = await services.buildDepreciationVoucher({ ...newParams, type: 1 });
          break;
        default:
          data = null;
      }
    } catch (e) {
      return;
    } finally {
      this.setState({
        vochuerLoading: false,
      });
    }
    const that = this;
    if (Array.isArray(data)) {
      data = data.map((v) => {
        const item = v;
        item.isInitSerialize = 0;
        return v;
      });
    } else {
      data.isInitSerialize = 0;
    }
    superLayer('voucher/record', {
      data: {
        title: '生成凭证',
        assetId: data[0].assetIdList.join(','),
        disableCrossPeriod: true,
      },
      isBack: false,
      renderData() {
        return data;
      },
      onDestroy() {
        that.validate();
        if (that.save) {
          const { type } = that.getState();
          if (type) {
            that.queryDetailData(type);
          } else {
            that.validate();
          }
        }
        that.save = undefined;
      },
      onSave(save) {
        that.save = save;
      },
    });
  }

  // 锁定
  async lock(params) {
    await services.lock(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 取消锁定
  async unlock(params) {
    await services.unlock(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 修改本月折旧
  async updateThisMonthDepreciate(params) {
    await services.updateThisMonthDepreciate(params);
    message.success('操作成功');
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  openCardManage(data) {
    this.initPeriod();
    superLayer(cardManage, {
      data: {
        title: '查看卡片',
        type: 1, // 0 为新增 1 为详情 2为编辑 3为修改
        pageType: 'depreciation',
        datail: data,
      },
      className: 'card-manage-layer',
    });
  }

  // 根据数据查看详情
  async openDetailById(record) {
    try {
      const res = await services.getLifeRecord({ assetId: record.fixedAssetId });
      this.openCardManage({ ...res, ...{ assetId: record.fixedAssetId } });
    } catch (e) {
      message.error(e.message || '获取详情失败');
    }
  }

  // 是否显示导入按钮
  async isShowImportBtn() {
    this.initPeriod();
    const { query } = this.getState();
    const { endDate } = query;
    const params = {
      period: endDate,
    };
    const data = await services.isShowImportBtn(params);
    this.setState({
      showImportBtn: data.showButton,
    });
  }

  // 跟新状态
  async updateFlagState(params) {
    await this.setState({
      isShowNew: params,
    });
  }

  // 是否显示本月折旧额
  async isShowThisMonthDepreciation(params) {
    await this.setState({
      isShowNew: params,
    });
    this.nuomiProps.onChange(params);
    const { type } = this.getState();
    this.queryDetailData(type);
  }

  // 获取自定义显示列数据
  async getDepreciationColumnList() {
    const data = await services.getDepreciationColumnList();
    const treeData = [];
    const keys = [];
    const columnsData = [];
    data.forEach((val, key) => {
      const index = keys.indexOf(val.contents);
      if (index === -1) {
        treeData.push({
          name: val.contents,
          columnName: val.contents,
          key: keys.length,
          children: [{ ...val, key }],
        });
        keys.push(val.contents);
      } else {
        treeData[index].children.push({ ...val, key });
      }
      if (val.isShow === 1) {
        columnsData.push({ ...val, key });
      }
    });
    this.setState({
      treeData,
      columnsData,
    });
  }

  // 恢复默认列头
  async initDepreciationColumn() {
    await services.initDepreciationColumnList();
    message.success('恢复成功！');
    this.getDepreciationColumnList();
    this.queryDetailData('accruedAsset');
  }

  // 更新自定义显示列
  async updateDepreciationColumn(params) {
    await services.updateDepreciationColumnList(params);
    message.success('操作成功！');
    this.getDepreciationColumnList();
    this.queryDetailData('accruedAsset');
  }

  // 本月折旧额恢复默认
  async recoveryDefaultDepreciation(params) {
    const data = await services.recoveryDefaultDepreciation(params);
    const {
      successNum,
      failNum,
      afterPeriodChangeOrClearAsset,
      afterPeriodHaveVoucherAsset,
      failInfo,
    } = data;
    if (failNum === 0) {
      Confirm({
        title: '提示',
        errorMsg: `恢复默认折旧成功${successNum}条!`,
        handleOk: () => {
          this.queryDetailData('accruedAsset');
        },
        onCancel: () => {
          this.queryDetailData('accruedAsset');
        },
      });
    } else {
      Confirm({
        title: '提示',
        errorMsg: `恢复默认折旧成功${successNum}条，失败${failNum}。详细原因如下：`,
        children: (
          // eslint-disable-next-line
          <>
            {afterPeriodChangeOrClearAsset && afterPeriodChangeOrClearAsset.length > 0 && (
              <>
                <p style={{ marginBottom: '0px' }}>
                  以下卡片在后续期间存在变动或清理记录，不允许恢复默认折旧：
                </p>
                <ul style={{ paddingLeft: '1em' }}>
                  {afterPeriodChangeOrClearAsset.map((item, key) => {
                    const i = key;
                    return <li key={i}>{item}</li>;
                  })}
                </ul>
              </>
            )}
            {afterPeriodHaveVoucherAsset && afterPeriodHaveVoucherAsset.length > 0 && (
              <>
                <p style={{ marginBottom: '0px' }}>以下卡片已生成折旧凭证，请删除凭证后重试：</p>
                <ul style={{ paddingLeft: '1em' }}>
                  {afterPeriodHaveVoucherAsset.map((item, key) => {
                    const i = key;
                    return <li key={i}>{item}</li>;
                  })}
                </ul>
              </>
            )}
            {failInfo && failInfo.length > 0 && (
              <>
                <p style={{ marginBottom: '0px' }}>其他原因：</p>
                <ul style={{ paddingLeft: '1em' }}>
                  {failInfo.map((item, key) => {
                    const i = key;
                    return <li key={i}>{item}</li>;
                  })}
                </ul>
              </>
            )}
          </>
        ),
        handleOk: () => {
          this.queryDetailData('accruedAsset');
        },
        onCancel: () => {
          this.queryDetailData('accruedAsset');
        },
      });
    }
  }
}
