import { util } from 'nuijs';

export default util.createRequest({
  validate: 'fixedasset/voucher/validate',
  buildNewVoucher: 'fixedasset/voucher/buildNewVoucher:postJSON',
  buildChangedVoucher: 'fixedasset/voucher/buildChangedVoucher:postJSON',
  buildClearedVoucher: 'fixedasset/voucher/buildClearedVoucher:postJSON',
  buildDepreciationVoucher: 'fixedasset/voucher/buildDepreciationVoucher:postJSON',
  tryJudgeAsset: 'fixedasset/voucher/check',
  getNewAssetList: 'fixedasset/voucher/getNewAssetList',
  getChangedAssetList: 'fixedasset/voucher/getChangedAssetList',
  getClearedAssetList: 'fixedasset/voucher/getClearedAssetList',
  getDepreciationAssetList: 'fixedasset/voucher/getDepreciationAssetList',
  lock: 'fixedasset/voucher/lock:post',
  unlock: 'fixedasset/voucher/unlock:post',
  updateThisMonthDepreciate: 'fixedasset/voucher/updateThisMonthDepreciate:postJSON',
  // 查询固定资产详情及其变动、禁用、启用记录
  getLifeRecord: 'fixedasset/card/getLifeRecord:post',
  isShowImportBtn: 'fixedasset/showImportButton:post',
  checkVoucher: 'fixedasset/voucher/buildDepreciationVoucherCheck:postJSON',
  // 获取自定义显示列
  getDepreciationColumnList: 'fixedasset/difineColumn/getAllDepreciationAssetColumn:post',
  // 更新自定义显示列
  updateDepreciationColumnList: 'fixedasset/difineColumn/upDepreciationAssetColumn:postJSON',
  // 恢复默认显示列
  initDepreciationColumnList: 'fixedasset/difineColumn/initDepreciationAssetColumn:post',
  // 本月折旧额恢复默认
  recoveryDefaultDepreciation: 'fixedasset/voucher/recoveryDefaultDepreciation:postJSON',
});
