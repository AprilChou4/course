import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Spin } from 'antd';
import { Layout, Head, Right, Center, Content, Title, Left } from '@/Layout';
import Period from '@/Period';
import ContentCard from './ContentCard';
import BalanceModal from './BalanceModal';
import '../style/index.less';

const Main = (props) => {
  const { isShowBalanceModal, dispatch, loadings } = props;
  const handleClick = () => {
    dispatch({ type: 'tryJudgeAsset' });
  };
  const handleChange = (e) => {
    const { beginDate, endDate } = e;
    dispatch({ type: 'setState', payload: { query: { startDate: beginDate, endDate } } });
    dispatch({ type: 'validate' });
  };
  return (
    <Layout>
      <Head>
        <Left>
          <Period limit onChange={handleChange} />
        </Left>
        <Center>
          <Title />
        </Center>
        <Right>
          {window.inAuth(169) && (
            <Button type="primary" onClick={handleClick}>
              核对总账
            </Button>
          )}
        </Right>
      </Head>
      <Content>
        <Spin spinning={loadings.$init}>
          <ContentCard />
        </Spin>
      </Content>
      {isShowBalanceModal && <BalanceModal />}
    </Layout>
  );
};

Main.propTypes = {
  isShowBalanceModal: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  loadings: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(({ isShowBalanceModal, loadings }) => ({ isShowBalanceModal, loadings }))(
  Main,
);
