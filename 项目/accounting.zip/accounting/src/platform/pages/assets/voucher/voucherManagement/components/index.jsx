import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, message } from 'antd';
import { Layout, Head, Left, Center, Right, Title, Content } from '@/Layout';
import Period from '@/Period';
import Tables from './Tables';
import '../../style/index.less';
import endDate from '../../../../../public/components/buttons/GenerateBooksButton/index';

const MainDetail = (props) => {
  const {
    selectedRows,
    dispatch,
    type,
    selectedRowKeys,
    tableData,
    currentYear,
    currentMonth,
    query,
  } = props;
  const newData = [...tableData];
  newData.splice(-1, 1);
  let typeName = '';
  let voucherType;
  switch (type) {
    case 'newAsset':
      voucherType = 1;
      typeName = '新增';
      break;
    case 'changeAsset':
      voucherType = 2;
      typeName = '变动';
      break;
    case 'clearAsset':
      voucherType = 3;
      typeName = '清理';
      break;
    case 'accruedAsset':
      voucherType = 4;
      typeName = '折旧';
      break;
    default:
      typeName = '新增';
      voucherType = 1;
  }
  const currentPeriod =
    currentMonth < 10 ? `${currentYear}-0${currentMonth}` : `${currentYear}-${currentMonth}`;
  const handleVoucher = () => {
    if (selectedRows.length <= 0) {
      message.warning('请选择需要生成凭证的卡片');
      return;
    }
    if (
      selectedRows.every((item) => {
        return item.isCreated;
      })
    ) {
      message.warning('所选卡片均已生成凭证');
      return;
    }
    const parmas =
      voucherType === 2
        ? {
            type: voucherType,
            fixedAssetIdList: selectedRowKeys,
          }
        : {
            type: voucherType,
            fixedAssetIdList: selectedRowKeys,
          };
    dispatch({
      type: 'createVoucher',
      payload: parmas,
    });
  };
  const handleChange = () => {
    // dispatch({
    //   type: 'setState',
    //   payload: { query: { startDate: e.beginDate, endDate: e.endDate } },
    // });
    dispatch({ type: 'queryDetailData', payload: type });
  };
  return (
    <Layout>
      <Head>
        <Left>
          <span>
            {typeName}期间：
            <Period limit onChange={handleChange} />
          </span>
        </Left>
        <Center>
          <Title />
        </Center>
        <Right>
          {window.inAuth(168) && (
            <Button
              type="primary"
              onClick={handleVoucher}
              disabled={
                tableData.length <= 0 ||
                newData.every((item) => {
                  return item.isCreated;
                }) ||
                query.endDate !== currentPeriod
              }
            >
              生成凭证
            </Button>
          )}
        </Right>
      </Head>
      <Content>
        <div styleName="voucher-create">
          <Tables />
        </div>
      </Content>
    </Layout>
  );
};
MainDetail.defaultProps = {
  type: '',
};
MainDetail.propTypes = {
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  type: PropTypes.string,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  tableData: PropTypes.arrayOf(PropTypes.any).isRequired,
  currentYear: PropTypes.number.isRequired,
  currentMonth: PropTypes.number.isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default connect(
  (
    { selectedRows, type, selectedRowKeys, tableData, query },
    { account: { currentYear, currentMonth } },
  ) => ({
    selectedRows,
    type,
    selectedRowKeys,
    tableData,
    query,
    currentYear,
    currentMonth,
  }),
)(MainDetail);
