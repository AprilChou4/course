import defaultProps from '../entryInvoice';

export default {
  ...defaultProps,
  state: {
    ...defaultProps.state,
    invoiceType: 'vat',
  },
};
