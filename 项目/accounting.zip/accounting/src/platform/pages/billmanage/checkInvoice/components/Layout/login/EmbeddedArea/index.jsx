import React from 'react';
import AreaCascader from '@/AreaCascader';

import './style.less';

class EmbeddedAreaCascader extends React.PureComponent {
  render() {
    const { labelName, ...rest } = this.props;

    return (
      <div styleName="embedded-cascader">
        {/* <AreaCascader {...rest} getPopupContainer={(triggerNode) => triggerNode.parentNode} /> */}
        <AreaCascader {...rest} />
        <span styleName="label-name">{labelName}</span>
      </div>
    );
  }
}

export default EmbeddedAreaCascader;
