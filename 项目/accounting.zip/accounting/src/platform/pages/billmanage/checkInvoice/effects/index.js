import moment from 'moment';
import { store } from 'nuomi';
import services from '../services';
import { dictionary } from '../utils';

export default {
  // pc端初始化
  async PCInit() {
    await this.queryCompanyInfo();
    const { taxNumber } = this.getState();
    // 如果没返回税号，就不往下执行了，弹窗提示
    if (!taxNumber) {
      this.updateEmptyTipModal({ visible: true });
      return;
    }

    await this.getTaxRzPeriod();
    this.getCheckStatistics();
    this.handleGetInvoiceInfo();
  },

  // 获取登陆企业信息
  async queryCompanyInfo() {
    const data = await services.queryCompanyInfo();
    const { gxrqfw, qylx, qysh, level } = data || {};
    this.updateState({
      gxrqfw,
      enterpriseType: qylx,
      taxNumber: qysh || '',
      taxerLevel: level,
    });
  },

  // 获取所属税期信息
  async getTaxRzPeriod() {
    const { taxNumber } = this.getState();
    const data = await services.getTaxRzPeriod({ taxNumber });
    const { ssq, jzssq } = data || {};
    this.updateState({
      rzPeriod: ssq ? moment(ssq, 'YYYYMM').format('YYYY-MM') : '',
      rzPeriodDeadline: ssq ? moment(jzssq, 'YYYYMMDD').format('YYYY-MM-DD') : '',
    });
  },

  // 查询发票信息
  handleGetInvoiceInfo() {
    // eslint-disable-next-line array-callback-return
    dictionary.invoiceType.list.map((item) => {
      this.getInvoiceInfo({ invoiceType: item.value });
    });
  },

  // 获取发票信息
  async getInvoiceInfo(payload = {}) {
    const { invoiceType } = payload;
    const { gxrqfw, taxNumber, rzPeriod } = this.getState();
    const gxrqfwArray = (gxrqfw || '').split('-');
    const startDate = gxrqfwArray?.[0];
    const endDate = gxrqfwArray?.[1];
    const data = await services.getInvoiceInfo({
      taxNumber,
      rzPeriod,
      startDate: startDate ? moment(startDate, 'YYYYMMDD').format('YYYY-MM-DD') : '',
      endDate: endDate ? moment(endDate, 'YYYYMMDD').format('YYYY-MM-DD') : '',
      ...payload,
    });
    const { size, taxTotal } = data || {};
    const dataIndex = dictionary.invoiceType.map[invoiceType]?.dataIndex;
    dataIndex &&
      this.updateInvoiceTypeDatas({
        [dataIndex]: { size, taxTotal },
      });
  },

  updateInvoiceTypeDatas(payload = {}) {
    const { invoiceTypeDatas } = this.getState();
    this.updateState({
      invoiceTypeDatas: { ...invoiceTypeDatas, ...payload },
    });
  },

  // 获取勾选统计信息
  async getCheckStatistics() {
    const { gxrqfw, taxNumber, rzPeriod, enterpriseType } = this.getState();
    const gxrqfwArray = (gxrqfw || '').split('-');
    const startDate = gxrqfwArray?.[0];
    const endDate = gxrqfwArray?.[1];
    const data = await services.getCheckStatistics({
      taxNumber,
      rzPeriod,
      isTs: +['外贸企业', '外综服企业'].includes(enterpriseType),
      startDate: startDate ? moment(startDate, 'YYYYMMDD').format('YYYY-MM-DD') : '',
      endDate: endDate ? moment(endDate, 'YYYYMMDD').format('YYYY-MM-DD') : '',
    });
    const { checkStatistics } = this.getState();
    const { xrow = [], ycolumn = {} } = data || {};
    this.updateState({
      checkStatistics: {
        ...checkStatistics,
        xrow,
        ycolumn,
      },
    });
  },

  // 空数据提示弹窗
  updateEmptyTipModal(payload = {}) {
    const { emptyTipModal } = this.getState();
    this.updateState({
      emptyTipModal: { ...emptyTipModal, ...payload },
    });
  },

  // 更新发票提示弹窗
  updateInvoiceTipModal(payload = {}) {
    const { invoiceTipModal } = this.getState();
    this.updateState({
      invoiceTipModal: { ...invoiceTipModal, ...payload },
    });
  },

  // 获取地区字符串
  async getAreaStr(payload) {
    const data = await services.getAreaStr(payload);
    return data || '';
  },

  // 获取登陆信息 客户端
  async getInputCheckLoginInfo(type) {
    const {
      account: { accountName },
    } = store.getState();
    const data = await services.getInputCheckLoginInfo();
    window.encryptJson = {
      ...(window.encryptJson || {}),
      ssoId: data.ssoToken,
      timestamp: data.time,
      userId: data.userId,
      companyName: accountName || '', // 企业名称 ()
      source: data.source,
      customerId: '', // 客户id
      texnum: data.taxNumber,
      gxPlatform: data.gxPlatform, // 版本（新老）
      companyType: data.companyType, // 企业类型
      areaCode: data.areaCode,
      location: data.location,
      cerPassword: data.cerPassword,
    };
    await new Promise((resolve) => {
      window.ExternService.CryptTaxNo({
        nsrsh: data.taxNumber,
        timestamp: `${data.time}`,
        complete: async (encryptData) => {
          const { guid, crypdata, timestamp } = JSON.parse(encryptData);
          console.log('加密返回值：', JSON.parse(encryptData));
          window.encryptJson = {
            ...(window.encryptJson || {}),
            time: timestamp,
            tokenId: guid,
            encTaxNum: crypdata,
          };
          resolve();
        },
      });
    });
    if (!type) {
      this.updateState({
        times: new Date().getTime(),
        showIframe: true,
      });
    }
    return window.encryptJson;
  },

  // 初始化页面
  async initData() {
    if (typeof ExternService === 'object') {
      await window.Gxpt.OnlineStatus({
        success: (data) => {
          console.log(JSON.stringify(data));
          console.log(data);
          this.updateState({
            isLogins: true,
          });
        },
        failed: (data) => {
          this.updateState({
            isLogins: false,
          });
          console.log(data);
        },
      });
      window.getUserData = async () => {
        // const returnData = await this.getInputCheckLoginInfo(1);
        // return returnData;
        return window.encryptJson;
      };
      // 第一次请求
      this.getInputCheckLoginInfo();
    } else {
      this.PCInit();
    }
  },
};
