import React, { useMemo } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Card, Col, Row } from 'antd';
import { dictionary } from '../../utils';
import Title from './Title';
import styles from './style.less';

const Header = ({ invoiceTypeDatas, dispatch }) => {
  const handleCardClick = usePersistFn(() => {
    dispatch({
      type: 'updateInvoiceTipModal',
      payload: { visible: true },
    });
  });

  const content = useMemo(
    () =>
      dictionary.invoiceType.list.map((item) => (
        <Col span={6} key={item.value}>
          <Card bordered={false} className={styles.card} onClick={handleCardClick}>
            <img src={item.data.img} alt={item.data.name} className={styles.img} />
            <div className={styles.content}>
              <div className={styles.title}>{item.data.name}</div>
              <div>增值税发票份数：</div>
              <div>
                <span className={styles.number}>{invoiceTypeDatas[item.data.dataIndex]?.size}</span>{' '}
                份
              </div>
              <div>增值税发票税额：</div>
              <div>
                <span className={styles.number}>
                  {invoiceTypeDatas[item.data.dataIndex]?.taxTotal}
                </span>{' '}
                元
              </div>
            </div>
          </Card>
        </Col>
      )),
    [handleCardClick, invoiceTypeDatas],
  );

  return (
    <>
      <Title />
      <Row gutter={12}>{content}</Row>
    </>
  );
};

export default connect(({ invoiceTypeDatas }) => ({ invoiceTypeDatas }))(Header);
