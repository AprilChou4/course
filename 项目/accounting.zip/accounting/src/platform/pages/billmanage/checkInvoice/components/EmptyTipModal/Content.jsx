import React from 'react';
import LinkButton from '@/LinkButton';
import styles from './style.less';

const Content = () => (
  <div className={styles.container}>
    <div>当前暂无数据，请按如下步骤操作</div>
    <div className={styles.tip}>
      <div>
        1. 下载“诺账通”客户端安装并登录，
        <LinkButton href="https://nnfw.jss.com.cn/诺诺云记账企业版.exe">点击下载</LinkButton>
      </div>
      <div>2. 进入账套，点击-发票管理-进项勾选</div>
      <div>3. 插入税盘登录使用，本页面即可展示数据</div>
    </div>
  </div>
);

export default Content;
