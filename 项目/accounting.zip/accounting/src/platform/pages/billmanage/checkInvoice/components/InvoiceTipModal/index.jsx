/**
 * 发票提示弹窗
 */
import React from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import AntdModal from '@/AntdModal';
import Content from './Content';

const InvoiceTipModal = ({ visible, dispatch }) => {
  const handleCancel = usePersistFn(() => {
    dispatch({
      type: 'updateInvoiceTipModal',
      payload: { visible: false },
    });
  });

  return (
    <AntdModal
      title="提示"
      width={320}
      getContainer={false}
      footer={null}
      visible={visible}
      onCancel={handleCancel}
    >
      <Content />
    </AntdModal>
  );
};

export default connect(({ invoiceTipModal: { visible } }) => ({
  visible,
}))(InvoiceTipModal);
