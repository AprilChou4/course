import React from 'react';
import { connect } from 'nuomi';
import Iconfont from '@/Icon';
import styles from './style.less';

const Title = ({ rzPeriod, rzPeriodDeadline, taxerLevel }) => (
  <div className={styles.container}>
    当前税款所属期间：<span className={styles.date}>{rzPeriod}</span>
    （勾选截至日期：{rzPeriodDeadline}）
    <div className={styles.tip}>
      <Iconfont type="tongzhi" />
      <span>亲，当前您可免费体验“进项勾选”功能！</span>
    </div>
    <div className={styles.level}>纳税人等级：{taxerLevel || '-'}</div>
  </div>
);

export default connect(({ rzPeriod, rzPeriodDeadline, taxerLevel }) => ({
  rzPeriod,
  rzPeriodDeadline,
  taxerLevel,
}))(Title);
