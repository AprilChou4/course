/**
 * @object 数据字典
 */
import notChecked from '../../images/invoice_not_checked.png';
import deducted from '../../images/invoice_deducted.png';
import nonDeductible from '../../images/invoice_non_deductible.png';
import exportTax from '../../images/invoice_export_tax.png';

const getData = (params) => {
  const map = {};
  params.list.forEach(({ value, name, label, data }) => {
    map[value] = data || name || label;
  });
  return { ...params, map };
};

// 1-抵扣，2-不抵扣，3-待抵扣，4-退税
const invoiceType = {
  title: '发票类型',
  list: [
    {
      value: 3,
      data: {
        name: '未勾选发票',
        dataIndex: 'notCheckedInvoice',
        img: notChecked,
      },
    },
    {
      value: 1,
      data: {
        name: '抵扣发票',
        dataIndex: 'deductedInvoice',
        img: deducted,
      },
    },
    {
      value: 2,
      data: {
        name: '不抵扣发票',
        dataIndex: 'nonDeductibleInvoice',
        img: nonDeductible,
      },
    },
    {
      value: 4,
      data: {
        name: '出口退税',
        dataIndex: 'exportTaxInvoice',
        img: exportTax,
      },
    },
  ],
};

export default {
  invoiceType: getData(invoiceType),
};
