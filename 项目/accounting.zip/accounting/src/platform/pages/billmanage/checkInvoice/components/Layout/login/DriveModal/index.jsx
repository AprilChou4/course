import React from 'react';
import { Modal, Button } from 'antd';
import { connect } from 'nuomi';

import './style.less';

const DriveModal = ({ visible, dispatch }) => {
  // 取消弹窗
  function onCancel() {
    dispatch({
      type: 'updateState',
      payload: {
        DriveModalVisible: false,
      },
    });
  }

  return (
    <Modal
      width="620px"
      title="驱动下载"
      visible={visible}
      onCancel={onCancel}
      centered
      wrapClassName="drive-download-modal"
      footer={false}
    >
      <div className="download-wrap">
        <div className="download-item">
          <h3>使用金税盘的企业</h3>
          <p>一、在开票机上使用本系统的用户</p>
          <a href="http://nnfw.jss.com.cn/E7DC8AF3E4594B2F84E4F87352C3E1B6/driver_jsp_01.rar">
            <Button type="primary" icon="download">
              驱动及安装手册下载
            </Button>
          </a>
          <p>二、不在开票机上使用本系统的用户</p>
          <a href="http://nnfw.jss.com.cn/DC62FBD36313486982F669E0A565CB04/driver_jsp_02.rar">
            <Button type="primary" icon="download">
              驱动及安装手册下载
            </Button>
          </a>
        </div>
        <div className="download-item">
          <h3>使用税控盘的企业</h3>
          <p>一、在开票机上使用本系统的用户</p>
          <a href="http://nnfw.jss.com.cn/577BCD639C72432B824E8CB6370EE5DE/driver_skp_01.rar">
            <Button type="primary" icon="download">
              驱动及安装手册下载
            </Button>
          </a>
          <p>二、不在开票机上使用本系统的用户</p>
          <a href="http://nnfw.jss.com.cn/3310E8F3A5DC4CE090B41042DC7FF447/driver_skp_02.rar">
            <Button type="primary" icon="download">
              驱动及安装手册下载
            </Button>
          </a>
        </div>
      </div>
    </Modal>
  );
};

export default connect(({ DriveModalVisible }) => ({
  visible: DriveModalVisible,
}))(DriveModal);
