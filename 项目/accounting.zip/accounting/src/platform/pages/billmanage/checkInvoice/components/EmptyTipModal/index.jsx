/**
 * 空数据提示弹窗
 */
import React from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import AntdModal from '@/AntdModal';
import Content from './Content';

const EmptyTipModal = ({ visible, dispatch }) => {
  const handleCancel = usePersistFn(() => {
    dispatch({
      type: 'updateEmptyTipModal',
      payload: { visible: false },
    });
  });

  return (
    <AntdModal
      title="提示"
      width={350}
      getContainer={false}
      footer={null}
      visible={visible}
      onCancel={handleCancel}
    >
      <Content />
    </AntdModal>
  );
};

export default connect(({ emptyTipModal: { visible } }) => ({
  visible,
}))(EmptyTipModal);
