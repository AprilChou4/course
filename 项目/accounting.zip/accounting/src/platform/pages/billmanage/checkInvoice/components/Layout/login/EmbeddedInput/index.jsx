import React from 'react';
import { Input } from 'antd';

import './style.less';

class EmbeddedInput extends React.PureComponent {
  render() {
    const { labelName, style, ...rest } = this.props;

    return (
      <div styleName="embedded-input" style={style}>
        <Input {...rest} autoComplete="off" />
        <span styleName="label-name">{labelName}</span>
      </div>
    );
  }
}

export default EmbeddedInput;
