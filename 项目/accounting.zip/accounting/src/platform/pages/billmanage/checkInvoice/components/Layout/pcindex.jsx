import React, { useRef } from 'react';
import { useSize } from 'ahooks';
import { connect } from 'nuomi';
import { Layout as ContentLayout } from '@/Layout';
import Header from '../Header';
import Content from '../Content';
import EmptyTipModal from '../EmptyTipModal';
import InvoiceTipModal from '../InvoiceTipModal';
import styles from './style.less';

const Layout = () => {
  const headerRef = useRef();
  const headerSize = useSize(headerRef);

  return (
    <ContentLayout>
      <div className={styles.header} ref={headerRef}>
        <Header />
      </div>
      <div style={{ height: `calc(100% - ${headerSize.height || 0}px)` }}>
        <Content />
      </div>
      <EmptyTipModal />
      <InvoiceTipModal />
    </ContentLayout>
  );
};

export default connect(({ showIframe }) => ({ showIframe }))(Layout);
