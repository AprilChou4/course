import React from 'react';
import { connect } from 'nuomi';
import Layout from './iframe';
import Login from './login';

const Main = ({ isLogins, userName }) => {
  if (isLogins === '') {
    return '';
  }
  return isLogins ? <Layout userName={userName} /> : <Login />;
};

export default connect(({ isLogins }) => ({ isLogins }))(Main);
