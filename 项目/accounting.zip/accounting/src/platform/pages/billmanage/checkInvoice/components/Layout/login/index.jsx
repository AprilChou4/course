import React, { useState } from 'react';
import { Modal, Form, Button, message, Spin } from 'antd';
import { connect } from 'nuomi';
import qs from 'qs';
import DriveModal from './DriveModal';
import EmbeddedInput from './EmbeddedInput';
import EmbeddedArea from './EmbeddedArea';
import './style.less';

let encryptJson = {};

const LoginModal = ({ showIframe, form, dispatch }) => {
  const [visible, setVisible] = useState(true);
  const editItem = window.encryptJson || {};
  console.log(editItem);
  console.log(showIframe);
  // 控制按钮、遮罩的loading
  const [loading, setLoading] = useState({ status: false, text: '' });

  // 关闭弹窗 isRedirect 代表是否是跳转前关闭，跳转前关闭不用重新请求列表
  const onCancel = () => {
    setVisible(false);
    // form.resetFields();
  };

  // 出错，取消loading
  const cancelLoading = (result) => {
    setLoading({ status: false });
    result && message.error(result);
  };

  // 3. 读取驱动检验u-key设备
  const promiseReadDrive = () => {
    return new Promise((resolve) => {
      let source = window.readTaxDevice('kingTax') || {};
      if (!source.corpCode) {
        source = window.readTaxDevice('taxDev');
      }
      if (source.corpCode && source.cmpName && source.crypdata && source.guid) {
        resolve(source);
        return;
      }
      window.Gxpt.check({
        // 插入USB-KEY
        success(data) {
          resolve(data);
        },
        // 没有插入USB-KEY
        failed() {
          resolve('');
          cancelLoading('请插入税盘/USBK认证');
        },
      });
    });
  };

  // 7.更新用户信息
  const updatePassword = async (password, areaCode) => {
    // const { tokenId, encTaxNum, ssoId, userId, companyName, source, time } = encryptJson;
    // const res = await dispatch({
    //   type: '$updatePassword',
    //   payload: {
    //     password,
    //     areacode: areaCode,
    //     encryptJson: {
    //       tokenId,
    //       encTaxNum,
    //       ssoId,
    //       userId,
    //       source,
    //       companyName,
    //       rzUser: pubData.get('userInfo_realName'),
    //       time,
    //     },
    //   },
    // });
    // cancelLoading();
    // if (!res) {
    //   message.err('更新口令出错！');
    //   return;
    // }
    onCancel(true);
    dispatch({
      type: 'updateState',
      payload: {
        isLogins: true,
      },
    });
    // window.top.location.href = `/cloud/invoice.html?${qs.stringify({ ...encryptJson, isFirst })}`;
  };

  // 6.更新跳转校验加密参数  透传 password, area.areaCode
  const validateEncryJson = async (password, areaCode) => {
    // 6.1 gxPlatform/companyType不存在时，也就是首次登陆，需要再次调用获取信息接口，拿到gxPlatform/companyType
    // if (typeof encryptJson.gxPlatform !== 'number') {
    //   console.log('[debugger:6.1] => gxPlatform/companyType不存在重新请求');
    //   const { gxPlatform, companyType } = await dispatch({
    //     type: '$updateGxPlatform',
    //   });
    //   encryptJson.gxPlatform = gxPlatform;
    //   encryptJson.companyType = companyType;
    // }
    // 6.2 跳转前需要再次请求getEncryption获取一遍time, 防止time过期
    // console.log('[debugger:6.2] => 再次调用客户端加密');
    // const res = await dispatch({
    //   type: '$getSsoToken',
    // });
    // 调用客户端加密
    // window.ExternService.CryptTaxNo({
    //   nsrsh: '',
    //   timestamp: `${res.timestamp}`,
    //   complete: (encryptData) => {
    //     const { guid, crypdata, timestamp } = JSON.parse(encryptData);
    //     console.log('加密返回值：', JSON.parse(encryptData));
    //     encryptJson = {
    //       ...encryptJson,
    //       tokenId: guid,
    //       time: timestamp,
    //       encTaxNum: crypdata,
    //       ssoId: res.token,
    //     };
    //     // 7.更新用户信息
    //     updatePassword(password, areaCode);
    //   },
    // });
  };

  // 5.客户端登录
  const clientLogin = async () => {
    setLoading({ text: '正在登录...', status: true });
    const { taxNo, password, area } = form.getFieldsValue();
    const areaString = await dispatch({
      type: 'getAreaStr',
      payload: {
        areaCode: area.areaCode,
      },
    });
    console.log('[debugger:5] => 获取到地区string ', areaString);
    if (!areaString) {
      cancelLoading('获取地区字符出错！');
      return;
    }
    const params = { taxNo, area: areaString, password };
    console.log('[debugger:5] => 调用客户端登录 ', params);
    window.Gxpt.login(JSON.stringify(params), {
      success() {
        console.log('[debugger:5] => 调用客户端登录成功');
        dispatch({
          type: 'updateState',
          payload: {
            isLogins: true,
          },
        });
        // 6.更新跳转校验加密参数  透传 password, area.areaCode
        // validateEncryJson(password, area.areaCode);
      },
      failed(data) {
        console.log('[debugger:5] => 调用客户端登录失败');
        cancelLoading(data);
      },
    });
  };

  // 4.请求接口获取跳转所需字段（单点登录token）
  const getSsoToken = async () => {
    // console.log('获取单点登录token');
    // const res = await dispatch({
    //   type: '$getSsoToken',
    // });
    // // 赋值加密，更新密码、跳转时需要
    // encryptJson = res;
    // // 调用客户端加密
    // console.log('获取必要字段', res);
    // if (!Object.keys(res).length) {
    //   cancelLoading('获取必要字段失败！');
    //   return;
    // }
    // console.log('调用客户端加密：', res.timestamp);
    // window.ExternService.CryptTaxNo({
    //   nsrsh: '',
    //   timestamp: `${res.timestamp}`,
    //   complete: (encryptData) => {
    //     const { guid, crypdata, timestamp } = JSON.parse(encryptData);
    //     console.log('加密返回值：', JSON.parse(encryptData));
    //     encryptJson = {
    //       ...encryptJson,
    //       time: timestamp,
    //       tokenId: guid,
    //       encTaxNum: crypdata,
    //     };
    //     // 5.客户端登录
    //     clientLogin();
    //   },
    // });
    clientLogin();
  };

  // 2. 判断是否匹配税号
  const judgeTaxNumber = () => {
    setLoading({ text: '正在检测税盘...', status: true });
    const data = JSON.stringify({
      nsrsh: editItem.texnum,
    });
    window.Ydk.open({
      data,
      success() {
        // 3. 读取驱动检验u-key设备
        promiseReadDrive().then((source) => {
          if (!source) return;
          // 4.请求接口获取跳转所需字段（单点登录的token）
          getSsoToken();
        });
      },
      failed(result) {
        if (
          // data === '未接入CA设备' ||
          result === '未找到对应设备' ||
          result === '未安装易代开(集中开票)' ||
          result === '缺少此税号设备信息，请先使用易代开(集中开票)扫描设备'
        ) {
          // 3. 读取驱动检验u-key设备
          promiseReadDrive().then((source) => {
            if (!source) return;
            // 4.请求接口获取跳转所需字段
            getSsoToken();
          });
        } else {
          cancelLoading(result);
        }
      },
    });
  };

  // 提交
  const onSubmit = () => {
    // 必须先保存企业税号
    form.validateFields((err) => {
      if (err) return;
      // 2.判断是否匹配税号
      judgeTaxNumber();
    });
  };

  // 展示驱动下载页面
  const showDriveModal = () => {
    dispatch({
      type: 'updateState',
      payload: {
        DriveModalVisible: true,
      },
    });
  };

  const { getFieldDecorator } = form;

  return (
    <>
      <Modal
        visible={visible}
        onCancel={() => onCancel()}
        centered
        wrapClassName="workbench-invoice-modal"
        footer={false}
        maskClosable={false}
      >
        <Spin tip={loading.text} spinning={loading.status}>
          <h1 className="title">勾选平台登录</h1>
          <Form>
            <Form.Item>
              {getFieldDecorator('customerName', {
                initialValue: editItem.companyName,
              })(<EmbeddedInput labelName="企业名称" readOnly />)}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('taxNo', {
                initialValue: editItem.texnum,
                rules: [
                  { required: true, message: '请完善统一社会信用代码' },
                  {
                    pattern: /^[a-zA-Z0-9]{15,20}$/,
                    message: '格式有误，须为15~20位数字、字母',
                  },
                ],
              })(
                <EmbeddedInput
                  labelName="统一社会信用代码"
                  placeholder="请输入信用代码"
                  readOnly={editItem.texnum}
                />,
              )}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('password', {
                rules: [
                  {
                    required: true,
                    pattern: /^[a-zA-Z0-9]{0,16}$/,
                    message: '请输入正确的证书口令',
                  },
                ],
                initialValue: editItem.cerPassword,
              })(<EmbeddedInput labelName="证书口令" placeholder="请输入证书口令" />)}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('area', {
                rules: [
                  {
                    validator(rule, value, callback) {
                      if (!value.areaCode) {
                        callback('请完善地区信息');
                        return;
                      }
                      callback();
                    },
                  },
                ],
                initialValue: {
                  areaName: editItem.areaCode ? editItem.location : '',
                  areaCode: editItem.areaCode,
                },
              })(<EmbeddedArea labelName="所在地区" placeholder="请选择所在地区" allowClear />)}
            </Form.Item>
            <Button
              type="primary"
              style={{ height: 40 }}
              block
              loading={loading.status}
              onClick={onSubmit}
            >
              登录
            </Button>
          </Form>
          <p className="drive-tip">
            如未安装驱动，请点击 <span onClick={showDriveModal}> 驱动下载</span>
          </p>
        </Spin>
      </Modal>
      <DriveModal />
    </>
  );
};

export default connect(({ showIframe }) => ({
  showIframe,
}))(Form.create()(LoginModal));
