import dictionary from './dictionary';

export { dictionary };
