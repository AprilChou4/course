/**
 * 进项勾选
 */
import React from 'react';
import Layout from './components/Layout';
import LayoutPc from './components/Layout/pcindex';
import effects from './effects';

export default {
  state: {
    // 是否已经登陆
    isLogins: '',
    times: new Date().getTime(),
    showIframe: false,
    gxrqfw: '', // 所属期勾选范围
    enterpriseType: '', // 企业类型
    taxNumber: '', // 企业税号
    taxerLevel: '', // 纳税人等级
    rzPeriod: '', // 所属期
    rzPeriodDeadline: '', // 所属期截止日期
    // 顶部发票信息
    invoiceTypeDatas: {
      // 未勾选发票
      notCheckedInvoice: {
        size: 0, // 数量（不包含缴款书）
        taxTotal: 0, // 税额合计
      },
      // 抵扣发票
      deductedInvoice: {
        size: 0, // 数量（不包含缴款书）
        taxTotal: 0, // 税额合计
      },
      // 不抵扣发票
      nonDeductibleInvoice: {
        size: 0, // 数量（不包含缴款书）
        taxTotal: 0, // 税额合计
      },
      // 出口退税
      exportTaxInvoice: {
        size: 0, // 数量（不包含缴款书）
        taxTotal: 0, // 税额合计
      },
    },
    // 勾选统计图表数据
    checkStatistics: {
      xrow: [], // x轴坐标
      ycolumn: {
        deuction: [], // 抵扣
        noDeduction: [], // 不抵扣
        taxRefund: [], // 退税
      },
    },
    // 空数据提示弹窗
    emptyTipModal: { visible: false },
    // 点击发票提示弹窗
    invoiceTipModal: { visible: false },
  },
  effects,
  render() {
    if (typeof ExternService === 'object') {
      return <Layout userName={this.location.pathname.replace('/billmanage', '')} />;
      // return <Layout />;
    }
    return <LayoutPc />;
  },
  onInit() {
    this.store.dispatch({ type: 'initData' });
  },
};
