import React from 'react';
import Qs from 'qs'; // qs 在安装 axios 后会自动安装
import { connect } from 'nuomi';
import { Layout as ContentLayout } from '@/Layout';

const Layout = ({ userName, showIframe, times }) => {
  // const times = new Date().getTime();
  console.log(times);
  const urlUserName =
    userName.indexOf('?') !== -1 ? `${userName}&times=${times}` : `${userName}?times=${times}`;
  return (
    <ContentLayout>
      {(window.encryptJson || showIframe) && (
        <iframe
          src={`/newinvoiceMicroService/?${Qs.stringify(window.encryptJson)}/#${urlUserName}`}
          title="gxpt"
          style={{ width: '100%', height: '100%' }}
        />
      )}
    </ContentLayout>
  );
};

export default connect(({ showIframe, times }) => ({ showIframe, times }))(Layout);
