import util from 'util';

export default util.createRequest({
  queryCompanyInfo: 'invoice/inputcheck/queryCompanyInfo', // 获取登陆企业信息
  getTaxRzPeriod: 'invoice/inputcheck/getTaxRzPeriod', // 获取所属税期信息
  getInvoiceInfo: 'invoice/inputcheck/getInvoiceInfo', // 获取发票信息
  getCheckStatistics: 'invoice/inputcheck/queryViewIndex', // 获取勾选统计信息
  getInputCheckLoginInfo: 'account/getInputCheckLoginInfo',
  getAreaStr: 'account/getAreaInfo:post', // 根据areaCode, 获取客户端所需要的字符串
  // batchAddAuxiliary: 'invoice/bill/batchAddAuxiliary:postJSON',
});
