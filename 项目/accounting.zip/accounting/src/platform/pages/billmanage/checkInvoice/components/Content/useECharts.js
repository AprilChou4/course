import { useEffect, useRef } from 'react';
import { usePersistFn, useSize } from 'ahooks';
// 引入 ECharts 主模块
import echarts from 'echarts/lib/echarts';
// 引入折线图
import 'echarts/lib/chart/line';
// 引入提示框和标题组件
import 'echarts/lib/component/title';

export default function useECharts(chartRef, config) {
  const chartInstance = useRef(null);
  const chartSize = useSize(chartRef);

  const renderChart = usePersistFn(() => {
    const renderedInstance = echarts.getInstanceByDom(chartRef.current);
    if (renderedInstance) {
      chartInstance.current = renderedInstance;
    } else {
      chartInstance.current = echarts.init(chartRef.current);
    }
    chartInstance.current.setOption(config);
  });

  useEffect(() => {
    renderChart();
    return () => {
      chartInstance.current?.dispose();
    };
  }, [config, renderChart, chartSize]);
}
