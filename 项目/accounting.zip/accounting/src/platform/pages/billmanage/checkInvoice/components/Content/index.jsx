import React, { useMemo, useRef } from 'react';
import { connect } from 'nuomi';
import currency from 'currency.js';
import useECharts from './useECharts';
import styles from './style.less';

const Chart = ({ checkStatistics }) => {
  const chartRef = useRef(null);

  const chartOption = useMemo(
    () => ({
      title: {
        text: '勾选统计',
        top: 10,
        left: 20,
      },
      legend: {
        top: 10,
        right: 30,
        data: ['抵扣', '不抵扣', '退税'],
      },
      tooltip: {
        trigger: 'axis',
        formatter(params) {
          let res = `${params?.[0]?.name}<br>`;
          params?.forEach?.((item) => {
            res += `<span style="display:inline-block; width:60px">${item?.marker}${
              item?.seriesName
            }</span>
            <span>${currency(item?.value || 0).format()} ${
              Number(item?.value) > 0 ? '万元' : '元'
            }</span><br>`;
          });
          return res;
        },
      },
      color: ['#5E92F6', '#FBAF63', '#60D7A7'],
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true,
      },
      toolbox: {
        feature: { saveAsImage: {} },
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: checkStatistics?.xrow || [],
      },
      yAxis: { type: 'value' },
      series: [
        {
          name: '抵扣',
          type: 'line',
          data: checkStatistics?.ycolumn?.deuction || [],
        },
        {
          name: '不抵扣',
          type: 'line',
          data: checkStatistics?.ycolumn?.noDeduction || [],
        },
        {
          name: '退税',
          type: 'line',
          data: checkStatistics?.ycolumn?.taxRefund || [],
        },
      ],
    }),
    [checkStatistics],
  );

  // 绘制图表
  useECharts(chartRef, chartOption);

  return <div className={styles.chart} ref={chartRef} />;
};

export default connect(({ checkStatistics }) => ({ checkStatistics }))(Chart);
