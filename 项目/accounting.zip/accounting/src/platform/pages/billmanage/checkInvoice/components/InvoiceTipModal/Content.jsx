import React from 'react';
import LinkButton from '@/LinkButton';
import styles from './style.less';

const Content = () => (
  <div className={styles.container}>
    <div>进项勾选更多操作，请前往诺账通客户端！</div>
    <div className={styles.tip}>
      还没安装客户端？
      <LinkButton href="https://nnfw.jss.com.cn/诺诺云记账企业版.exe">点击下载</LinkButton>
    </div>
  </div>
);

export default Content;
