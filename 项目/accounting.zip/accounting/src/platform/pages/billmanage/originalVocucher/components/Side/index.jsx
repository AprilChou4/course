import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Spin, Tree } from 'antd';

const { TreeNode } = Tree;

class Side extends React.Component {
  componentDidMount() {}

  select = (selectKeys, e) => {
    const { dispatch } = this.props;
    // 当前选中的是未整理的
    if (e.selected) {
      const [typeId] = selectKeys;
      dispatch({ type: 'setTableSearchParmas', payload: { typeId } });
    }
    dispatch({ type: '$queryTableData' });
  };

  renderTree = (data) => {
    return data.map((v) => {
      return (
        <TreeNode
          title={
            <span>
              <em>{v.name}</em>
              {v.count > 0 && <b className="count">{v.count}</b>}
            </span>
          }
          key={v.id}
        >
          {!!v.children.length && this.renderTree(v.children)}
        </TreeNode>
      );
    });
  };

  render() {
    const { treeData, loadings } = this.props;
    return (
      <div className="side">
        <Spin spinning={loadings.$queryTreeData}>
          <h3>业务分类</h3>
          <div className="tree">
            {treeData.length > 0 && (
              <Tree
                showLine
                onSelect={this.select}
                onExpand={this.expand}
                defaultExpandedKeys={['0']}
                defaultSelectedKeys={['-2']}
              >
                {this.renderTree(treeData)}
              </Tree>
            )}
          </div>
        </Spin>
      </div>
    );
  }
}
Side.defaultProps = {
  treeData: [],
  loadings: {},
};
Side.propTypes = {
  treeData: PropTypes.arrayOf(PropTypes.any),
  loadings: PropTypes.objectOf(PropTypes.any),
  dispatch: PropTypes.func.isRequired,
};
export default connect((state) => state)(Side);
