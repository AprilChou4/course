import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Checkbox } from 'antd';
import Item from './Item';

class List extends React.Component {
  checked = () => {
    const { originalVoucherResultList, checkedIds } = this.props;
    return originalVoucherResultList.every((v) => {
      return checkedIds.indexOf(v.originalId) !== -1;
    });
  };

  handleChange = (e) => {
    const { originalVoucherResultList, checkedIds, dispatch } = this.props;
    const checkeds = [].concat(checkedIds);
    if (e.target.checked) {
      originalVoucherResultList.forEach((v) => {
        if (!checkeds.includes(v.originalId)) {
          checkeds.push(v.originalId);
        }
      });
    } else {
      originalVoucherResultList.forEach((v) => {
        const index = checkeds.indexOf(v.originalId);
        if (index !== -1) {
          checkeds.splice(index, 1);
        }
      });
    }
    dispatch({ type: 'setChecked', payload: checkeds });
  };

  render() {
    const { originalVoucherResultList, uploadDate } = this.props;
    return (
      <dl className="list">
        <dt>
          <Checkbox checked={this.checked()} onChange={this.handleChange}>
            {uploadDate}
          </Checkbox>
        </dt>
        {originalVoucherResultList.length && (
          <dd>
            {originalVoucherResultList.map((v) => {
              return <Item key={v.originalId} data={v} />;
            })}
          </dd>
        )}
      </dl>
    );
  }
}
List.defaultProps = {
  originalVoucherResultList: [],
  uploadDate: '',
};
List.propTypes = {
  originalVoucherResultList: PropTypes.arrayOf(PropTypes.any),
  checkedIds: PropTypes.arrayOf(PropTypes.any).isRequired,
  uploadDate: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect((state) => state)(List);
