import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Checkbox, Spin } from 'antd';
import List from './List';

class Table extends React.Component {
  checked = () => {
    const { voucherData, checkedIds } = this.props;
    if (!voucherData.length) {
      return false;
    }
    return voucherData.every((item) => {
      return item.originalVoucherResultList.every((v) => {
        return checkedIds.indexOf(v.originalId) !== -1;
      });
    });
  };

  handleCheckChange = (e) => {
    const { voucherData, dispatch } = this.props;
    let checkeds = [];
    if (e.target.checked) {
      voucherData.forEach((item) => {
        item.originalVoucherResultList.forEach((v) => {
          checkeds.push(v.originalId);
        });
      });
    } else {
      checkeds = [];
    }
    dispatch({ type: 'setChecked', payload: checkeds });
  };

  handeClick = () => {
    const {
      tableSearchParams: { order },
      dispatch,
    } = this.props;
    dispatch({ type: 'setTableSearchParmas', payload: { order: !order ? 1 : 0 } });
    dispatch({ type: '$queryTableData' });
  };

  render() {
    const {
      voucherData,
      tableSearchParams: { order },
      loadings,
    } = this.props;
    return (
      <div className="table-main">
        <Spin spinning={loadings.$queryTableData}>
          <div className="title">
            <div className="f-fl">
              <Checkbox checked={this.checked()} onChange={this.handleCheckChange}>
                全选
              </Checkbox>
            </div>
            <div className="f-fr">
              <a className="f-cblue" onClick={this.handeClick}>
                上传日期
                <i className={!order ? 'iconfont icon-up' : 'iconfont icon-down1'} />
              </a>
            </div>
          </div>
          <div className="wrap">
            {voucherData.length ? (
              <>
                {voucherData.map((v) => {
                  // eslint-disable-next-line
                  return <List key={v.uploadDate} {...v} />;
                })}
              </>
            ) : (
              <span className="ui-void" />
            )}
          </div>
        </Spin>
      </div>
    );
  }
}
Table.defaultProps = {
  loadings: {},
};
Table.propTypes = {
  voucherData: PropTypes.arrayOf(PropTypes.any).isRequired,
  checkedIds: PropTypes.arrayOf(PropTypes.any).isRequired,
  tableSearchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  loadings: PropTypes.objectOf(PropTypes.any),
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ voucherData, tableSearchParams, loadings, checkedIds }) => ({
  voucherData,
  tableSearchParams,
  loadings,
  checkedIds,
}))(Table);
