import React, { Component } from 'react';
import Proptypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { Tabs } from 'antd';
import { util } from 'nuijs';
import Icon from '@/Icon';

const { TabPane } = Tabs;

class Detail extends Component {
  state = {
    show: false,
  };

  toggle = () => {
    const { show } = this.state;
    this.setState({
      show: !show,
    });
  };

  render() {
    const { show } = this.state;
    const { data, paths, currentIndex, UnitItem, nuomiProps, globalStore } = this.props;
    const {
      account: { quantityPrecision, unitPricePrecision },
    } = globalStore;
    const currentPath = paths[currentIndex];
    const attDetail = currentPath ? currentPath.attachDetailList : [];
    const size = paths.length;
    return (
      <div className={show ? 'detail' : ''}>
        <a onClick={this.toggle} className="f-pr" style={{ top: -3 }}>
          <b className="f-cblue">{show ? '收起' : '展开'}详细信息</b>
          <Icon
            type={show ? 'xialafuben-copy' : 'xialafuben'}
            className="f-vam f-fs14"
            style={{ marginLeft: 3 }}
          />
        </a>
        <div style={{ display: show ? 'block' : 'none' }}>
          {size > 1 && (
            <>
              <Tabs
                activeKey={currentIndex.toString()}
                onChange={(key) => {
                  nuomiProps.slider.carousel.goTo(Number(key));
                }}
                animated={false}
                size="small"
                style={{ marginBottom: 10 }}
              >
                {paths.map((v, i) => {
                  const key = i;
                  return <TabPane tab={`发票${i + 1}`} key={key} />;
                })}
              </Tabs>
              {UnitItem}
            </>
          )}
          <table className="ui-table nobg">
            <thead>
              <tr>
                <th width="33.33%">不含税金额</th>
                <th width="33.33%">税额</th>
                <th>价税合计</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="f-tar">
                  <span className="f-toe" title={util.toFixed(data.exMoney || 0, 2)} />
                </td>
                <td className="f-tar">
                  <span className="f-toe" title={util.toFixed(data.taxMoney || 0, 2)} />
                </td>
                <td className="f-tar">
                  <span className="f-toe" title={util.toFixed(data.money || 0, 2)} />
                </td>
              </tr>
            </tbody>
          </table>
          {!!attDetail.length && (
            <div className="detailTable">
              {attDetail.map((v, i) => {
                const key = i;
                return (
                  <table className="ui-table" key={key}>
                    <thead>
                      <tr>
                        <th colSpan={3} style={{ textAlign: 'left' }}>
                          <span className="f-toe" title={`货物商品:${v.detailName}`} />
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td width="60">
                          <span className="f-toe" title={`单位:${v.detailUnit}`} />
                        </td>
                        <td width="95">
                          <span
                            className="f-toe"
                            title={`数量:${util.toFixed(
                              v.detailNum,
                              quantityPrecision,
                              quantityPrecision,
                            )}`}
                          />
                        </td>
                        <td>
                          <span
                            className="f-toe"
                            title={`单价:${util.toFixed(
                              v.detailPrice,
                              unitPricePrecision,
                              unitPricePrecision,
                            )}`}
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                );
              })}
            </div>
          )}
        </div>
      </div>
    );
  }
}
Detail.defaultProps = {
  data: {},
  paths: [],
  currentIndex: 0,
};
Detail.propTypes = {
  data: Proptypes.object,
  paths: Proptypes.array,
  currentIndex: Proptypes.number,
  UnitItem: Proptypes.any.isRequired,
  nuomiProps: Proptypes.object.isRequired,
  globalStore: Proptypes.object.isRequired,
};
export default connect((state, globalStore) => ({ ...state, globalStore }))(withNuomi(Detail));
