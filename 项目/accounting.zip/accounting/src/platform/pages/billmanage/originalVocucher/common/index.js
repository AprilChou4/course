/**
 * @param { str: 待处理的参数 }
 * @param { count: 保留的位数}
 */
const preZero = function (str, count) {
  return `${str}`.padStart(count, '0');
};
/**
 *
 * @param {会计区间} period
 * @param {当前会计区间 年} currentYear
 * @param {当前会计区间 月} currentMonth
 */
const currentPeriodExtendOneYear = (period, currentYear, currentMonth) => {
  const index = period.indexOf(`${currentYear}-${preZero(currentMonth, 2)}`) + 1;
  let maxDates = period.slice(0, index);
  let year = currentYear;
  let month = currentMonth;
  for (let i = 0; i < 12; i += 1) {
    month += 1;
    if (month === 13) {
      month -= 12;
      year += 1;
    }
    maxDates = [...maxDates, `${year}-${preZero(month, 2)}`];
  }
  return maxDates;
};
/**
 * 获取当前会计区间一年的日期
 * @param {当前会计区间 年} currentYear
 */
const currentYearPeriod = (currentYear) => {
  const Dates = [];
  const year = currentYear;
  for (let i = 1; i <= 12; i++) {
    Dates.push(`${year}-${preZero(i, 2)}`);
  }
  return Dates;
};

export {
  preZero, // 前导 0
  currentPeriodExtendOneYear, //
  currentYearPeriod,
};
