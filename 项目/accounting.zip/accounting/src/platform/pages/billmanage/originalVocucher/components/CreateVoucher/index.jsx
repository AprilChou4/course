import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { Button, message } from 'antd';
import { util } from 'nuijs';
import { formLayer, superLayer } from 'layer';
import ChooseForm from './ChooseForm';

const CreateVoucher = (props) => {
  const {
    dispatch,
    dispatchAll,
    checkedIds,
    selectDate,
    type,
    ghost,
    nuomiProps,
    detailQuery,
    save,
    isCheckOut,
  } = props;
  let res;
  const getLocal = () => {
    const originalVoucherGenerate = JSON.parse(
      localStorage.getItem('originalVoucherGenerate') || '{}',
    );
    const accountToken = util.getParam('id', `/${window.location.search}`);
    if (!originalVoucherGenerate[accountToken]) {
      originalVoucherGenerate[accountToken] = {};
    }
    return {
      accountToken,
      originalVoucherGenerate,
    };
  };
  const [originalVoucherGenerated, setOriginalVocherGenerate] = useState(
    getLocal().originalVoucherGenerate[getLocal().accountToken].type || '0',
  );
  const showOriginalVoucherGenerate = () => {
    const { accountToken, originalVoucherGenerate } = getLocal();
    if (originalVoucherGenerate[accountToken].show !== false) {
      return true;
    }
    return false;
  };
  const openVocher = (data) => {
    let isSaveSuccess = false;
    superLayer('voucher/record', {
      data: {
        title: '生成凭证',
        originalId: data[0].originalId,
        isBillManage: true,
      },
      isBack: false,
      renderData() {
        data.forEach((val) => {
          const v = val;
          v.isInitSerialize = 0;
        });
        return data;
      },
      onSave(parmas) {
        res = parmas;
        isSaveSuccess = true;
      },
      onDestroy() {
        if (type) {
          nuomiProps.isSave = true;
          const params = !isSaveSuccess
            ? {
                ...detailQuery,
                originalIds: checkedIds.join(','),
                typeId: Number(detailQuery.typeId) === -2 ? '' : detailQuery.typeId,
              }
            : {
                startDate: res.voucherDate.slice(0, 7) || detailQuery.startDate,
                endDate: res.voucherDate.slice(0, 7) || detailQuery.endDate,
                typeId: Number(detailQuery.typeId) === -2 ? '' : detailQuery.typeId,
                order: detailQuery.order,
                originalIds: checkedIds.join(','),
              };
          dispatch({ type: '$queryDetail', payload: { ...params } });
        } else if (res) {
          dispatch({ type: '$queryTreeData' });
          dispatch({ type: '$queryTableData' });
        }
        res = undefined;
      },
    });
  };
  const handleVchTypeChange = (data) => {
    console.log(data.target.value);
    setOriginalVocherGenerate(data.target.value);
  };
  const handleCreateSubject = async () => {
    // 弹窗中生成凭证不需要判断是否已经生成凭证
    if (!save) {
      if (await dispatch({ type: 'hasInvalid', payload: [checkedIds, 'voucherId'] })) {
        message.error('亲，已有原始凭证生成会计凭证，不能批量生成凭证！');
        return;
      }
      if (await dispatch({ type: 'hasInvalid', payload: [checkedIds, 'clearState', 0] })) {
        message.error('亲，批量生成凭证时，不允许存在未整理的原始凭证。');
        return;
      }
      if (checkedIds.length > 1) {
        // 选则凭证生成的方式
        if (showOriginalVoucherGenerate()) {
          formLayer({
            width: 360,
            title: '选择凭证生成方式',
            cancel: {
              enable: false,
            },
            confirm: {
              enable: false,
            },
            render() {
              return (
                <ChooseForm
                  getLocal={() => getLocal()}
                  submit={() => this.submit()}
                  vchType={(data) => handleVchTypeChange(data)}
                />
              );
            },
            request(data) {
              const { accountToken, originalVoucherGenerate } = getLocal();
              if (data.unshow) {
                originalVoucherGenerate[accountToken].show = false;
              }
              originalVoucherGenerate[accountToken].type = data.type;
              localStorage.setItem(
                'originalVoucherGenerate',
                JSON.stringify(originalVoucherGenerate),
              );
              const { self } = this;
              const params = {
                originalIds: checkedIds.join(','),
                type: data.type,
              };
              dispatch({
                type: 'prepareVoucher',
                payload: {
                  originalIds: checkedIds.join(','),
                  cb: (userHandleResult = []) => {
                    dispatch({
                      type: 'createOriginalVouchers',
                      payload: { ...params, userHandleResult },
                    }).then((resa) => {
                      if (!resa) {
                        return;
                      }
                      openVocher(resa);
                    });
                  },
                },
              });
              self.destroy();
            },
          });
          return;
        }
        const params = {
          originalIds: checkedIds.join(','),
          type: originalVoucherGenerated,
          selectDate,
        };
        dispatch({
          type: 'prepareVoucher',
          payload: {
            originalIds: checkedIds.join(','),
            cb: (userHandleResult = []) => {
              dispatch({
                type: 'createOriginalVouchers',
                payload: { ...params, userHandleResult },
              }).then((rest) => {
                if (!rest) {
                  return;
                }
                openVocher(rest);
              });
            },
          },
        });
        // dispatch({ type: 'createOriginalVouchers', payload: { ...params } }).then((rest) => {
        //   if (!rest) {
        //     return;
        //   }
        //   openVocher(rest);
        // });
        return;
      }
      if (await dispatch({ type: 'hasInvalid', payload: [checkedIds, 'voucherId'] })) {
        message.error('亲，该原始凭证已生成会计凭证！');
        return;
      }
    }
    if (save) {
      await save((resData, resParams) => {
        const params = {
          originalIds: checkedIds.join(','),
          type: originalVoucherGenerated,
          selectDate: resParams.voucherDate || selectDate,
        };
        dispatchAll({
          type: 'prepareVoucher',
          payload: {
            originalIds: checkedIds.join(','),
            cb: (userHandleResult = []) => {
              dispatch({
                type: 'createOriginalVouchers',
                payload: { ...params, userHandleResult },
              }).then((resp) => {
                if (!resp) {
                  return;
                }
                openVocher(resp);
              });
            },
          },
        });
        // dispatch({ type: 'createOriginalVouchers', payload: { ...params } }).then((resp) => {
        //   if (!resp) {
        //     return;
        //   }
        //   openVocher(resp);
        // });
      }, true);
    } else {
      const params = {
        originalIds: checkedIds.join(','),
        type: originalVoucherGenerated,
        selectDate,
      };
      dispatch({
        type: 'prepareVoucher',
        payload: {
          originalIds: checkedIds.join(','),
          cb: (userHandleResult = []) => {
            dispatch({
              type: 'createOriginalVouchers',
              payload: { ...params, userHandleResult },
            }).then((resp) => {
              if (!resp) {
                return;
              }
              openVocher(resp);
            });
          },
        },
      });
      // dispatch({ type: 'createOriginalVouchers', payload: { ...params } }).then((resp) => {
      //   if (!resp) {
      //     return;
      //   }
      //   openVocher(resp);
      // });
    }
  };
  return (
    <Button
      type={type || 'default'}
      ghost={!!ghost}
      className="e-ml16"
      onClick={handleCreateSubject}
      disabled={isCheckOut}
    >
      生成凭证
    </Button>
  );
};
CreateVoucher.defaultProps = {
  dispatchAll: () => {},
  checkedIds: [],
  selectDate: '',
  type: '',
  ghost: false,
  detailQuery: {},
  save: '',
  isCheckOut: false,
};
CreateVoucher.propTypes = {
  dispatch: PropTypes.func.isRequired,
  dispatchAll: PropTypes.func,
  checkedIds: PropTypes.arrayOf(PropTypes.any),
  selectDate: PropTypes.string,
  type: PropTypes.string,
  ghost: PropTypes.bool,
  nuomiProps: PropTypes.objectOf(PropTypes.any).isRequired,
  detailQuery: PropTypes.objectOf(PropTypes.any),
  save: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
  isCheckOut: PropTypes.bool,
};

export default connect((state, { account: { isCheckOut } }) => ({ ...state, isCheckOut }))(
  withNuomi(CreateVoucher),
);
