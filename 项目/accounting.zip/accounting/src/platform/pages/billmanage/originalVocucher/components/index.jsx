import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Select, message } from 'antd';
import { Head, Left, Center, Right, Content, Title, Layout } from '@/Layout';
import Period from '@/Period';
import { SuperModal } from '@/modal';
import ToTemplateMemoIcon from '@/ToTemplateMemoIcon';
import Side from './Side';
import Table from './Table';
import Import from './Import';
// import Import from './Import/import';
import Merge from './Merge';
import CreateVoucher from './CreateVoucher';
import initPeriod from '../../../../../public/initPeriod';
import { currentPeriodExtendOneYear } from '../common';
import Tips from './Tips';
import AuxiliaryHandle from '../../auxiliaryHandle';
import CreateAuxiliart from '../../entryInvoice/components/CreateAuxiliary';
import '../styles/index.less';

const { Option } = Select;

const Main = (props) => {
  const {
    isAuxiliary,
    treeSearchParams: { voucherState },
    dispatch,
    globalStore,
    checkedIds,
    router,
    query,
  } = props;
  const {
    account: { currentDate, isCheckOut, period, currentYear, currentMonth },
  } = globalStore;
  const { endDate } = query;
  const periods = currentPeriodExtendOneYear(period, currentYear, currentMonth);
  const handlePriodChange = (e) => {
    if (!period.includes(e.endDate)) {
      SuperModal({
        content: <p className="tip-message">所选期间尚未开账，是否确认开账</p>,
        centered: true,
        width: 360,
        onOk: () => {
          initPeriod(undefined, e.endDate, (layerInst) => {
            layerInst.hide();
            const newParams = [...period];
            newParams.push(e.endDate);
            dispatch({ type: 'account/updateState', payload: { period: newParams } });
            dispatch({ type: '$queryTreeData' });
            dispatch({ type: '$queryTableData' });
          });
        },
        onCancel: () => {
          dispatch({
            type: 'setState',
            payload: {
              query: {
                startDate: endDate,
                endDate,
              },
            },
          });
        },
      });
    } else {
      // console.log(1111);
      // dispatch({ type: 'setState', payload: { query: e } });
      dispatch({ type: '$queryTreeData' });
      dispatch({ type: '$queryTableData' });
    }
  };
  const handleTypeChange = (e) => {
    dispatch({ type: 'setTreeSearchParams', payload: { voucherState: e } });
    dispatch({ type: 'setTableSearchParmas', payload: { voucherState: e } });
    dispatch({ type: '$queryTreeData' });
    dispatch({ type: '$queryTableData' });
  };
  const handleDelete = async () => {
    if (await dispatch({ type: 'hasInvalid', payload: [checkedIds, 'voucherId'] })) {
      message.error('亲，已有原始凭证生成会计凭证，请先删除相应的会计凭证再删除！');
      return;
    }
    SuperModal({
      content: <p className="f-tac e-p20">亲，该原始凭证被删除之后，将不能被恢复！</p>,
      cancelText: '我在想想',
      okText: '确认删除',
      width: 360,
      centered: true,
      onOk: () => {
        dispatch({ type: 'deleteData', payload: { ids: checkedIds.join(',') } });
      },
    });
  };
  const disabled = query.endDate < currentDate;

  const enableEdit = inAuth();
  return (
    <>
      <Layout
        className="original-voucher"
        id="original-voucher"
        style={{ display: !isAuxiliary ? 'block' : 'none' }}
      >
        <div className="original">
          <Head>
            <Left>
              <Period limit onChange={handlePriodChange} periods={periods} />
              <Select
                defaultValue={0}
                value={voucherState}
                className="e-ml16"
                onChange={handleTypeChange}
              >
                <Option value={0}>未生成凭证</Option>
                <Option value={1}>已生成凭证</Option>
                <Option value={2}>所有附件</Option>
              </Select>
            </Left>
            <Center>
              <Title />
            </Center>
            <Right>
              {voucherState !== 1 && (
                <>
                  {checkedIds.length > 1 && enableEdit && <Merge />}
                  {checkedIds.length > 0 && enableEdit && (
                    <Button type="default" className="e-ml16" onClick={handleDelete}>
                      删除附件
                    </Button>
                  )}
                  {checkedIds.length > 0 && enableEdit && <CreateVoucher />}
                </>
              )}
              {enableEdit &&
                (isCheckOut === true ? (
                  <Button type="primary" disabled>
                    导入附件
                  </Button>
                ) : (
                  <Import disabled={disabled} date={endDate} router={router} />
                ))}
            </Right>
            <ToTemplateMemoIcon />
          </Head>
          <Content>
            <Tips />
            <div className="content">
              <Side />
              <Table />
            </div>
          </Content>
        </div>
      </Layout>
      {isAuxiliary && (
        <Layout>
          <AuxiliaryHandle />
        </Layout>
      )}
      <CreateAuxiliart />
    </>
  );
};
Main.defaultProps = {
  query: {},
  router: null,
};
Main.propTypes = {
  isAuxiliary: PropTypes.bool.isRequired,
  treeSearchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  globalStore: PropTypes.objectOf(PropTypes.any).isRequired,
  checkedIds: PropTypes.arrayOf(PropTypes.any).isRequired,
  router: PropTypes.objectOf(PropTypes.any),
  query: PropTypes.objectOf(PropTypes.any),
  dispatch: PropTypes.func.isRequired,
};

export default connect((state, globalStore) => ({ ...state, globalStore }))(Main);
