import React from 'react';
import Main from './components/index';
import Effetcs from './effetcs';
import VoucherState from '../entryInvoice/voucherState';

export default {
  state: {
    ...VoucherState,
    // 左侧树的数据
    treeData: [],
    // 树搜索的条件
    treeSearchParams: {
      // 附件类型 0：未生成凭证 1：已生成凭证 2：所有附件
      voucherState: 0,
      startDate: undefined,
      endDate: undefined,
    },
    tableSearchParams: {
      // 附件类型 0：未生成凭证 1：已生成凭证 2：所有附件
      voucherState: 0,
      startDate: undefined,
      endDate: undefined,
      // 树形结构的id，默认未整理为-2
      typeId: -2,
      // 排序，默认时间升序
      order: 0,
      isRequest: false, // 是否在请求
    },
    // 右侧表格数据
    voucherData: [],
    // 选中的check
    checkedIds: [],
    invoiceType: 'original',
  },
  effects() {
    return new Effetcs(this);
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  render() {
    return <Main />;
  },
  onInit() {
    this.store.dispatch({ type: 'initData' });
    this.store.dispatch({
      type: '$queryTreeData',
    });
    this.store.dispatch({
      type: '$queryTableData',
    });
  },
};
