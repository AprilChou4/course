import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { Button, Form, Input, Row, Col, Select, DatePicker, message } from 'antd';
import moment from 'moment';
import $data from 'data';
import { util, template } from 'nuijs';
import Icon from 'Icon';
import CreateVoucher from '../../../CreateVoucher';
import Detail from './Detail';
// import AddVoucherTemplate from '@/AddVoucherTemplate';
import TemplateMemorySelection from '@/TemplateMemorySelection';
import TemplateOperation from '@/TemplateOperation';

const FormItem = Form.Item;
const { Option } = Select;
const itemLayout = {
  labelCol: {
    sm: {
      span: 8,
    },
  },
  wrapperCol: {
    sm: {
      span: 16,
    },
  },
};

class DetailForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: '',
      isSaveSuccess: false,
    };
  }

  UNSAFE_componentWillMount() {
    const { nuomiProps, form } = this.props;
    nuomiProps.form = form;
  }

  componentDidMount() {
    const { globalStore, dispatch } = this.props;
    dispatch({ type: 'queryMoldList' });
    this.getTemplateLastUsed();
    const {
      account: { period },
    } = globalStore;
    const [year, month] = period[period.length - 1].split('-');
    this.period = [`${period[0]}-01`, moment(new Date(year, month, 0)).format('YYYY-MM-DD')];
  }

  UNSAFE_componentWillReceiveProps = (nextProps) => {
    const {
      data: { originalId },
    } = this.props;
    const {
      data: { originalId: newOriginalId },
    } = nextProps;
    if (originalId !== newOriginalId) {
      this.setState({
        type: '',
      });
    }
    if (originalId !== newOriginalId) {
      this.setState({ isSaveSuccess: false });
    }
  };

  // 设置参数
  setData = (data) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'setState',
      payload: {
        ...data,
      },
    });
  };

  // 获取最近使用的模板
  getTemplateLastUsed = () => {
    const { dispatch } = this.props;
    dispatch({ type: 'queryTemplateLastUsed' });
  };

  save = async (cb, noMessage) => {
    const { form, dispatch, data, nuomiProps } = this.props;
    form.validateFields(async (err, val) => {
      const values = val;
      if (!err) {
        if (values.date) {
          values.date = values.date.format('YYYY-MM-DD');
        }
        if (values.invoiceDate) {
          values.invoiceDate = values.invoiceDate.format('YYYY-MM-DD');
        }
        const params = {
          ...data,
          voucherDate: values.date,
          exMoney: values.exMoney,
          taxMoney: values.taxMoney,
          money: values.money,
          showRec: 0,
          clearState: 0,
          voucherState: 0,
        };
        await dispatch({
          type: 'setState',
          payload: {
            data: params,
          },
        });
        await setTimeout(() => {
          dispatch({ type: 'clearAtt', payload: { ...values, noMessage } }).then((res) => {
            nuomiProps.isSave = true;
            this.setState({ isSaveSuccess: true });
            this.getTemplateLastUsed();
            if (res && res.type) {
              // 模板记忆
              TemplateMemorySelection({
                ...res,
                category: res.type === 4 || res.type === 5 ? '' : '1',
              });
            }

            cb && cb(res, params);
          });
        }, 100);
      }
    });
  };

  numberChange = (e) => {
    const value = e.target.value.replace(/[^\d.]+/g, '');
    // 单独的number
    const max = 999999999.99;
    if (value > max) {
      e.target.value = max;
    } else {
      e.target.value = value;
    }
  };

  numberKeyup = (e) => {
    if (e.keyCode === 13) {
      this.numberBlur(e);
    }
  };

  numberBlur = (e) => {
    const { form } = this.props;
    const { id } = e.target;
    const value = e.target.value.replace(/[^\d.]+/g, '');
    if (value) {
      e.target.value = parseFloat(value).toFixed(2);
    }
    form.setFieldsValue({
      [id]: e.target.value,
    });
  };

  countMoney = (e) => {
    const { form } = this.props;
    const { id } = e.target;
    let { value } = e.target;
    const max = 999999999.99;
    const min = -max;
    let aboutValue;
    if (id === 'taxMoney') {
      aboutValue = form.getFieldValue('exMoney');
    } else {
      aboutValue = form.getFieldValue('taxMoney');
    }

    let total = parseFloat(value || 0) + parseFloat(aboutValue || 0);

    if (Number.isNaN(total)) {
      total = 0;
    }

    if (total > max) {
      message.error(`价税合计不能大于${max}`);
      value = (max - aboutValue || 0).toFixed(2);
      total = max;
    } else if (total < min) {
      message.error(`价税合计不能低于${min}`);
      value = (min - aboutValue || 0).toFixed(2);
      total = min;
    }

    e.target.value = value;

    form.setFieldsValue({
      money: total.toFixed(2),
    });
  };

  getUnitItem = () => {
    const { form, data, globalStore } = this.props;
    const { getFieldDecorator } = form;
    const {
      account: { isCheckOut },
    } = globalStore;
    // 账套禁用
    const enableEdit = inAuth();
    const disabled = isCheckOut || !!data.voucherId || !enableEdit;

    let { unitProperty } = data;
    let { unitName } = data;
    if (!unitName || unitName === 'null') {
      unitName = '';
    }
    if (!unitProperty || unitProperty === 'null') {
      unitProperty = '供应商';
    }
    return (
      <Row>
        <Col span={itemLayout.labelCol.sm.span}>
          <FormItem>
            {getFieldDecorator('unitProperty', {
              initialValue: unitProperty,
            })(
              <Select disabled={disabled} style={{ width: 82 }} className="unitSelect">
                <Option value="客户">客户</Option>
                <Option value="供应商">供应商</Option>
              </Select>,
            )}
          </FormItem>
        </Col>
        <Col span={itemLayout.wrapperCol.sm.span}>
          <FormItem>
            {getFieldDecorator('unitName', {
              initialValue: unitName,
            })(<Input disabled={disabled} maxLength={32} autoComplete="off" />)}
          </FormItem>
        </Col>
      </Row>
    );
  };

  getTypeName = () => {
    const { data } = this.props;
    const { businessType } = data;
    const typeId = businessType;
    let dataT;
    if (!typeId) {
      // this.props.data.c_type = $data('treeAllData')[0].id;
      return $data('treeAllData')[0].name; // 模板匹配时，没有模板默认显示第一个模板
    }
    $data('treeAllData').some((v) => {
      if (v.id === typeId) {
        dataT = v;
        return true;
      }
      return false;
    });
    if (dataT) {
      return dataT.name;
    }
    return '';
  };

  search = (e) => {
    const { target } = e;
    const self = this;
    const { data, usedTemplate, form, dispatch, nuomiProps } = this.props;
    self.data = [
      {
        name: '最近',
        children: usedTemplate.map((item) => {
          const trem = item;
          trem.name = item.templateName;
          return trem;
        }),
      },
    ].concat($data('treeData') || []);
    target.cDefaultValue = target.value;
    $(target)
      .search({
        id: 'add',
        field: 'name',
        className: 'search',
        focus: false,
        nullable: true,
        empty: '没有搜索结果，请变换搜索条件',
        foot: '新增模板',
        size: {
          width: 80,
        },
        match: [
          {
            field: 'name',
            like(fieldValue, value) {
              return fieldValue.indexOf(value) !== -1;
            },
          },
        ],
        tabs: self.data.map((v, i) => {
          return {
            title: v.name,
            id: v.id,
            content() {
              return template.render(
                '<ul class="con-search-list">' +
                  '<%each $list%>' +
                  '<li class="con-search-item items" data-index="<%$index%>" data-id="<%$value.id%>"><%$value.name%></li>' +
                  '<%/each%>' +
                  '</ul>',
                self.data[i].children,
              );
            },
            onShow() {
              const { name, children } = self.data[i];
              let prompt = '';
              if (name !== '最近') {
                this.data = children;
                prompt = `搜索业务类型为“${v.name}”，匹配到<%count%>条数据`;
              } else {
                this.data = $data('treeAllData');
              }
              this.children = children;
              // eslint-disable-next-line no-underscore-dangle
              this.self._template.prompt = prompt;
              this.toggle();
              this.current = i + 1;
            },
          };
        }),
        events: {
          'click .items': function (event, elem) {
            this.select(this.children[elem.data('index')]);
            elem.toggleClass('s-crt');
          },
          'click .con-search-foot': function () {
            // const {self} = this;
            const thisSelf = this.self;
            thisSelf.destroy();
            $(target).search('destroy');
            TemplateOperation({
              type: '1',
              callback: (datas, id) => {
                form.setFieldsValue({
                  templateName: datas.templateName,
                  summary: datas.templateName,
                  typeId: id,
                });
                const {
                  data: { treeSearchParams },
                } = nuomiProps;
                dispatch({ type: '$queryTreeData', payload: treeSearchParams });
              },
            });
            // self.setData({
            //   isShowAddTplModal: true,
            //   editTableData: [
            //     { credit: '', debit: '', key: 0, subject: '', summary: '' },
            //     { credit: '', debit: '', key: 1, subject: '', summary: '' },
            //     { credit: '', debit: '', key: 2, subject: '', summary: '' },
            //   ],
            // });
            // $(target).search('destroy');
          },
        },
        toggle() {
          const that = this;
          that.self.activeTab.$container.find('.con-search-item').each(function () {
            const elem = $(this);
            const typeId = form.getFieldValue('typeId');
            elem.toggleClass('s-crt', typeId === elem.data('id'));
          });
        },
        select(res) {
          this.self.value(res.name);
          this.self.hide();
          this.self.target.blur();
        },
        onSelect(selfs, datas) {
          this.select(datas);
        },
        onHide(ele) {
          const { _elemData } = ele;
          // eslint-disable-next-line no-param-reassign,no-underscore-dangle
          ele._selectTab = _elemData[this.current];
        },
        onBlur(ele) {
          const val = ele.target.val().trim();
          if (target.cDefaultValue !== val) {
            let eleData = {};
            $data('treeAllData').some((v) => {
              if (v.name.trim() === val) {
                eleData = v;
                return true;
              }
              return false;
            });
            ele.value(eleData.name);
            form.setFieldsValue({
              templateName: eleData.name,
              typeId: eleData.id,
              // eslint-disable-next-line no-nested-ternary
              summary: eleData.summary
                ? data.invoiceNumber
                  ? `发票号${data.invoiceNumber}:${eleData.summary}`
                  : eleData.summary
                : data.summary || '',
            });
          }
        },
      })
      .search('show');
  };

  getSummary = () => {
    const {
      data: { summary },
    } = this.props;
    if (!summary) {
      return $data('treeAllData')[0].name; // 模板匹配时，没有模板摘要默认显示第一个模板摘要
    }
    return false;
  };

  setType = (data) => {
    this.setState({
      type: data,
    });
  };

  valiDataNum = (e) => {
    const value = e.target.value.replace(/[^\d.]+/g, '');
    e.target.value = value;
  };

  saveContinue = () => {
    const { nid, dispatch, detailQuery } = this.props;
    this.save(() => {
      if (nid !== '0') {
        const params = {
          ...detailQuery,
          originalIds: nid,
          typeId: detailQuery.typeId === -2 ? '' : detailQuery.typeId,
        };
        dispatch({ type: '$queryDetail', payload: { ...params } });
      }
    });
  };

  handleAddEvent = async (params) => {
    const { dispatch, form } = this.props;
    const { setFieldsValue } = form;
    await dispatch({ type: 'addTemplateO', payload: { ...params } }).then((res) => {
      setFieldsValue({
        templateName: params.templateName,
        summary: params.templateName,
        typeId: res.data,
      });
    });
  };

  render() {
    const { data, form, moldList, globalStore, paths, detailQuery, dispatchAll } = this.props;
    const { endDate } = detailQuery;
    const [year, month] = endDate.split('-');
    const { getFieldDecorator } = form;
    const {
      account: {
        user: { currentTime },
        period,
        isCheckOut,
      },
    } = globalStore;
    const { type, isSaveSuccess } = this.state;
    // 账套禁用
    const enableEdit = inAuth();
    const disabled = isCheckOut || !!data.voucherId || !enableEdit;
    const types = type || data.invoiceType;
    let initDate;
    let maxDate = currentTime;
    let minDate = currentTime;
    if (period) {
      maxDate = period[period.length - 1];
      [minDate] = period;
      maxDate = moment(new Date(maxDate.split('-')[0], maxDate.split('-')[1], 0));
      minDate = moment(new Date(minDate.split('-')[0], minDate.split('-')[1] - 1, 1));
    }
    if (data.voucherDate) {
      initDate = moment(data.voucherDate);
    } else if (year) {
      initDate = moment(new Date(year, month, 0));
    }
    const getSelect = () => {
      return (
        <Select disabled={disabled} onChange={this.setType}>
          {moldList.map((val, index) => {
            const key = index;
            return (
              <Option key={key} value={val.value}>
                {val.name}
              </Option>
            );
          })}
        </Select>
      );
    };
    const selects = getSelect();
    /*
     * types 为发票类型
     * 增值税专用发票 = vat_special_invoice
     * 增值税普通发票 = vat_common_invoice
     * 增值税电子发票 = vat_electronic_invoice
     * 增值税卷式发票 = vat_roll_invoice
     * 车辆通行费 = vehicle_toll_invoice
     * 长途汽车票 = bus_ticket
     * 飞机行程票 = flight_itinerary
     * 出租车票 = taxi_ticket
     * 火车票 = train_ticket
     * 定额发票 = quota_invoice
     * 银行回单 = bank_receipt
     * 其他类型 = other_invoice
     */
    return (
      <div className="formwrap">
        <Form className="form">
          <div
            style={{
              maxHeight: '100%',
              overflow: 'auto',
            }}
          >
            {getFieldDecorator('originalId', {
              initialValue: data.originalId,
            })(<Input type="hidden" />)}
            {['vat_common_invoice', 'vat_electronic_invoice', 'other_invoice'].includes(types) &&
              getFieldDecorator('exMoney', { initialValue: util.toFixed(data.exMoney || 0, 2) })(
                <Input type="hidden" />,
              )}
            {types !== 'vat_special_invoice' &&
              getFieldDecorator('taxMoney', { initialValue: util.toFixed(data.taxMoney || 0, 2) })(
                <Input type="hidden" />,
              )}
            {getFieldDecorator('typeId', {
              initialValue: data.businessType,
            })(<Input type="hidden" />)}
            {/* eslint-disable-next-line */}
            <FormItem {...itemLayout} label="票据类型">
              {getFieldDecorator('type', {
                initialValue: types,
                rules: [
                  {
                    required: true,
                    message: '请选择票据类型',
                  },
                ],
              })(selects)}
            </FormItem>
            {/* eslint-disable-next-line */}
            <FormItem {...itemLayout} label="凭证日期">
              {getFieldDecorator('date', {
                initialValue: initDate,
                rules: [
                  {
                    required: true,
                    message: '请选择凭证日期',
                  },
                ],
              })(
                <DatePicker
                  format="YYYY-MM-DD"
                  showToday={false}
                  disabled={disabled}
                  disabledDate={(current) => {
                    return (
                      moment(moment(current).format('YYYY-MM-DD')) < moment(minDate) ||
                      moment(moment(current).format('YYYY-MM-DD')) > moment(maxDate)
                    );
                  }}
                />,
              )}
            </FormItem>
            {/* eslint-disable-next-line */}
            <FormItem {...itemLayout} label="凭证模板">
              {getFieldDecorator('templateName', {
                initialValue: data.templateName || this.getTypeName(),
                rules: [
                  {
                    required: true,
                    message: '请选择凭证模板',
                  },
                ],
              })(
                <Input
                  disabled={disabled}
                  ref={(ele) => {
                    this.typeInput = ele;
                  }}
                  onFocus={this.search}
                  suffix={<Icon type="piaojuguanli" onClick={() => this.typeInput.input.focus()} />}
                  autoComplete="off"
                  placeholder="请选择凭证模板"
                />,
              )}
            </FormItem>
            {/* eslint-disable-next-line */}
            <FormItem {...itemLayout} label="凭证摘要">
              {getFieldDecorator('summary', {
                initialValue: data.summary || this.getSummary(),
                rules: [
                  {
                    required: true,
                    message: '请填写凭证摘要',
                  },
                ],
              })(
                <Input.TextArea disabled={disabled} maxLength={100} placeholder="请输入凭证摘要" />,
              )}
            </FormItem>
            {types === 'bank_receipt' && (
              // eslint-disable-next-line
              <FormItem {...itemLayout} label="交易日期">
                {getFieldDecorator('invoiceDate', {
                  initialValue: data.invoiceDate ? moment(data.invoiceDate) : null,
                  rules: [
                    {
                      required: true,
                      message: '请选择交易日期',
                    },
                  ],
                })(
                  <DatePicker
                    format="YYYY-MM-DD"
                    showToday={false}
                    disabled={disabled}
                    disabledDate={(current) => {
                      return (
                        moment(moment(current).format('YYYY-MM-DD')) >
                        moment(currentTime.split(' ')[0])
                      );
                    }}
                  />,
                )}
              </FormItem>
            )}
            {types === 'vat_special_invoice' && (
              <>
                {paths.length > 1 && data.voucherState === 0 && (
                  <h4 className="e-mb10">合并发票金额合计</h4>
                )}
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="不含税金额">
                  {getFieldDecorator('exMoney', {
                    initialValue: util.toFixed(data.exMoney, 2),
                    rules: [
                      {
                        required: true,
                        message: '请填写不含税金额',
                      },
                    ],
                  })(
                    <Input
                      disabled={disabled}
                      onChange={this.numberChange}
                      onKeyUp={this.numberKeyup}
                      onBlur={this.numberBlur}
                      autoComplete="off"
                      placeholder="0.00"
                    />,
                  )}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="税额">
                  {getFieldDecorator('taxMoney', {
                    initialValue: util.toFixed(data.taxMoney, 2),
                    rules: [
                      {
                        required: true,
                        message: '请填写税额',
                      },
                    ],
                  })(
                    <Input
                      disabled={disabled}
                      onChange={this.numberChange}
                      onKeyUp={this.numberKeyup}
                      onBlur={this.numberBlur}
                      autoComplete="off"
                      placeholder="0.00"
                    />,
                  )}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="价税合计">
                  {getFieldDecorator('money', {
                    initialValue: util.toFixed(data.money, 2),
                  })(
                    <Input
                      disabled={disabled}
                      onChange={this.numberChange}
                      onKeyUp={this.numberKeyup}
                      onBlur={this.numberBlur}
                      autoComplete="off"
                      placeholder="0.00"
                    />,
                  )}
                </FormItem>
              </>
            )}
            {['vat_common_invoice', 'vat_electronic_invoice', 'other_invoice'].includes(types) && (
              // eslint-disable-next-line
              <FormItem {...itemLayout} label="金额">
                {getFieldDecorator('money', {
                  initialValue: util.toFixed(data.money, 2),
                  rules: [
                    {
                      required: true,
                      message: '请填写金额',
                    },
                  ],
                })(
                  <Input
                    disabled={disabled}
                    onChange={(e) => this.numberChange(e)}
                    onKeyUp={this.numberKeyup}
                    onBlur={this.numberBlur}
                    autoComplete="off"
                    placeholder="0.00"
                  />,
                )}
              </FormItem>
            )}
            {![
              'vat_special_invoice',
              'vat_common_invoice',
              'vat_electronic_invoice',
              'other_invoice',
            ].includes(types) && (
              // eslint-disable-next-line
              <FormItem {...itemLayout} label="金额">
                {getFieldDecorator('exMoney', {
                  initialValue: util.toFixed(data.exMoney, 2),
                  rules: [
                    {
                      required: true,
                      message: '请填写金额',
                    },
                  ],
                })(
                  <Input
                    disabled={disabled}
                    onChange={(e) => this.numberChange(e)}
                    onKeyUp={this.numberKeyup}
                    onBlur={this.numberBlur}
                    autoComplete="off"
                    placeholder="0.00"
                  />,
                )}
              </FormItem>
            )}

            {[
              'vehicle_toll_invoice',
              'bus_ticket',
              'taxi_ticket',
              'train_ticket',
              'flight_itinerary',
            ].includes(types) && (
              // eslint-disable-next-line
              <FormItem {...itemLayout} label="发生日期">
                {getFieldDecorator('invoiceDate', {
                  initialValue: data.invoiceDate ? moment(data.invoiceDate) : null,
                })(
                  <DatePicker
                    format="YYYY-MM-DD"
                    showToday={false}
                    disabled={disabled}
                    disabledDate={(current) => {
                      return (
                        moment(moment(current).format('YYYY-MM-DD')) >
                        moment(currentTime.split(' ')[0])
                      );
                    }}
                  />,
                )}
              </FormItem>
            )}
            {(types === 'train_ticket' || types === 'flight_itinerary') && (
              <>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="旅客姓名">
                  {getFieldDecorator('passengerName', {
                    initialValue: data.passengerName,
                  })(
                    <Input
                      disabled={disabled}
                      autoComplete="off"
                      maxLength={20}
                      placeholder="请填写旅客姓名"
                    />,
                  )}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="出发地">
                  {getFieldDecorator('departureStation', {
                    initialValue: data.departureStation,
                  })(
                    <Input
                      disabled={disabled}
                      autoComplete="off"
                      maxLength={10}
                      placeholder="请填写出发地"
                    />,
                  )}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="目的地">
                  {getFieldDecorator('terminus', {
                    initialValue: data.terminus,
                  })(
                    <Input
                      disabled={disabled}
                      autoComplete="off"
                      maxLength={10}
                      placeholder="请填写目的地"
                    />,
                  )}
                </FormItem>
              </>
            )}
            {types === 'quota_invoice' && (
              // eslint-disable-next-line
              <FormItem {...itemLayout} label="发票所在地">
                {getFieldDecorator('city', {
                  initialValue: data.city,
                })(
                  <Input
                    disabled={disabled}
                    autoComplete="off"
                    maxLength={10}
                    placeholder="请填写发票所在地"
                  />,
                )}
              </FormItem>
            )}
            {[
              'vat_special_invoice',
              'vat_common_invoice',
              'vat_electronic_invoice',
              'vat_roll_invoice',
              'other_invoice',
            ].includes(types) &&
              data.showRec === 0 &&
              paths.length === 1 &&
              this.getUnitItem()}
            {types === 'bank_receipt' && (
              <>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="付款方">
                  {getFieldDecorator('payerName', {
                    initialValue: data.payerName,
                  })(<Input disabled={disabled} maxLength={40} />)}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="付款账号">
                  {getFieldDecorator('payerAccount', {
                    initialValue: data.payerAccount,
                  })(
                    <Input
                      disabled={disabled}
                      maxLength={30}
                      onChange={(e) => this.valiDataNum(e)}
                    />,
                  )}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="收款方">
                  {getFieldDecorator('payeeName', {
                    initialValue: data.payeeName,
                  })(<Input disabled={disabled} maxLength={40} />)}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="收款账号">
                  {getFieldDecorator('payeeAccount', {
                    initialValue: data.payeeAccount,
                  })(
                    <Input
                      disabled={disabled}
                      maxLength={30}
                      onChange={(e) => this.valiDataNum(e)}
                    />,
                  )}
                </FormItem>
                {/* eslint-disable-next-line */}
                <FormItem {...itemLayout} label="转款备注">
                  {getFieldDecorator('remark', {
                    initialValue: data.remark,
                  })(
                    <Input.TextArea
                      disabled={disabled}
                      maxLength={100}
                      placeholder="请输入转款备注"
                    />,
                  )}
                </FormItem>
              </>
            )}
          </div>
          {[
            'vat_special_invoice',
            'vat_common_invoice',
            'vat_electronic_invoice',
            'vat_roll_invoice',
            'other_invoice',
          ].includes(types) &&
            data.showRec === 0 && <Detail UnitItem={this.getUnitItem()} />}
        </Form>
        {/* <AddVoucherTemplate */}
        {/*  isShowAddTplModal={isShowAddTplModal} */}
        {/*  subjectList={subjectList} */}
        {/*  editTableData={editTableData} */}
        {/*  onAdd={(params) => { */}
        {/*    this.handleAddEvent(params); */}
        {/*  }} */}
        {/*  hideModal={() => { */}
        {/*    dispatch({ */}
        {/*      type: 'setState', */}
        {/*      payload: { isShowAddTplModal: false, editTableData: [] }, */}
        {/*    }); */}
        {/*  }} */}
        {/* /> */}
        {this.inAuth(98) && (
          <div className="formbtn">
            {((data.clearState === 1 && data.voucherState === 0) || isSaveSuccess) && !disabled && (
              <CreateVoucher
                type="primary"
                checkedIds={[data.originalId]}
                save={(...args) => {
                  this.save(...args);
                }}
                ghost
                selectDate={data.voucherDate}
                dispatchAll={dispatchAll}
                detailQuery={detailQuery}
              />
            )}
            <Button type="primary" disabled={disabled} ghost onClick={() => this.save()}>
              保存
            </Button>
            <Button type="primary" disabled={disabled} onClick={() => this.saveContinue()}>
              保存并继续
            </Button>
          </div>
        )}
      </div>
    );
  }
}
DetailForm.defaultProps = {
  usedTemplate: [],
  nid: '',
  detailQuery: {},
  moldList: [],
  paths: [],
  dispatchAll: () => {},
};
DetailForm.propTypes = {
  nuomiProps: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  globalStore: PropTypes.objectOf(PropTypes.any).isRequired,
  data: PropTypes.objectOf(PropTypes.any).isRequired,
  usedTemplate: PropTypes.arrayOf(PropTypes.any),
  nid: PropTypes.string,
  detailQuery: PropTypes.objectOf(PropTypes.any),
  moldList: PropTypes.arrayOf(PropTypes.any),
  paths: PropTypes.arrayOf(PropTypes.any),
  dispatchAll: PropTypes.func,
  dispatch: PropTypes.func.isRequired,
};
// const RightForm = Form.create()(DetailForm);
export default connect((state, globalStore) => ({ ...state, globalStore }))(
  withNuomi(Form.create()(DetailForm)),
);
