import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { superLayer } from 'layer';
import Slider from '@/Slider';
import RecIcon from './RecIcons';
// import Mask from './Mask';

const imgDiff = [];
const smallDiff = [];
class Picture extends Component {
  constructor() {
    super();
    this.state = {
      diffX: 1,
      diffY: 1,
      diff: [],
      sDiff: [],
    };
  }

  componentDidUpdate() {
    const { currentIndex } = this.props;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      const currentElement = this.thumbs.children[currentIndex];
      if (currentElement) {
        const width = this.thumbs.offsetWidth;
        const { left } = $(currentElement).position();
        const sleft = this.thumbs.scrollLeft;
        const oWidth = left + currentElement.offsetWidth;
        const diff = oWidth - (width + sleft);
        if (left < 0) {
          this.thumbs.scrollLeft = 0;
        } else if (diff > 0) {
          this.thumbs.scrollLeft = diff;
        }
      }
    }, 100);
  }

  change = (index) => {
    const { dispatch } = this.props;
    dispatch({ type: 'setState', payload: { currentIndex: index } });
  };

  handleLoad = (e, url) => {
    const { target } = e;
    const { width, height, naturalWidth, naturalHeight } = target;
    const diffX = width / naturalWidth;
    const diffY = height / naturalHeight;
    smallDiff.push({ width: naturalWidth, height: naturalHeight, url });
    this.setState({
      diffX,
      diffY,
      sDiff: smallDiff,
    });
  };

  handleMyLoad = (e) => {
    const { naturalWidth, naturalHeight, src } = e.target;
    imgDiff.push({ x: naturalWidth, y: naturalHeight, url: src });
    this.setState({
      diff: imgDiff,
    });
  };

  render() {
    const { currentIndex, detailQuery, paths, dispatch, data, nuomiProps } = this.props;
    const { voucherId, voucherCode, showRec } = data;
    const { diffX, diffY, diff, sDiff } = this.state;
    const size = paths.length;

    // 账套禁用
    const enableEdit = inAuth();

    return (
      <div className="picture">
        <div className="slider">
          <Slider
            // eslint-disable-next-line no-multi-assign
            ref={(ele) => {
              nuomiProps.slider = ele;
              this.slider = ele;
            }}
            urls={paths}
            change={this.change}
            from
          />
          <span className="picExtra">
            {!!voucherId && enableEdit && (
              <a
                onClick={() => {
                  superLayer('voucher/record', {
                    data: {
                      title: '记账凭证',
                      voucherId,
                      isBillManage: true,
                    },
                    onDestroy() {
                      // 删除凭证后操作
                      if (this.saveData && !this.saveData.voucherId) {
                        const params = {
                          ...data,
                          ...{ voucherId: '', voucherCode: '', voucherState: 0 },
                        };
                        dispatch({
                          type: 'setState',
                          payload: { data: params },
                        });
                      }
                    },
                    onSave(res) {
                      this.saveData = res;
                    },
                  });
                }}
                style={{ color: '#fff', textDecoration: 'underline' }}
              >
                {voucherCode}
              </a>
            )}
          </span>
          {showRec === 1 && this.inAuth(98) && <RecIcon detailQuery={detailQuery} />}
          <p>
            {size ? currentIndex + 1 : 0} / {size}
          </p>
        </div>
        <div
          className="thumb"
          ref={(ele) => {
            this.thumbs = ele;
          }}
        >
          {paths.map((v, i) => {
            const key = i;
            return (
              <span
                key={key}
                className={i === currentIndex ? 's-crt' : ''}
                onClick={() => this.slider.carousel.goTo(i)}
              >
                {v.smallAttachPath.indexOf('.ofd') !== -1 ? (
                  <i className="iconfont icon-OFD" />
                ) : (
                  <div>
                    {/* eslint-disable-next-line jsx-a11y/alt-text */}
                    <img
                      src={v.bigAttachPath}
                      onLoad={this.handleMyLoad}
                      style={{ display: 'none' }}
                    />
                    <img
                      src={v.smallAttachPath}
                      alt="图片"
                      onLoad={(e) => {
                        this.handleLoad(e, v.smallAttachPath);
                      }}
                    />
                    {v.position && (
                      <span
                        style={{
                          position: 'absolute',
                          left:
                            JSON.parse(v.position)[0] *
                            ((sDiff.find(({ url }) => url === v.smallAttachPath)?.width || 1) /
                              (diff.find(({ url }) => url === v.bigAttachPath)?.x || 1)) *
                            diffX,
                          top:
                            JSON.parse(v.position)[1] *
                            (sDiff.find(({ url }) => url === v.smallAttachPath)?.height /
                              diff.find(({ url }) => url === v.bigAttachPath)?.y) *
                            diffY,
                          height:
                            (JSON.parse(v.position)[JSON.parse(v.position).length - 1] -
                              JSON.parse(v.position)[1]) *
                            ((sDiff.find(({ url }) => url === v.smallAttachPath)?.height || 1) /
                              (diff.find(({ url }) => url === v.bigAttachPath)?.y || 1)) *
                            diffY,
                          width:
                            (JSON.parse(v.position)[2] - JSON.parse(v.position)[0]) *
                            ((sDiff.find(({ url }) => url === v.smallAttachPath)?.width || 1) /
                              (diff.find(({ url }) => url === v.bigAttachPath)?.x || 1)) *
                            diffX,
                          border: `2px solid red`,
                        }}
                      />
                    )}
                  </div>
                )}
              </span>
            );
          })}
        </div>
        {/* {paths.map(({ smallAttachPath }) => {
          if (smallAttachPath.indexOf('.ofd') !== -1) {
            return <Mask key={smallAttachPath} />;
          }
          return '';
        })} */}
      </div>
    );
  }
}
Picture.defaultProps = {
  currentIndex: 0,
  detailQuery: {},
  paths: [],
  data: {},
};
Picture.propTypes = {
  currentIndex: PropTypes.number,
  detailQuery: PropTypes.objectOf(PropTypes.any),
  paths: PropTypes.arrayOf(PropTypes.any),
  data: PropTypes.objectOf(PropTypes.any),
  nuomiProps: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect((state) => state)(withNuomi(Picture));
