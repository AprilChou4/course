import React from 'react';
import PropTypes from 'prop-types';
import LazyLoad from 'react-lazyload';
import { Checkbox, Row, Col, message } from 'antd';
import { connect } from 'nuomi';
import { superLayer } from 'layer';
import SuperModal from '@/modal/SuperModal';
import Icon from '@/Icon';
import Detail from '../Detail/index';

const imgDiff = [];
const smallImgDiff = [];
const handleLoad = (e, props) => {
  const { target } = e;
  const { naturalWidth, naturalHeight } = target;
  const { loaded, url } = props;
  let marginTop = -target.offsetHeight / 2;
  let marginLeft = -target.offsetWidth / 2;
  if (props.two) {
    if (props.count === 1) {
      marginTop += -4;
      marginLeft += -4;
    } else {
      marginTop += 4;
      marginLeft += 4;
    }
  }
  target.parentElement.style.marginTop = `${marginTop}px`;
  target.parentElement.style.marginLeft = `${marginLeft}px`;
  // 一开始不可见，等到加载完毕再显示，不然图片会有跳动的bug
  target.style.opacity = 1;
  loaded && loaded(target);
  smallImgDiff.push({ width: naturalWidth, height: naturalHeight, url });
};

const Img = (args) => {
  const { url, path, x, y, diffX, diffY } = args;
  const { width, height } = smallImgDiff.find((e) => e.url === url) || { width: 150, height: 150 };
  return (
    <span height={170} className="image">
      <img src={url} onLoad={(e) => handleLoad(e, args)} />
      {path?.position && (
        <span
          style={{
            position: 'absolute',
            left: JSON.parse(path.position)[0] * (width / x) * diffX,
            top: JSON.parse(path.position)[1] * (height / y) * diffY,
            height:
              (JSON.parse(path.position)[JSON.parse(path.position).length - 1] -
                JSON.parse(path.position)[1]) *
              (height / y) *
              diffY,
            width:
              (JSON.parse(path.position)[2] - JSON.parse(path.position)[0]) * (width / x) * diffX,
            border: `2px solid red`,
          }}
        />
      )}
    </span>
  );
};

let isRequest = false;
// const diff = [];
class Item extends React.Component {
  constructor() {
    super();
    this.state = {
      diffX: 1,
      diffY: 1,
      diff: [],
    };
  }

  splitEvent = async () => {
    try {
      const { data, dispatch } = this.props;
      if (await dispatch({ type: 'hasInvalid', payload: [data.originalId, 'voucherId'] })) {
        message.error('亲，该原始凭证已生成会计凭证的，请先删除相应的会计凭证再拆分！');
        return;
      }
      if (await dispatch({ type: 'hasInvalid', payload: [data.originalId, 'clearState', 1] })) {
        SuperModal({
          content: (
            <p className="e-p20 f-tal">
              亲，拆分后将会丢失原始凭证上原已录入的信息，是否确定要拆分？
            </p>
          ),
          cancelText: '我再想想',
          okText: '确认拆分',
          centerd: true,
          onOk: () => {
            dispatch({ type: 'splitFile', payload: { id: data.originalId } });
          },
        });
        return;
      }
      dispatch({ type: 'splitFile', payload: { id: data.originalId } });
    } finally {
      isRequest = false;
    }
  };

  split = async (e) => {
    e.stopPropagation();
    if (isRequest) {
      return;
    }
    isRequest = true;
    this.splitEvent();
  };

  change = (e) => {
    const { data, checkedIds, dispatch } = this.props;
    const checkeds = [].concat(checkedIds);
    if (e.target.checked) {
      checkeds.push(data.originalId);
    } else {
      const index = checkeds.indexOf(data.originalId);
      if (index !== -1) {
        checkeds.splice(index, 1);
      }
    }
    dispatch({ type: 'setChecked', payload: checkeds });
  };

  delete = (e) => {
    e.stopPropagation();
    const { data, dispatch } = this.props;
    SuperModal({
      content: (
        <p style={{ height: '60px', lineHeight: '60px' }}>
          亲，该原始凭证被删除之后，将不能被恢复！
        </p>
      ),
      cancelText: '我在想想',
      okText: '确认删除',
      width: 360,
      centered: true,
      onOk: () => {
        dispatch({ type: 'deleteData', payload: { ids: data.originalId } });
      },
    });
  };

  showVoucher = (e) => {
    e.stopPropagation();
    let isSave = false;
    const {
      data: { voucherId },
      dispatch,
    } = this.props;
    superLayer('voucher/record', {
      data: {
        title: '记账凭证',
        voucherId,
        isBillManage: true,
      },
      isBack: false,
      onDestroy() {
        if (isSave) {
          dispatch({ type: '$queryTreeData' });
          dispatch({ type: '$queryTableData' });
        }
      },
      onSave() {
        isSave = true;
      },
    });
  };

  edit = (e) => {
    const { tableSearchParams, data, treeSearchParams, dispatch } = this.props;
    e.stopPropagation();
    superLayer(Detail, {
      zIndex: '5',
      data: {
        title: '生成凭证',
        detailQuery: {
          ...tableSearchParams,
          originalIds: data.originalId,
        },
        treeSearchParams,
        dispatchAll: dispatch,
        isBack: true,
      },
      container: $('#original-voucher'),
      isSave: false,
      slider: null,
      onDestroy() {
        dispatch({ type: '$queryTreeData' });
        dispatch({ type: '$queryTableData' });
      },
    });
  };

  handleOnload = (e) => {
    const { width, height, naturalWidth, naturalHeight } = e;
    const diffX = width / naturalWidth;
    const diffY = height / naturalHeight;
    this.setState({
      diffX,
      diffY,
    });
  };

  handleMyLoad = (e) => {
    const { naturalWidth, naturalHeight, src } = e.target;
    imgDiff.push({ x: naturalWidth, y: naturalHeight, url: src });
    this.setState({
      diff: imgDiff,
    });
  };

  render() {
    const { data, checkedIds } = this.props;
    const { diffX, diffY, diff } = this.state;
    const { attachPathList } = data;
    const path = attachPathList[0] || {};
    const { x, y } = diff.find(({ url }) => url === path.bigAttachPath) || { x: 1, y: 1 };
    // 账套禁用
    const enableEdit = inAuth();
    return (
      <div className="item" onClick={this.edit}>
        <LazyLoad height={170} overflow once>
          <>
            {/* eslint-disable-next-line jsx-a11y/alt-text */}
            <img src={path.bigAttachPath} onLoad={this.handleMyLoad} style={{ display: 'none' }} />
            {path.smallAttachPath.indexOf('.ofd') !== -1 ? (
              <i className="iconfont icon-OFD" />
            ) : (
              <Img
                url={path.smallAttachPath || ''}
                two={attachPathList.length > 1}
                count={1}
                loaded={this.handleOnload}
                path={path}
                x={x}
                y={y}
                diffY={diffY}
                diffX={diffX}
              />
            )}
            {attachPathList.length > 1 && (
              <Img
                url={path.smallAttachPath || ''}
                two
                count={2}
                loaded={this.handleOnload}
                path={path}
                x={x}
                y={y}
                diffY={diffY}
                diffX={diffX}
              />
            )}

            <Checkbox
              onClick={(e) => e.stopPropagation()}
              checked={checkedIds.indexOf(data.originalId) !== -1}
              className="f-fl"
              onChange={this.change}
            />
            {!data.voucherId && enableEdit && (
              <em className="f-fr">
                {attachPathList.length > 1 && (
                  <Icon
                    type="chai"
                    onClick={this.split}
                    className="f-fs16 e-ml8"
                    data-title="拆分附件"
                  />
                )}
                <Icon
                  onClick={this.delete}
                  type="huishouzhan"
                  className="f-fs14 e-ml5"
                  style={{ top: -1 }}
                  data-title="删除附件"
                />
              </em>
            )}
            {!!data.templateName && data.clearState !== 0 && (
              <Row>
                <Col span={12} title={data.templateName} className="f-toe">
                  {data.voucherCode ? (
                    <em
                      className="f-cp"
                      style={{ textDecoration: 'underline' }}
                      onClick={this.showVoucher}
                    >
                      {data.voucherCode}
                    </em>
                  ) : (
                    data.templateName
                  )}
                </Col>
                <Col span={12} title={data.money} className="f-toe">
                  {data.money}
                </Col>
              </Row>
            )}
          </>
        </LazyLoad>
      </div>
    );
  }
}
Item.defaultProps = {
  data: {},
};
Item.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
  checkedIds: PropTypes.arrayOf(PropTypes.any).isRequired,
  tableSearchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  treeSearchParams: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ checkedIds, tableSearchParams, treeSearchParams }) => ({
  checkedIds,
  tableSearchParams,
  treeSearchParams,
}))(Item);
