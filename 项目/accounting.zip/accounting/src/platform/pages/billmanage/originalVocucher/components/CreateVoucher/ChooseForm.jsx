import React from 'react';
import PropTypes from 'prop-types';
import { Form, Popover, Button, Radio, Row, Col, Checkbox } from 'antd';
import { createForm } from 'layer';
import Icon from '@/Icon';

const options = [
  {
    label: '按业务分类汇总生成凭证',
    title: '每个业务分类汇总生成一张凭证，金额为当前分类下所有附件的金额汇总。',
    value: '1',
  },
  {
    label: '所选原始凭证汇总生成一张凭证',
    title:
      '所有选择的原始凭证生成一张凭证，相当于各份原始凭证生成凭证后再汇总。如果出现相同科目则给出提示，让用户选择。',
    value: '2',
  },
  {
    label: '按业务分类+日期汇总生成凭证',
    title: '每个分类下不同日期分别汇总生成凭证。',
    value: '3',
  },
  {
    label: '每份原始凭证生成一张凭证',
    title: '每份原始凭证对应生成一张凭证。',
    value: '4',
  },
];

class ChooseForm extends React.Component {
  componentDidMount() {}

  render() {
    const { layer, form, vchType, getLocal, submit } = this.props;
    const { getFieldDecorator } = form;
    const { originalVoucherGenerate, accountToken } = getLocal();
    return (
      <Form style={{ padding: '4px 20px 20px' }}>
        <div className="e-mb20 e-pl20">
          {getFieldDecorator('type', {
            initialValue: originalVoucherGenerate[accountToken].type || '1',
          })(
            <Radio.Group onChange={vchType}>
              {options.map((v) => {
                return (
                  <Radio key={v.value} style={{ display: 'block', marginTop: 16 }} value={v.value}>
                    {v.label}
                    <Popover
                      getPopupContainer={() => layer.element[0]}
                      arrowPointAtCenter
                      placement="rightTop"
                      content={<div style={{ width: 160 }}>{v.title}</div>}
                      trigger="hover"
                    >
                      <Icon type="wenhao1" className="e-ml5" />
                    </Popover>
                  </Radio>
                );
              })}
            </Radio.Group>,
          )}
        </div>
        <Row>
          <Col span={10} style={{ paddingTop: 4 }}>
            {getFieldDecorator('unshow')(<Checkbox>不再显示</Checkbox>)}
          </Col>
          <Col span={14} className="f-tar">
            <Button type="primary" ghost onClick={() => layer.destroy()}>
              关闭
            </Button>
            <Button type="primary" onClick={() => submit()} className="e-ml16">
              确定
            </Button>
          </Col>
        </Row>
      </Form>
    );
  }
}
ChooseForm.propTypes = {
  layer: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  vchType: PropTypes.func.isRequired,
  getLocal: PropTypes.func.isRequired,
  submit: PropTypes.func.isRequired,
};

export default createForm()(ChooseForm);
