import { message } from 'antd';
import { BaseEffects } from 'effects';
import { request } from 'nuijs';
import $data from 'data';
import { ConfirmModal } from '@/modal';
import { backupCheck } from '@/BackUp';
import services from '../services';

class Effetcs extends BaseEffects {
  setState = (data) => {
    this.dispatch({
      type: 'updateState',
      payload: data,
    });
  };

  async initData() {
    await this.initPeriod();
    await this.getStockAuxiliaryList();
  }

  // 获取左侧树的数据
  async $queryTreeData(queryData) {
    // await this.initPeriod();
    const { query, treeSearchParams } = this.getState();
    const { beginDate, endDate, startDate } = query;
    const params = {
      ...treeSearchParams,
      endDate,
      startDate: beginDate || startDate,
    };
    if (!params.startDate) {
      return false;
    }
    const data = await services.queryTree(queryData || params);
    const treeData = [];
    const temp = {};
    data.forEach((val) => {
      const v = val;
      if (!v.children) {
        v.children = [];
      }
      if (temp[v.id]) {
        v.children = temp[v.id].children;
      }
      if (temp[v.pid]) {
        temp[v.pid].children.push(v);
      } else if (v.pid !== undefined) {
        temp[v.pid] = {
          children: [v],
        };
      } else {
        treeData.push(v);
      }
      temp[v.id] = v;
    });
    try {
      const { children } = treeData[0].children[1];
      let leaf = [];
      children.forEach((v) => {
        leaf = leaf.concat(v.children);
      });
      $data('treeData', children);
      $data('treeAllData', leaf);
    } catch (e) {
      console.log(e);
    }
    this.setState({
      treeData,
      treeSearchParams: params,
    });
  }

  // 获取右侧主体部分的数据
  async $queryTableData() {
    // await this.initPeriod();
    const { query, tableSearchParams } = this.getState();
    const { beginDate, endDate, startDate } = query;
    const params = {
      ...tableSearchParams,
      endDate,
      startDate: beginDate || startDate,
    };
    const data = await services.queryTableData(params);
    this.setState({
      voucherData: data.list || [],
      checkedIds: [],
      tableSearchParams: params,
    });
  }

  // 设置选中数据
  setChecked = (parmas) => {
    this.setState({
      checkedIds: parmas,
    });
  };

  // 更新树搜索的条件
  setTreeSearchParams = (params) => {
    const { treeSearchParams } = this.getState();
    const data = {
      ...treeSearchParams,
      ...params,
    };
    this.setState({
      treeSearchParams: data,
    });
  };

  // 更新表格搜素的条件
  setTableSearchParmas = (params) => {
    const { tableSearchParams } = this.getState();
    const data = {
      ...tableSearchParams,
      ...params,
    };
    this.setState({
      tableSearchParams: data,
    });
  };

  // 删除表格数据
  deleteData = async (params) => {
    await services.deleteData({ originalIds: params.ids });
    message.success('删除成功！');
    this.$queryTreeData();
    this.$queryTableData();
  };

  // 需要操作的原始凭证中是否包含无效的，比如已生成凭证/已整理 ids, field, value, callback
  hasInvalid = (rest) => {
    let fieldValue;
    let ret = false;
    const args = rest;
    let len = args.length;
    let [ids, field, value, callback] = args;
    const { voucherData } = this.getState();
    if (typeof value === 'function') {
      callback = value;
      value = undefined;
      len = 2;
    }
    ids = ids.concat(ids);
    field = String(field);
    voucherData.forEach((v) => {
      v.originalVoucherResultList.forEach((_v) => {
        if (ids.includes(_v.originalId)) {
          const val = _v[field];
          if ((len === 2 && val) || (len > 2 && val === value)) {
            fieldValue = val;
            ret = true;
            return false;
          }
        }
        return true;
      });
      if (ret) {
        return false;
      }
      return true;
    });
    if (ret && callback) {
      callback(fieldValue);
    }
    return ret;
  };

  // 合并附件
  mergeFile = async (params) => {
    try {
      this.setState({ isRequest: true });
      const originalIds = params.join(',');
      await services.mergeFile({ originalIds });
      message.success('合并成功！');
      this.$queryTableData();
      this.$queryTreeData();
    } finally {
      this.setState({
        isRequest: false,
      });
    }
  };

  // 拆分附件
  splitFile = async (params) => {
    await services.splitFile({ originalId: params.id });
    message.success('拆分成功！');
    this.$queryTreeData();
    this.$queryTableData();
  };

  // 获取存货
  async getStockAuxiliaryList() {
    const data = await services.getStockAuxiliaryList();
    this.setState({
      stockAuxiliaryList: data,
    });
  }

  // 存货新增相关
  async getAuxTypeIdByType() {
    const { addStockProps } = this.getState();
    if (!addStockProps.auxiliaryTypeId) {
      const data = await services.getAuxTypeIdByType({ type: 4 }); // 4为存货
      await this.updateState({
        addStockProps: {
          ...addStockProps,
          auxiliaryTypeId: data,
        },
      });
    }
    await this.generateCode();
    await this.getStdClassifies();
  }

  async generateCode() {
    const { addStockProps } = this.getState();
    const { auxiliaryTypeId } = addStockProps;
    const data = await services.generateCode({ auxTypeId: auxiliaryTypeId, autoExpand: false });
    this.updateState({
      addStockProps: {
        ...addStockProps,
        auxiliaryCode: data,
      },
    });
  }

  async getStdClassifies() {
    const data = await services.getStdClassifies();
    this.updateState({
      stockTypeList: data.map((v) => ({ ...v, key: v.value, title: v.name })),
    });
  }

  // addAuxiliary = async (state) => {
  //   const data = await services.addAuxiliary(state);
  //   return data;
  // };

  async matchStockAuxiliary(state) {
    const { success, details } = state;
    const { auxiliaryVoucherObject } = this.getState();
    const data = await services.matchStockAuxiliary({ details });
    const { userHandleList } = data;
    success(userHandleList);
    await this.updateState({
      auxiliaryVoucherObject: {
        ...auxiliaryVoucherObject,
        userHandleList,
      },
    });
    await this.getStockAuxiliaryList();
  }
  // 新增存货相关结束

  getGeneralConvertRuleByCondition = () => {
    return services.getGeneralConvertRuleByCondition();
  };

  async batchAddAuxiliary(state) {
    const { userHandleResult, customerAuxiliaryRequest, supplierAuxiliaryRequest, cb } = state;
    const params = {
      aliasSource: '1,2',
      userHandleResult,
      customerAuxiliaryRequest,
      supplierAuxiliaryRequest,
    };
    const { auxiliaryCb } = this.getState();
    await services.batchAddAuxiliary(
      {
        ...params,
        autoExpand: false,
      },
      {
        loading: true,
        status: {
          '^300': (data) => {
            message.error(data.message);
          },
          30000010025: () => {
            ConfirmModal({
              title: '新增失败',
              content: '编码长度已到达上限，可在账套设置中增加长度位数后重试。',
              okText: '立即增加',
              cancelText: '再想想',
              centered: true,
              width: 319,
              className: 'modal-without-close',
              onOk: async () => {
                backupCheck({}, async (fig) => {
                  if (fig !== false) {
                    await services.batchAddAuxiliary(
                      { ...params, autoExpand: true },
                      { loading: true },
                    );
                    if (cb) {
                      await cb();
                    } else {
                      await auxiliaryCb(userHandleResult);
                    }
                  }
                });
              },
              onCancel: () => {},
            });
          },
        },
      },
    );
    if (cb) {
      await cb();
    } else {
      await auxiliaryCb(userHandleResult);
    }
  }

  // 生成凭证预处理
  async prepareVoucher(state) {
    const { originalIds, cb } = state;
    const data = await services.prepareVoucher({ originalIds }, { loading: true });
    this.dispatch({
      type: 'updateState',
      payload: {
        prepareData: {
          ...data,
          cb,
        },
      },
    }).then(() => {
      this.prepareOperation();
    });
  }

  async prepareOperation(type) {
    const { prepareData } = this.getState();
    const {
      stockAuxiliaryMatchResponse = {},
      supplierAuxiliaryResponse = {},
      customerAuxiliaryResponse = {},
      cb,
    } = prepareData;
    if (
      type !== 'auxiliaryNext' &&
      (supplierAuxiliaryResponse.auxiliaryNames || customerAuxiliaryResponse.auxiliaryNames)
    ) {
      this.dispatch({
        type: 'updateState',
        payload: {
          isShowCreateAuxiliary: true,
          supplierAuxiliaryResponse,
          customerAuxiliaryResponse,
        },
      });
      return;
    }
    const { userHandleList = [] } = stockAuxiliaryMatchResponse;
    if (userHandleList.length > 0) {
      await this.getStockAuxiliaryList();
      this.setState({
        isAuxiliary: true,
        auxiliaryVoucherObject: {
          ...stockAuxiliaryMatchResponse,
          allMatchCount:
            Number(stockAuxiliaryMatchResponse.matchCount) +
            Number(stockAuxiliaryMatchResponse.notMatchCount),
        },
        auxiliaryCb: async (userHandleResult) => {
          await this.setState({ isAuxiliary: false });
          await cb(userHandleResult);
        },
      });
    } else {
      cb();
    }
  }

  // 生成凭证
  createOriginalVouchers = async (params) => {
    // console.log(params);
    const {
      query: { endDate },
    } = this.getState();
    let newParmas;
    if (params.selectDate) {
      newParmas = {
        selectDate: endDate,
        ...params,
      };
    } else {
      newParmas = {
        ...params,
        selectDate: endDate,
      };
    }
    const data = await services.createOriginalVouchers(newParmas, { loading: true });
    return data;
  };

  // 获取详情数据
  async $queryDetail(params) {
    const { form } = this.nuomiProps;
    // const { startDate, endDate, originalIds } = params;
    const res = await services.queryByDetail(params);
    const data = { ...res };
    const { nextId, preId, attachPathList, ...rest } = data;
    if (form) {
      form.resetFields();
    }
    this.setState({
      currentIndex: 0,
      nid: nextId,
      pid: preId,
      paths: attachPathList || [],
      data: rest,
    });
  }

  // 获取表单数据
  queryMoldList = async () => {
    const data = await services.queryMoldList();
    this.setState({
      moldList: data,
    });
  };

  // 获取最近使用的模板
  queryTemplateLastUsed = async () => {
    const data = await services.queryTemplateLastUsed();
    this.setState({
      usedTemplate: data,
    });
  };

  /* 新增存货核算 start */

  // 获取单位列表
  async getUnitList(state = {}) {
    const { isOtherTab, type, ...params } = state;
    const { unitType } = this.getState();
    const useType = isOtherTab ? type : Number(unitType);
    if (useType === 1) {
      params.needLines = 1;
    }
    const data = await services.getUnitList({ ...params, type: useType });
    this.setState({
      unitListDataSource: data,
      ...(useType === 1 ? { unitGroupList: data } : { unitList: data }),
    });
  }

  // 添加计量单位
  async addUnit(state) {
    const { success, ...params } = state;
    const { unitType } = this.getState();
    await services.addUnit({ ...params, type: Number(unitType) });

    message.success('新增成功');
    success && success();
    this.getUnitList();
  }

  async updateUnit(state) {
    const { success, ...params } = state;
    const { unitType } = this.getState();
    await services.updateUnit({ ...params, type: Number(unitType) });
    success && success();
    this.getUnitList();
  }
  // 查询所有的存货别名
  async getStockAlias() {
    const data = await services.getStockAlias();
    this.setState({
      stockAliasDataSource: data,
    });
  }

  // 存货接口
  async openStockModal({ type, params }) {
    const { unitList = [], stockAliasDataSource = [], auxiliarySetting = [] } = this.getState();
    const getAuxiliarySetting =
      auxiliarySetting.length > 0 ? auxiliarySetting : await services.getAuxiliaryTypes();

    unitList.length === 0 && (await this.getUnitList({ isOtherTab: true, type: 0 }));

    await this.getUnitList({ isOtherTab: true, type: 1, needLines: 1 });
    stockAliasDataSource.length === 0 && (await this.getStockAlias());

    const item = getAuxiliarySetting.find((v) => v.auxiliaryTypeName === '存货');

    const code = await services.generateCode({
      autoExpand: false,
      auxTypeId: item.auxiliaryTypeId,
    });

    await this.setState({
      auxiliarySetting: getAuxiliarySetting,
      stockConfigure: {
        visible: true,
        type,
        formData: {
          ...params,
          auxiliaryCode: code,
        },
      },
    });
  }

  // 新增存货
  async getCategory() {
    const { categorySourceList = {} } = this.getState();
    const onData = categorySourceList.stockConfigure;

    const addSet = {};
    this.openStockModal({ type: 'add' });

    if (onData && onData.length > 0) {
      this.setState({
        categorySource: onData,
        ...addSet,
      });
      return;
    }
    const data = await services.getCategory({ type: '3' }, { loading: true });

    this.setState({
      isSimplify: true,
      isShowCategory: false,
      categorySource: data,
      categorySourceList: {
        ...categorySourceList,
        stockConfigure: data,
      },
      ...addSet,
    });
  }

  // 添加辅助核算
  async addAuxiliary(state) {
    const { callback, ...rest } = state;
    const { auxiliarySetting } = this.getState();
    const archiveCategoryName = '存货';

    const item = auxiliarySetting.find((v) => v.auxiliaryTypeName === archiveCategoryName);
    await services.addAuxiliary(
      {
        ...rest,
        auxiliaryTypeId: item.auxiliaryTypeId,
        autoExpand: false,
      },
      { loading: true },
    );
    callback && callback();
    await this.getStockAuxiliaryList();
  }

  // async queryAuxiliaries(name) {
  //   const { auxiliarySetting } = this.getState();
  //   const item = auxiliarySetting.find((v) => v.auxiliaryTypeName === name);
  //   const data = await services.queryAuxiliaries(
  //     {
  //       auxiliaryTypeId: item.auxiliaryTypeId,
  //       isEnable: 1,
  //     },
  //     { loading: true },
  //   );
  //   this.setState({
  //     stockAuxiliaryList: data.map((element) => {
  //       const { auxiliaryName, model, auxiliaryCode } = element;
  //       return {
  //         ...element,
  //         stockInfo: `${auxiliaryCode} ${auxiliaryName} ${model}`,
  //       };
  //     }),
  //   });
  // }

  /* 新增存货核算 end */

  // 新增发票资金
  addTemplateO = async (data) => {
    const { treeSearchParams } = this.nuomiProps.data;
    // const { templateType } = this.getState();
    const params = data;
    params.templateType = 1; // templateType === 'invoice' ? 1 : 2;
    params.invoiceType = Number(params.invoiceType);
    return request.postJSON('account/originalTemplate/add', params, {
      200: (res) => {
        message.success('新增成功！');
        this.$queryTreeData(treeSearchParams);
        this.setState({
          isShowAddTplModal: false,
          editTableData: [],
          templateId: res.data,
        });
        return res.data;
      },
      201: (res) => {
        ConfirmModal({
          title: '已存在相同凭证模板，继续将覆盖原有凭证模板，确定继续？',
          content: '',
          width: 320,
          centered: true,
          okText: '确认',
          cancelText: '取消',
          onOk: () => {
            params.templateId = res.data;
            const resp = services.updateTemplateO(params);
            message.success('新增成功！');
            this.$queryTreeData(treeSearchParams);
            this.setState({
              isShowAddTplModal: false,
              editTableData: [],
              templateId: res.data,
            });
            return resp;
          },
        });
      },
    });
  };

  // 获取科目列表数据
  getSubjectList = async () => {
    const data = await services.getSubjectList();
    this.setState({ subjectList: data });
  };

  // 详情生成凭证保存
  clearAtt = async (params) => {
    const { noMessage } = params;
    const data = await services.clearAtt(params);
    !noMessage && message.success('保存成功！');
    return data;
  };
}

export default Effetcs;
