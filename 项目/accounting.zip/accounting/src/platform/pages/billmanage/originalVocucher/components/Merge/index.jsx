import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, message } from 'antd';
import { superLayer } from 'layer';
import SuperModal from '@/modal/SuperModal';

const Merge = (props) => {
  const { checkedIds, dispatch, isRequest } = props;
  const [resData, setResData] = useState(undefined);
  const handleMerge = async () => {
    if (checkedIds.length > 100) {
      message.error('每次合并最多选择100张图片，您已经超过上限，请重新选择图片');
      return false;
    }

    if (
      await dispatch({
        type: 'hasInvalid',
        payload: [
          checkedIds,
          'voucherId',
          (voucherId) => {
            SuperModal({
              content: (
                <p className="e-p20 e-pt15 e-pb15 f-lh20">
                  亲，已有原始凭证生成会计凭证，请先删除相应的会计凭证再合并！
                </p>
              ),
              cancelText: '我知道了',
              okText: '查看凭证',
              centered: true,
              onOk: () => {
                superLayer('voucher/record', {
                  data: {
                    title: '记账凭证',
                    voucherId,
                    isBillManage: true,
                  },
                  isBack: false,
                  onDestroy() {
                    if (resData) {
                      dispatch({ type: '$queryTreeData' });
                      dispatch({ type: '$queryTableData' });
                    }
                    setResData(undefined);
                  },
                  onSave(data) {
                    setResData(data);
                  },
                });
              },
            });
          },
        ],
      })
    ) {
      return false;
    }
    if (await dispatch({ type: 'hasInvalid', payload: [checkedIds, 'clearState', 1] })) {
      SuperModal({
        content: (
          <p className="e-p20 f-tal">亲，合并后将会丢失原始凭证上原已录入的信息，是否继续合并？</p>
        ),
        cancelText: '我再想想',
        okText: '确认合并',
        width: 360,
        centered: true,
        onOk: () => {
          dispatch({ type: 'mergeFile', payload: checkedIds });
        },
      });
      return false;
    }
    return dispatch({ type: 'mergeFile', payload: checkedIds });
  };
  return (
    <Button type="default" onClick={handleMerge} loading={isRequest}>
      合并附件
    </Button>
  );
};
Merge.defaultProps = {
  checkedIds: [],
};
Merge.propTypes = {
  checkedIds: PropTypes.arrayOf(PropTypes.any),
  dispatch: PropTypes.func.isRequired,
  isRequest: PropTypes.bool.isRequired,
};

export default connect(({ checkedIds, isRequest }) => ({
  checkedIds,
  isRequest,
}))(Merge);
