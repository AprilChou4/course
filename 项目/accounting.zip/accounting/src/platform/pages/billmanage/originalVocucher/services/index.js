import { util } from 'nuijs';

export default util.createRequest({
  // 获取科目列表
  getSubjectList: 'account/subject/queryLeafSubject',
  queryTree: 'invoice/originalVoucher/queryTree:post',
  queryTableData: 'invoice/originalVoucher/query:post',
  mergeFile: 'invoice/originalVoucher/merge:post',
  deleteData: 'invoice/originalVoucher/delete:post',
  splitFile: 'invoice/originalVoucher/split:post',
  queryTemplateLastUsed: 'invoice/originalVoucher/getTemplateLastUsed',
  queryByDetail: 'invoice/originalVoucher/detail:post',
  queryMoldList: 'invoice/originalVoucher/getRecognitionTypeList',
  clearAtt: 'invoice/originalVoucher/arrange:post',
  // 获取所有存货辅助核算
  getStockAuxiliaryList: 'account/auxiliary/getStockAuxiliaryList', // 'invoice/bill/getStockAuxiliaryList', //
  getGeneralConvertRuleByCondition: 'invoice/bill/getGeneralConvertRuleByCondition',
  // 存辅助核算
  batchAddAuxiliary: 'invoice/bill/batchAddAuxiliary:postJSON',
  // 生成凭证预处理
  prepareVoucher: 'invoice/originalVoucher/prepareVoucher:post',
  createOriginalVouchers: 'invoice/originalVoucher/createVouchers:postJSON',
  updateTemplateO: 'account/originalTemplate/update:postJSON',
  // 存货新增相关
  getAuxTypeIdByType: 'account/auxiliary/type/getAuxTypeIdByType',
  generateCode: 'account/auxiliary/generateCode', // 存货编码
  getStdClassifies: 'account/auxiliary/classify/getStdClassifies', // 存货类别
  addAuxiliary: 'account/auxiliary/add:postJSON', // 添加辅助核算
  matchStockAuxiliary: 'invoice/bill/matchStockAuxiliary:postJSON', // 匹配存货

  // 存货相关
  // 获取辅助核算类型
  getAuxiliaryTypes: 'account/auxiliary/type/getAuxiliaryTypes:post',
  getUnitList: 'account/unit/list', // 获取单位列表
  getStockAlias: 'account/stockAlias/list', // 查询所有的存货别名
  // generateCode: 'account/auxiliary/generateCode', // 获取编码
  // 类别
  getCategory: 'account/archiveCategory/list',
  // 获取辅助核算
  queryAuxiliaries: 'account/auxiliary/queryAuxiliaries.do:postJSON',

  triggerNoDiskExtract: `invoice/bill/triggerNoDiskExtract`,
  addUnit: 'account/unit/add:postJSON', // 新增单位
  updateUnit: 'account/unit/update:postJSON',
});
