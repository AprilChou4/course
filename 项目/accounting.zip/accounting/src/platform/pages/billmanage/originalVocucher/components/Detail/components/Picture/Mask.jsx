import React, { useState } from 'react';
import './index.less';

const Mask = () => {
  const [visible, setVisible] = useState(true);
  return (
    visible && (
      <div styleName="original-voucher">
        <i
          className="iconfont icon-yeqianguanbi"
          onClick={() => {
            setVisible(false);
          }}
        />
        <div styleName="content">
          <p style={{ marginBottom: '20px' }}>ofd电子发票暂不支持预览，请下载“ofd文件阅读器”查看</p>
          <p>
            <a href="https://inv-veri.chinatax.gov.cn/xgxz.html" target="black">
              下载ofd文件阅读器
            </a>
          </p>
        </div>
      </div>
    )
  );
};

export default Mask;
