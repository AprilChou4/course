import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, DatePicker, Row, Col, Select, message } from 'antd';
import { reactLayer } from 'layer';
import { util, request } from 'nuijs';
import moment from 'moment';
import trackEvent from 'public/trackEvent';
import SuperModal from '@/modal/SuperModal';
import './index.less';

const { MonthPicker } = DatePicker;
const { Option } = Select;
const accountToken = util.getParam('id', `/${window.location.search}`);
const useH5 = typeof FormData !== 'undefined' && typeof FileReader !== 'undefined';
const uploadId = 'upload-original-voucher';
let type = ''; // 1.发票 2.银行回单
let succSize = 0; // 成功得数量
let errSize = 0; // 失败数量

const services = util.createRequest({
  getQuato: 'invoice/bill/getQuota',
});

class Import extends Component {
  UNSAFE_componentWillMount() {
    require.ensure([], (require) => {
      // 高级浏览器使用H5上传
      if (useH5) {
        require('nuonuo-libs/script/uploadify/jquery.uploadifive');
      }
      // 低版本使用flash上传
      else {
        require('nuonuo-libs/script/uploadify/jquery.uploadify');
      }
    });
  }

  // 企业版检测可用额度
  checkQuota = async () => {
    const { dispatch, companyId, isAdmin } = this.props;
    const { freeQuota, paymentQuota, totalPaymentQuota } = await services.getQuato({
      companyId,
      productType: 4,
    });

    // if (paymentQuota) {//测试
    if (!freeQuota && !paymentQuota) {
      const title = '你的额度已用完，如需使用请联系客服人员购买';
      // !freeQuota && !totalPaymentQuota
      //   ? '您的500张免费额度已用完，如果觉得不错就请购买吧！'
      //   : '您的额度已用完，如需使用请进行购买！';

      SuperModal({
        content: <div style={{ height: 50, marginTop: 10 }}>{title}</div>,
        okText: '关闭',
        hideOk: !isAdmin,
        onOk: () => {
          // trackEvent('OCR票据识别', '立即购买');
          // dispatch({ type: 'account/onBuy', payload: 4 });
        },
      });

      return false;
    }

    const usedNum = totalPaymentQuota - paymentQuota;
    return { usedNum, freeQuota, paymentQuota, totalPaymentQuota };
  };

  click = async () => {
    const { dispatch, date, isCompanyType, entoken } = this.props;

    let countData = null;
    // 企业版检测
    if (isCompanyType) {
      const res = await this.checkQuota();
      if (!res) return;
      countData = res;
    }

    const { usedNum, freeQuota, paymentQuota, totalPaymentQuota } = countData || {};
    // TODO:BUY
    // <%if isCompanyType%>
    //                   <%if freeQuota%>
    //                     <div class="g-charge-tips">
    //                       <span class="orange">亲！您有${freeQuota}张免费体验的优惠哦！</span>
    //                     </div>
    //                   <%else%>
    //                     <div class="g-charge-tips">
    //                       总额度：${totalPaymentQuota}张 &nbsp;&nbsp;<span class="used">已使用：${usedNum}张</span> &nbsp;&nbsp;<span class="nouse">未使用：${paymentQuota}张</span>
    //                     </div>
    //                   <%/if%>
    //                 <%/if%>

    reactLayer({
      title: '导入附件',
      width: 500,
      template: `<div>
                    <%if isCompanyType%>
                      <%if freeQuota%>
                        <div class="g-charge-tips">
                          <span class="orange">亲！您有${freeQuota}张免费体验的优惠哦！</span>
                        </div>
                      <%else%>
                        <div class="g-charge-tips">
                          总额度：${totalPaymentQuota}张 &nbsp;&nbsp;<span class="used">已使用：${usedNum}张</span> &nbsp;&nbsp;<span class="nouse">未使用：${paymentQuota}张</span>
                        </div>
                      <%/if%>
                    <%/if%>
                    <div class="e-p20 e-pb10">
                      <div class="component-container"></div>
                      <div class="import">
                        <span>
                          <%if installFlash%>
                          <em
                            >导入附件需要Adobe Flash支持，<a
                              href="{{installFlash}}"
                              target="_blank"
                              class="f-cblue"
                              >请先下载</a
                            >，安装完后请重启浏览器！</em
                          >
                          <%else%>
                          <input type="file" name="file" id="${uploadId}" multiple="true" />
                          <%/if%>
                        </span>
                        <p class="f-cred">亲，导入扫描的票据越清晰，系统识别率越高。</p>
                        <div id="queue"></div>
                      </div>
                    </div>
                  </div>`,
      data: {
        // 检测是否需要安装flash
        installFlash: useH5 ? false : util.isInstallFlash(),
        date,
        freeQuota,
        paymentQuota,
        totalPaymentQuota,
        usedNum,
        isCompanyType,
      },
      cencel: {
        text: '关闭',
      },
      confirm: {
        enable: true,
        text: '导入',
        callback(self) {
          if (!type) {
            message.error('请选择单据类型');
            return false;
          }
          const len = self.main.find('.uploadify-queue-item').length;
          if (!len) {
            message.error('请添加图片');
            return false;
          }
          const $upload = $(`#${uploadId}`);
          const formData = {
            date,
            type,
            // accountToken,
          };
          if (useH5) {
            const { settings } = $upload.data('uploadify');
            settings.formData = formData;
          } else {
            $upload.uploadify('settings', 'formData', formData);
          }

          $upload.uploadify('upload', '*');
          return false;
        },
      },
      changeEvent(e) {
        type = e;
      },
      render() {
        const { element } = this;
        return (
          <Row>
            <Col span={4} className="f-lh32" styleName="label">
              会计期间：
            </Col>
            <Col span={7}>
              <MonthPicker
                disabled
                defaultValue={moment(date)}
                getCalendarContainer={() => element[0]}
              />
            </Col>
            <Col span={4} className="f-lh32" style={{ marginLeft: 36 }} styleName="label">
              单据类型：
            </Col>
            <Col span={7}>
              <Select
                onChange={this.changeEvent}
                getPopupContainer={() => element[0]}
                style={{ width: '100%' }}
              >
                <Option value="1">发票</Option>
                <Option value="2">银行回单</Option>
              </Select>
            </Col>
          </Row>
        );
      },
      getUploadUrl() {
        const url = 'invoice/originalVoucher/imageUpload';
        return `${
          request.config('preurl')(url) + url + request.config('ext')
        }?accountToken=${accountToken}${entoken ? `&entoken=${entoken}` : ''}`;
      },
      // 弹出层关闭前需要销毁上传组件，不然IE下弹出层无法关闭
      onDestroyBefore() {
        $(`#${uploadId}`).uploadify('destroy');
        type = '';
        // 存在部分上次成功情况
        if (succSize !== 0 && errSize !== 0) {
          dispatch({ type: '$queryTreeData' });
          dispatch({ type: '$queryTableData' });
        }
        succSize = 0;
        errSize = 0;
      },
      onInit(self) {
        let myQueueData;
        const uploadError = function (file, msg) {
          let $elem;
          // flash导入
          if (file.id) {
            $elem = $(`#${file.id}`).addClass('err');
          }
          // h5导入
          else if (file.queueItem) {
            $elem = file.queueItem.addClass('err');
          }
          if ($elem) {
            $elem
              .find('.uploadify-detail > .fileName')
              .append(`<s class="e-ml5" data-title="${msg}">导入失败！</s>`);
          }
        };
        $(`#${uploadId}`).uploadify({
          preventCaching: false,
          auto: false,
          removeCompleted: false,
          buttonText: `<span class="f-db f-cblue" style="margin-top:12px;">
                            <i class="iconfont e-mr5">&#xe63a;</i><span>点击添加文件</span>
                        </span>
                        <span class="f-db f-cgray" style="margin-top:6px;">
                            支持扩展名：.jpg 、 .jpeg 、 .png 、 .bmp 、 .pdf、 .ofd格式文件
                        </span>`,
          itemTemplate:
            /* eslint-disable */
            '<div id="${fileID}" class="uploadify-queue-item">\
                            <div class="uploadify-detail">\
                                <span class="fileName f-fl"><b class="f-fl f-toe filename">${fileName}</b></span>\
                                <a class="f-fr close" href="javascript:$(\'#${instanceID}\').uploadify(\'cancel\', \'${fileID}\')">X</a>\
                                <span class="fileSize f-fr f-cgray">${fileSize}</span>\
                            </div>\
                            <div class="uploadify-progress">\
                                <div class="uploadify-progress-bar"></div>\
                            </div>\
                        </div>',
          removeTimeout: 20,
          fileTypeExts: '*',
          // fileType: 'image/jpeg,image/png,image/bmp,application/pdf,application/ofd',
          fileObjName: 'files',
          swf: `${basePath}static/files/uploadify.swf?_=${new Date().getTime()}`,
          queueID: 'queue',
          width: '100%',
          height: '100%',
          fileSizeLimit: 20 * 1024 * 1024,
          uploader: this.getUploadUrl(),
          onSelect() {
            self.resize();
            const { queueData } = this;
            myQueueData = queueData;
          },
          onRemove(id) {
            self.resize();
            if (myQueueData) {
              Nui.each(myQueueData.files, (v, k) => {
                if (k === id) {
                  delete myQueueData.files[k];
                }
              });
            }
          },
          // 全部上传完毕后回调
          onQueueComplete: () => {
            const $items = self.main.find('.uploadify-queue-item');
            errSize = $items.filter('.err').length;
            succSize = $items.filter('.succ').length;
            if (!errSize && succSize) {
              self.destroy();
              message.success('上传成功！');
              dispatch({ type: '$queryTreeData' });
              dispatch({ type: '$queryTableData' });
            }
          },
          // h5
          onError(file, status, msg) {
            if (status === 'UPLOAD_LIMIT_EXCEEDED') {
              message.error(msg);
            } else if (file) {
              uploadError(file, msg);
            }
          },
          // flash
          onUploadError(file, status, msg) {
            if (status === -240) {
              message.error(msg);
            }
            // IE9下面上传后报406，但其实以及上传了
            else if (msg.indexOf('406') !== -1) {
              $(`#${file.id}`).addClass('succ');
            } else if (file) {
              uploadError(file, msg);
            } else if (status === 309) {
              window.location.reload();
            }
          },
          // 单张上传后回调
          onUploadSuccess(file, res) {
            if (res && /^{|}$/.test(res)) {
              let data = res;
              data = JSON.parse(data);
              if (data.status === '200') {
                // flash导入
                if (file.id) {
                  $(`#${file.id}`).addClass('succ');
                }
                // h5导入
                else if (file.queueItem) {
                  file.queueItem.addClass('succ');
                }
              } else {
                uploadError(file, data.message);
              }
            }
          },
        });
      },
    });
  };

  render() {
    const { state, currentDate, period } = this.props;
    const {
      query: { endDate },
    } = state;
    const maxOpenPeriod = period.length > 0 ? period[period.length - 1] : currentDate;
    const disabled = endDate < currentDate || endDate > maxOpenPeriod;
    return (
      <Button onClick={this.click} disabled={disabled} className="e-ml16" type="primary">
        导入附件
      </Button>
    );
  }
}

Import.defaultProps = {
  entoken: '',
};

Import.propTypes = {
  dispatch: PropTypes.func.isRequired,
  date: PropTypes.string.isRequired,
  state: PropTypes.any.isRequired,
  currentDate: PropTypes.string.isRequired,
  period: PropTypes.array.isRequired,
  companyId: PropTypes.string.isRequired,
  entoken: PropTypes.string.isRequired,
  isCompanyType: PropTypes.bool.isRequired,
  isAdmin: PropTypes.bool.isRequired,
};

export default connect(
  (state, { account: { currentDate, period, user, versionType, entoken } }) => ({
    state,
    currentDate,
    period,
    companyId: user.companyId || '',
    isCompanyType: versionType === '2',
    entoken,
    isAdmin: user?.roleName?.indexOf('管理员') !== -1,
  }),
)(Import);
