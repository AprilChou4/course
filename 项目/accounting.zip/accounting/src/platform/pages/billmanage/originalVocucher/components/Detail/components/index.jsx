import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Spin } from 'antd';
import { Head, Left, Right, Center, Title, Content, Layout } from '@/Layout';
import Picture from './Picture';
import RightForm from './RightForm';
import '../styles/index.less';

const Main = (props) => {
  const { data, nid, pid, dispatch, detailQuery, accountId, loadings, dispatchAll } = props;
  const { endDate } = detailQuery;
  useEffect(() => {
    dispatch({ type: '$queryDetail', payload: { ...detailQuery, accountId } });
    dispatch({ type: 'getSubjectList' });
  }, []);
  const preChange = () => {
    const params = {
      ...detailQuery,
      originalIds: pid,
    };
    dispatch({ type: '$queryDetail', payload: { ...params } });
  };
  const nextChange = () => {
    const params = {
      ...detailQuery,
      originalIds: nid,
    };
    dispatch({ type: '$queryDetail', payload: { ...params } });
  };
  return (
    <Layout>
      <Spin spinning={loadings.$queryDetail}>
        <div className="detail">
          <Head>
            <Left />
            <Center>
              <Title />
              <span className="e-ml16">会计期间：{endDate}</span>
            </Center>
            <Right>
              <Button
                onClick={preChange}
                disabled={pid === '0'}
                type="primary e-ml20"
                style={{ minWidth: 'auto' }}
              >
                <i className="iconfont icon-left" />
              </Button>
              <Button
                onClick={nextChange}
                disabled={nid === '0'}
                type="primary"
                style={{ marginLeft: 1, minWidth: 'auto' }}
              >
                <i className="iconfont icon-right" />
              </Button>
            </Right>
          </Head>
          <Content>
            {data && (
              <>
                <Picture detailQuery={detailQuery} />
                <RightForm detailQuery={detailQuery} dispatchAll={dispatchAll} />
              </>
            )}
          </Content>
        </div>
      </Spin>
    </Layout>
  );
};
Main.defaultProps = {
  data: null,
  nid: '',
  pid: '',
  detailQuery: {},
  loadings: {},
  dispatchAll: () => {},
};
Main.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
  nid: PropTypes.string,
  pid: PropTypes.string,
  detailQuery: PropTypes.objectOf(PropTypes.any),
  accountId: PropTypes.string.isRequired,
  loadings: PropTypes.objectOf(PropTypes.any),
  dispatchAll: PropTypes.func,
  dispatch: PropTypes.func.isRequired,
};

export default connect((state, { account: { accountId } }) => ({ ...state, accountId }))(Main);
