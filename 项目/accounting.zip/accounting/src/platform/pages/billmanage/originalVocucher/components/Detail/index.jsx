import React from 'react';
import Main from './components/index';
import Effetcs from '../../effetcs';

export default {
  render() {
    // eslint-disable-next-line
    return <Main {...this.data} />;
  },
  state: {
    currentIndex: 0,
    nid: '0',
    pid: '0',
    paths: [],
    usedTemplate: [],
    moldList: [],
    data: null,
    isShowAddTplModal: false, // 是否显示弹层
    editTableData: [],
    subjectList: [],
    templateId: '', // 模板id
  },
  reducers: {
    updateState: (state, { payload }) => ({ ...state, ...payload }),
  },
  effects() {
    return new Effetcs(this);
  },
};
