import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { Icon, message } from 'antd';
import { request } from 'nuijs';

class RecIcon extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
    };
  }

  click = () => {
    const { loading } = this.state;
    const { data, detailQuery, dispatch } = this.props;
    const { originalId } = data;
    const params = {
      ...detailQuery,
      originalIds: originalId,
    };
    if (!loading) {
      this.setState({
        loading: true,
      });
      request
        .post(
          'invoice/originalVoucher/distinguish',
          { originalId },
          {
            200: async (res) => {
              if (res.data && res.data.taskState === 3) {
                message.success('识别成功');
                await dispatch({
                  type: 'setState',
                  payload: {
                    currentIndex: 0,
                    ...res.data,
                  },
                });
                await dispatch({ type: '$queryDetail', payload: { ...params } });
              } else {
                message.error('识别失败');
              }
            },
          },
          null,
        )
        .complete(() => {
          this.setState({
            loading: false,
          });
        });
    }
  };

  render() {
    const { loading } = this.state;
    return (
      <span onClick={this.click} className="recIcon">
        {loading ? <Icon type="loading" /> : '自动识别'}
      </span>
    );
  }
}
RecIcon.defaultProps = {
  data: {},
  detailQuery: {},
};
RecIcon.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
  detailQuery: PropTypes.objectOf(PropTypes.any),
  dispatch: PropTypes.func.isRequired,
};
export default connect((state) => state)(withNuomi(RecIcon));
