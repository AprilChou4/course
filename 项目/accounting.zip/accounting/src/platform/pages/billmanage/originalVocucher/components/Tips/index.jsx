import React from 'react';
import '../../styles/index.less';
import SuperModal from '@/modal/SuperModal';

const Tips = () => {
  const handleClick = () => {
    SuperModal({
      className: 'origial-tips',
      title: '',
      width: 460,
      centered: true,
      content: (
        <div className="tips-modal">
          <p className="modal-content">
            <span>目前支持识别的发票类型：</span>
            增值税专用发票、增值税普通发票、增值税电子发票、火车票、出租车发票、增值税卷式发票、定额发票。
          </p>
          <p className="modal-content">
            <span>支持识别的回单包括：</span>
            中国银行、建设银行、交通银行、中国光大银行、兴业银行、农业银行、华夏银行、台州银行、工商银行、招商银行、民生银行、上海浦东发展银行、北京银行、杭州银行等。
          </p>
          <p className="modal-smail">
            <i className="iconfont icon-tanhao" />
            票据图片越清晰，角度越正，识别率越高哦！
          </p>
          <p className="modal-width-300">
            开发小哥哥正在努力地调教智能识别机器人，支持的单据类型会越来越多，识别率也会进一步提升，
            <span>敬请期待!</span>
          </p>
          <span className="modal-tips-bg" />
        </div>
      ),
      cancelText: '知道了',
      okButtonProps: {
        style: { display: 'none' },
      },
      cancelButtonProps: {
        style: { color: '#008CFF', borderColor: 'transparent' },
      },
    });
  };
  return (
    <div className="original-tips">
      <i className="iconfont icon-tongzhi1" />
      <span className="original-tips-info">
        支持识别的票据类型：增值税专用发票、增值税普通发票、增值税电子发票、火车票、出租车发票、增值税卷式发票、定额发票、大部分银行回单…
      </span>
      <span className="original-tips-more" onClick={handleClick}>
        查看详细信息
      </span>
    </div>
  );
};

export default Tips;
