/* eslint-disable react/jsx-no-bind */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Modal, Form, Select, message } from 'antd';

const { Option } = Select;

const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};

class MatchButton extends PureComponent {
  constructor() {
    super();
    this.state = {
      visible: false,
    };
  }

  match() {
    const { selectedRowKeys } = this.props;
    if (selectedRowKeys.length < 1) {
      message.info('请勾选需要匹配的行');
      return;
    }
    this.setState({ visible: true });
  }

  handleOk() {
    const { form, stockAuxiliaryList, success } = this.props;
    form.validateFields((err, obj) => {
      if (!err) {
        const { match } = obj;
        this.setState({ visible: false });
        success && success(stockAuxiliaryList.find((v) => v.auxiliaryId === match));
      }
    });
  }

  handleCancel() {
    this.setState({ visible: false });
  }

  render() {
    const { activeType, stockAuxiliaryList, selectedRowKeys, form } = this.props;
    const { getFieldDecorator } = form;
    const { visible } = this.state;
    return (
      <>
        {activeType === 2 && (
          <Button type="primary" ghost onClick={this.match.bind(this)} className="e-ml15">
            批量匹配
          </Button>
        )}
        <Modal
          visible={visible}
          onOk={this.handleOk.bind(this)}
          destroyOnClose
          width={380}
          title="批量匹配存货辅助核算"
          onCancel={this.handleCancel.bind(this)}
        >
          <Form {...formItemLayout}>
            <p>共选中{selectedRowKeys.length}条账外存货数据</p>
            <Form.Item
              className="e-mt12"
              label="匹配至"
              {...formItemLayout}
              style={{ padding: '16px 16px 16px 8px', background: '#fafafa' }}
            >
              {getFieldDecorator('match', {
                rules: [
                  {
                    required: true,
                    message: '请选择辅助核算',
                  },
                ],
              })(
                <Select
                  style={{ width: 230 }}
                  showSearch
                  filterOption={(val, option) => {
                    const { value, title } = option.props;
                    return value.toString().includes(val) || title.includes(val);
                  }}
                  placeholder="选择账面存货辅助核算"
                >
                  {stockAuxiliaryList.map((v) => {
                    const name = `${v.auxiliaryCode} ${v.auxiliaryName} ${v.model || ''}`;
                    return (
                      <Option key={v.auxiliaryId} value={v.auxiliaryId} title={name}>
                        {name}
                      </Option>
                    );
                  })}
                </Select>,
              )}
            </Form.Item>
          </Form>
        </Modal>
      </>
    );
  }
}
MatchButton.propTypes = {
  activeType: PropTypes.number.isRequired,
  stockAuxiliaryList: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  success: PropTypes.func.isRequired,
};
export default Form.create()(
  connect(({ stockAuxiliaryList }) => ({
    stockAuxiliaryList,
  }))(MatchButton),
);
