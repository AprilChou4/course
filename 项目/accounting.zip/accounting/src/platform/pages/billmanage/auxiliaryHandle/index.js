import React, { PureComponent } from 'react';
import Header from './commponents/Header';
import Content from './commponents/Content';

export default class AuxiliaryHandle extends PureComponent {
  render() {
    return (
      <>
        <Header />
        <Content />
      </>
    );
  }
}
