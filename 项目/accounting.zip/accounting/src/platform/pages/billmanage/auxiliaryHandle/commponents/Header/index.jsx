import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Head, Center, Title } from '@/Layout';
import Icon from '@/Icon';
import '../../css/index.less';

class Header extends PureComponent {
  returnInvoice() {
    const { dispatch } = this.props;
    dispatch({
      type: 'updateState',
      payload: {
        isAuxiliary: false,
      },
    });
  }

  render() {
    const { invoiceType } = this.props;
    return (
      <Head>
        <Center>
          <div styleName="return-btn" onClick={this.returnInvoice.bind(this)}>
            <Icon type="fanhui1" />
            <span style={{ marginLeft: 5 }}>{`返回${
              ['销项发票', '原始凭证'][['vat', 'original'].indexOf(invoiceType)] || '进项发票'
            }`}</span>
          </div>
          <Title text="账外存货辅助核算处理" />
        </Center>
      </Head>
    );
  }
}
Header.defaultProps = {
  invoiceType: '',
};
Header.propTypes = {
  invoiceType: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ invoiceType }) => ({ invoiceType }))(Header);
