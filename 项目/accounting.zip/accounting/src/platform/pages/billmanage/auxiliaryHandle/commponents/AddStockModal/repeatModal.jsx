import React from 'react';
import { Modal, Button } from 'antd';
import PropTypes from 'prop-types';
import { SuperModal } from '@/modal';
import './style.less';

const RepeatRowModal = (props) => {
  const { repeatData, onCancel, showMask, stockTypeList } = props;
  const { msg, auxiliary } = repeatData;

  const showRepeatRowInfo = () => {
    onCancel();
    const { auxiliaryCode, model, unit, classify, auxiliaryName } = auxiliary;
    const classifyName = [];

    if (classify) {
      const ids = classify.split(',');
      stockTypeList.forEach((item) => {
        if (ids.includes(`${item.value}`)) {
          classifyName.push(item.name);
        }
      });
    }

    showMask(false);
    SuperModal({
      title: '存货查看',
      onCancel: () => {
        showMask(true);
      },
      content: (
        <div styleName="tip-content">
          <p>存货编码：{auxiliaryCode}</p>
          <p>存货名称：{auxiliaryName}</p>
          <p>规格型号：{model}</p>
          <p>计量单位：{unit}</p>
          <p>核算分类：{classifyName.toString()}</p>
        </div>
      ),
      cancelText: '关闭',
      okButtonProps: {
        style: { display: 'none' },
      },
    });
  };

  const footer = (
    <>
      <Button type="default" onClick={showRepeatRowInfo}>
        查看
      </Button>
      <Button type="primary" onClick={onCancel}>
        重新输入
      </Button>
    </>
  );

  return (
    <Modal title="温馨提示" onCancel={onCancel} footer={footer} visible width={400} zIndex={10000}>
      <div styleName="tip-message">{msg}</div>
    </Modal>
  );
};

RepeatRowModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  showMask: PropTypes.func.isRequired,
  repeatData: PropTypes.objectOf(PropTypes.any).isRequired,
  stockTypeList: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default RepeatRowModal;
