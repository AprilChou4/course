import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect, router } from 'nuomi';
import { Button, Badge, Tooltip, message, Select, Checkbox, Modal } from 'antd';
import {
  StockModal,
  UnitModal,
  UnitGroupModal,
} from 'pages/stockModule/install/fileManagement/components/modals';
import { Content } from '@/Layout';
import SearchInput from '@/SearchInput';
import SuperTable from '@/SuperTable';
import TabelCell from '@/TableCell';
import InputNumber from '@/NumberInput';
import Ico from '@/Icon';
import MatchButton from '../MatchModal';
// import AddStockModal from '../AddStockModal';

import '../../css/index.less';

const { Option } = Select;
class auxiliaryContent extends PureComponent {
  constructor() {
    super();
    this.routerJump = () => {
      router.location('setting/auxiliary-manage?name=存货', {}, true);
    };
    this.events = [];
    this.state = {
      tableHeight: 0,
      activeType: 2,
      searchCondition: '',
      // 待新增数量
      waitAddCount: 0,
      // 待匹配数量
      waitMatchCount: 0,
      // 已匹配待转换
      matchWaitConvert: 0,

      allDataSource: [],
      dataSource: [],
      selectedRowKeys: [],
      // AddStockModalVisible: false,

      // someSubmitNum: 0,
      // someMatchNum: 0, // 自动匹配的数量
      noMemoryList: [],

      refreshKey: '',
    };
  }

  UNSAFE_componentWillMount() {
    const { userHandleList } = this.props;
    let isHas1 = true; // 是否有已匹配待转换
    const newUserHandleList = userHandleList.map((v) => {
      if (v.convertType !== 1) {
        isHas1 = false;
      }
      if (v.auxiliaryId) {
        const { stockAuxiliaryList } = this.props;
        const item = stockAuxiliaryList.find((h) => h.auxiliaryId === v.auxiliaryId) || {};
        const {
          auxiliaryCode,
          auxiliaryId,
          auxiliaryName,
          unit,
          model,
          unitId,
          isUnitGroup,
          unitGroup,
          convertType,
        } = item;
        const row = {
          ...v,
          auxiliaryCode,
          auxiliaryId,
          auxiliaryName,
          auxiliaryUnit: unit,
          auxiliaryModel: model,
          isRemember: v.convertType === 2 ? 1 : 0,
          unitId,
          isUnitGroup,
        };

        // row.convertType = 2;
        row.convertQuantity = 1;
        row.convertedQuantity = 1;
        row.convertRate = 1;
        if (unitGroup && isUnitGroup) {
          const unitline = unitGroup.filter((items) => items.subUnit === row.unit);
          if (unitline.length > 0) {
            row.convertRate = unitline[0].convertRate;
            row.disableds = convertType === 1;
          }
        }
        row.disabledConvert = !isUnitGroup && row.unit === row.auxiliaryUnit;
        return row;
      }
      return { ...v, isRemember: 0 };
    });
    if (isHas1) {
      this.switchChange(1, newUserHandleList || []);
    } else {
      this.setDataSource(newUserHandleList || []);
    }

    this.setState({ tableHeight: window.innerHeight - 240 });
    this.bind(window, 'resize', () => {
      this.setState({ tableHeight: window.innerHeight - 240 });
    });
    // setTimeout(() => {
    //   this.setState({ refreshKey: new Date().getTime() });
    // }, 100);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    setTimeout(
      () =>
        dispatch({
          type: 'setState',
          payload: {
            auxiliaryHandleRefreshTableKey: new Date().getTime(),
          },
        }),
      200,
    );
  }

  UNSAFE_componentWillReceiveProps() {
    const { refreshKey } = this.state;
    if (!refreshKey) {
      this.setState({ refreshKey: new Date().getTime() });
    }
  }

  componentWillUnmount() {
    this.unbind();
  }

  bind(elem, event, callback) {
    elem.addEventListener(event, callback);
    this.events.push({
      elem,
      event,
      callback,
    });
  }

  unbind() {
    this.events.forEach(({ elem: ele, event: e, callback: cb }) => {
      ele.removeEventListener(e, cb);
    });
  }

  onSelectChange(selectedRowKeys) {
    this.setState({ selectedRowKeys });
  }

  setDataSource(auxiliaryVoucherList, type) {
    const { activeType, searchCondition } = this.state;
    const { dispatch, auxiliaryVoucherObject } = this.props;
    let waitAddCount = 0; // 待新增
    let waitMatchCount = 0; // 待匹配
    let matchWaitConvert = 0; // 已匹配待转换
    let dataSource = [];
    const newList = auxiliaryVoucherList.map((v, i) => {
      const { convertType, isRemember } = v;
      let { defaultType } = v;
      defaultType = defaultType === undefined ? convertType : defaultType;
      return {
        ...v,
        key: (i + 1).toString(),
        defaultType,
        // eslint-disable-next-line no-nested-ternary
        isRemember: !isRemember && isRemember !== 0 ? 1 : isRemember,
      };
    });
    newList.forEach((v) => {
      if (v.convertType === 1) {
        matchWaitConvert += 1;
      } else if (v.convertType === 2) {
        waitMatchCount += 1;
      } else if (v.convertType === 3) {
        waitAddCount += 1;
      }
      if (activeType === v.convertType) {
        dataSource.push(v);
      }
    });
    dataSource = dataSource.map((v, i) => ({ ...v, index: i + 1 }));
    this.setState({
      waitAddCount,
      waitMatchCount,
      matchWaitConvert,
      dataSource: dataSource.filter((v, i) =>
        `${i + 1}_${v.name}_${v.model}`.includes(searchCondition),
      ),
      allDataSource: newList,
    });
    const newAuxiliaryVoucherObject = {
      ...auxiliaryVoucherObject,
      userHandleList: newList,
    };
    dispatch({
      type: 'updateState',
      payload: {
        auxiliaryVoucherObject: newAuxiliaryVoucherObject,
      },
    });
  }

  changeType(rowData) {
    const { activeType, selectedRowKeys, allDataSource } = this.state;
    const { key, defaultType, name, model, auxiliaryName, auxiliaryModel } = rowData;
    const i = selectedRowKeys.indexOf(key);
    let newRow = {};
    if (i !== -1) {
      selectedRowKeys.splice(i, 1);
    }
    if (activeType === 3) {
      newRow = {
        ...rowData,
        convertType: defaultType === 1 ? 1 : 2,
      };
    } else {
      if (!!name && name === auxiliaryName && !!model && model === auxiliaryModel) {
        message.error('切换失败，与账面辅助核算同名称同规格型号的无法新增！');
        return;
      }
      newRow = {
        ...rowData,
        convertType: 3,
      };
    }
    this.setDataSource(allDataSource.map((v) => (v.key === key ? newRow : v)));
    this.setState({ selectedRowKeys });
    message.success('切换成功');
  }

  changeTypeAll() {
    const { activeType, selectedRowKeys, allDataSource } = this.state;
    let newList = [];
    let convertFailCount = 0;
    if (selectedRowKeys.length < 1) {
      message.info('请勾选需要切换的行');
      return;
    }
    newList = allDataSource.map((v) => {
      const { name, auxiliaryName, model, auxiliaryModel, defaultType } = v;
      let newRow = v;
      if (selectedRowKeys.includes(v.key)) {
        if (activeType === 3) {
          newRow = {
            ...v,
            convertType: defaultType === 1 ? 1 : 2,
          };
        } else if (
          (!!name && name === auxiliaryName && (model || '') === (auxiliaryModel || '')) ||
          defaultType !== 3
        ) {
          convertFailCount += 1;
        } else {
          newRow = {
            ...v,
            convertType: 3,
          };
        }
      }
      return newRow;
    });
    Modal.success({
      width: 364,
      okText: '确定',
      centered: true,
      content: (
        <dl style={{ marginTop: -8, lineHeight: '24px' }}>
          <dt className="f-fwb">
            已成功切换 {selectedRowKeys.length - convertFailCount} 条，失败 {convertFailCount} 条
          </dt>
          {convertFailCount > 0 && (
            <dd className="f-cgray">与账面辅助核算同名称同规格型号的无法新增</dd>
          )}
        </dl>
      ),
    });
    this.setDataSource(newList);
    this.setState({ selectedRowKeys: [] });
  }

  tableSelectChange(option, key) {
    const { stockAuxiliaryList } = this.props;
    const { allDataSource } = this.state;
    const item = stockAuxiliaryList.find((v) => v.auxiliaryId === option);
    this.setDataSource(allDataSource.map((v) => (v.key === key ? this.unitMatch(item, key) : v)));
  }

  unitMatch(item, key) {
    const { allDataSource } = this.state;
    const {
      auxiliaryCode,
      auxiliaryId,
      auxiliaryName,
      unit,
      model,
      unitId,
      isUnitGroup,
      unitGroup,
      convertType,
    } = item;
    let row = allDataSource.find((v) => v.key === key);
    row = {
      ...row,
      auxiliaryCode,
      auxiliaryId,
      auxiliaryName,
      auxiliaryUnit: unit,
      auxiliaryModel: model,
      isRemember: 1,
      unitId,
      isUnitGroup,
    };
    row.convertType = 2;
    row.convertQuantity = 1;
    row.convertedQuantity = 1;
    row.convertRate = 1;
    if (unitGroup && isUnitGroup) {
      const unitline = unitGroup.filter((items) => items.subUnit === row.unit);
      if (unitline.length > 0) {
        row.convertRate = unitline[0].convertRate;
        row.disableds = convertType === 1;
      }
    }
    row.disabledConvert = !isUnitGroup && row.unit === row.auxiliaryUnit;
    return row;
  }

  allMatch(item) {
    const { selectedRowKeys, allDataSource } = this.state;
    this.setDataSource(
      allDataSource.map((v) => {
        return selectedRowKeys.includes(v.key) ? this.unitMatch(item, v.key) : v;
      }),
    );
  }

  inputNumberBlur(e, name, key) {
    const { value } = e.target;
    const { allDataSource } = this.state;
    const row = allDataSource.find((v) => v.key === key);
    row[name] = value;
    this.setDataSource(allDataSource.map((v) => (v.key === key ? row : v)));
  }

  inputNumberChange(value, name, key) {
    const { allDataSource } = this.state;
    const row = allDataSource.find((v) => v.key === key);
    row[name] = value;
    this.setDataSource(allDataSource.map((v) => (v.key === key ? row : v)));
  }

  changeMemory(key) {
    const { allDataSource } = this.state;
    const row = allDataSource.find((v) => v.key === key);
    row.isRemember = row.isRemember ? 0 : 1;
    this.setDataSource(allDataSource.map((v) => (v.key === key ? row : v)));
  }

  // 全选记忆或取消
  onCheckedAll = (checked) => {
    const { dataSource, allDataSource } = this.state;

    const newSource = allDataSource.map((item) => {
      if (dataSource.find((v) => v.key === item.key)) {
        // 不支持选择操作
        if (item.convertType === 1) {
          return item;
        }
        return { ...item, isRemember: Number(checked) };
      }
      return item;
    });
    this.setDataSource(newSource);
    // this.setState({ dataSource: newSource });
  };

  searchSure(val) {
    const { allDataSource } = this.state;
    this.setState({ searchCondition: val }, () => {
      this.setDataSource(allDataSource);
    });
  }

  switchChange(activeType, sourceData) {
    this.setState({ activeType, selectedRowKeys: [] }, () => {
      const { allDataSource } = this.state;
      this.setDataSource(sourceData || allDataSource);
    });
  }

  addStock() {
    const { dispatch } = this.props;
    dispatch({ type: 'getCategory' });
    // dispatch({ type: 'getAuxTypeIdByType' });
    // this.setState({ AddStockModalVisible: true });
  }

  addStockAfterFunc() {
    const { allDataSource } = this.state;
    const { dispatch } = this.props;

    dispatch({
      type: 'matchStockAuxiliary',
      payload: {
        details: allDataSource,
        success: (data) => {
          this.setDataSource(data);
          // this.setState({ AddStockModalVisible: false });
        },
      },
    });
  }

  submit() {
    const { allDataSource } = this.state;
    const { noMemoryList } = this.state;
    const { dispatch } = this.props;
    const json = [];
    const surplusData = [];
    const newNoMemoryList = [];
    const newAllDataSource = allDataSource.concat(noMemoryList);
    newAllDataSource.forEach((v) => {
      const {
        name,
        model,
        unit,
        // convertQuantity,
        // convertedQuantity,
        auxiliaryUnit,
        convertRate,
        auxiliaryId,
        isRemember,
        taxCode,
        taxName,
        convertType,
        unitId,
        isUnitGroup,
      } = v;
      const data = {
        auxiliaryId,
        // convertQuantity,
        // convertedQuantity,
        auxUnit: auxiliaryUnit,
        convertRate,
        handleType: convertType === 3 ? 1 : 2,
        isRemember: convertType === 3 ? 0 : isRemember || 0,
        model,
        name,
        taxCode,
        taxName,
        unit,
        unitId,
        isUnitGroup,
      };
      json.push(data);
      if (
        // (data.handleType === 2 && (!Number(convertQuantity) || !Number(convertedQuantity))) ||
        (data.handleType === 2 && !Number(convertRate)) ||
        (convertType !== 3 && !auxiliaryId)
      ) {
        surplusData.push(v);
      } else if (data.handleType === 2 && data.isRemember === 0) {
        newNoMemoryList.push(v);
      }
    });
    this.setState({ noMemoryList: newNoMemoryList });
    if (surplusData.length > 0) {
      this.someSubmit(json, surplusData, noMemoryList);
      return;
    }
    dispatch({
      type: 'batchAddAuxiliary',
      payload: {
        userHandleResult: json,
      },
    });
  }

  someSubmit(data, surplusData, noMemoryList) {
    const that = this;
    const { dispatch } = this.props;
    const someSubmitNum = data.length - surplusData.length - noMemoryList.length;
    dispatch({
      type: 'batchAddAuxiliary',
      payload: {
        userHandleResult: data,
        cb: () => {
          that.setState((preState) => ({
            someSubmitNum: someSubmitNum + preState.someSubmitNum,
          }));
          if (someSubmitNum === 0) {
            message.error('待匹配项没有填写单位换算的数量或填写的换算数量为0，请检查!');
          } else {
            message.success(`已成功提交${someSubmitNum}个`);
            dispatch({ type: 'getStockAuxiliaryList' });
            this.setState({ selectedRowKeys: [] });
          }
          this.setDataSource(surplusData);
        },
      },
    });
  }

  render() {
    const {
      stockConfigure,
      unitConfigure,
      unitGroupConfigure,
      auxiliaryHandleRefreshTableKey,
    } = this.props;

    const {
      tableHeight,
      activeType,
      searchCondition,
      waitAddCount,
      waitMatchCount,
      matchWaitConvert,
      dataSource,
      selectedRowKeys,
      // AddStockModalVisible,
      refreshKey,
    } = this.state;
    const notMemoItems = dataSource.find((item) => item.auxiliaryId && item.isRemember !== 1);
    const isMemoryAll = !notMemoItems;
    const waitAddColumns = [
      {
        title: '编号',
        dataIndex: 'index',
        align: 'center',
        width: 50,
        minWidth: 5,
        render: (val) => {
          return <TabelCell>{val}</TabelCell>;
        },
      },
      {
        title: '存货名称',
        dataIndex: 'name',
        width: 300,
        minWidth: 5,
        render(value) {
          return <TabelCell>{value}</TabelCell>;
        },
      },
      {
        title: '规格型号',
        dataIndex: 'model',
        width: 200,
        minWidth: 5,
        render(value) {
          return <TabelCell>{value}</TabelCell>;
        },
      },
      // {
      //   title: '票面单位',
      //   dataIndex: 'unit',
      //   align: 'center',
      //   width: 150,
      //   minWidth: 5,
      //   render(value) {
      //     return <TabelCell>{value}</TabelCell>;
      //   },
      // },
      {
        title: '操作',
        key: 'operation',
        align: 'center',
        width: 100,
        minWidth: 5,
        render: (value, row, index) => {
          return (
            <a className="f-cblue" onClick={this.changeType.bind(this, row, index)}>
              切换为待匹配
            </a>
          );
        },
      },
    ];
    const waitMatchColumns = [
      {
        title: '编号',
        key: 'index',
        dataIndex: 'index',
        align: 'center',
        width: 50,
        minWidth: 5,
        render: (val) => {
          return <TabelCell>{val}</TabelCell>;
        },
      },
      {
        title: '存货名称',
        dataIndex: 'name',
        width: 250,
        minWidth: 5,
        render(text) {
          return <TabelCell>{text}</TabelCell>;
        },
      },
      {
        title: '规格型号',
        dataIndex: 'model',
        width: 90,
        minWidth: 5,
        render(text) {
          return <TabelCell>{text}</TabelCell>;
        },
      },
      {
        title: '匹配至',
        key: 'auxiliaryId',
        dataIndex: 'auxiliaryId',
        width: 160,
        minWidth: 5,
        align: 'center',
        render: (text, row) => {
          const { stockAuxiliaryList } = this.props;
          const { key } = row;
          return (
            <TabelCell>
              <Select
                style={{ width: '100%' }}
                showSearch
                filterOption={(val, option) => {
                  const { value, title } = option.props;
                  return value.toString().includes(val) || title.includes(val);
                }}
                onChange={(option) => {
                  this.tableSelectChange(option, key);
                }}
                placeholder="选择账面存货辅助核算"
                value={text}
                dropdownRender={(menu) => (
                  <div>
                    {menu}
                    <div
                      style={{
                        padding: '0px 8px',
                        cursor: 'pointer',
                        background: '#FAE7C8',
                        height: '30px',
                        lineHeight: '30px',
                      }}
                      onMouseDown={() => this.addStock()}
                    >
                      <Ico style={{ fontSize: '14px' }} type="tianjia" /> 新增
                    </div>
                  </div>
                )}
                disabled={activeType === 1}
              >
                {stockAuxiliaryList.map((v) => {
                  const name = `${v.auxiliaryCode} ${v.auxiliaryName} ${v.model || ''}`;
                  return (
                    <Option key={v.auxiliaryId} value={v.auxiliaryId} title={name}>
                      {name}
                    </Option>
                  );
                })}
              </Select>
            </TabelCell>
          );
        },
      },
      {
        title: '换算',
        key: 'type',
        dataIndex: 'type',
        width: 50,
        minWidth: 5,
        align: 'center',
        render(value, row) {
          const { auxiliaryId, convertType } = row;
          return auxiliaryId ? <TabelCell>{convertType === 1 ? '自动' : '手动'}</TabelCell> : null;
        },
      },
      {
        title: '单位换算比例',
        key: 'convert',
        dataIndex: 'convert',
        width: 150,
        minWidth: 5,
        align: 'left',
        render: (value, row) => {
          // const { convertType, convertRate, convertQuantity, convertedQuantity, unit, auxiliaryUnit, key } = row;
          const {
            convertType,
            convertRate,
            unit,
            auxiliaryUnit,
            key,
            disabledConvert,
            isUnitGroup,
            disableds,
          } = row;
          const disabled =
            (convertType === 2 && disabledConvert) ||
            (convertType === 2 && isUnitGroup === true && disableds); // isUnitGroup
          return (
            // <TabelCell>
            <div style={{ position: 'relative' }}>
              <span>{unit && `1${unit}=`}</span>
              <InputNumber
                disabled={disabled}
                precision={4}
                min={0}
                max={999999999.9999}
                style={{ width: '100px', margin: '0 4px' }}
                onBlur={(e) => {
                  this.inputNumberBlur(e, 'convertRate', key);
                }}
                onChange={(e) => {
                  this.inputNumberChange(e, 'convertRate', key);
                }}
                placeholder="请输入转换率"
                value={convertRate}
              />
              <span>
                {/* {unit && auxiliaryUnit && `/`} */}
                {auxiliaryUnit && `${auxiliaryUnit}`}
              </span>
            </div>
            // </TabelCell>
          );
        },
      },
      {
        title: (
          <TabelCell>
            {activeType !== 1 && (
              <Checkbox
                checked={isMemoryAll}
                onChange={(e) => {
                  this.onCheckedAll(e.target.checked);
                }}
              />
            )}
            <em style={{ marginRight: 3, marginLeft: 4 }}>记忆</em>
            <Tooltip
              placement="bottom"
              title={
                <span style={{ maxWidth: 200 }}>
                  系统将为您记忆此规则，储存至存货辅助核算的自定义规则库中，以后无需手动匹配。
                </span>
              }
            >
              <Ico style={{ color: '#008cff' }} type="ShapeCopy2" />
            </Tooltip>
          </TabelCell>
        ),
        key: 'isRemember',
        dataIndex: 'isRemember',
        width: 90,
        minWidth: 5,
        align: 'center',
        render: (value, row) => {
          const { auxiliaryId, convertType, key, defaultType } = row;
          return auxiliaryId ? (
            <TabelCell>
              {((convertType === 1 && defaultType === 1) || convertType !== 1) && (
                <Checkbox
                  checked={value}
                  onChange={() => {
                    this.changeMemory(key);
                  }}
                  // disabled={convertType === 1}
                />
              )}
            </TabelCell>
          ) : null;
        },
      },
      {
        title: '操作',
        key: 'operation',
        align: 'center',
        width: 100,
        minWidth: 5,
        render: (text, data, index) => {
          return data.defaultType === 3 ? (
            <a className="f-cblue" onClick={this.changeType.bind(this, data, index)}>
              切换为待新增
            </a>
          ) : (
            ''
          );
        },
      },
    ];
    if (activeType === 1) {
      waitMatchColumns.pop();
    }

    const { allMatchCount } = this.props;

    return (
      <Content>
        <div className="auxiliary-content">
          <div className="auxiliary-content-head">
            <div className="auxiliary-content-head-left">
              状态：
              <Badge count={waitAddCount} showZero>
                <span
                  className={activeType === 3 ? 'selected' : ''}
                  onClick={this.switchChange.bind(this, 3, null)}
                >
                  待新增
                </span>
              </Badge>
              <Badge count={waitMatchCount} showZero>
                <span
                  className={activeType === 2 ? 'selected' : ''}
                  onClick={this.switchChange.bind(this, 2, null)}
                >
                  待匹配
                </span>
              </Badge>
              <Badge count={matchWaitConvert} showZero>
                <span
                  className={activeType === 1 ? 'selected' : ''}
                  onClick={this.switchChange.bind(this, 1, null)}
                >
                  已匹配待转换
                </span>
              </Badge>
              <SearchInput
                placeholder="编号/名称/规格型号"
                value={searchCondition}
                style={{ width: 200, marginLeft: 10 }}
                onSearch={(val) => {
                  this.searchSure(val);
                }}
              />
            </div>
            <div className="auxiliary-content-head-right">
              {activeType !== 1 && (
                <MatchButton
                  activeType={activeType}
                  selectedRowKeys={selectedRowKeys}
                  success={(item) => {
                    this.allMatch(item);
                  }}
                />
              )}
              {activeType === 2 && (
                <Button
                  type="primary"
                  ghost
                  onClick={() => {
                    this.changeTypeAll();
                  }}
                >
                  切换为待新增
                </Button>
              )}
              {activeType === 3 && (
                <Button
                  type="primary"
                  ghost
                  onClick={() => {
                    this.changeTypeAll();
                  }}
                >
                  切换为待匹配
                </Button>
              )}
              <Button
                type="primary"
                onClick={() => {
                  this.submit();
                }}
              >
                提交
              </Button>
            </div>
          </div>
          <div style={{ margin: '16px 0 12px' }}>
            本次匹配商品{allMatchCount}
            条，其中已匹配账面存货辅助核算或别名共
            {allMatchCount - waitAddCount - waitMatchCount}条，待处理
            {waitAddCount + waitMatchCount}条
          </div>
          <div style={{ height: tableHeight }}>
            <SuperTable
              dragCell
              id="auxiliaryContent"
              rowSelection={{
                columnWidth: 40,
                selectedRowKeys,
                onChange: this.onSelectChange.bind(this),
              }}
              refreshTable={auxiliaryHandleRefreshTableKey}
              refreshColumns={auxiliaryHandleRefreshTableKey}
              scroll={{ x: '100%' }}
              dataSource={dataSource}
              pagination={false}
              columns={activeType === 3 ? waitAddColumns : waitMatchColumns}
              footer={() => (
                <div>
                  提示：若账面原有存货辅助核算中，存货名称包含税收大类(双*号），建议使用
                  <span
                    className="f-cblue"
                    style={{ cursor: 'pointer' }}
                    onClick={this.routerJump.bind(this)}
                  >
                    智能设置分类简称
                  </span>
                  一键到智能拆分，大幅提高入账识别率。
                </div>
              )}
              bordered
            />
          </div>
        </div>
        {stockConfigure.visible && <StockModal />}
        {unitConfigure.visible && <UnitModal />}
        {unitGroupConfigure.visible && <UnitGroupModal />}
        {/* {AddStockModalVisible && (
          <CustomerModal />
          // <AddStockModal
          //   onCancel={() => this.setState({ AddStockModalVisible: false })}
          //   onSuccess={() => this.addStockAfterFunc()}
          // />
        )} */}
      </Content>
    );
  }
}
auxiliaryContent.defaultProps = {
  auxiliaryHandleRefreshTableKey: '',
  allMatchCount: 0,
  stockConfigure: {},
  unitConfigure: {},
  unitGroupConfigure: {},
};
auxiliaryContent.propTypes = {
  stockAuxiliaryList: PropTypes.arrayOf(PropTypes.any).isRequired,
  auxiliaryVoucherObject: PropTypes.objectOf(PropTypes.any).isRequired,
  userHandleList: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
  allMatchCount: PropTypes.number,
  stockConfigure: PropTypes.objectOf(PropTypes.any),
  unitConfigure: PropTypes.objectOf(PropTypes.any),
  unitGroupConfigure: PropTypes.objectOf(PropTypes.any),
  auxiliaryHandleRefreshTableKey: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
export default connect(
  ({
    stockConfigure,
    unitConfigure,
    unitGroupConfigure,
    stockAuxiliaryList,
    auxiliaryVoucherObject,
    auxiliaryVoucherObject: { userHandleList, allMatchCount },
    auxiliaryHandleRefreshTableKey,
  }) => ({
    stockConfigure,
    unitConfigure,
    unitGroupConfigure,
    stockAuxiliaryList,
    auxiliaryVoucherObject,
    userHandleList,
    allMatchCount,
    auxiliaryHandleRefreshTableKey,
  }),
)(auxiliaryContent);
