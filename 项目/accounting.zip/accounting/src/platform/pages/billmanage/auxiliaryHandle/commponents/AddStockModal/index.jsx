import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Button, Form, Input, TreeSelect } from 'antd';
import RepeatModal from './repeatModal';

const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
  labelAlign: 'right',
};
const AddStockModal = ({ addStockProps, stockTypeList, onCancel, onSuccess, form, dispatch }) => {
  const [showRepeatModal, setShowRepeatModal] = useState(false);
  const [repeatData, setRepeatData] = useState({});
  const [isShowMask, setIsShowMask] = useState(true);
  const { auxiliaryCode } = addStockProps;
  const { setFieldsValue } = form;
  useEffect(() => {
    setFieldsValue({ auxiliaryCode });
  }, [auxiliaryCode, setFieldsValue]);
  const treeSelectFilter = (val, treeNode) => {
    const {
      props: { title, value },
    } = treeNode;
    return `${title}${value}`.includes(val.trim());
  };
  const saveStock = () => {
    form.validateFields((errors, values) => {
      if (!errors) {
        dispatch({
          type: 'addAuxiliary',
          payload: {
            ...addStockProps,
            ...values,
            classify: values.classify ? values.classify.join(',') : '',
          },
        }).then((res) => {
          if (res) {
            if (res.msg) {
              setRepeatData(res);
              setShowRepeatModal(true);
            } else {
              onSuccess && onSuccess();
            }
          }
        });
      }
    });
  };
  return (
    <>
      <Modal
        title="新增存货"
        visible
        onCancel={onCancel}
        width={420}
        mask={!showRepeatModal && isShowMask}
        footer={
          <>
            <Button onClick={onCancel}>取消</Button>
            <Button type="primary" onClick={saveStock}>
              保存
            </Button>
          </>
        }
      >
        <Form {...formItemLayout}>
          <Form.Item label="编码：">
            {form.getFieldDecorator('auxiliaryCode', {
              rules: [{ required: true, message: '编码不能为空' }],
              normalize: (val) => {
                return val ? val.replace(/[\D]/gi, '').slice(0, 4) : '';
              },
            })(<Input style={{ width: 270 }} />)}
          </Form.Item>
          <Form.Item label="名称：">
            {form.getFieldDecorator('auxiliaryName', {
              rules: [{ required: true, message: '名称不能为空' }],
            })(<Input style={{ width: 270 }} />)}
          </Form.Item>
          <Form.Item label="规格型号：">
            {form.getFieldDecorator('model')(<Input style={{ width: 270 }} />)}
          </Form.Item>
          <Form.Item label="单位：">
            {form.getFieldDecorator('unit')(<Input style={{ width: 270 }} />)}
          </Form.Item>
          <Form.Item label="存货类别：">
            {form.getFieldDecorator('classify')(
              <TreeSelect
                treeData={stockTypeList}
                className="checkbox-dropdown"
                dropdownClassName="checkbox-select-dropdown"
                filterTreeNode={treeSelectFilter}
                treeCheckable
                style={{ width: 270 }}
              />,
            )}
          </Form.Item>
        </Form>
      </Modal>
      {showRepeatModal && (
        <RepeatModal
          repeatData={repeatData}
          stockTypeList={stockTypeList}
          showMask={setIsShowMask}
          onCancel={() => setShowRepeatModal(false)}
        />
      )}
    </>
  );
};
AddStockModal.propTypes = {
  addStockProps: PropTypes.objectOf(PropTypes.any).isRequired,
  stockTypeList: PropTypes.arrayOf(PropTypes.any).isRequired,
  onSuccess: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ addStockProps, stockTypeList }) => ({ addStockProps, stockTypeList }))(
  Form.create()(AddStockModal),
);
