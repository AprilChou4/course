import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, message } from 'antd';
import TemplateOperation from '@/TemplateOperation';

const ModifyTemplate = ({ invoiceType, selectedRows, isPeriodWrong, className, dispatch }) => {
  const templateModify = () => {
    const invoiceIdList = selectedRows
      .filter((v) => v.invoiceId !== 'total')
      .map((v) => v.invoiceId);
    if (invoiceIdList.length < 1) {
      message.error('请选择需要批量替换模板的数据');
      return;
    }
    TemplateOperation({
      switchTemp: true,
      type: '1',
      invoiceType: invoiceType === 'vat' ? '3' : '1,2',
      // 切换模板 getDatas 可以只有templateId 也可以传 全部信息
      getDatas: {
        templateId: selectedRows[0].templateId,
      },
      callback: (data) => {
        const { templateId } = data;
        dispatch({
          type: 'batchUpdateTemplate',
          payload: {
            invoiceIdList,
            templateId,
          },
        });
      },
    });
  };

  return (
    <>
      <Button
        type="primary"
        className={className}
        ghost
        disabled={!isPeriodWrong}
        onClick={templateModify}
      >
        修改模板
      </Button>
    </>
  );
};
ModifyTemplate.defaultProps = {
  className: '',
  invoiceType: '',
};
ModifyTemplate.propTypes = {
  invoiceType: PropTypes.string,
  isPeriodWrong: PropTypes.bool.isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  className: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ invoiceType, selectedRows, isPeriodWrong }) => ({
  invoiceType,
  selectedRows,
  isPeriodWrong,
}))(ModifyTemplate);
