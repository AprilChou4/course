import React from 'react';
import Layout from './components/Layout';
import Effects from './effects';
import VoucherState from './voucherState';
import TransformInvoiceState from '../transformInvoiceList/state';

export default {
  state: {
    ...VoucherState,
    ...TransformInvoiceState,
    layoutKey: '',
    loadings: {
      $getList: false,
    },
    // 没有权限 1、税号未绑定 2、没有授权
    noPower: 2,
    // 客户端插盘提示语
    clientPowerInfo: '插入税盘可以自动获取授权码',
    // 授权码
    powerNumber: '',
    autoPowerNumber: '', // 插盘获取的授权码
    // 授权输入弹框
    powerModalVisible: false,
    // 期间是否正确，关系按钮是否阔以点击
    isPeriodWrong: true,
    isCheckOutDate: false, // 是否结账期间
    // 凭证模板科目
    buildTaxSubjectIdModalVisible: false,
    // 进度条
    isShowProgress: false,
    isShowFpcyModal: false,
    progressArgs: {
      failCount: 0,
      successCount: 0,
      totalCount: 0,
      list: [],
    },
    // 表格数据源
    dataSource: [],
    dataSourceOriginal: {},
    paginationProps: {
      current: 1,
      total: 0,
      pageSize: 30,
    },
    // 表格选中数据
    selectedRowKeys: [],
    selectedRows: [],
    // 校验码
    checkCodeProps: {
      checkCodeVisible: false,
      invoiceId: '',
      checkCode: '',
    },
    // 所有科目
    allSubject: [],
    // 所有末级科目
    leafSubject: [],
    // 限额提醒设置
    limitSetting: {
      taxType: 1,
      taxTypeValue: '10',
      tlvMonths: 1,
      tlvMonthsValue: '500',
      tips: 1,
    },
    // 手动录入
    manualImportVisible: false,
    manualImportType: '', // 手动新增类型
    manualImportState: '', // 手动新增操作状态
    manualImportInvoiceSource: '', // 发票来源
    manualImportData: {
      details: [{}, {}, {}, {}, {}],
    },
    // 凭证模板列表
    allTemplateList: [],
    voucherBuildSetting: {
      buildSummary: '', // 摘要组合（1:发票号码; 2:开票日期; 3:发票内容; 4:客户 以逗号隔开）
      customizeSummary: '', // 自定义摘要，长度不能超过100个字符
      isSaveSpec: 1, // 新增存货辅助核算是否保存规格型号（0:不保存; 1:保存 默认为1）
      buildTaxSubjectId: '', // 进项未认证：生成凭证的税额科目ID
      buildMode: 1, // 凭证生成方式（1:每张; 2:所有; 3:相同单位; 4:相同日期）
      buildLineSort: 1, // 1：先借后贷 ，2：一借一贷，默认为1
      isAmtMerge: 1, // 是否合并金额科目分录（1:是; 0:否 默认为1）
      isTaxMerge: 1, // 是否合并税额科目分录（1:是; 0:否 默认为1）
      isAmtTaxMerge: 1, // 是否合并价税合计科目分录（1:是; 0:否 默认为1）
      buildVoucherDate: '0,0', // 凭证日期字段（按逗号拼接，前一位是发票日期在当前会计期间的设置，后一位是发票日期不在当前会计期间的设置）
      machineNo: '', // 开票机号
    },
    query: {
      state: '', // 发票状态，1已认证，5未认证，2销售发票，3收购发票,4机车票，5二手车，6通行费
      dateDesc: 0, // 是否按开票日期降序排列，默认升序 是：1；否：0
      invoiceNumberDesc: 0, // 是否按发票号码降序排列，默认升序 是：1；否：0
      voucherDesc: 0, // 是否按凭证号降序排列，默认升序
      invoiceNumberSortFirst: 1, // 查询排序以哪个字段为主（2，voucherDesc；1，invoiceNumberSort；0，dateSort；默认：0）
      name: '', // 搜索条件，发票内容或辅助核算筛选

      invoiceType: [],
      invoiceNumber: '', // 发票号码
      priceStart: '', // 起始单价
      priceEnd: '', // 结束单价
      taxRate: '', // 税率
      minDate: '', // 开票日期起
      maxDate: '', // 开票日期止
      taxTotalStart: '', // 起始价税合计
      taxTotalEnd: '', // 结束价税合计
      templateId: '', // 模板ID
      voucherSort: '0', // 是否生成凭证筛选，0: 全部；1:已生成；2：未生成
      invoiceContentState: '',
    },
    // 自定义列
    columnsDefine: [],
    // 常用条件
    commonlyList: [],
    commonlyId: '0',
    quotaData: {}, // 扫码录入优惠券信息
    addInvoiceModalVisible: false, // 是否显示发票录入弹窗

    // 扫码查验
    isShowScanResModal: false,
    scanInvoiceData: [],
    // 微信小程序录入
    isShowMiniResModal: false, // 小程序录入的弹框显示
    scanMiniInvoiceData: [], // 录入发票的表格数据
    wxQRCodeData: {}, // 二维码
    scanConnectStatus: false, // 扫码连接状态true为连接
    scanTabValue: '1', // 1.扫码,2.连接表格
  },
  effects() {
    return new Effects(this);
  },
  render() {
    return <Layout />;
  },
  onChange: {
    $onTabChange() {
      const { dispatch } = this.store;
      setTimeout(() => {
        dispatch({
          type: '_updateState',
          payload: {
            layoutKey: new Date().getTime(),
          },
        });
      }, 200);
    },
  },
  onInit() {
    this.store.dispatch({
      type: 'initData',
    });
  },
};
