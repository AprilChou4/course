import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Input, Popover } from 'antd';
import PopoverContent from './PopoverContent';
import './index.less';

const Search = ({ invoiceType, queryInvoiceType, onSearch }) => {
  const [visible, setVisible] = useState(false);
  const [isNeeShow, setIsNeeShow] = useState(false);

  const PopoverProps = {
    overlayClassName: 'no-arrow popover-padding',
    trigger: 'click',
    placement: 'bottomLeft',
    visible,
    content: (
      <PopoverContent
        hide={() => {
          setVisible(false);
        }}
      />
    ),
    onVisibleChange: (e) => {
      if (!e) {
        setIsNeeShow(false);
        setVisible(e);
      } else if (e && isNeeShow) {
        setVisible(e);
      }
    },
  };
  const SearchProps = {
    enterButton: true,
    placeholder:
      invoiceType !== 'vat' || queryInvoiceType === '3' ? '供应商或发票内容' : '客户名或发票内容',
    onSearch: (value) => {
      onSearch(value);
    },
  };

  return (
    <div className="search-input e-ml16">
      <Popover {...PopoverProps}>
        <Input.Search {...SearchProps} />
        <span
          className="more-conditions"
          onClick={() => {
            setTimeout(() => {
              setIsNeeShow(true);
              setVisible(true);
            }, 100);
          }}
        >
          更多条件
        </span>
      </Popover>
    </div>
  );
};
Search.defaultProps = {
  invoiceType: '',
  queryInvoiceType: '',
};
Search.propTypes = {
  invoiceType: PropTypes.string,
  queryInvoiceType: PropTypes.string,
  onSearch: PropTypes.func.isRequired,
};
export default connect(({ invoiceType, query: { invoiceType: [queryInvoiceType] } }) => ({
  invoiceType,
  queryInvoiceType,
}))(Search);
