export const invoiceStateData = [
  {
    title: '未认证',
    value: '5',
    key: '5',
  },
  {
    title: '抵扣认证',
    value: '1',
    key: '1',
  },
  {
    title: '不抵扣认证',
    value: '8',
    key: '8',
  },
  {
    title: '退税认证',
    value: '7',
    key: '7',
  },
  {
    title: '其他',
    value: '0',
    key: '0',
  },
  {
    title: '进项异常',
    value: '6',
    key: '6',
  },
  {
    title: '作废',
    value: '2',
    key: '2',
  },
];
export const taxData = [
  {
    title: '17%',
    value: '17',
    key: '17',
  },
  {
    title: '16%',
    value: '16',
    key: '16',
  },
  {
    title: '13%',
    value: '13',
    key: '13',
  },
  {
    title: '11%',
    value: '11',
    key: '11',
  },
  {
    title: '10%',
    value: '10',
    key: '10',
  },
  {
    title: '9%',
    value: '9',
    key: '9',
  },
  {
    title: '6%',
    value: '6',
    key: '6',
  },
  {
    title: '5%',
    value: '5',
    key: '5',
  },
  {
    title: '4%',
    value: '4',
    key: '4',
  },
  {
    title: '3%',
    value: '3',
    key: '3',
  },
  {
    title: '0%',
    value: '0',
    key: '0',
  },
];
export const invoiceTypeData = [
  {
    title: '增值税专用发票',
    value: '7',
    sign: 's',
    key: '7',
  },
  {
    title: '增值税电子发票',
    value: '9',
    sign: 'p',
    key: '9',
  },
  {
    title: '增值税普通发票',
    value: '8',
    sign: 'c',
    key: '8',
  },
  {
    title: '机动车销售发票',
    value: '4',
    sign: 'j',
    key: '4',
  },
  {
    title: '二手车销售发票',
    value: '5',
    sign: 'u',
    key: '5',
  },
  {
    title: '农产品收购发票',
    value: '3',
    sign: 'cs',
    key: '3',
  },
  {
    title: '车辆通行费发票',
    value: '6',
    sign: 't',
    key: '6',
  },
  // {
  //   title: '海关缴款书',
  //   value: '15',
  //   sign: 'gs',
  //   key: '15',
  // },
  {
    title: '其他类型',
    value: '14',
    sign: 'o',
    key: '14',
  },
  {
    title: '废票',
    value: '2',
    key: '2',
  },
];
