import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Checkbox } from 'antd';
import services from '../../services';

const SecondSubject = ({ secondSubjectData, dispatch }) => {
  const [secondSubjectIndex, setSecondSubjectIndex] = useState(0);
  const currentData = secondSubjectData[secondSubjectIndex];
  const defaultCheckValue = currentData ? currentData.secondSubjectNames : [];
  const [checkValue, setCheckValue] = useState(defaultCheckValue);
  const onCheckChange = (e) => {
    setCheckValue(e);
  };

  const secondSubjectCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        secondSubjectModalVisible: false,
      },
    });
  };

  const showNext = () => {
    if (secondSubjectIndex + 1 < secondSubjectData.length) {
      const nextSubject = secondSubjectData[secondSubjectIndex + 1];
      const { secondSubjectNames } = nextSubject;
      setSecondSubjectIndex(secondSubjectIndex + 1);
      setCheckValue(secondSubjectNames);
    } else {
      secondSubjectCancel();
      dispatch({ type: 'prepareCreate' });
    }
  };

  const secondSubjectOk = async () => {
    if (checkValue.length > 0) {
      await services.batchAdd({
        isConfirm: true,
        names: checkValue.join('\r\n'),
        parentId: currentData.subjectId,
      });
      await showNext();
    } else {
      showNext();
    }
  };

  return (
    <>
      <Modal
        visible
        title={`新增${currentData.subjectName}二级科目`}
        onCancel={secondSubjectCancel}
        onOk={secondSubjectOk}
      >
        <div style={{ padding: '10px 20px 0' }}>
          <p style={{ color: '#DF8201' }}>未检测到以下二级科目，确定后系统将自动为您新增</p>
          <Checkbox.Group
            style={{ width: '100%', lineHeight: '25px', paddingTop: '10px' }}
            value={checkValue}
            onChange={onCheckChange}
          >
            {currentData.secondSubjectNames.map((val) => (
              <p key={val}>
                <Checkbox value={val}>{val}</Checkbox>
              </p>
            ))}
          </Checkbox.Group>
        </div>
      </Modal>
    </>
  );
};
SecondSubject.propTypes = {
  secondSubjectData: PropTypes.arrayOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ secondSubjectData }) => ({
  secondSubjectData,
}))(SecondSubject);
