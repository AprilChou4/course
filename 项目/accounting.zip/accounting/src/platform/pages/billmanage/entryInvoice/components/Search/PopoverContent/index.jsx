import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Form, Input, Select, DatePicker, message, Checkbox, TreeSelect } from 'antd';
import moment from 'moment';
import InputNumber from '@/NumberInput';
import CommomlyConditions from '../../commonlyConditions';
import SaveModal from './saveModal';
import { invoiceStateData, invoiceTypeData } from '../../static';
import './style.less';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { Option } = Select;
const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
  labelAlign: 'right',
};
const invoiceSourceData = [
  {
    title: '发票提取',
    value: '0',
    key: '0',
  },
  {
    title: '手动新增',
    value: '1',
    key: '1',
  },
];
const PopoverContent = ({
  form,
  invoiceType,
  allTemplateList,
  query,
  commonlyList,
  commonlyId,
  hide,
  dispatch,
}) => {
  const [visible, setVisible] = useState(false);
  const [saveData, setSaveData] = useState({});
  const { getFieldDecorator } = form;
  const invoiceTypeDataSource = invoiceTypeData.filter((v) => {
    if (invoiceType !== 'vat') {
      return !['14'].includes(v.value);
    }
    return v.value !== '3';
  });
  const formSetData = (data) => {
    const obj = form.getFieldsValue();
    for (const i in obj) {
      if (['source', 'voucherSort', 'invoiceContentState'].includes(i)) {
        obj[i] = data[i] ? [data[i]] : [];
      } else if (i === 'state') {
        obj[i] = data[i] ? data[i].split(',') : [];
      } else if (i === 'date') {
        obj[i] =
          data.minDate && data.maxDate ? [moment(data.minDate), moment(data.maxDate)] : undefined;
      } else {
        obj[i] = data[i];
      }
    }
    form.setFieldsValue(obj);
  };
  const formGetData = () => {
    const data = form.getFieldsValue();
    if (data.taxRate && !/^\d+(\.\d+)?$/.test(data.taxRate)) {
      message.error('请输入正确的税率');
      return false;
    }
    return {
      ...data,
      invoiceContentState: data.invoiceContentState.length === 1 ? data.invoiceContentState[0] : '',
      voucherSort: data.voucherSort.length === 1 ? data.voucherSort[0] : '0',
      minDate: data.date && data.date.length > 0 ? data.date[0].format('YYYY-MM-DD') : '',
      maxDate: data.date && data.date.length > 0 ? data.date[1].format('YYYY-MM-DD') : '',
      state: (data.state || []).join(','),
      source: data.source.length === 1 ? data.source[0] : '',
      remarks: data.remarks ? data.remarks.trim() : '',
    };
  };

  useEffect(() => {
    formSetData(query);
  }, []);

  const resetForm = () => {
    form.resetFields();
  };

  const contentSubmit = (isHide = true) => {
    const data = formGetData();
    if (!data) return;
    dispatch({
      type: 'setQuery',
      payload: data,
    });
    isHide && hide();
  };

  const onSelect = (key, data) => {
    dispatch({
      type: 'updateState',
      payload: {
        commonlyId: key,
      },
    });
    if (!data) {
      resetForm();
      contentSubmit(false);
      return;
    }
    const { commonlyContent } = data;
    formSetData(JSON.parse(commonlyContent));
    contentSubmit(false);
  };

  const treeSelectFilter = (val, treeNode) => {
    const {
      props: { title, value },
    } = treeNode;
    return `${title}${value}`.includes(val.trim());
  };

  const getContent = () => {
    return (
      <Form style={{ width: 540 }} {...formItemLayout}>
        <FormItem label="发票来源">
          {getFieldDecorator('source', {
            initialValue: [],
          })(
            <TreeSelect
              treeData={invoiceSourceData}
              className="checkbox-dropdown"
              dropdownClassName="checkbox-select-dropdown"
              filterTreeNode={treeSelectFilter}
              treeCheckable
              style={{ width: 400 }}
            />,
          )}
        </FormItem>
        {invoiceType !== 'vat' && (
          <FormItem label="发票状态">
            {getFieldDecorator('state', {
              initialValue: [],
            })(
              <TreeSelect
                treeData={invoiceStateData}
                className="checkbox-dropdown"
                dropdownClassName="checkbox-select-dropdown"
                filterTreeNode={treeSelectFilter}
                treeCheckable
                style={{ width: 400 }}
              />,
            )}
          </FormItem>
        )}
        <FormItem label="发票类型">
          {getFieldDecorator('invoiceType', {
            initialValue: [],
          })(
            <TreeSelect
              treeData={invoiceTypeDataSource}
              className="checkbox-dropdown"
              dropdownClassName="checkbox-select-dropdown"
              filterTreeNode={treeSelectFilter}
              treeCheckable
              style={{ width: 400 }}
            />,
          )}
        </FormItem>
        <FormItem label="税率">
          {getFieldDecorator('taxRate', {
            normalize: (val) => {
              return val ? val.trim() : '';
            },
          })(<Input style={{ width: 160 }} suffix={<span>%</span>} />)}
          <span style={{ display: 'inline-block', width: 80, textAlign: 'right' }}>发票号码：</span>
          {getFieldDecorator('invoiceNumber', {
            normalize: (val) => {
              return val ? val.replace(/[^\d]/gi, '').slice(0, 8) : '';
            },
          })(<Input style={{ width: 160 }} />)}
        </FormItem>
        <FormItem label="开票日期">
          {getFieldDecorator('date')(
            <RangePicker dropdownClassName="ui-switching-date" style={{ width: 400 }} />,
          )}
        </FormItem>
        <FormItem label="单价区间">
          {getFieldDecorator('priceStart')(
            <InputNumber min={0} max={999999999.9999} precision={4} style={{ width: 185 }} />,
          )}
          <span style={{ display: 'inline-block', width: '30px', textAlign: 'center' }}>至</span>
          {getFieldDecorator('priceEnd')(
            <InputNumber min={0} max={999999999.9999} precision={4} style={{ width: 185 }} />,
          )}
        </FormItem>
        <FormItem label="价税合计区间">
          {getFieldDecorator('taxTotalStart')(
            <InputNumber
              min={-999999999.99}
              max={999999999.99}
              precision={2}
              style={{ width: 185 }}
            />,
          )}
          <span style={{ display: 'inline-block', width: '30px', textAlign: 'center' }}>至</span>
          {getFieldDecorator('taxTotalEnd')(
            <InputNumber
              min={-999999999.99}
              max={999999999.99}
              precision={2}
              style={{ width: 185 }}
            />,
          )}
        </FormItem>
        <FormItem label="凭证模板">
          {getFieldDecorator('templateId')(
            <Select
              showSearch
              allowClear
              style={{ width: 160 }}
              filterOption={(input, option) => {
                const { props: filterProps } = option;
                const { searchprops } = filterProps;
                return searchprops.includes(input.trim());
              }}
            >
              {allTemplateList.map((v) => (
                <Option
                  value={v.templateId}
                  key={v.templateId}
                  searchprops={`${v.templateId} ${v.templateName}`}
                >
                  {v.templateName}
                </Option>
              ))}
            </Select>,
          )}
          <span style={{ display: 'inline-block', width: 80, textAlign: 'right' }}>发票备注：</span>
          {getFieldDecorator('remarks', {
            normalize: (val) => {
              return val ? val.slice(0, 200) : '';
            },
          })(<Input style={{ width: 160 }} />)}
        </FormItem>
        {invoiceType === 'vat' && (
          <FormItem label="开票机号">
            {getFieldDecorator('machineNo', {
              initialValue: '',
              normalize: (val) => {
                return val ? val.replace(/[^\d]/gi, '').slice(0, 10) : '';
              },
            })(<Input style={{ width: 400 }} />)}
          </FormItem>
        )}
        <FormItem label="是否生成凭证">
          {getFieldDecorator('voucherSort', {
            initialValue: [],
          })(
            <Checkbox.Group>
              <Checkbox value="1" style={{ width: 100 }}>
                是
              </Checkbox>
              <Checkbox value="2" style={{ width: 100 }}>
                否
              </Checkbox>
            </Checkbox.Group>,
          )}
        </FormItem>
        <FormItem label="发票明细">
          {getFieldDecorator('invoiceContentState', {
            initialValue: [],
          })(
            <Checkbox.Group>
              <Checkbox value="1" style={{ width: 100 }}>
                已获取
              </Checkbox>
              <Checkbox value="0" style={{ width: 100 }}>
                未获取
              </Checkbox>
            </Checkbox.Group>,
          )}
        </FormItem>
        {/* <div style={{ textAlign: 'center' }}>
      <Button type="primary" ghost onClick={resetForm}>
        清空
      </Button>
      <Button type="primary" className="e-ml16" onClick={contentSubmit}>
        筛选
      </Button>
    </div> */}
      </Form>
    );
  };

  const onSave = () => {
    const data = formGetData();
    if (!data) return;
    setSaveData(data);
    setVisible(true);
    hide();
  };

  const saveCommonly = (data) => {
    if (commonlyList.length > 19) {
      message.error('常用查询条件数量最多为20个');
      return;
    }
    dispatch({
      type: 'saveCommonly',
      payload: {
        ...data,
        commonlyContent: JSON.stringify(saveData),
        model: 0,
        bookType: 10,
        onSuccess: () => {
          message.success('保存成功');
          setVisible(false);
        },
      },
    });
  };

  const delCommonly = (data) => {
    dispatch({
      type: 'deleteCommonly',
      payload: data,
    });
  };

  const defaultCommonly = (data) => {
    dispatch({
      type: 'defaultCommonly',
      payload: data,
    });
  };

  return (
    <>
      <CommomlyConditions
        commonlyId={commonlyId}
        getContent={getContent}
        commonlyList={commonlyList}
        onSelect={onSelect}
        onSearch={contentSubmit}
        onReset={resetForm}
        onSave={onSave}
        onDelete={delCommonly}
        onDefault={defaultCommonly}
      />
      {visible && <SaveModal onCancel={() => setVisible(false)} onOk={saveCommonly} />}
    </>
  );
};
PopoverContent.defaultProps = {
  invoiceType: '',
};
PopoverContent.propTypes = {
  invoiceType: PropTypes.string,
  allTemplateList: PropTypes.arrayOf(PropTypes.object).isRequired,
  query: PropTypes.objectOf(PropTypes.any).isRequired,
  commonlyList: PropTypes.arrayOf(PropTypes.any).isRequired,
  commonlyId: PropTypes.string.isRequired,
  hide: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default Form.create({ name: 'coordinated' })(
  connect(({ invoiceType, allTemplateList, query, commonlyList, commonlyId }) => ({
    invoiceType,
    allTemplateList,
    query,
    commonlyList,
    commonlyId,
  }))(PopoverContent),
);
