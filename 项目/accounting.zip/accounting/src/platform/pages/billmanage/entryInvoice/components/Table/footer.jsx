import React from 'react';
import Proptypes from 'prop-types';
import { connect } from 'nuomi';
import { formatNumber } from 'utils';
import CustomPagination from './pagination';
import '../../css/index.less';

const Footer = ({
  invoiceType,
  invoiceList,
  sumTaxTotal,
  sumAmt,
  sumTax,
  sumEffectiveTax,
  totalCount,
  buyCount,
  vatLimitFlag,
  vatLimitResponse,
}) => {
  const specialSpan =
    invoiceType !== 'vat' ? (
      <span>
        包含收购发票<em>{buyCount}</em>张
      </span>
    ) : (
      <span>
        另有收购发票<em>{buyCount}</em>张请在进项发票列表查看
      </span>
    );
  const effectSpan =
    invoiceType !== 'vat' ? (
      <span>
        有效税额<em>{formatNumber(sumEffectiveTax)}</em>
        元，
      </span>
    ) : null;
  return (
    <div>
      {(invoiceList || []).length > 0 && (
        <p styleName="table-info">
          发票总计<em>{totalCount}</em>张（{specialSpan}）， 金额<em>{formatNumber(sumAmt)}</em>元，
          税额<em>{formatNumber(sumTax)}</em>元，{effectSpan}价税合计
          <em>{formatNumber(sumTaxTotal)}</em>元。
        </p>
      )}
      {vatLimitFlag && (
        <p styleName="table-info">
          <span key="2">
            本期已开票{' '}
            <em styleName={vatLimitResponse.taxTypeFlag ? 'color-red' : ''}>
              {formatNumber(vatLimitResponse.taxTypeValue)}
            </em>{' '}
            元，本期剩余可开票{' '}
            <em styleName={vatLimitResponse.taxTypeFlag ? 'color-red' : ''}>
              {formatNumber(vatLimitResponse.theRestTaxType)}
            </em>{' '}
            元
            {vatLimitResponse.tlvMonthsValue !== undefined &&
            vatLimitResponse.theRestTlvMonths !== undefined
              ? [
                  '；连续12个月已开票 ',
                  <em key="91" styleName={vatLimitResponse.tlvMonthsFlag ? 'color-red' : ''}>
                    {formatNumber(vatLimitResponse.tlvMonthsValue)}
                  </em>,
                  '元，连续12个月剩余可开票  ',
                  <em key="92" styleName={vatLimitResponse.tlvMonthsFlag ? 'color-red' : ''}>
                    {formatNumber(vatLimitResponse.theRestTlvMonths)}
                  </em>,
                  ' 元',
                ]
              : null}
          </span>
        </p>
      )}
      {(invoiceList || []).length > 0 && <CustomPagination />}
    </div>
  );
};
Footer.defaultProps = {
  invoiceType: '',
  sumTaxTotal: 0,
  sumAmt: 0,
  sumTax: 0,
  sumEffectiveTax: 0,
  totalCount: 0,
  buyCount: 0,
  invoiceList: [],
  vatLimitFlag: false,
  vatLimitResponse: {},
};
Footer.propTypes = {
  invoiceType: Proptypes.string,
  sumTaxTotal: Proptypes.number,
  sumAmt: Proptypes.number,
  sumTax: Proptypes.number,
  sumEffectiveTax: Proptypes.number,
  totalCount: Proptypes.number,
  buyCount: Proptypes.oneOfType([Proptypes.number, Proptypes.string]),
  invoiceList: Proptypes.arrayOf(Proptypes.any),
  vatLimitFlag: Proptypes.bool,
  vatLimitResponse: Proptypes.objectOf(Proptypes.any),
};
export default connect(
  ({
    invoiceType,
    dataSourceOriginal: {
      sumTaxTotal,
      sumAmt,
      sumTax,
      sumEffectiveTax,
      totalCount,
      buyCount,
      invoiceList,
      vatLimitFlag,
      vatLimitResponse,
    },
  }) => ({
    invoiceType,
    invoiceList,
    sumTaxTotal,
    sumAmt,
    sumTax,
    sumEffectiveTax,
    totalCount,
    buyCount,
    vatLimitFlag,
    vatLimitResponse,
  }),
)(Footer);
