import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Modal, Input, Checkbox, Form } from 'antd';

const formItemLayout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
  labelAlign: 'right',
};
const SaveModal = ({ onCancel, onOk, form }) => {
  const [defaultValue, setDefaultValue] = useState(false);
  const modalProps = {
    visible: true,
    destroyOnClose: true,
    width: 420,
    title: '存为常用条件',
    icon: null,
    className: 'ywy-modal-info',
    okText: '保存',
    onCancel,
    onOk: () => {
      form.validateFields((errors, values) => {
        if (!errors) {
          onOk({
            ...values,
            isDefault: Number(defaultValue),
          });
        }
      });
    },
  };

  const defaultChange = (e) => {
    const { checked } = e.target;
    setDefaultValue(checked);
  };

  return (
    <Modal {...modalProps}>
      <div>
        <Form {...formItemLayout}>
          <Form.Item label="常用条件名称：">
            {form.getFieldDecorator('commonlyName', {
              rules: [{ required: true, message: '请输入常用条件名称' }],
            })(<Input maxLength={10} style={{ width: 250 }} placeholder="必填项，最多10个字" />)}
          </Form.Item>
        </Form>
        <Checkbox checked={defaultValue} style={{ margin: '0 0 0 124px' }} onChange={defaultChange}>
          设为默认筛选条件
        </Checkbox>
      </div>
    </Modal>
  );
};
SaveModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  onOk: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default Form.create()(SaveModal);
