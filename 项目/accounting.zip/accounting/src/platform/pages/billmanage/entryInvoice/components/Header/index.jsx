import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import moment from 'moment';
import { Button, Icon } from 'antd';
import { Head, Left, Center, Right, Title } from '@/Layout';
import Ico from '@/Icon';
import Period from '@/Period';
import ToTemplateMemoIcon from '@/ToTemplateMemoIcon';
import Search from '../Search';
import {
  ImportButton,
  ModifyTemplateButton,
  CreateVoucherButton,
  PowerButton,
  MoreButton,
} from '../Button';
import initPeriod from '../../../../../../public/initPeriod';
import '../../css/index.less';

const { inAuth } = window;

class Header extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      synchronization: false,
    };
  }

  componentDidMount() {
    const { isCheckOut, dispatch, isPeriodWrong, currentDate, endDate } = this.props;
    if (isCheckOut && isPeriodWrong) {
      dispatch({
        type: 'updateState',
        payload: {
          isPeriodWrong: false,
        },
      });
    }
    dispatch({
      type: 'periodWrong',
      payload: { endDate: endDate || currentDate, startDate: endDate || currentDate },
    });
  }

  async periodChange(date) {
    const { dispatch, period } = this.props;
    const { endDate } = date;
    await dispatch({
      type: 'periodWrong',
      payload: date,
    });
    if (!period.includes(endDate)) {
      initPeriod(undefined, endDate, async (layerInst) => {
        layerInst.hide();
        await dispatch({ type: 'switchingDate' });
      });
      return;
    }
    await dispatch({ type: 'switchingDate' });
  }

  searchInvoice(value) {
    const { dispatch } = this.props;
    dispatch({
      type: 'setQuery',
      payload: {
        name: value,
      },
    });
  }

  extractData() {
    const { dispatch, endDate, period, noDiskExtract } = this.props;
    if ([1, 2].includes(noDiskExtract)) {
      if ([1].includes(noDiskExtract)) {
        dispatch({
          type: 'stopNoDiskExtract',
          payload: { accountPeriod: endDate.replace('-', '') },
        });
      }
      return;
    }
    if (!period.includes(endDate)) {
      initPeriod(undefined, endDate, (layerInst) => {
        layerInst.hide();
        dispatch({ type: 'extractEntryInvoiceList', payload: 'likeInit' });
      });
      return;
    }
    dispatch({ type: 'extractEntryInvoiceList', payload: 'likeInit' });
  }

  goTransformInvoice() {
    const { endDate, dispatch } = this.props;
    dispatch({ type: 'updateState', payload: { isTransform: true } });
    dispatch({ type: 'setTransformInvoiceQuery', payload: { endDate } });
  }

  onMouseOver = () => {
    const { noDiskExtract } = this.props;
    if (noDiskExtract === 1) {
      this.setState({
        synchronization: true,
      });
    }
  };

  onMouseOut = () => {
    const { synchronization } = this.state;
    if (synchronization) {
      this.setState({
        synchronization: false,
      });
    }
  };

  render() {
    const {
      invoiceType,
      noPower,
      isPeriodWrong,
      year,
      month,
      vatType,
      currentDate,
      useStatus,
      noDiskExtract,
      extractType,
    } = this.props;
    const { synchronization } = this.state;
    // console.log(noPower);
    const { period } = this.props;
    const maxDates = [];
    period.forEach((v) => {
      maxDates.push(v);
    });
    for (let i = year; i <= year + 1; i += 1) {
      const initMonth = i === year ? month : 1; // 从1开始或从当前会计期间开始
      let maxMonth = 1;
      if (i === year) {
        maxMonth = 12;
      } else {
        maxMonth = currentDate.split('-')[1] > month ? month : currentDate.split('-')[1];
      }
      for (let j = initMonth; j <= maxMonth; j += 1) {
        const date = `${i}-${j < 10 ? `0${j}` : j}`;
        if (!maxDates.includes(date)) {
          maxDates.push(date);
        }
      }
    }

    return (
      <Head>
        <Left>
          <Period periods={maxDates} limit onChange={(e) => this.periodChange(e)} />
          <Search onSearch={(e) => this.searchInvoice(e)} />
        </Left>
        <Center>
          {invoiceType !== 'vat' && (
            <span styleName="bill-left-btn" onClick={() => this.goTransformInvoice()}>
              未认证转已认证发票列表
              <Ico type="new" style={{ color: '#ff0000', marginLeft: 5 }} />
            </span>
          )}
          <Title />
          {useStatus !== 3 && (
            <ToTemplateMemoIcon style={{ color: '#008CFF' }} content="凭证模板记忆" />
          )}
        </Center>
        {inAuth() && (
          <Right>
            {useStatus !== 3 && (
              <>
                {!!noPower && extractType !== 1 && <PowerButton />}
                {(!noPower || extractType === 1) && (
                  <Button
                    type="primary"
                    className="e-ml5"
                    onClick={() => this.extractData()}
                    disabled={!isPeriodWrong}
                    onBlur={() => {}}
                    onFocus={() => {}}
                    onMouseOver={this.onMouseOver}
                    onMouseOut={this.onMouseOut}
                  >
                    {[1, 2].includes(noDiskExtract) && extractType === 1 ? (
                      <>
                        {[1].includes(noDiskExtract) && synchronization ? (
                          '取消同步'
                        ) : (
                          <>
                            {/* <Ico type="zuoxuanzhuan" /> */}
                            <Icon type="sync" spin style={{ paddingRight: '5px' }} />
                            同步中
                          </>
                        )}
                      </>
                    ) : (
                      `数据同步`
                    )}
                  </Button>
                )}

                <ImportButton maxDates={maxDates} />
                <ModifyTemplateButton className="e-ml5" />
                <CreateVoucherButton className="e-ml5" />
                <MoreButton showLimit={invoiceType === 'vat' && vatType === 1 && inAuth('531')} />
              </>
            )}
          </Right>
        )}
      </Head>
    );
  }
}
Header.defaultProps = {
  invoiceType: '',
  endDate: '',
  period: [],
  year: 0,
  month: 0,
  currentDate: '',
  isCheckOut: false,
  vatType: '',
  useStatus: 0,
  noDiskExtract: 0, // -1:提取状态异常, 0:不存在处理中的任务, 1:排队中, 2:处理中, 3:拉取成功, 4:拉取失败, 5:终止任务, 6维护税号， 7维护登陆信息
  extractType: 0,
};
Header.propTypes = {
  invoiceType: PropTypes.string,
  noPower: PropTypes.oneOfType([PropTypes.bool, PropTypes.number]).isRequired,
  isPeriodWrong: PropTypes.bool.isRequired,
  endDate: PropTypes.string,
  period: PropTypes.arrayOf(PropTypes.string),
  year: PropTypes.number,
  month: PropTypes.number,
  currentDate: PropTypes.string,
  isCheckOut: PropTypes.bool,
  vatType: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  dispatch: PropTypes.func.isRequired,
  useStatus: PropTypes.number,
  noDiskExtract: PropTypes.number,
  extractType: PropTypes.number,
};
export default connect(
  (
    { invoiceType, noPower, isPeriodWrong, noDiskExtract, query: { endDate } },
    {
      account: {
        period,
        currentYear: year,
        currentMonth: month,
        currentDate,
        isCheckOut,
        vatType,
        extractType,
        user: { useStatus },
      },
    },
  ) => ({
    invoiceType,
    noPower,
    isPeriodWrong,
    noDiskExtract,
    endDate,
    period,
    year,
    month,
    currentDate,
    isCheckOut,
    vatType,
    useStatus,
    extractType,
  }),
)(withNuomi(Header));
