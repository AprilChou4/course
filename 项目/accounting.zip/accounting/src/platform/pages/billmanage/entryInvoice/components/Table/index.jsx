import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Icon } from 'antd';
import { renderTableCell } from 'utils';
import Ico from '@/Icon';
import { Content } from '@/Layout';
import SuperTable from '@/SuperTable';
import TableCell from '@/TableCell';
import { ConfirmModal } from '@/modal';
import TemplateOperation from '@/TemplateOperation';
import MachineNoInput from './machineNoInput';
import Footer from './footer';
import CheckCode from '../Layer/checkCode';
import StockModal from '../../../../stock/common/StockModal';
import { superLayer } from '../../../../../public/layer';
import '../../css/index.less';

class invoiceTable extends PureComponent {
  constructor(props) {
    super(props);
    this.sortElement = (name, key, isDesc) => {
      return (
        <div onClick={this.sortChange.bind(this, key)} style={{ cursor: 'pointer' }}>
          <span style={{ lineHeight: '38px', verticalAlign: 'bottom', display: 'inline-block' }}>
            {name}
          </span>
          <div style={{ display: 'inline-block' }}>
            <div>
              <Icon
                type="caret-up"
                style={{
                  verticalAlign: 'bottom',
                  marginBottom: -3,
                  color: isDesc === 0 ? '#3f91f1' : '#bfbfbf',
                }}
              />
            </div>
            <div>
              <Icon
                type="caret-down"
                style={{
                  verticalAlign: 'top',
                  marginTop: -3,
                  color: isDesc === 0 ? '#bfbfbf' : '#3f91f1',
                }}
              />
            </div>
          </div>
        </div>
      );
    };
  }

  onRowRender(record) {
    return {
      onDoubleClick: record.invoiceId && !record.isTotal && this.showInvoice.bind(this, record),
    };
  }

  onSelectChange(selectedRowKeysArgs) {
    const { dataSource, invoiceList, selectedRowKeys, dispatch } = this.props;
    const ableDataSource = dataSource.filter((v) => !v.voucherId && v.invoiceState !== 2);
    const showKeys = ableDataSource.map((v) => v.invoiceId);
    const newKeys = [].concat(selectedRowKeysArgs);
    if (!newKeys.includes('total') && newKeys.length === ableDataSource.length - 1) {
      newKeys.push('total');
    }
    if (newKeys.includes('total') && newKeys.length === 1) {
      newKeys.pop();
    }
    selectedRowKeys.forEach((v) => {
      if (v === 'total' && !newKeys.includes(v)) {
        newKeys.push(v);
        return;
      }
      if (!showKeys.includes(v)) {
        newKeys.push(v);
      }
    });
    dispatch({
      type: 'updateState',
      payload: {
        selectedRowKeys: newKeys,
        selectedRows: invoiceList.filter((v) => newKeys.includes(v.invoiceId)),
      },
    });
  }

  getInvoiceContent(row) {
    const { dispatch } = this.props;
    const { invoiceId } = row;
    dispatch({
      type: 'fpcyEntryInvoiceList',
      payload: {
        invoiceId,
      },
    });
  }

  showInvoice(row) {
    const { dispatch } = this.props;
    const { invoiceId } = row;
    dispatch({
      type: 'queryInvoiceByCodeAndNumber',
      payload: {
        invoiceIds: invoiceId,
        success: (data) => {
          StockModal({ invoiceJson: data });
        },
      },
    });
  }

  sortChange(key) {
    const { dispatch, invoiceNumberDesc, dateDesc, voucherDesc } = this.props;
    const valueObj = { invoiceNumber: invoiceNumberDesc, date: dateDesc, voucher: voucherDesc };
    const valueArr = ['date', 'invoiceNumber', 'voucher'];
    const obj = {};
    obj[`${key}Desc`] = Number(valueObj[key] === 0);
    dispatch({
      type: 'setQuery',
      payload: {
        ...obj,
        invoiceNumberSortFirst: valueArr.indexOf(key),
      },
    });
  }

  toVoucherPage(voucherId) {
    const { dataSource, dispatch } = this.props;
    superLayer('voucher/record', {
      data: {
        title: '记账凭证',
        voucherId,
        isBillManage: true,
      },
      getVoucherIds: () => dataSource.filter((v) => !!v.voucherId).map((v) => v.voucherId),
      async onDestroy() {
        await dispatch({ type: '$getList', payload: 'noReset' });
      },
    });
  }

  generateVoucher(row) {
    const { invoiceId, invoiceState } = row;
    const { invoiceType, endDate, dispatch } = this.props;
    dispatch({
      type: 'prepareVoucher',
      payload: {
        invoiceType: invoiceType === 'vat' ? 0 : 1,
        invoiceIdList: [invoiceId],
        accountPeriod: Number(endDate.split('-').join('')),
        hasNoAuth: Number(invoiceState) === 5,
      },
    });
  }

  async modifyTemplate(row) {
    const { invoiceType, dispatch } = this.props;
    const { templateId, invoiceId } = row;
    TemplateOperation({
      switchTemp: true,
      type: '1',
      invoiceType: invoiceType === 'vat' ? '3' : '1,2',
      // 切换模板 getDatas 可以只有templateId 也可以传 全部信息
      getDatas: {
        templateId,
      },
      callback: (data) => {
        dispatch({
          type: 'batchUpdateTemplate',
          payload: {
            invoiceIdList: [invoiceId],
            templateId: data.templateId,
          },
        });
      },
    });
  }

  machineNoBlur(value, row) {
    const { invoiceId } = row;
    const { dispatch } = this.props;
    dispatch({
      type: 'replenishMachineNo',
      payload: {
        invoiceIds: [invoiceId],
        machineNo: value,
      },
    });
  }

  createColumns() {
    const {
      invoiceType,
      isPeriodWrong,
      isCheckOutDate,
      columnsDefine,
      invoiceNumberDesc,
      dateDesc,
      voucherDesc,
      queryInvoiceType,
      unitPricePrecision,
      useStatus,
    } = this.props;
    const columns = [];
    const finalColumns = [];
    finalColumns.push({
      title: '',
      dataIndex: 'delete',
      key: 'delete',
      fixed: 'left',
      width: 0,
      minWidth: 0,
      dragCell: false,
      render: (value, row) => {
        const { invoiceId, voucherCode, source, detailSource, invoiceContent, systemLine } = row;

        return inAuth() === false ||
          invoiceId === 'total' ||
          voucherCode ||
          isCheckOutDate ? null : (
          <span className="cell-nowrap">
            <span className="cell-text">
              {![1, 2, 8].includes(source) && (
                <Icon
                  type="close-circle"
                  onClick={() => {
                    this.invoiceDelete(invoiceId);
                  }}
                />
              )}
              {((detailSource === 0 && systemLine !== 1) ||
                ![1, 2, 8].includes(source) ||
                !invoiceContent) && (
                <Ico type="bianji1" onClick={() => this.editInvoiceInfo(invoiceId, source)} />
              )}
            </span>
          </span>
        );
      },
    });
    if (invoiceType !== 'vat') {
      columns.push({
        title: '发票状态',
        dataIndex: 'invoiceStateName',
        key: 'invoiceStateName',
        align: 'center',
        width: 75,
        minWidth: 70,
        render: renderTableCell('text'),
      });
    }
    columns.push(
      {
        title: '发票类型',
        dataIndex: 'typeName',
        key: 'typeName',
        align: 'center',
        width: 100,
        minWidth: 100,
        render: renderTableCell('text'),
      },
      {
        title: this.sortElement('发票号码', 'invoiceNumber', invoiceNumberDesc),
        dataIndex: 'invoiceNumber',
        key: 'invoiceNumber',
        align: 'center',
        width: 95,
        minWidth: 95,
        render: (value, record) => {
          return (
            <TableCell>
              <span styleName="like-a" onClick={this.showInvoice.bind(this, record)}>
                {value}
              </span>
            </TableCell>
          );
        },
      },
      {
        title: this.sortElement('开票日期', 'date', dateDesc),
        dataIndex: 'date',
        key: 'date',
        align: 'center',
        width: 95,
        minWidth: 95,
        render: renderTableCell('text'),
      },
      {
        title: invoiceType !== 'vat' || queryInvoiceType === '3' ? '供应商名称' : '客户名称',
        dataIndex: 'auxiliaryName',
        key: 'auxiliaryName',
        width: 215,
        minWidth: 100,
        render: renderTableCell('text'),
      },
      {
        title: '发票内容',
        dataIndex: 'invoiceContent',
        key: 'invoiceContent',
        width: 230,
        minWidth: 70,
        render: (value, row) => {
          const { isTotal, type } = row;
          let HTMLDOM = '';
          if (value) {
            HTMLDOM = value;
          } else if (['t', 'p', 'cs', 'ps', 'c'].includes(type)) {
            HTMLDOM = isPeriodWrong ? (
              <span styleName="like-a" onClick={this.showCheckCode.bind(this, row)}>
                补全发票
              </span>
            ) : (
              <span style={{ color: '#ccc' }}>补全发票</span>
            );
          } else {
            HTMLDOM = isPeriodWrong ? (
              <span styleName="like-a" onClick={this.getInvoiceContent.bind(this, row)}>
                获取明细
              </span>
            ) : (
              <span style={{ color: '#ccc' }}>获取明细</span>
            );
          }
          return (
            this.inAuth(invoiceType === 'vat' ? 104 : 101) &&
            !isTotal && <TableCell>{HTMLDOM}</TableCell>
          );
        },
      },
      {
        title: '单价',
        dataIndex: 'price',
        key: 'price',
        className: 'total-line-need-border',
        width: 130,
        minWidth: 50,
        align: 'right',
        render: renderTableCell({ type: 'number', toFixed: unitPricePrecision, showZero: true }),
      },
      {
        title: '金额',
        dataIndex: 'amt',
        key: 'amt',
        className: 'total-line-need-border',
        width: 130,
        minWidth: 50,
        align: 'right',
        render: renderTableCell({ type: 'number', showZero: true }),
      },
      {
        title: '税率',
        dataIndex: 'taxRateStr',
        key: 'taxRateStr',
        className: 'total-line-need-border',
        width: 55,
        minWidth: 50,
        align: 'center',
        render: renderTableCell('text'),
      },
      {
        title: '税额',
        dataIndex: 'tax',
        key: 'tax',
        className: 'total-line-need-border',
        width: 135,
        minWidth: 50,
        align: 'right',
        render: renderTableCell({ type: 'number', showZero: true }),
      },
    );
    if (invoiceType !== 'vat') {
      columns.push({
        title: '有效税额',
        dataIndex: 'effectiveTax',
        key: 'effectiveTax',
        className: 'total-line-need-border',
        width: 135,
        minWidth: 50,
        align: 'right',
        render: renderTableCell({ type: 'number', showZero: true }),
      });
    }
    columns.push(
      {
        title: '价税合计',
        dataIndex: 'taxTotal',
        key: 'taxTotal',
        className: 'total-line-need-border',
        width: 145,
        minWidth: 70,
        align: 'right',
        render: renderTableCell({ type: 'number', showZero: true }),
      },
      {
        title: '备注',
        draglast: 50,
        dragCell: false,
        dataIndex: 'remarks',
        key: 'remarks',
        className: 'total-line-need-border',
        width: 100,
        minWidth: 50,
        render: renderTableCell('text'),
      },
    );
    if (invoiceType === 'vat') {
      columns.push({
        dragCell: false,
        title: '开票机号',
        dataIndex: 'machineNo',
        key: 'machineNo',
        className: 'total-line-need-border',
        width: 112,
        minWidth: 112,
        align: 'center',
        render: (val, row) => {
          const { isTotal, macNoSource, voucherId } = row;
          return macNoSource === 0 || isTotal || !!voucherId ? (
            <span>{val}</span>
          ) : (
            <MachineNoInput
              initValue={val}
              disabled={!isPeriodWrong}
              onBlur={(e) => {
                this.machineNoBlur(e, row);
              }}
            />
          );
        },
      });
    }
    columns.push({
      title: '发票来源',
      dataIndex: 'sourceName',
      key: 'sourceName',
      className: 'total-line-need-border',
      width: 100,
      minWidth: 70,
      render: renderTableCell('text'),
    });
    columnsDefine.forEach((v) => {
      if (v.isShow) {
        const item = columns.find((y) => y.key === v.columnField);
        if (item) {
          finalColumns.push(item);
        }
      }
    });
    finalColumns.push({
      title: '凭证模板',
      dataIndex: 'templateName',
      align: 'center',
      key: 'templateName',
      fixed: 'right',
      width: 120,
      minWidth: 100,
      render: (value, row) => {
        const { voucherId, invoiceId, invoiceState } = row;
        return (
          this.inAuth(invoiceType === 'vat' ? 104 : 101) && (
            <TableCell>
              {voucherId ||
              !isPeriodWrong ||
              invoiceId === 'total' ||
              useStatus === 3 ||
              invoiceState === 2 ? (
                <span style={{ color: '#ccc' }}>{value}</span>
              ) : (
                <span styleName="like-a" onClick={this.modifyTemplate.bind(this, row)}>
                  {value || '请选择模板'}
                </span>
              )}
            </TableCell>
          )
        );
      },
    });
    if (invoiceType !== 'vat') {
      finalColumns.push({
        title: this.sortElement('凭证', 'voucher', voucherDesc),
        dataIndex: 'voucherId',
        align: 'center',
        key: 'voucherId',
        fixed: 'right',
        width: 100,
        minWidth: 100,
        render: (value, row) => {
          const { voucherCode, isTotal, invoiceState } = row;
          let HTMLDOM = '';
          if (voucherCode) {
            HTMLDOM = (
              <span styleName="like-a" onClick={this.toVoucherPage.bind(this, value)}>
                {voucherCode}
              </span>
            );
          } else {
            HTMLDOM =
              isPeriodWrong && useStatus !== 3 && invoiceState !== 2 ? (
                <span styleName="like-a" onClick={this.generateVoucher.bind(this, row)}>
                  生成凭证
                </span>
              ) : (
                <span style={{ color: '#ccc' }}>生成凭证</span>
              );
          }
          return (
            this.inAuth(invoiceType === 'vat' ? 104 : 101) &&
            !isTotal && <TableCell>{HTMLDOM}</TableCell>
          );
        },
      });
    } else {
      finalColumns.push({
        title: this.sortElement('凭证', 'voucher', voucherDesc),
        dataIndex: 'voucherId',
        align: 'center',
        key: 'voucherId',
        fixed: 'right',
        width: 100,
        minWidth: 100,
        render: (value, row) => {
          const { voucherCode, templateId, invoiceState, isTotal } = row;
          return (
            this.inAuth(invoiceType === 'vat' ? 104 : 101) &&
            !isTotal && (
              <TableCell>
                {voucherCode && (
                  <span styleName="like-a" onClick={this.toVoucherPage.bind(this, value)}>
                    {voucherCode}
                  </span>
                )}
                {!voucherCode &&
                  (isPeriodWrong && templateId && invoiceState !== 2 ? (
                    <span styleName="like-a" onClick={this.generateVoucher.bind(this, row)}>
                      生成凭证
                    </span>
                  ) : (
                    <span style={{ color: '#ccc' }}>生成凭证</span>
                  ))}
              </TableCell>
            )
          );
        },
      });
    }

    return finalColumns;
  }

  async invoiceDelete(ids) {
    const { dispatch } = this.props;
    ConfirmModal({
      width: 265,
      className: 'ywy-no-close-btn',
      title: '删除后不可恢复，确定删除所选发票？',
      onOk: () => {
        dispatch({
          type: 'deleteInvoice',
          payload: {
            ids,
          },
        });
      },
    });
  }

  async editInvoiceInfo(invoiceId, source) {
    const { dispatch } = this.props;
    dispatch({ type: 'getInvoiceInfo', payload: { invoiceId, source } });
  }

  showLocale() {
    const { noPower, invoiceType } = this.props;
    let emptyText = '暂无数据';
    if (invoiceType === 'vat') {
      emptyText = '当月无符合筛选条件的发票';
    } else {
      emptyText = `当月无符合筛选条件的发票`;
    }
    if (noPower) {
      emptyText = '请通过申请授权或者手动新增等方式获取发票数据';
    }
    return emptyText;
  }

  showCheckCode(row) {
    const { checkCode, invoiceId } = row;
    const { dispatch } = this.props;
    dispatch({
      type: 'updateState',
      payload: {
        checkCodeProps: {
          checkCode,
          invoiceId,
          checkCodeVisible: true,
        },
      },
    });
  }

  render() {
    const { dataSource, selectedRowKeys, layoutKey, pageSize } = this.props;
    const newColumns = this.createColumns();
    const showKeys = dataSource.map((v) => v.invoiceId);
    const showSelectedRowKeys = selectedRowKeys.filter((v) => showKeys.includes(v));
    if (showSelectedRowKeys.length === 1 && showSelectedRowKeys.includes('total')) {
      showSelectedRowKeys.pop();
    }
    const rowSelection = {
      fixed: true,
      selectedRowKeys: showSelectedRowKeys,
      onChange: (selectedRowKeysArg, selectedRows) => {
        this.onSelectChange(selectedRowKeysArg, selectedRows);
      },
      getCheckboxProps: (record) => ({
        style: { display: record.isTotal ? 'none' : 'block', borderRightColor: 'transparent' },
        disabled: !!record.voucherId || record.invoiceState === 2,
      }),
    };
    return (
      <Content style={{ paddingLeft: 0 }}>
        <SuperTable
          draglast
          dragCell
          noLazyLoading={pageSize < 101}
          refreshTable={layoutKey}
          className="delete-table total-table"
          setRecalculate={new Date().getTime()}
          rowSelection={rowSelection}
          columns={newColumns}
          dataSource={dataSource}
          onRow={(record) => this.onRowRender(record)}
          footer={() => <Footer />}
          scroll={{ x: '100%' }}
          rowClassName={(record) => {
            const { invoiceState, isTotal } = record;
            let lineClassName = '';
            if (isTotal) {
              lineClassName = 'total-line';
            } else if (invoiceState === 2) {
              lineClassName = 'disabled-line';
            }
            return lineClassName;
          }}
          bordered
          pagination={false}
          locale={{
            emptyText: (
              <div style={{ height: '260px' }}>
                <span
                  className="ui-void"
                  style={{ paddingTop: '150px', width: '290px', margin: '-70px 0 0 -141px' }}
                >
                  {this.showLocale()}
                </span>
              </div>
            ),
          }}
        />
        <CheckCode />
      </Content>
    );
  }
}
invoiceTable.defaultProps = {
  invoiceType: '',
  queryInvoiceType: '',
  unitPricePrecision: 2,
  invoiceList: [],
  useStatus: 0,
};
invoiceTable.propTypes = {
  layoutKey: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  noPower: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]).isRequired,
  isPeriodWrong: PropTypes.bool.isRequired,
  isCheckOutDate: PropTypes.bool.isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
  invoiceList: PropTypes.arrayOf(PropTypes.any),
  selectedRowKeys: PropTypes.arrayOf(PropTypes.any).isRequired,
  invoiceType: PropTypes.string,
  columnsDefine: PropTypes.arrayOf(PropTypes.any).isRequired,
  pageSize: PropTypes.number.isRequired,
  invoiceNumberDesc: PropTypes.number.isRequired,
  dateDesc: PropTypes.number.isRequired,
  voucherDesc: PropTypes.number.isRequired,
  endDate: PropTypes.string.isRequired,
  queryInvoiceType: PropTypes.string,
  unitPricePrecision: PropTypes.number,
  dispatch: PropTypes.func.isRequired,
  useStatus: PropTypes.number,
};
export default connect(
  (
    {
      layoutKey,
      noPower,
      isPeriodWrong,
      isCheckOutDate,
      dataSource,
      dataSourceOriginal: { invoiceList },
      selectedRowKeys,
      invoiceType,
      columnsDefine,
      paginationProps: { pageSize },
      query: {
        invoiceNumberDesc,
        dateDesc,
        endDate,
        voucherDesc,
        invoiceType: [queryInvoiceType],
      },
    },
    {
      account: {
        unitPricePrecision,
        user: { useStatus },
      },
    },
  ) => ({
    layoutKey,
    noPower,
    isPeriodWrong,
    isCheckOutDate,
    dataSource,
    invoiceList,
    selectedRowKeys,
    invoiceType,
    columnsDefine,
    pageSize,
    invoiceNumberDesc,
    dateDesc,
    voucherDesc,
    endDate,
    queryInvoiceType,
    unitPricePrecision,
    useStatus,
  }),
)(invoiceTable);
