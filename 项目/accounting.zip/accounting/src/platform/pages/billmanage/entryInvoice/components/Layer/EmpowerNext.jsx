import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Form, Input, Modal, Popover } from 'antd';
import '../../css/empower.less';

const content1 = (
  <div styleName="ui-pop-emp">
    <h6>适用对象：被代账企业数据提取</h6>
    <p>使用方法：</p>
    <p>1、安装于增值税发票税控开票软件所在电脑</p>
    <p>2、插入税盘进行税盘绑定</p>
    <p>3、进入“我的企业”，生成授权码</p>
  </div>
);
const content2 = (
  <div styleName="ui-pop-emp">
    <h6>适用对象：代账公司批量数据提取</h6>
    <p>使用方法：</p>
    <p>1、安装于增值税发票税控开票软件所在电脑</p>
    <p>2、查看企业对应授权码</p>
  </div>
);
const content3 = (
  <div styleName="ui-pop-emp">
    <h6>适用对象：代账公司会计</h6>
    <p>使用方法：</p>
    <p>1、将云代账客户端安装于防伪税控开票电脑上</p>
    <p>2、插入接税盘自动获取授权码</p>
  </div>
);
const content4 = (
  <div styleName="ui-pop-emp">
    <h6>适用对象：企业公司会计</h6>
    <p>使用方法：</p>
    <p>1、将云企业版客户端安装于防伪税控开票电脑上</p>
    <p>2、插入接税盘自动获取授权码</p>
  </div>
);
class Empower extends PureComponent {
  constructor() {
    super();
    this.state = {
      visible: false,
      imageNum: 1,
      modalWidth: 1000,
      validateStatus: '',
      help: '',
    };
    this.static = {
      formItemLayout: {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 4 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 20 },
        },
      },
    };
  }

  componentDidMount() {
    this.resizeWidth();
  }

  UNSAFE_componentWillReceiveProps(newProps) {
    const { powerNumber: newValue } = newProps;
    const { powerNumber: oldValue } = this.props;
    if (newValue !== oldValue) {
      this.validateValue(newValue);
    }
  }

  onValueChange(e) {
    const { value } = e.target;
    const { dispatch } = this.props;
    dispatch({
      type: 'updateState',
      payload: {
        powerNumber: value,
      },
    });
    this.validateValue(value);
  }

  validateValue(value) {
    let obj = { validateStatus: 'success', help: '' };
    if (value === '') {
      obj = { validateStatus: 'error', help: '请填写授权码信息' };
    } else if (!/^[0-9A-Za-z]{6,48}$/.test(value)) {
      obj = { validateStatus: 'error', help: '授权码为6位或48位数字或字母组合' };
    }
    this.setState(obj);
  }

  powerModalSure() {
    const { dispatch, powerNumber, autoPowerNumber } = this.props;
    this.validateValue(powerNumber);
    const { validateStatus } = this.state;
    if (validateStatus !== 'success') {
      return;
    }
    dispatch({
      type: 'addAuthCodeRelation',
      payload: {
        authCode: powerNumber,
        flag: Number(powerNumber === autoPowerNumber), // 如果插盘获取flag=1
      },
    });
    this.powerModalCancel();
  }

  powerModalCancel() {
    const { dispatch } = this.props;
    dispatch({
      type: 'updateState',
      payload: {
        powerModalVisible: false,
        powerNumber: '',
      },
    });
    this.setState({
      validateStatus: '',
      help: '',
    });
  }

  resizeWidth() {
    window.addEventListener('resize', () => {
      const { innerWidth } = window;
      this.setState({
        // eslint-disable-next-line no-nested-ternary
        modalWidth: innerWidth > 1000 ? 1000 : innerWidth > 200 ? innerWidth - 40 : 200,
      });
    });
  }

  modalShow(num) {
    this.setState({
      visible: true,
      imageNum: num,
    });
  }

  modalCancel() {
    this.setState({ visible: false });
  }

  render() {
    const FormItem = Form.Item;
    const { formItemLayout } = this.static;
    const { clientPowerInfo, powerNumber, versionType } = this.props;
    const isClient = typeof ExternService === 'object';
    const { visible, imageNum, modalWidth, validateStatus, help } = this.state;
    return (
      <div style={{ display: 'inline-block' }}>
        <Modal
          visible
          title="温馨提示"
          onCancel={() => this.powerModalCancel()}
          onOk={() => this.powerModalSure()}
          width={versionType === '2' ? 550 : 520}
        >
          {isClient && <p style={{ paddingLeft: 80, color: '#F5A623' }}>{clientPowerInfo}</p>}
          <Form {...formItemLayout}>
            <FormItem label="授权码" validateStatus={validateStatus} help={help}>
              <Input
                placeholder="请填写授权码"
                value={powerNumber}
                onChange={(e) => this.onValueChange(e)}
              />
            </FormItem>
          </Form>
          <div styleName="ui-empower-down">
            <h6>授权码获取方法：</h6>
            <div>
              1、在【财税助手2.0】的<a onClick={this.modalShow.bind(this, 1)}>“我的企业”</a>
              页面可生成授权码{' '}
              <span>
                <a href="http://nnfw.jss.com.cn/4F277D7F919F46439B5F0B7FBAECEF7B/诺诺财税助手2.0.5.5.exe">
                  立即下载
                </a>
                <Popover placement="bottom" content={content1}>
                  <em className="iconfont">&#xe6aa;</em>
                </Popover>
              </span>
            </div>
            {versionType === '2' ? (
              <div>
                2、使用【云记账企业版客户端】，税盘插入状态，即可自动获取授权码
                <span>
                  <a href="http://nnfw.jss.com.cn/F2907EFA884E411BB89AB9C3DFF14B3A/诺诺企业版云记账1.0.0.exe">
                    立即下载
                  </a>
                  <Popover placement="bottom" content={content4}>
                    <em className="iconfont">&#xe6aa;</em>
                  </Popover>
                </span>
              </div>
            ) : (
              <>
                <div>
                  2、在【发票提取工具】的<a onClick={this.modalShow.bind(this, 2)}>“进销项发票”</a>
                  页面，查看授权
                  <span>
                    <a href="http://v.jss.com.cn/cszs/进销项提取工具.exe">立即下载</a>
                    <Popover placement="bottom" content={content2}>
                      <em className="iconfont">&#xe6aa;</em>
                    </Popover>
                  </span>
                </div>
                <div>
                  3、使用【云代账客户端】，税盘插入状态，即可自动获取授权码
                  <span>
                    <a href="http://nnfw.jss.com.cn/07945098A77C4814AC140DCA8A1064E0/诺诺云代账2.0.1.8.exe">
                      立即下载
                    </a>
                    <Popover placement="bottom" content={content3}>
                      <em className="iconfont">&#xe6aa;</em>
                    </Popover>
                  </span>
                </div>
              </>
            )}
          </div>
        </Modal>
        <Modal
          visible={visible}
          width={modalWidth}
          footer={null}
          onCancel={() => this.modalCancel()}
        >
          <div style={{ width: '100%' }}>
            <img
              style={{ width: '100%' }}
              src={imageNum === 1 ? '/static/images/tmp1.png' : '/static/images/tmp2.png'}
              alt="发票样例"
            />
          </div>
        </Modal>
      </div>
    );
  }
}
Empower.propTypes = {
  powerNumber: PropTypes.string.isRequired,
  autoPowerNumber: PropTypes.string.isRequired,
  clientPowerInfo: PropTypes.string.isRequired,
  dispatch: PropTypes.func.isRequired,
  versionType: PropTypes.string.isRequired,
};
export default connect(
  ({ powerNumber, autoPowerNumber, clientPowerInfo }, { account: { versionType } }) => ({
    powerNumber,
    autoPowerNumber,
    clientPowerInfo,
    versionType,
  }),
)(Empower);
