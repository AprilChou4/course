import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Progress } from 'antd';

const modalProgress = ({ isShowProgress, failCount, successCount, totalCount }) => {
  const modalProps = {
    visible: isShowProgress,
    width: 420,
    footer: null,
    maskClosable: false,
    closable: false,
  };

  const progressProps = {
    percent: ((failCount + successCount) / totalCount) * 100,
    strokeColor: { from: '#00C0FF', to: '#008CFF' },
    strokeWidth: 16,
    showInfo: false,
  };

  return (
    <Modal {...modalProps}>
      <p style={{ color: '#008CFF', marginBottom: 12 }}>正在获取发票明细，请耐心等待......</p>
      <Progress {...progressProps} />
      <p style={{ marginTop: 12 }}>
        已成功获取<span style={{ color: '#008CFF' }}>{successCount}</span>条，失败
        <span style={{ color: '#008CFF' }}>{failCount}</span>条，剩余
        <span style={{ color: '#008CFF' }}>{totalCount - failCount - successCount}</span>条
      </p>
    </Modal>
  );
};
modalProgress.defaultProps = {
  percent: 20,
};
modalProgress.propTypes = {
  percent: PropTypes.number,
  isShowProgress: PropTypes.bool.isRequired,
  failCount: PropTypes.number.isRequired,
  successCount: PropTypes.number.isRequired,
  totalCount: PropTypes.number.isRequired,
};
export default connect(
  ({ isShowProgress, progressArgs: { failCount, successCount, totalCount } }) => ({
    isShowProgress,
    failCount,
    successCount,
    totalCount,
  }),
)(modalProgress);
