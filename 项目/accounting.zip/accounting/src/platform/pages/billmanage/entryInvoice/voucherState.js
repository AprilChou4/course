export default {
  // 二级科目
  secondSubjectModalVisible: false,
  secondSubjectData: [],
  // 新增客户/供应商弹框
  isShowCreateAuxiliary: false,
  supplierAuxiliaryResponse: {}, // 供应商
  customerAuxiliaryResponse: {}, // 客户
  // 生成凭证，存货辅助核算
  isAuxiliary: false,
  addStockProps: {
    auxiliaryTypeId: '',
    currencyIdList: [],
    autoExpand: false,
    auxiliaryCode: '',
    auxiliaryName: '',
    model: '',
    unit: '',
    classify: '',
  },
  stockTypeList: [], // 存货类别
  // 预处理参数
  prepareVoucherCondition: {},
  // 生成凭证请求参数
  createVoucherCondition: {},
  // 所有存货辅助核算
  stockAuxiliaryList: [],
  // 辅助核算凭证数据
  auxiliaryVoucherObject: {},
  // 红字发票
  isShowRedInvoiceCheck: false,
  redInvoices: [],
  redFilterInvoices: [],
};
