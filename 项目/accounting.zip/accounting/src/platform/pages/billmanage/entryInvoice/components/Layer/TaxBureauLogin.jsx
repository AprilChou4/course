import React from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Select } from 'antd';
import { create } from 'layer';

const FormItem = Form.Item;
const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};
const TaxNum = ({ form, layer, usernameLoginIdentity }) => {
  return (
    <Form {...formItemLayout} style={{ paddingTop: 20 }}>
      <div style={{ opacity: '0', height: '0px', overflow: 'hidden' }}>
        <Input type="text" name="usernameLoginIdentityName" />
        <Input type="password" />
        <Input type="text" name="username" />
      </div>
      <FormItem label="用户名" colon>
        {form.getFieldDecorator('username', {
          rules: [{ required: true, message: '用户名不能为空' }],
          // normalize: (val) => {
          //   return val ? val.slice(0, 20) : '';
          // },
        })(
          <Input
            placeholder="请填写用户名"
            style={{ width: 300 }}
            maxLength={20}
            autoComplete="off"
          />,
        )}
      </FormItem>
      <FormItem label="密码" colon>
        {form.getFieldDecorator('password', {
          rules: [{ required: true, message: '密码不能为空' }],
          // normalize: (val) => {
          //   return val ? val.slice(0, 20) : '';
          // },
        })(
          <Input.Password
            placeholder="请填写密码"
            style={{ width: 300 }}
            maxLength={20}
            autoComplete="off"
          />,
        )}
      </FormItem>

      <FormItem label="登录身份" colon>
        {form.getFieldDecorator('usernameLoginIdentity', {
          rules: [{ required: true, message: '登录身份不能为空' }],
        })(
          <Select style={{ width: 300 }} getPopupContainer={() => layer.element[0]}>
            {usernameLoginIdentity.map((item) => {
              return (
                <Select.Option key={item.value} value={item.value}>
                  {item.name}
                </Select.Option>
              );
            })}
          </Select>,
        )}
      </FormItem>
      <FormItem label="姓名" colon>
        {form.getFieldDecorator('usernameLoginIdentityName', {
          rules: [{ required: true, message: '姓名不能为空' }],
        })(
          <Input
            placeholder="请填写姓名"
            style={{ width: 300 }}
            maxLength={20}
            autoComplete="off"
          />,
        )}
      </FormItem>
      <FormItem label="身份密码" colon>
        {form.getFieldDecorator('usernameLoginIdentityPassword', {
          rules: [{ required: true, message: '身份密码不能为空' }],
        })(
          <Input.Password
            placeholder="请填写身份密码"
            style={{ width: 300 }}
            maxLength={20}
            autoComplete="off"
          />,
        )}
      </FormItem>
    </Form>
  );
};
TaxNum.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  layer: PropTypes.objectOf(PropTypes.any).isRequired,
  usernameLoginIdentity: PropTypes.arrayOf(PropTypes.any).isRequired,
};
export default Form.create()(create(TaxNum));
