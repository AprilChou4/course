import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, message, Input } from 'antd';

const MachineNoModal = ({ selectedRows, onCancel, dispatch }) => {
  const [machineNo, setMachineNo] = useState('');
  const modalProps = {
    visible: true,
    title: '开票机号编辑',
    width: 420,
    onOk: () => {
      if (machineNo) {
        dispatch({
          type: 'replenishMachineNo',
          payload: {
            invoiceIds: selectedRows
              .filter((v) => v.macNoSource !== 0 && !v.voucherId && v.invoiceId !== 'total')
              .map((v) => v.invoiceId),
            machineNo,
          },
        });
        onCancel();
      } else {
        message.warning('请输入开票机号');
      }
    },
    onCancel: () => {
      onCancel();
    },
  };
  const valueProps = {
    value: machineNo,
    style: { width: 120 },
    onChange: (e) => {
      const { value } = e.currentTarget;
      setMachineNo(value.replace(/[^\d]/gi, '').slice(0, 10));
    },
  };
  return (
    <Modal {...modalProps}>
      <div style={{ textAlign: 'center' }}>
        <span>请输入开票机号：</span>
        <Input {...valueProps} />
      </div>
    </Modal>
  );
};
MachineNoModal.propTypes = {
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  onCancel: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ selectedRows }) => ({
  selectedRows,
}))(MachineNoModal);
