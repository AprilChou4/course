import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Layout as ContentLayout } from '@/Layout';
import Header from '../Header';
import Table from '../Table';
import AuxiliaryHandle from '../../../auxiliaryHandle';
import TransformInvoiceList from '../../../transformInvoiceList';
import CreateAuxiliart from '../CreateAuxiliary';
import ModalProgress from '../Progress';
import FpcyMessage from '../Progress/fpcyMessage';
import SecondSubject from '../Layer/secondSubject';
import RedInvoiceCheck from '../RedInvoiceCheck';
import ManualModal from '../Button/ImportInvoice/ManualModal/ManualModal';

const Layout = ({ isAuxiliary, isTransform, secondSubjectModalVisible }) => {
  return (
    <ContentLayout>
      {isAuxiliary && <AuxiliaryHandle />}
      {isTransform && <TransformInvoiceList style={{ display: isAuxiliary ? 'none' : 'block' }} />}
      {!isAuxiliary && !isTransform && <Header />}
      {!isAuxiliary && !isTransform && <Table />}
      {secondSubjectModalVisible && <SecondSubject />}
      <CreateAuxiliart />
      <ModalProgress />
      <FpcyMessage />
      <ManualModal />
      <RedInvoiceCheck />
    </ContentLayout>
  );
};
Layout.propTypes = {
  isAuxiliary: PropTypes.bool.isRequired,
  isTransform: PropTypes.bool.isRequired,
  secondSubjectModalVisible: PropTypes.bool.isRequired,
};
export default connect(({ isAuxiliary, isTransform, secondSubjectModalVisible }) => ({
  isAuxiliary,
  isTransform,
  secondSubjectModalVisible,
}))(Layout);
