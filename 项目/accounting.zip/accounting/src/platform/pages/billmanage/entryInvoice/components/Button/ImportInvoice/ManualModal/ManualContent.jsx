import React, { useMemo, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Button } from 'antd';
import ManualForm from './ManualForm';
import ManualTable from './ManualTable';
import { invoiceTypeData } from '../../../static';
import './style.less';

const ManualContent = ({ tabsKey, dateValue, type, dispatch }) => {
  const modalTitle = useMemo(() => {
    let { title } = invoiceTypeData.find((v) => v.sign === type) || { title: '发票' };
    if (type === 'ps') {
      title = '农产品收购发票';
    }
    return title;
  }, [type]);
  const cancelModal = () => {
    dispatch({
      type: 'updateState',
      payload: { manualImportState: 'reset' },
    });
  };
  const resetModal = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: 'reset' } });
  };

  const saveModal = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: 'save' } });
  };

  const saveAndAdd = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: 'saveAndAdd' } });
  };

  useEffect(() => {
    cancelModal();
  }, [tabsKey]);

  return (
    <>
      <div styleName="manual-modal">
        <ManualForm modal={0} dateValue={dateValue} cancelModal={() => cancelModal} />
        <ManualTable modal={0} />
      </div>
      <div styleName="manual-modal-footer">
        <Button type="primary" ghost onClick={resetModal}>
          清空
        </Button>
        <Button type="primary" onClick={saveAndAdd}>
          保存
        </Button>
      </div>
    </>
  );
};
ManualContent.defaultProps = {
  type: '',
};
ManualContent.propTypes = {
  tabsKey: PropTypes.string.isRequired,
  dateValue: PropTypes.string.isRequired,
  type: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ manualImportData: { type } }) => ({
  type,
}))(ManualContent);
