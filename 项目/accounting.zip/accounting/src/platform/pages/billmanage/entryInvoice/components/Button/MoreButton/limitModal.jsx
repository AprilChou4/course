import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Form, Col, Radio, Checkbox } from 'antd';
import InputNumber from '@/NumberInput';

const FormItem = Form.Item;
const LimitModal = ({ limitSetting, onCancel, dispatch }) => {
  const { taxType, taxTypeValue, tlvMonths, tlvMonthsValue, tips } = limitSetting;
  const taxTypeChange = (e) => {
    const { value } = e.target;
    dispatch({
      type: 'updateState',
      payload: {
        limitSetting: {
          ...limitSetting,
          taxType: value,
          taxTypeValue: value === 1 ? '10' : '30',
        },
      },
    });
  };

  const taxTypeValueChange = (e) => {
    dispatch({
      type: 'updateState',
      payload: {
        limitSetting: {
          ...limitSetting,
          taxTypeValue: e,
        },
      },
    });
  };

  const twelveCheckChange = (e) => {
    const { checked } = e.target;
    dispatch({
      type: 'updateState',
      payload: {
        limitSetting: {
          ...limitSetting,
          tlvMonths: Number(checked),
          tlvMonthsValue: checked ? '500' : tlvMonthsValue,
        },
      },
    });
  };

  const twelveValueChange = (e) => {
    dispatch({
      type: 'updateState',
      payload: {
        limitSetting: {
          ...limitSetting,
          tlvMonthsValue: e,
        },
      },
    });
  };

  const tipsChange = (e) => {
    const { checked } = e.target;
    dispatch({
      type: 'updateState',
      payload: {
        limitSetting: {
          ...limitSetting,
          tips: Number(checked),
        },
      },
    });
  };

  const updateLimit = () => {
    dispatch({ type: 'updateVatInvoiceLimitSetting' });
    onCancel();
  };

  return (
    <Modal
      visible
      title="开票限额设置"
      onOk={updateLimit}
      onCancel={() => {
        onCancel();
      }}
    >
      <Form>
        <Col span={12}>
          <FormItem style={{ marginLeft: 100, marginBottom: 5 }}>
            <Radio.Group onChange={taxTypeChange} value={taxType}>
              <Radio value={1}>月</Radio>
              <Radio value={2}>季</Radio>
            </Radio.Group>
          </FormItem>
        </Col>
        <Col span={12}>
          <FormItem style={{ marginBottom: 5 }}>
            <InputNumber
              value={taxTypeValue}
              min={0}
              precision={2}
              style={{ width: 100, marginRight: 5 }}
              onChange={taxTypeValueChange}
            />
            万元
          </FormItem>
        </Col>
        <Col span={12}>
          <FormItem style={{ marginLeft: 100, marginBottom: 5 }}>
            <Checkbox onChange={twelveCheckChange} checked={tlvMonths === 1}>
              连续12个月
            </Checkbox>
          </FormItem>
        </Col>
        <Col span={12}>
          <FormItem style={{ marginBottom: 5 }}>
            <InputNumber
              value={tlvMonthsValue}
              min={0}
              precision={2}
              style={{ width: 100, marginRight: 5 }}
              onChange={twelveValueChange}
            />
            万元
          </FormItem>
        </Col>
        <Col span={24}>
          <FormItem style={{ marginLeft: 100, marginBottom: 0 }}>
            <Checkbox onChange={tipsChange} checked={tips === 1}>
              是否显示页面提醒
            </Checkbox>
          </FormItem>
        </Col>
      </Form>
    </Modal>
  );
};
LimitModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
  limitSetting: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default connect(({ limitSetting }) => ({ limitSetting }))(LimitModal);
