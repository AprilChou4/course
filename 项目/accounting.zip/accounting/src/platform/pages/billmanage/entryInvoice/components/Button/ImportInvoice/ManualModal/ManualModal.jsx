import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Button } from 'antd';
import ManualForm from './ManualForm';
import ManualTable from './ManualTable';
import { invoiceTypeData } from '../../../static';

const ManualModal = ({ manualImportVisible, type, dispatch }) => {
  const modalTitle = useMemo(() => {
    let { title } = invoiceTypeData.find((v) => v.sign === type) || { title: '发票' };
    if (type === 'ps') {
      title = '农产品收购发票';
    }
    return title;
  }, [type]);
  const cancelModal = () => {
    dispatch({
      type: 'updateState',
      payload: { manualImportVisible: false, manualImportState: 'reset' },
    });
  };
  const resetModal = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: 'reset' } });
  };

  const saveModal = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: 'save' } });
  };

  const saveAndAdd = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: 'saveAndAdd' } });
  };
  const modalProps = {
    width: 840,
    visible: true,
    title: modalTitle,
    bodyStyle: { padding: '24px 24px 0 0' },
    maskClosable: false,
    onCancel: cancelModal,
    footer: (
      <div>
        <Button type="primary" ghost onClick={resetModal}>
          清空数据
        </Button>
        <Button type="primary" onClick={saveModal}>
          保存
        </Button>
      </div>
    ),
  };
  return (
    <>
      {manualImportVisible && (
        <Modal {...modalProps}>
          <ManualForm modal={1} cancelModal={() => cancelModal} />
          <ManualTable modal={1} />
        </Modal>
      )}
    </>
  );
};
ManualModal.defaultProps = {
  type: '',
};
ManualModal.propTypes = {
  manualImportVisible: PropTypes.bool.isRequired,
  type: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ manualImportVisible, manualImportData: { type } }) => ({
  manualImportVisible,
  type,
}))(ManualModal);
