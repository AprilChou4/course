import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button } from 'antd';
import util from 'util';
import trackEvent from 'public/trackEvent';
import SuperModal from '@/modal/SuperModal';
import ImportModal from './Import';
import CheckImport from './CheckImport';
import AddInvoiceModal from './AddInvoiceModal';


const services = util.createRequest({
  getQuato: 'invoice/bill/getQuota',
});


const MoreButton = ({ isPeriodWrong, noPower, isCompanyType, companyId, dispatch, isAdmin,quotaData }) => {
  const [importVisible, setImportVisible] = useState(false);
  //const [addInvoiceModalVisible, setAddInvoiceModalVisible] = useState(false);
  //const [quotaData, setQuotaData] = useState(null);

  // 企业版检测可用额度
  const checkQuota = async () => {
    const res = await services.getQuato({ companyId, productType: 5 });
    // const res = {
    //   freeQuota: 0,
    //   paymentQuota: 1,
    //   totalPaymentQuota: 1
    // }
    const { freeQuota, paymentQuota, totalPaymentQuota } = res || {};

    // 没有额度时弹框提示
    // if (!freeQuota && !paymentQuota) {
    //   const title =
    //     !freeQuota && !totalPaymentQuota
    //       ? '您的50张免费额度已用完，如果觉得不错就请购买吧！'
    //       : '您的额度已用完，如需使用请联系客服人员购买！';

    //   SuperModal({
    //     content: <div style={{ height: 50, marginTop: 10 }}>{title}</div>,
    //     okText: '关闭',
    //     // hideOk: !isAdmin,
    //     // onOk: () => {
    //     //   // trackEvent('发票查验录入', '立即购买');
    //     //   // dispatch({ type: 'account/onBuy', payload: 5 });
    //     // },
    //   });

    //   return false;
    // }

    const usedNum = totalPaymentQuota - paymentQuota;
    return { usedNum, freeQuota, paymentQuota, totalPaymentQuota };
  };


  const onCheckImport = async () => {
    // 企业版检测
    if (isCompanyType) {
      const res = await checkQuota();
      if (!res) return;

      //setQuotaData(res);
      dispatch({ type: 'setState', payload: { quotaData: res }})
    }
    //setAddInvoiceModalVisible(true);
    dispatch({type: 'setState',payload: { addInvoiceModalVisible: true }})
  };

  const addInvoiceModalCancel = () => {
    //setAddInvoiceModalVisible(false);
    dispatch({type: 'setState',payload: { addInvoiceModalVisible: false }})
    dispatch({
      type: 'updateState',
      payload: {
        manualImportData: {
          details: [{}, {}, {}, {}, {}],
        },
      },
    });
  };

  return (
    <>
      <Button
        className="e-ml5"
        disabled={!isPeriodWrong || noPower === 1}
        onClick={onCheckImport}
        type="primary"
      >
        录入发票
      </Button>
      <AddInvoiceModal  onCancel={addInvoiceModalCancel} />

      {importVisible && <ImportModal onCancel={() => setImportVisible(false)} />}

      {/* {checkImportVisible && (
        <CheckImport quotaData={quotaData} onCancel={() => setCheckImportVisible(false)} />
      )} */}
    </>
  );
};
MoreButton.propTypes = {
  isPeriodWrong: PropTypes.bool.isRequired,
  noPower: PropTypes.oneOfType([PropTypes.number, PropTypes.bool]).isRequired,
  isCompanyType: PropTypes.bool.isRequired,
  companyId: PropTypes.string.isRequired,
  //dispatch: PropTypes.bool.isRequired,
  isAdmin: PropTypes.bool.isRequired,
};

export default connect(
  (
    { isPeriodWrong, noPower,quotaData },
    {
      account: {
        versionType,
        user: { companyId, roleName },
      },
    },
    
  ) => ({
    isPeriodWrong,
    noPower,
    isCompanyType: versionType === '2',
    companyId,
    isAdmin: roleName?.indexOf('管理员') !== -1,
    quotaData,
  }),
)(MoreButton);
