import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, message, Modal } from 'antd';
import ButtonGroup from '@/ButtonGroup';
import { ConfirmModal } from '@/modal';
import LimitModal from './limitModal';
import ColumnsDefine from './columnsDefine';
import MachineNoModal from './machineNoModal';
import '../../../css/index.less';

const MoreButton = ({
  invoiceType,
  noPower,
  isPeriodWrong,
  columnsDefine,
  selectedRows,
  showLimit,
  notPerfectInvoiceCount,
  dispatch,
}) => {
  const [limitVisible, setLimitVisible] = useState(false);
  const [columnsVisible, setColumnsVisible] = useState(false);
  const [machineNoVisible, setMachineNoVisible] = useState(false);
  const invoiceDelete = () => {
    if (selectedRows.length < 1) {
      message.warning('请选择要删除的发票');
      return;
    }
    const deleteIds = selectedRows.filter(
      (v) => v.invoiceId !== 'total' && ![1, 2].includes(v.source) && !v.voucherId,
    );
    if (deleteIds.length === 0) {
      message.error('系统自动提取的发票不允许删除！');
      return;
    }
    ConfirmModal({
      width: 265,
      title: '删除后不可恢复，确定删除所选发票？',
      className: 'ywy-no-close-btn',
      onOk: () => {
        dispatch({
          type: 'deleteInvoice',
          payload: {
            ids: selectedRows
              .filter((v) => v.invoiceId !== 'total')
              .map((v) => v.invoiceId)
              .join(','),
            allIds: selectedRows.filter((v) => v.invoiceId !== 'total'),
            deleteIds,
          },
        });
      },
    });
  };
  const invoiceClear = () => {
    ConfirmModal({
      width: 265,
      title: '确定清空所有手动新增的发票？',
      className: 'ywy-no-close-btn',
      onOk: () => {
        dispatch({ type: 'delManualEntryInvoice' });
      },
    });
  };
  const getDetails = () => {
    const noTotalRows = selectedRows.filter((v) => v.invoiceId !== 'total'); // 排除总计
    const noTRows = selectedRows.filter((v) => v.type !== 't'); // 排除通行费
    if (noTotalRows.length < 1) {
      message.warning('请选择需要获取明细的发票');
      return;
    }
    if (noTotalRows.length === 1 && noTRows.length === 0) {
      dispatch({
        type: 'updateState',
        payload: {
          checkCodeProps: {
            checkCode: noTotalRows[0].checkCode,
            invoiceId: noTotalRows[0].invoiceId,
            checkCodeVisible: true,
          },
        },
      });
      return;
    }
    dispatch({
      type: 'batchFpcyEntryInvoiceList',
      payload: {
        invoiceIds: noTotalRows.map((v) => v.invoiceId),
      },
    });
  };
  const downloadTool = () => {
    // eslint-disable-next-line
    location.href = 'http://v.jss.com.cn/cszs/进销项提取工具.exe';
  };
  const expireAuthState = () => {
    ConfirmModal({
      title: '解除授权关系以后，将不能自动同步发票数据，确认解除？',
      onOk: () =>
        dispatch({
          type: 'expireAuthState',
        }),
    });
  };
  return (
    <>
      <ButtonGroup space={5} className="newGuide9" count={1}>
        {isPeriodWrong && <Button onClick={invoiceDelete}>批量删除</Button>}
        {isPeriodWrong && <Button onClick={invoiceClear}>清空手动新增发票</Button>}
        <Button
          style={
            sessionStorage.getItem('guideoption') === '9'
              ? { backgroundColor: '#008cff', color: '#fff' }
              : {}
          }
          onClick={() => {
            setColumnsVisible(true);
          }}
        >
          自定义显示列
        </Button>
        {notPerfectInvoiceCount > 0 && isPeriodWrong && (
          <Button onClick={getDetails}>获取明细</Button>
        )}
        {showLimit && (
          <Button
            onClick={() => {
              setLimitVisible(true);
            }}
          >
            开票限额
          </Button>
        )}
        {invoiceType === 'vat' && isPeriodWrong && (
          <Button
            onClick={() => {
              const rows = selectedRows.filter(
                (v) => v.macNoSource !== 0 && !v.voucherId && v.invoiceId !== 'total',
              );
              if (rows.length > 0) {
                setMachineNoVisible(true);
              } else if (selectedRows.length < 1) {
                message.warning('请选择需要补充开票机号的发票');
              } else {
                message.warning('您勾选的发票已有分机号，请选择其他需要补充开票机号的发票');
              }
            }}
          >
            编辑开票机号
          </Button>
        )}
        <Button onClick={downloadTool}>工具下载</Button>
        {!noPower && <Button onClick={expireAuthState}>解除授权</Button>}
      </ButtonGroup>
      {limitVisible && (
        <LimitModal
          onCancel={() => {
            setLimitVisible(false);
          }}
        />
      )}
      {columnsVisible && (
        <ColumnsDefine
          dataSource={columnsDefine}
          onCancel={() => {
            setColumnsVisible(false);
          }}
        />
      )}
      {machineNoVisible && (
        <MachineNoModal
          onCancel={() => {
            setMachineNoVisible(false);
          }}
        />
      )}
    </>
  );
};
MoreButton.defaultProps = {
  invoiceType: '',
  notPerfectInvoiceCount: 0,
};
MoreButton.propTypes = {
  invoiceType: PropTypes.string,
  noPower: PropTypes.oneOfType([PropTypes.bool, PropTypes.number]).isRequired,
  columnsDefine: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  showLimit: PropTypes.bool.isRequired,
  isPeriodWrong: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
  notPerfectInvoiceCount: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};
export default connect(
  ({
    invoiceType,
    noPower,
    isPeriodWrong,
    columnsDefine,
    selectedRows,
    dataSourceOriginal: { notPerfectInvoiceCount },
  }) => ({
    invoiceType,
    noPower,
    isPeriodWrong,
    columnsDefine,
    selectedRows,
    notPerfectInvoiceCount,
  }),
)(MoreButton);
