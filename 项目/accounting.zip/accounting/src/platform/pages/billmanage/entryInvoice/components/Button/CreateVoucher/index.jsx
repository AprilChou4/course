import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Icon, Popover, message, Modal } from 'antd';
import { ConfirmModal } from '@/modal';
import VoucherPopover from './createVoucherPopover';
import VoucherForm from './voucherForm';
import '../../../css/createVoucher.less';

const ButtonGroup = Button.Group;
class CreateVoucherButton extends PureComponent {
  constructor() {
    super();
    this.state = {
      popoverVisible: false,
    };
  }

  popoverVisibleChange(visible) {
    this.setState({ popoverVisible: visible });
  }

  updateVoucherBuildSetting() {
    const { dispatch, voucherBuildSetting } = this.props;
    const { buildSummary, customizeSummary } = voucherBuildSetting;
    if (!buildSummary) {
      message.error('摘要组合不能为空');
      return;
    }
    if (buildSummary.includes('6')) {
      if (!customizeSummary) {
        message.error('自定义摘要不能为空');
        return;
      }
    }
    dispatch({
      type: 'updateVoucherBuildSetting',
      payload: {
        success: this.popoverVisibleChange.bind(this, false),
      },
    });
  }

  CreateVoucher() {
    const { invoiceType, selectedRows = [], endDate, dispatch } = this.props;
    const hasNoAuth = selectedRows.some((v) => Number(v.invoiceState) === 5);
    const invoiceIdList = selectedRows
      .filter((v) => v.invoiceId !== 'total')
      .map((v) => v.invoiceId);
    if (invoiceIdList.length < 1) {
      message.error('请选择要生成凭证的发票');
      return;
    }
    if (invoiceIdList.length > 50) {
      ConfirmModal({
        title: '温馨提示',
        content: (
          <div>
            <p style={{ lineHeight: '24px' }}>
              当前您选中了{invoiceIdList.length}
              条数据生成凭证，大批量生成将会造成数据压力，耗时较久。
            </p>
            <p>建议您取消当前操作，重新选择50条数据以内生成，无需漫长等待</p>
          </div>
        ),
        width: 600,
        className: 'create-voucher-validate',
        okText: '继续生成',
        cancelText: '取消',
        onOk: () => {
          dispatch({
            type: 'prepareVoucher',
            payload: {
              invoiceType: invoiceType === 'vat' ? 0 : 1,
              invoiceIdList,
              accountPeriod: Number(endDate.split('-').join('')),
              hasNoAuth,
            },
          });
        },
      });
    } else {
      dispatch({
        type: 'prepareVoucher',
        payload: {
          invoiceType: invoiceType === 'vat' ? 0 : 1,
          invoiceIdList,
          accountPeriod: Number(endDate.split('-').join('')),
          hasNoAuth,
        },
      });
    }
  }

  render() {
    const { popoverVisible } = this.state;
    const { className, isPeriodWrong } = this.props;
    return (
      <div className="create-voucher-btn">
        {isPeriodWrong ? (
          <ButtonGroup className={className}>
            <Popover placement="bottomRight" content={<VoucherPopover />}>
              <Button
                type="primary"
                className="no-right-border"
                ghost
                onClick={() => {
                  this.CreateVoucher();
                }}
              >
                生成凭证
              </Button>
            </Popover>
            <span className="button-group-center">|</span>
            <Button
              type="primary"
              className="no-left-border"
              ghost
              onClick={() => this.popoverVisibleChange(true)}
            >
              <Icon type="setting" />
            </Button>
          </ButtonGroup>
        ) : (
          <ButtonGroup className={className}>
            <Button type="primary" className="no-right-border" ghost disabled>
              生成凭证
            </Button>
            <span className="button-group-center disabled">|</span>
            <Button type="primary" className="no-left-border" ghost disabled>
              <Icon type="setting" />
            </Button>
          </ButtonGroup>
        )}

        <Modal
          visible={popoverVisible}
          title="生成凭证设置"
          width={755}
          centered
          maskClosable={false}
          className="create-voucher-setting-popover"
          onCancel={() => this.popoverVisibleChange(false)}
          footer={
            <>
              <Button
                type="primary"
                ghost
                disabled={!isPeriodWrong}
                onClick={() => {
                  this.popoverVisibleChange(false);
                }}
              >
                取消
              </Button>
              <Button
                type="primary"
                onClick={() => {
                  this.updateVoucherBuildSetting();
                }}
              >
                确定
              </Button>
            </>
          }
        >
          <VoucherForm
            hide={() => {
              this.popoverVisibleChange(false);
            }}
          />
        </Modal>
      </div>
    );
  }
}
CreateVoucherButton.defaultProps = {
  invoiceType: '',
};
CreateVoucherButton.propTypes = {
  className: PropTypes.string.isRequired,
  invoiceType: PropTypes.string,
  isPeriodWrong: PropTypes.bool.isRequired,
  voucherBuildSetting: PropTypes.objectOf(PropTypes.any).isRequired,
  selectedRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  endDate: PropTypes.string.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(
  ({ invoiceType, isPeriodWrong, voucherBuildSetting, selectedRows, query: { endDate } }) => ({
    invoiceType,
    isPeriodWrong,
    voucherBuildSetting,
    selectedRows,
    endDate,
  }),
)(CreateVoucherButton);
