import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Input } from 'antd';

const FormItem = Form.Item;

const PopoverContent = ({ form, onBlur, initValue, disabled }) => {
  useEffect(() => {
    form.setFieldsValue({ machineNo: initValue });
  }, [initValue]);
  const valueBlur = () => {
    const value = form.getFieldValue('machineNo');
    initValue !== value && onBlur(value);
  };
  return (
    <Form>
      <FormItem>
        {form.getFieldDecorator('machineNo', {
          initialValue: initValue,
          normalize: (val) => {
            return val.replace(/[^\d]/gi, '').slice(0, 10);
          },
        })(<Input onBlur={valueBlur} style={{ padding: 4 }} disabled={disabled} />)}
      </FormItem>
    </Form>
  );
};
PopoverContent.defaultProps = {
  initValue: '',
  disabled: false,
};
PopoverContent.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  onBlur: PropTypes.func.isRequired,
  disabled: PropTypes.bool,
  initValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};
export default Form.create()(PopoverContent);
