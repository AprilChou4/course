import React from 'react';
import PropTypes from 'prop-types';
import { Form, Input } from 'antd';
import { create } from 'layer';

const FormItem = Form.Item;
const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};
const TaxNum = ({ form }) => {
  return (
    <>
      <div
        className="ui-empower-div"
        style={{ paddingLeft: 110, paddingTop: 10, paddingBottom: 5, color: '#f5a623' }}
      >
        系统检测到您尚未维护税号，请填写企业税号
      </div>
      <Form {...formItemLayout}>
        <FormItem label="企业税号" colon>
          {form.getFieldDecorator('value', {
            rules: [
              {
                validator(rule, value, callback) {
                  if (value === '') {
                    callback('请填写税号信息');
                  } else if (!/^[0-9A-Za-z]{15,20}$/.test(value)) {
                    callback('税号为15至20位数字或字母组合');
                  } else {
                    callback();
                  }
                },
              },
            ],
            normalize: (val) => {
              return val ? val.slice(0, 20) : '';
            },
          })(<Input placeholder="请填写税号" style={{ width: 300 }} />)}
        </FormItem>
      </Form>
    </>
  );
};
TaxNum.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default Form.create()(create(TaxNum));
