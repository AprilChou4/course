import React, { useState, useRef, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import util from 'util';
import { Button, Modal, Icon, message } from 'antd';
import Upload from '@/Upload';
import { ConfirmModal } from '@/modal';
import img from '../../../images/upload.png';
import '../../../css/import.less';


const services = util.createRequest({
  getQuato: 'invoice/bill/getQuota',
});


// 下载错误记录
const downLoadFailExcel = 'jz/accounting/invoice/import/downLoadFailExcel';
// 进项excel导入
const importEntryExcelInvoice = 'jz/accounting/invoice/import/importEntryExcelInvoice';
// 发票查验导入
const importFpcyExcelInvoice = 'jz/accounting/invoice/import/importFpcyExcelInvoice';
// 通用模板发票导入
const importInvoice = 'jz/accounting/invoice/import/importInvoice';

const getUploadUrl = (invoiceType, importMethod) => {
  if (invoiceType === 'vat' && importMethod === 0) {
    return importInvoice;
  }
  if (importMethod === 1) {
    return importFpcyExcelInvoice;
  }
  if (invoiceType !== 'vat' && importMethod === 0) {
    return importEntryExcelInvoice;
  }
  if (importMethod === 2) {
    return importInvoice;
  }
  return '';
};

const getUploadParams = (invoiceType, importMethod, dateValue) => {
  const [year, month] = dateValue.split('-');
  if (invoiceType === 'vat' && importMethod === 0) {
    return {
      year,
      month,
      type: 0, // 销项
    };
  }
  if (importMethod === 1) {
    return {
      accountPeriod: Number(`${year}${month}`),
      invoiceType: Number(invoiceType !== 'vat'),
    };
  }
  if (invoiceType !== 'vat' && importMethod === 0) {
    return {
      accountPeriod: Number(`${year}${month}`),
    };
  }
  if (invoiceType !== 'vat' && importMethod === 2) {
    return {
      year,
      month,
      type: 1, // 进项
    };
  }
  return {};
};

const ImportButton = ({ invoiceType, importMethod, dateValue, dispatch, tabsKey, isCompanyType, companyId }) => {
  const [fileName, setFileName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [error, setError] = useState(false);
  const [importResult, setImportResult] = useState(false);
  const [failCountState, setFailCountState] = useState(0);
  const [failKeyState, setFailKeyState] = useState('');
  const [successCountState, setSuccessCountState] = useState(0);

  const downErrorType = useRef(0);
  const uploadRef = useRef();

  const deleteFile = useCallback(() => {
    uploadRef.current.clearInput();
    setFileName('');
  }, [uploadRef]);

  const hideImport = useCallback(() => {
    setErrorMsg('');
    setError(false);
    deleteFile();
  }, [setErrorMsg, deleteFile]);
  useEffect(() => {
    hideImport();
  }, [importMethod, hideImport, tabsKey]);

  const CheckQuota = async () => {
    const res = await services.getQuato({ companyId, productType: 5 });
    const { freeQuota, paymentQuota, totalPaymentQuota } = res || {};
    const usedNum = totalPaymentQuota - paymentQuota;
    const resultData = { usedNum, freeQuota, paymentQuota, totalPaymentQuota };
    dispatch({ type: 'setState', payload: { quotaData: resultData } })
  }

  const uploadChange = (e) => {
    const { value } = e.currentTarget;
    const selectFileName = value.split('\\').pop();
    setFileName(selectFileName);
    const files = e.target.files[0];
    if (files) {
      if (!files.name.includes('.xlsx') && !files.name.includes('.xls')) {
        setError(true);
        setErrorMsg(
          <p>
            <i className="iconfont icon-tanhao" />
            文件格式错误，请检查后重新上传
          </p>,
        );
        return false;
      }
      if (files.size > 10 * 1024 * 1024) {
        setError(true);
        setErrorMsg(
          <p>
            <i className="iconfont icon-tanhao" />
            文件过大，请将文件大小控制在10M内
          </p>,
        );
        return false;
      }
      if (files.size < 0) {
        setError(true);
        setErrorMsg(
          <p>
            <i className="iconfont icon-tanhao" />
            导入文件有误，请下载模板编辑后重新导入
          </p>,
        );
        return false;
      }
    }
    setError(false);
    return true;
  };

  const uploadSubmit = () => {
    dispatch({
      type: 'account/_updateLoading',
      payload: {
        loading: true,
      },
    });
    uploadRef.current.upload();
  };

  const onDownError = () => {
    util.submit(
      `${downLoadFailExcel}`,
      { importType: downErrorType.current, failKey: failKeyState },
      '_blank',
      'download',
    );
  };

  const importResultCallback = (data) => {
    const { failCount, failKey, successCount } = data;
    setImportResult(true);
    setFailCountState(failCount);
    setFailKeyState(failKey);
    setSuccessCountState(successCount);
  };

  // 进项excel导入结果回调
  const entryExcelInvoiceCallback = (res) => {
    const { data = {} } = res;
    importResultCallback(data);
    downErrorType.current = 0;
    dispatch({ type: '$getList' });
  };

  // 发票查验导入结果回调
  const fpcyExcelInvoiceCallback = (res) => {
    const { data = {} } = res;
    importResultCallback(data);
    downErrorType.current = 1;

    dispatch({ type: '$getList' });
  };

  // 销项发票导入
  const VATInvoiceCallback = (res) => {
    const { data = {} } = res;
    const { errorLine = [], existsInvoiceNumber, successCount } = data;
    if (errorLine.length > 0 || existsInvoiceNumber) {
      Modal.warning({
        content: (
          <div style={{ maxHeight: 350, overflow: 'auto' }}>
            {errorLine.length > 0 &&
              errorLine.map((v, index) => (
                // eslint-disable-next-line react/no-array-index-key
                <p key={index}>
                  {v.errorLine.map((h) => `第${h}行`).join('、')},{v.msg}
                </p>
              ))}
            {existsInvoiceNumber && (
              <p>
                {existsInvoiceNumber}发票已存在，其余{successCount}条发票导入成功！
              </p>
            )}
          </div>
        ),
        onOk: () => {
          dispatch({ type: '$getList' });
        },
      });
    } else {
      message.success('导入成功');
      dispatch({ type: '$getList' });
    }
  };

  const uploadCallback = (res) => {
    if ((invoiceType === 'vat' && importMethod === 0) || importMethod === 2) {
      VATInvoiceCallback(res);
    }
    if (importMethod === 1) {
      fpcyExcelInvoiceCallback(res);
    }
    if (invoiceType !== 'vat' && importMethod === 0) {
      entryExcelInvoiceCallback(res);
    }
  };

  const uploadEnd = (res) => {
    dispatch({
      type: 'account/_updateLoading',
      payload: {
        loading: false,
      },
    });
    if (fileName) {
      if (res) {
        if (res.status === '200') {
          uploadCallback(res);
          hideImport();

          // 企业版检测
          if (isCompanyType) {
            CheckQuota();
          }
        }
      }
    }
  };

  const onDownTemplate = () => {
    let type; // 票据类型 1：查验导入模板，2：进项excel模板，3：销项excel模板
    if (importMethod === 1) {
      type = 1;
    } else if (importMethod === 2) {
      type = 2;
    } else if (invoiceType === 'vat' && importMethod === 0) {
      type = 3;
    }

    util.submit('jz/accounting/invoice/import/uploadTemplate.do', { type }, '_blank', 'download');
  };

  const url = getUploadUrl(invoiceType, importMethod);
  const params = getUploadParams(invoiceType, importMethod, dateValue);
  const uploadProps = {
    url,
    params,
    onChange: uploadChange,
    onEnd: uploadEnd,
    onError: (res) => {
      const { message: msg, status, data } = res || {};
      if (status === '201') {
        ConfirmModal({
          title: `${res.message}`,
          centered: true,
          width: 380,
          okText: '录入',
          cancelText: '不录入',
          onOk: async () => {
            const [year, month] = dateValue.split('-');
            const result = await dispatch({
              type: 'confirmImportExcelInvoice',
              payload: {
                accountPeriod: Number(`${year}${month}`),
                dataKey: data,
                invoiceType: Number(invoiceType !== 'vat'),
              },
            });
            importResultCallback(result);
            downErrorType.current = 1;
            hideImport();
            // 企业版检测
            if (isCompanyType) {
              CheckQuota();
            }
          },
        });
      } else {
        setErrorMsg(msg);
        deleteFile();
      }
    },
    autoUpload: false,
    accept: '.xlsx,.xls',
  };

  const handleCancel = () => {
    setImportResult(false);
  };

  return (
    <>
      <div className="e-mt10" style={{ border: '1px solid #E2E2E2' }}>
        <div styleName="upload-area" style={{ display: !fileName ? 'block' : 'none' }}>
          {(errorMsg || error) && (
            <p styleName="error-message">
              <Icon type="exclamation-circle" theme="filled" />
              {errorMsg}
            </p>
          )}
          <Upload {...uploadProps} ref={uploadRef}>
            <div styleName={!errorMsg && !error ? 'upload-btn' : 'upload-error-button'}>
              {!errorMsg && !error && <img src={img} alt="上传" />}
              <div>
                {!errorMsg && !error ? (
                  <Button type="primary">点我上传</Button>
                ) : (
                    <Button type="primary" ghost>
                      重新上传
                    </Button>
                  )}
              </div>
            </div>
          </Upload>
          <div styleName="upload-font">
            {importMethod === 0 && invoiceType !== 'vat' && (
              <>
                <div styleName="upload-info">
                  1.从“增值税发票综合服务平台”，下载抵扣发票明细Excel
                </div>
                <div styleName="upload-info">2.直接导入该Excel，不可修改</div>
              </>
            )}
            {((importMethod === 0 && invoiceType === 'vat') || importMethod === 2) && (
              <>
                <div styleName="upload-info">
                  1.使用模板导入，
                  <span styleName="download-template" onClick={onDownTemplate}>
                    点击下载模板
                  </span>
                </div>
                <div styleName="upload-info">2.文件大小不超过10M，且不要对模板进行修改</div>
              </>
            )}
            {importMethod === 1 && (
              <>
                <div styleName="upload-info">
                  1.使用模板导入，
                  <span styleName="download-template" onClick={onDownTemplate}>
                    点击下载模板
                  </span>
                </div>
                <div styleName="upload-info">
                  2.一次最多导入200张发票，且不要对模板的格式进行修改
                </div>
              </>
            )}
          </div>
        </div>
        <div styleName="upload-area" style={{ display: !fileName ? 'none' : 'block' }}>
          <p styleName="file-area">
            <Icon type="file-excel" />
            {fileName}
            <Icon type="close" onClick={deleteFile} />
          </p>
        </div>
      </div>
      <div style={{ textAlign: 'center', marginTop: '18px' }}>
        <Button disabled={!fileName} className="e-ml10" type="primary" onClick={uploadSubmit}>
          导入
        </Button>
      </div>
      <Modal
        width={320}
        title="导入结果"
        visible={importResult}
        footer={null}
        destroyOnClose
        maskClosable={false}
        onCancel={handleCancel}
        wrapClassName="invoice-import-result"
      >
        <div style={{ textAlign: 'center', marginBottom: '10px' }}>
          <Icon
            type="check-circle"
            style={{
              color: '#12D265',
              fontSize: '16px',
              verticalAlign: 'textBottom',
              marginRight: '12px',
            }}
            theme="filled"
          />
          <span style={{ color: '#323232' }}>导入完成</span>
        </div>
        <div>
          <p style={{ marginLeft: '80px' }} className="e-mt20">
            导入成功：{successCountState}条
          </p>
          <p style={{ marginTop: '4px', marginLeft: '80px' }}>
            导入失败：{failCountState}条
            {failCountState !== 0 && (
              <span className="e-ml10" styleName="download-template" onClick={onDownError}>
                点击下载
              </span>
            )}
          </p>
        </div>
      </Modal>
    </>
  );
};
ImportButton.defaultProps = {
  invoiceType: '',
  dateValue: '',
};
ImportButton.propTypes = {
  tabsKey: PropTypes.string.isRequired,
  invoiceType: PropTypes.string,
  dateValue: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
  importMethod: PropTypes.number.isRequired,
};
export default connect(({ invoiceType }, { account: { versionType, user: { companyId } } }) => ({
  invoiceType,
  isCompanyType: versionType === '2',
  companyId
}))(ImportButton);
