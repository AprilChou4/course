import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect, withNuomi } from 'nuomi';
import { Checkbox, Col, Input, Radio, Select } from 'antd';
import '../../../css/voucherForm.less';

const { Option } = Select;
const VoucherForm = ({
  invoiceType,
  leafSubject,
  allSubject,
  endDate,
  currentTime,
  voucherBuildSetting,
  dispatch,
}) => {
  const {
    buildSummary,
    customizeSummary,
    isSaveSpec,
    buildTaxSubjectId,
    buildMode,
    isAmtMerge,
    isAmtTaxMerge,
    isTaxMerge,
    buildLineSort,
    buildVoucherDate,
    buildCsTaxRate,
  } = voucherBuildSetting;
  const [buildVoucherDate1 = '', buildVoucherDate2 = ''] = (buildVoucherDate || '0,0').split(',');
  const [maxHeight, setMaxHeight] = useState(0);

  useEffect(() => {
    const handleFunc = () => {
      setMaxHeight(window.innerHeight - 105);
    };
    handleFunc();
    window.addEventListener('resize', () => handleFunc());
    return window.removeEventListener('resize', () => handleFunc());
  }, []);

  const buildSummaryChange = (list) => {
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildSummary: list.join(','),
      },
    });
  };

  const customizeSummaryChange = (e) => {
    const { value } = e.target;
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        customizeSummary: value.substring(0, 100),
      },
    });
  };

  const isSaveSpecChange = (e) => {
    const { value } = e.target;
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        isSaveSpec: value,
      },
    });
  };

  const buildTaxSubjectIdChange = (option) => {
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildTaxSubjectId: option,
      },
    });
  };

  const buildModeChange = (e) => {
    const { value } = e.target;
    if (value === 2) {
      dispatch({
        type: 'setVoucherBuildSetting',
        payload: {
          buildVoucherDate: `${'0'},${'0'}`,
        },
      });
    }
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildMode: value,
      },
    });
  };

  const mergeChange = (list) => {
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        isAmtMerge: list.includes('isAmtMerge') ? 1 : 0,
        isAmtTaxMerge: list.includes('isAmtTaxMerge') ? 1 : 0,
        isTaxMerge: list.includes('isTaxMerge') ? 1 : 0,
      },
    });
  };

  const buildLineSortChange = (e) => {
    const { value } = e.target;
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildLineSort: value,
      },
    });
  };

  const buildVoucherDate1Change = (e) => {
    const { value } = e.target;
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildVoucherDate: `${value},${buildVoucherDate2}`,
      },
    });
  };

  const buildVoucherDate2Change = (e) => {
    const { value } = e.target;
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildVoucherDate: `${buildVoucherDate1},${value}`,
      },
    });
  };

  const buildCsTaxRateChange = (e) => {
    let { value } = e.target;
    value = value.replace(/\D/g, '');
    if (value < 0 || value > 100) {
      return;
    }
    dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildCsTaxRate: value,
      },
    });
  };

  return (
    <div styleName="voucher-form" style={{ maxHeight, overflow: 'auto' }}>
      <div styleName="voucher-item abstract">
        <p>摘要组合</p>
        <Checkbox.Group
          style={{ width: '100%' }}
          onChange={buildSummaryChange}
          value={buildSummary.split(',')}
        >
          <Col span={4}>
            <Checkbox value="1">发票号码</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="2">开票日期</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="3">发票内容</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="4">客商信息</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="5">价税合计</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="7">发票类型</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="8">发票备注</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="9">凭证模板名称</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="10">凭证模板摘要</Checkbox>
          </Col>
          <Col span={4}>
            <Checkbox value="6">自定义摘要</Checkbox>
          </Col>
          <Col span={8}>
            {buildSummary.includes('6') && (
              <Input
                placeholder="请输入自定义摘要"
                value={customizeSummary}
                onChange={customizeSummaryChange}
              />
            )}
          </Col>
        </Checkbox.Group>
      </div>
      <div styleName="voucher-item">
        <p>存货设置</p>
        <Radio.Group onChange={isSaveSpecChange} value={isSaveSpec}>
          <Col span={8}>
            <Radio value={1}>规格型号系统带出</Radio>
          </Col>
          <Col span={8}>
            <Radio value={0}>规格型号系统不带出</Radio>
          </Col>
        </Radio.Group>
      </div>
      {invoiceType !== 'vat' && (
        <div styleName="voucher-item pb12">
          <p>科目设置</p>
          <span styleName="special-span">指定未认证发票税费科目</span>
          <Select
            style={{ width: 300 }}
            value={buildTaxSubjectId}
            onChange={buildTaxSubjectIdChange}
            showSearch
            allowClear
            filterOption={(input, option) => option.props.children.includes(input)}
          >
            {leafSubject.map((v) => (
              <Option value={v.subjectId} key={v.subjectId}>
                {`${v.subjectCode} ${v.fullName}`}
              </Option>
            ))}
            {[1].map(() => {
              let OptItem = null;
              if (buildTaxSubjectId) {
                const leafObj = leafSubject.find((obj) => obj.subjectId === buildTaxSubjectId);
                if (!leafObj) {
                  const allObj = allSubject.find((obj) => obj.subjectId === buildTaxSubjectId);
                  if (allObj) {
                    OptItem = (
                      <Option value={allObj.subjectId} key={allObj.subjectId}>
                        {`${allObj.subjectCode} ${allObj.subjectName}`}
                      </Option>
                    );
                  }
                }
              }
              return OptItem;
            })}
          </Select>
        </div>
      )}
      <div styleName="voucher-item">
        <p>凭证生成方式</p>
        <Radio.Group onChange={buildModeChange} value={buildMode}>
          <Col span={8}>
            <Radio value={1}>每张发票生成一张凭证</Radio>
          </Col>
          <Col span={8}>
            <Radio value={2} disabled={buildVoucherDate1 === '1'}>
              所有发票生成一张凭证
            </Radio>
          </Col>
          <Col span={8}>
            <Radio value={3} disabled={buildVoucherDate1 === '1'}>
              相同单位生成一张凭证
            </Radio>
          </Col>
          <Col span={8}>
            <Radio value={4}>相同日期生成一张凭证</Radio>
          </Col>
          <Col span={8}>
            <Radio value={5}>同单位同日期生成一张凭证</Radio>
          </Col>
        </Radio.Group>
      </div>
      <div styleName="voucher-item">
        <p>分录显示顺序</p>
        <Radio.Group onChange={buildLineSortChange} value={buildLineSort}>
          <Col span={8}>
            <Radio value={1}>先借后贷</Radio>
          </Col>
          <Col span={8}>
            <Radio value={2}>一借一贷</Radio>
          </Col>
        </Radio.Group>
      </div>
      <div styleName="voucher-item">
        <p>相同科目分录汇总</p>
        <Checkbox.Group
          style={{ width: '100%' }}
          onChange={mergeChange}
          value={[
            isAmtMerge ? 'isAmtMerge' : '',
            isAmtTaxMerge ? 'isAmtTaxMerge' : '',
            isTaxMerge ? 'isTaxMerge' : '',
          ]}
        >
          <Col span={8}>
            <Checkbox value="isAmtMerge">金额科目汇总</Checkbox>
          </Col>
          <Col span={8}>
            <Checkbox value="isTaxMerge">税额科目汇总</Checkbox>
          </Col>
          <Col span={8}>
            <Checkbox value="isAmtTaxMerge">价税合计科目汇总</Checkbox>
          </Col>
        </Checkbox.Group>
      </div>
      <div styleName="voucher-item">
        <p>凭证日期设置</p>
        <div>发票日期在当月：</div>
        <Radio.Group onChange={buildVoucherDate1Change} value={buildVoucherDate1}>
          <Col span={8}>
            <Radio value="0">当月最后一天</Radio>
          </Col>
          <Col span={8}>
            <Radio value="1" disabled={[2, 3].includes(buildMode)}>
              发票日期
            </Radio>
          </Col>
          <Col span={8}>
            <Radio value="2" disabled={!currentTime.includes(endDate) || buildMode === 2}>
              系统当前日期
            </Radio>
          </Col>
        </Radio.Group>
        {invoiceType !== 'vat' && <div>发票日期不在当月：</div>}
        {invoiceType !== 'vat' && (
          <Radio.Group onChange={buildVoucherDate2Change} value={buildVoucherDate2}>
            <Col span={8}>
              <Radio value="0">当月最后一天</Radio>
            </Col>
            <Col span={8}>
              <Radio value="2" disabled={!currentTime.includes(endDate) || buildMode === 2}>
                系统当前日期
              </Radio>
            </Col>
          </Radio.Group>
        )}
      </div>
      {invoiceType !== 'vat' && (
        <div styleName="voucher-item">
          <p>收购发票抵扣税率设置</p>
          <div style={{ lineHeight: '32px' }}>
            收购发票抵扣税率：
            <Input
              value={buildCsTaxRate}
              addonAfter="%"
              style={{ width: 100 }}
              onChange={buildCsTaxRateChange}
            />
          </div>
        </div>
      )}
    </div>
  );
};
VoucherForm.defaultProps = {
  invoiceType: '',
  endDate: '',
  currentTime: '',
};
VoucherForm.propTypes = {
  invoiceType: PropTypes.string,
  leafSubject: PropTypes.arrayOf(PropTypes.object).isRequired,
  allSubject: PropTypes.arrayOf(PropTypes.object).isRequired,
  voucherBuildSetting: PropTypes.objectOf(PropTypes.any).isRequired,
  endDate: PropTypes.string,
  currentTime: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect(
  (
    { invoiceType, leafSubject, allSubject, voucherBuildSetting, query: { endDate } },
    {
      account: {
        user: { currentTime },
      },
    },
  ) => ({
    invoiceType,
    leafSubject,
    allSubject,
    voucherBuildSetting,
    endDate,
    currentTime,
  }),
)(withNuomi(VoucherForm));
