// eslint-disable-next-line
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Table, Button } from 'antd';
import { DragDropContext, DragSource, DropTarget } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import update from 'immutability-helper';
import '../../../css/columnsDefine.less';

let dragingIndex = -1;

class BodyRow extends PureComponent {
  render() {
    // eslint-disable-next-line
    const { isOver, connectDragSource, connectDropTarget, moveRow, ...restProps } = this.props;
    const style = { ...restProps.style, cursor: 'move' };

    let { className } = restProps;
    if (isOver) {
      if (restProps.index > dragingIndex) {
        className += ' drop-over-downward';
      }
      if (restProps.index < dragingIndex) {
        className += ' drop-over-upward';
      }
    }

    return connectDragSource(
      connectDropTarget(<tr {...restProps} className={className} style={style} />),
    );
  }
}

const rowSource = {
  beginDrag(props) {
    dragingIndex = props.index;
    return {
      index: props.index,
    };
  },
};

const rowTarget = {
  drop(props, monitor) {
    const dragIndex = monitor.getItem().index;
    const hoverIndex = props.index;

    // Don't replace items with themselves
    if (dragIndex === hoverIndex) {
      return;
    }

    // Time to actually perform the action
    props.moveRow(dragIndex, hoverIndex);

    // Note: we're mutating the monitor item here!
    // Generally it's better to avoid mutations,
    // but it's good here for the sake of performance
    // to avoid expensive index searches.
    // eslint-disable-next-line
    monitor.getItem().index = hoverIndex;
  },
};

const DragableBodyRow = DropTarget('row', rowTarget, (connected, monitor) => ({
  connectDropTarget: connected.dropTarget(),
  isOver: monitor.isOver(),
}))(
  DragSource('row', rowSource, (connected) => ({
    connectDragSource: connected.dragSource(),
  }))(BodyRow),
);

const columns = [
  {
    title: '序号',
    dataIndex: 'index',
    key: 'index',
    width: 60,
    render: (val, row, index) => {
      return <span>{`${index < 9 ? '0' : ''}${index + 1}`}</span>;
    },
  },
  {
    title: '字段名称',
    dataIndex: 'columnName',
    key: 'columnName',
  },
];

// eslint-disable-next-line
class ColumnsDefine extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      selectedRowKeys: [],
    };
    this.components = {
      body: {
        row: DragableBodyRow,
      },
    };
  }

  componentDidMount() {
    const { dataSource = [] } = this.props;
    this.setState({
      data: dataSource,
      selectedRowKeys: dataSource.filter((v) => v.isShow).map((v) => v.columnField),
    });
  }

  onSaveColumns() {
    const { data } = this.state;
    const { invoiceType, onCancel, dispatch } = this.props;
    dispatch({
      type: 'updCustomerAuxCols',
      payload: {
        columnsDefine: data.map((v, i) => ({
          ...v,
          showSort: i + 1,
          module: invoiceType === 'vat' ? 2 : 1,
        })),
      },
    });
    onCancel();
  }

  onResetDefault() {
    const { onCancel, dispatch } = this.props;
    dispatch({
      type: 'restoreDefaultCustomerCols',
    });
    onCancel();
  }

  onSelectChange(selectedRowKeys) {
    const { data } = this.state;
    this.setState({
      selectedRowKeys,
      data: data.map((v) => ({
        ...v,
        isShow: selectedRowKeys.includes(v.columnField),
      })),
    });
  }

  moveRow = (dragIndex, hoverIndex) => {
    const { state } = this;
    const { data } = state;
    const dragRow = data[dragIndex];

    this.setState(
      update(state, {
        data: {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragRow],
          ],
        },
      }),
    );
  };

  render() {
    const { onCancel } = this.props;
    const { data, selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      columnWidth: 60,
      onChange: (selectedRowKeysArg) => {
        this.onSelectChange(selectedRowKeysArg);
      },
      getCheckboxProps: (record) => ({
        disabled: ['invoiceNumber'].includes(record.columnField),
      }),
    };
    return (
      <Modal
        visible
        title="显示列设置"
        footer={null}
        onCancel={onCancel}
        maskClosable={false}
        bodyStyle={{ paddingTop: 12 }}
      >
        <div styleName="tips">温馨提示：取消勾选可隐藏字段，鼠标拖动可调整顺序</div>
        <Table
          className="table-columns-define"
          columns={columns}
          dataSource={data}
          rowSelection={rowSelection}
          rowKey="columnField"
          components={this.components}
          pagination={false}
          bordered
          scroll={{ y: 359 }}
          onRow={(record, index) => ({
            index,
            moveRow: this.moveRow,
          })}
        />
        <div styleName="bottom-btn">
          <Button onClick={onCancel}>取消</Button>
          <Button className="e-ml10" onClick={() => this.onResetDefault()}>
            恢复默认
          </Button>
          <Button className="e-ml10" type="primary" onClick={() => this.onSaveColumns()}>
            保存
          </Button>
        </div>
      </Modal>
    );
  }
}
ColumnsDefine.defaultProps = {
  invoiceType: '',
};
ColumnsDefine.propTypes = {
  invoiceType: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.any).isRequired,
};
export default connect(({ invoiceType }) => ({ invoiceType }))(
  DragDropContext(HTML5Backend)(ColumnsDefine),
);
