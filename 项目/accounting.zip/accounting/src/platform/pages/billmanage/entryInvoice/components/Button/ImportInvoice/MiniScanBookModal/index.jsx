/**
 * 核对总账
 */
import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Table } from 'antd';
import './style.less';
import Icon from '@/Icon';
import services from '../../../../services';
import TableCell from '@/TableCell';

const MiniScanBookModal = forwardRef(
  (
    { dispatch, isShowMiniResModal, scanMiniInvoiceData, wxQRCodeData, dateValue, invoiceType },
    ref,
  ) => {
    const [tabValue, setTabValue] = useState('1');
    const [showDialog, setShowDialog] = useState(false);
    const [connectStatus, setConnectStatus] = useState(false);
    const toFixed2 = (text) => (text ? text.toFixed(2) : text);
    const columns = [
      {
        title: '发票类型',
        width: 80,
        dataIndex: 'type',
        render: (text) => <TableCell>{text}</TableCell>,
        align: 'center',
      },
      {
        title: '发票号码',
        width: 80,
        dataIndex: 'invoiceNumber',
        render: (text) => <TableCell>{text}</TableCell>,
        align: 'center',
      },
      {
        title: '开票日期',
        width: 80,
        dataIndex: 'date',
        render: (text) => <TableCell>{text}</TableCell>,
        align: 'center',
      },
      {
        title: '金额',
        width: 80,
        dataIndex: 'amt',
        align: 'center',
        render: (text) => <TableCell>{toFixed2(text)}</TableCell>
      },
      {
        title: '税额',
        width: 80,
        dataIndex: 'tax',
        align: 'center',
        render: (text) => <TableCell>{toFixed2(text)}</TableCell>
      },
      {
        title: '价税合计',
        width: 80,
        dataIndex: 'taxTotal',
        align: 'center',
        render: (text) => <TableCell>{toFixed2(text)}</TableCell>
      },
      {
        title: '状态',
        width: 80,
        dataIndex: 'enterStatus',
        align: 'center',
        render: (val) => {
          const statusMap = { 0: '已录入', 1: '未录入', 2: '禁止录入' };
          return <span>{statusMap[val]}</span>;
        },
      },
      {
        title: '说明',
        width: 110,
        dataIndex: 'errorMsg',
        align: 'center',
        render: (text) => <TableCell><span styleName="red-errorMsg">{text}</span></TableCell>
      },
      {
        title: '操作',
        dataIndex: 'operation',
        width: 80,
        align: 'center',
        render: (value, row, index) => {
          console.log(value, row, index);
          return (
            <>
              {row.enterStatus === 1 && (
                <a styleName="operation-icon" onClick={changeType.bind(this, row, index)}>
                  录入
                </a>
              )}
            </>
          );
        },
      },
    ];
    let timer = null;
    const cleanTimerFun = () => {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
    };
    const changeType = async (rowData) => {
      await services.wxContinueCommit({
        invoiceCode: rowData.invoiceCode,
        invoiceNumber: rowData.invoiceNumber,
        invoiceType: invoiceType === 'vat' ? 0 : 1,
        period: rowData.period,
        tid: rowData.tid,
        content: wxQRCodeData.content,
      });

      // 录入成功或者失败刷新一下数据
      const resNew = await services.queryWxEnterResult({ content: wxQRCodeData.content });
      setConnectStatus(resNew.connect);
      if (resNew.list) {
        dispatch({ type: 'setState', payload: { scanMiniInvoiceData: resNew.list } });
      }
    };

    const showDialogFun = async () => { //内部的弹窗开启
      const res = await services.wxGetQRCode({ invoiceType: invoiceType === 'vat' ? 0 : 1, period: dateValue });
      await dispatch({ type: 'setState', payload: { wxQRCodeData: res } });
      setShowDialog(true);
      smallTabStatus(res);
    };

    const changeTabStatus = async (resData) => { //发票表格连接状态控制
      console.log("changeTabStatus")
      const res = await services.queryWxEnterResult({ content: resData.content },{
        status:{
          '^300':(data)=> {
            dispatch({ type: 'setState', payload: { isShowMiniResModal: false } });
            cleanTimerFun();
          }
        }
      });
      setConnectStatus(res.connect);
      cleanTimerFun();
      if (res.list && res.list.length > 0) {
        dispatch({ type: 'setState', payload: { scanMiniInvoiceData: res.list } });
      }
      if (res.connect) {
        // 如果状态是连接的
        timer = setTimeout(function () {
          changeTabStatus(resData);
        }, 5000);
      }
    }

    const parentTabStatus = async () => {
      console.log("parentTabStatus")
      cleanTimerFun();
      const res = await services.queryWxEnterResult({ content: wxQRCodeData.content },{
          status:{
            '^300':(data)=> {
              dispatch({ type: 'setState', payload: { isShowMiniResModal: false } });
              cleanTimerFun();
            }
          }
      });
      if (res.connect) {
        setConnectStatus(res.connect);
        setTabValue('2');
        dispatch({
          type: 'setState',
          payload: { scanMiniInvoiceData: res.list, addInvoiceModalVisible: false },
        });
        changeTabStatus(wxQRCodeData);
      } else {
        timer = setTimeout(function () {
          parentTabStatus();
        }, 5000);
      }
    }

    const smallTabStatus = async (resData) => { //小弹窗的状态请求
      console.log("smallTabStatus")
      cleanTimerFun();
      const res = await services.queryWxEnterResult({ content: resData.content },{
        status:{
          '^300':(data)=> {
            setShowDialog(false);
            cleanTimerFun();
          }
        }
      });
      if (res.connect) {
        setConnectStatus(res.connect);
        setShowDialog(false);
        dispatch({ type: 'setState', payload: { scanMiniInvoiceData: res.list } });
        changeTabStatus(resData);
      } else {
        timer = setTimeout(function () {
          smallTabStatus(resData);
        }, 5000);
      }
    }



    // 传递参数去父组件
    useImperativeHandle(
      ref,
      () => ({
        parentTabStatus,
      }),
      [parentTabStatus],
    );

    useEffect(() => {
      return () => {
        cleanTimerFun();
      };
    }, []);

    return isShowMiniResModal ? (
      <>
        {tabValue === '1' ? (
          <Modal
            width={440}
            title="微信扫码录入"
            visible
            maskClosable={false}
            footer={false}
            className="scan-table-popup"
            onCancel={() => {
              dispatch({ type: 'setState', payload: { isShowMiniResModal: false } });
              cleanTimerFun();
            }}
          >
            <div styleName="qrcode-main">
              <img styleName="qrcode" src={wxQRCodeData.url} />
              <div styleName="qrcode-content">使用微信扫描上方二维码，链接账套</div>
            </div>
          </Modal>
        ) : null}
        {tabValue === '2' ? (
          <Modal
            width={840}
            title={
              <>
                <span styleName="mini-title">微信小程序录入</span>
                <span styleName="mini-title-text">
                  会计区间: <span styleName="mini-title-text-span">{dateValue}</span>
                </span>
                {connectStatus ? (
                  <span styleName="mini-title-right">
                    <Icon type="yilianjie" styleName="mini-icon" />
                    已连接
                  </span>
                ) : (
                    <span styleName="mini-title-right red">
                      <Icon type="weilianjie" styleName="mini-icon red" />
                    未连接
                    </span>
                  )}
              </>
            }
            visible
            maskClosable={false}
            footer={false}
            className="scan-table-popup"
            onCancel={async () => {
              cleanTimerFun();
              dispatch({ type: 'setState', payload: { isShowMiniResModal: false } });
              setTabValue('1');
              if(scanMiniInvoiceData&&scanMiniInvoiceData.length > 0) {
                dispatch({ type: 'initData'});
              }
              await services.clearWxEnterInvoiceCache({
                content: wxQRCodeData.content,
              });
            }}
          >
            <div>
              {!connectStatus ? (
                <div styleName="unconnect-main">
                  <div>
                    已断开连接，
                    <span styleName="unconnect-span" onClick={showDialogFun}>
                      扫码重新连接
                    </span>
                  </div>
                </div>
              ) : null}
              <div styleName="scan-table-content" className="scan-table-content">
                <Table
                  dataSource={scanMiniInvoiceData || []}
                  pagination={false}
                  columns={columns}
                  size="middle"
                  styleName="table"
                  bordered
                  rowKey={(record, i) => record.itemName || i}
                  scroll={{ y: 320 }}
                  locale={{
                    emptyText: (
                      <div style={{ height: '260px', paddingTop: '50px' }}>
                        <span>
                          {connectStatus ? (
                            <Icon type="yilianjie" styleName="big-icon" />
                          ) : (
                              <Icon type="weilianjie" styleName="big-icon red" />
                            )}
                          {connectStatus ? '已连接，请扫描发票左上角二维码，开始录入' : '未连接'}
                        </span>
                      </div>
                    ),
                  }}
                />
              </div>
            </div>
          </Modal>
        ) : null}
        {showDialog === true ? (
          <Modal
            width={440}
            title="微信扫码录入"
            visible
            maskClosable={false}
            footer={false}
            className="scan-table-popup"
            onCancel={() => {
              cleanTimerFun();
              setShowDialog(false);
            }}
          >
            <div styleName="qrcode-main">
              <img styleName="qrcode" src={wxQRCodeData.url} />
              <div styleName="qrcode-content">使用微信扫描上方二维码，链接账套</div>
            </div>
          </Modal>
        ) : null}
      </>
    ) : null;
  },
);

MiniScanBookModal.propTypes = {
  dispatch: PropTypes.func.isRequired,
  isShowMiniResModal: PropTypes.bool.isRequired,
  // scanMiniInvoiceData: PropTypes.arrayOf(PropTypes.object).isRequired,
  wxQRCodeData: PropTypes.object.isRequired,
};

export default connect((state) => state, null, null, { withRef: true })(MiniScanBookModal);
