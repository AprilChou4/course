import { BaseEffects } from 'effects';
import { message } from 'antd';
import { backupCheck } from '@/BackUp';
import { ConfirmModal } from '@/modal';
import TemplateMemorySelection from '@/TemplateMemorySelection';
import Modal from '@/TemplateOperation/components/Modal';
import { superLayer } from '../../../../public/layer';
import services from '../services';

export default class voucher extends BaseEffects {
  // 获取存货辅助核算
  async getStockAuxiliaryList() {
    const data = await services.getStockAuxiliaryList();
    this.updateState({
      stockAuxiliaryList: data,
    });
  }

  // 存货新增相关
  async getAuxTypeIdByType() {
    const { addStockProps } = this.getState();
    if (!addStockProps.auxiliaryTypeId) {
      const data = await services.getAuxTypeIdByType({ type: 4 }); // 4为存货
      await this.updateState({
        addStockProps: {
          ...addStockProps,
          auxiliaryTypeId: data,
        },
      });
    }
    await this.generateCode();
    await this.getStdClassifies();
  }

  async generateCode() {
    const { addStockProps } = this.getState();
    const { auxiliaryTypeId } = addStockProps;
    const data = await services.generateCode({ auxTypeId: auxiliaryTypeId, autoExpand: false });
    this.updateState({
      addStockProps: {
        ...addStockProps,
        auxiliaryCode: data,
      },
    });
  }

  async getStdClassifies() {
    const data = await services.getStdClassifies();
    this.updateState({
      stockTypeList: data.map((v) => ({ ...v, key: v.value, title: v.name })),
    });
  }

  // addAuxiliary = async (state) => {
  //   const data = await services.addAuxiliary(state);
  //   return data;
  // };

  async matchStockAuxiliary(state) {
    const { success, details } = state;
    const { auxiliaryVoucherObject } = this.getState();
    const data = await services.matchStockAuxiliary({ details });
    const { userHandleList = [] } = data;
    if (userHandleList.length === 0) {
      await this.createInvoiceVoucher({ userHandleResult: [] });
      return;
    }
    success(userHandleList);
    await this.updateState({
      auxiliaryVoucherObject: {
        ...auxiliaryVoucherObject,
        userHandleList,
      },
    });
    await this.getStockAuxiliaryList();
  }

  // 发票明细展示
  queryInvoiceByCodeAndNumber = async (state) => {
    const { invoiceIds, success } = state;
    const data = await services.queryInvoiceByCodeAndNumber({ invoiceIds });
    success(data);
  };

  // 模版记忆
  getSettings = async (query) => {
    const { invoiceType, isTransform } = this.getState();
    const settingsData = await services.getSettings(query);
    if (settingsData.isNeedMemory) {
      TemplateMemorySelection(
        {
          ...settingsData,
          ...{
            type: settingsData.alertCount <= 1 && settingsData.invoiceType ? '3' : '1',
            Income: true,
            category: invoiceType !== 'vat' ? '1' : '0', // 1=进项，0=销项
          },
        },
        async () => {
          if (!isTransform) {
            await this.$getList('keepSelects');
          } else {
            await this.queryTransferOutList();
          }
        },
      );
    }
  };

  // 修改凭证模版
  async batchUpdateTemplate(state) {
    const { invoiceType, isTransform } = this.getState();
    await services.batchUpdateTemplate({ ...state });
    message.success('修改模板成功');

    await this.getSettings({
      invoiceIds: state.invoiceIdList,
      templateId: state.templateId,
      type: invoiceType === 'vat' ? '0' : '1',
    });

    if (!isTransform) {
      await this.$getList('keepSelects');
    } else {
      await this.queryTransferOutList();
    }
  }

  async batchAddAuxiliary(state) {
    const { invoiceType } = this.getState();
    const { userHandleResult, customerAuxiliaryRequest, supplierAuxiliaryRequest, cb } = state;
    await services.batchAddAuxiliary(
      {
        aliasSource: invoiceType === 'vat' ? '2' : '1',
        userHandleResult,
        customerAuxiliaryRequest,
        supplierAuxiliaryRequest,
        autoExpand: false,
      },
      {
        status: {
          '^300': (data) => {
            message.error(data.message);
          },
          30000010025: () => {
            ConfirmModal({
              title: '新增失败',
              content: '编码长度已到达上限，可在账套设置中增加长度位数后重试。',
              okText: '立即增加',
              cancelText: '再想想',
              centered: true,
              width: 319,
              className: 'modal-without-close',
              onOk: async () => {
                backupCheck({}, async (fig) => {
                  if (fig !== false) {
                    await services.batchAddAuxiliary({
                      userHandleResult,
                      autoExpand: true,
                      aliasSource: invoiceType === 'vat' ? '2' : '1',
                    });
                    if (cb) {
                      cb();
                    } else {
                      await this.createInvoiceVoucher(state);
                    }
                  }
                });
              },
              onCancel: () => {},
            });
          },
        },
        loading: true,
      },
    );
    if (cb) {
      cb();
    } else {
      this.createInvoiceVoucher(state);
    }
  }

  async prepareVoucher(pState) {
    const { invoiceType } = this.getState();
    if (invoiceType === 'vat') {
      this.prepareRedInvoiceVoucher(pState);
    } else {
      this.checkTaxNumber(pState);
    }
  }

  async prepareRedInvoiceVoucher(pState) {
    const { invoiceIdList, accountPeriod } = pState;
    const data = await services.prepareRedInvoiceVoucher({ invoiceIdList, accountPeriod });
    const { redInvoices } = data;
    if (redInvoices && redInvoices.length > 0) {
      this.updateState({
        createVoucherCondition: pState,
        isShowRedInvoiceCheck: true,
        redInvoices,
      });
    } else {
      this.prepareVoucherCommon(pState);
    }
  }

  async createRedInvoiceVoucher(state) {
    const { list, filterList } = state;
    const {
      query: { endDate },
      createVoucherCondition,
    } = this.getState();
    const { invoiceIdList } = createVoucherCondition;
    await services.createRedInvoiceVoucher({
      accountPeriod: endDate.split('-').join(''),
      list,
    });
    if (filterList.length !== invoiceIdList.length) {
      this.prepareVoucherCommon({
        ...createVoucherCondition,
        invoiceIdList: invoiceIdList.filter((v) => !filterList.includes(v)),
      });
    } else {
      await this.$getList('noReset');
    }
  }

  async checkTaxNumber(pState) {
    const { hasNoAuth, invoiceIdList, ...state } = pState;
    try {
      await services.checkTaxNumber(
        { ...state, invoiceIdList },
        { loading: true, status: { '201': null } },
      );
      this.prepareVoucherCommon(pState);
    } catch (e) {
      if (e.status === '201') {
        ConfirmModal({
          title: '提示',
          content:
            invoiceIdList.length > 1
              ? '有购方税号与账套税号不同的发票，是否继续生成凭证？'
              : '该发票税号与账套税号不同，是否继续生成凭证？',
          okText: '继续',
          onOk: () => this.prepareVoucherCommon(pState),
        });
      }
    }
  }

  // 生成凭证预处理
  async prepareVoucherCommon(pState) {
    const { hasNoAuth, ...state } = pState;
    // const { voucherBuildSetting, invoiceType } = this.getState();
    // if (hasNoAuth) {
    //   const { buildTaxSubjectId } = voucherBuildSetting;
    //   if (!buildTaxSubjectId && invoiceType !== 'vat') {
    //     this.updateState({
    //       buildTaxSubjectIdModalVisible: true,
    //       prepareVoucherCondition: state,
    //     });
    //     return;
    //   }
    // }
    const data = await services.prepareVoucher({ ...state }, { loading: true });
    const { stockAuxiliaryMatchResponse, redInvoices = [] } = data;
    this.dispatch({
      type: 'updateState',
      payload: {
        createVoucherCondition: state,
        auxiliaryVoucherObject: stockAuxiliaryMatchResponse,
        prepareData: data,
      },
    }).then(() => {
      if (redInvoices.length > 0) {
        this.updateState({
          isShowRedInvoiceCheck: true,
          redInvoices,
        });
      } else {
        this.prepareOperation();
      }
    });
  }

  prepareOperation(type) {
    const { prepareData } = this.getState();
    const {
      reciprocalSubjectResponse = [],
      supplierAuxiliaryResponse = {},
      customerAuxiliaryResponse = {},
    } = prepareData;

    if (
      type !== 'auxiliaryNext' &&
      (supplierAuxiliaryResponse.auxiliaryNames || customerAuxiliaryResponse.auxiliaryNames)
    ) {
      this.updateState({
        isShowCreateAuxiliary: true,
        supplierAuxiliaryResponse,
        customerAuxiliaryResponse,
      });
      return;
    }
    if (reciprocalSubjectResponse.length > 0) {
      this.updateState({
        secondSubjectModalVisible: true,
        secondSubjectData: reciprocalSubjectResponse,
      });
      return;
    }
    this.prepareCreate();
  }

  // 预处理执行结果
  async prepareCreate() {
    const {
      createVoucherCondition: state,
      auxiliaryVoucherObject: stockAuxiliaryMatchResponse,
    } = this.getState();
    const { invoiceIdList } = state;
    if (
      stockAuxiliaryMatchResponse &&
      stockAuxiliaryMatchResponse.userHandleList &&
      stockAuxiliaryMatchResponse.userHandleList.length > 0
    ) {
      await this.getStockAuxiliaryList();
      await this.updateState({
        isAuxiliary: true,
        auxiliaryVoucherObject: {
          ...stockAuxiliaryMatchResponse,
          allMatchCount:
            Number(stockAuxiliaryMatchResponse.matchCount) +
            Number(stockAuxiliaryMatchResponse.notMatchCount),
        },
      });
      return;
    }
    await this.createInvoiceVoucher({ userHandleResult: [], invoiceIdList });
  }

  // 生成凭证
  async createInvoiceVoucher(state) {
    const { userHandleResult, invoiceIdList } = state;
    const { createVoucherCondition, isTransform } = this.getState();
    const { flag } = createVoucherCondition;
    const data = await services.createVoucher(
      {
        ...createVoucherCondition,
        userHandleResult,
      },
      { loading: true },
    );
    await this.updateState({
      isAuxiliary: false,
    });
    if (data.length > 0) {
      await this.createLayer(data, invoiceIdList);
      return;
    }
    if (flag === 1) {
      await this.query();
    } else if (!isTransform) {
      await this.$getList('noReset');
    } else {
      await this.queryTransferOutList();
    }
  }

  async createLayer(list) {
    const that = this;
    const { createVoucherCondition, isTransform } = this.getState();
    const { flag } = createVoucherCondition;
    let isSave = false;
    superLayer('voucher/record', {
      data: {
        title: '生成凭证',
        // fields: { invoiceIdList },
        isBillManage: true,
      },
      renderData() {
        return list.map((item) => ({
          ...item,
          isInitSerialize: false,
        }));
      },
      onSave() {
        // 保存
        isSave = true;
      },
      async onDestroy() {
        // 回调
        if (isSave) {
          if (flag === 1) {
            await this.query();
          } else if (!isTransform) {
            await that.$getList('noReset');
          } else {
            await that.queryTransferOutList();
          }
        }
      },
    });
  }

  /* 新增存货核算 start */

  // 获取单位列表
  async getUnitList(state = {}) {
    const { isOtherTab, type, ...params } = state;
    const { unitType, dataSource, tabValue } = this.getState();
    const useType = isOtherTab ? type : Number(unitType);
    if (useType === 1) {
      params.needLines = 1;
    }
    const data = await services.getUnitList({ ...params, type: useType });
    console.log(useType);
    this.setState({
      unitListDataSource: tabValue !== '7' ? dataSource : data,
      ...(useType === 1 ? { unitGroupList: data } : { unitList: data }),
    });
  }

  // 查询所有的存货别名
  async getStockAlias() {
    const data = await services.getStockAlias();
    this.setState({
      stockAliasDataSource: data,
    });
  }

  // 存货接口
  async openStockModal({ type, params }) {
    const { unitList = [], stockAliasDataSource = [], auxiliarySetting = [] } = this.getState();
    const getAuxiliarySetting =
      auxiliarySetting.length > 0 ? auxiliarySetting : await services.getAuxiliaryTypes();

    unitList.length === 0 && (await this.getUnitList({ isOtherTab: true, type: 0 }));

    await this.getUnitList({ isOtherTab: true, type: 1, needLines: 1 });
    stockAliasDataSource.length === 0 && (await this.getStockAlias());

    const item = getAuxiliarySetting.find((v) => v.auxiliaryTypeName === '存货');

    const code = await services.generateCode({
      autoExpand: false,
      auxTypeId: item.auxiliaryTypeId,
    });

    await this.setState({
      auxiliarySetting: getAuxiliarySetting,
      stockConfigure: {
        visible: true,
        type,
        formData: {
          ...params,
          auxiliaryCode: code,
        },
      },
    });
  }

  // 新增存货
  async getCategory() {
    const { categorySourceList = {} } = this.getState();
    const onData = categorySourceList.stockConfigure;

    const addSet = {};
    this.openStockModal({ type: 'add' });

    if (onData && onData.length > 0) {
      this.setState({
        categorySource: onData,
        ...addSet,
      });
      return;
    }
    const data = await services.getCategory({ type: '3' }, { loading: true });

    this.setState({
      isSimplify: true,
      isShowCategory: false,
      categorySource: data,
      categorySourceList: {
        ...categorySourceList,
        stockConfigure: data,
      },
      ...addSet,
    });
  }

  // 添加辅助核算
  async addAuxiliary(state) {
    const { callback, ...rest } = state;
    const { auxiliarySetting } = this.getState();
    const archiveCategoryName = '存货';

    const item = auxiliarySetting.find((v) => v.auxiliaryTypeName === archiveCategoryName);
    await services.addAuxiliary(
      {
        ...rest,
        auxiliaryTypeId: item.auxiliaryTypeId,
        autoExpand: false,
      },
      { loading: true },
    );
    callback && callback();
    await this.getStockAuxiliaryList();
  }

  // 添加计量单位
  async addUnit(state) {
    const { success, ...params } = state;
    const { unitType } = this.getState();
    await services.addUnit({ ...params, type: Number(unitType) });

    message.success('新增成功');
    success && success();
    this.getUnitList();
  }

  async updateUnit(state) {
    const { success, ...params } = state;
    const { unitType } = this.getState();
    await services.updateUnit({ ...params, type: Number(unitType) });
    success && success();
    this.getUnitList();
  }
  /* 新增存货核算 end */
}
