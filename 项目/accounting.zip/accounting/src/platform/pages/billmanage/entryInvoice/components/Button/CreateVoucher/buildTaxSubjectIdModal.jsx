import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Form, Select, Icon, Modal, Button, message } from 'antd';

const { Option } = Select;
const FormItem = Form.Item;
const formItemLayout = {
  labelCol: {
    sm: { span: 10 },
  },
  wrapperCol: {
    sm: { span: 14 },
  },
};
const BuildTaxSubjectIdTip = ({ leafSubject, prepareVoucherCondition, dispatch }) => {
  const [value, setValue] = useState('');

  const valueChange = (option) => {
    setValue(option);
  };

  const hideModal = () => {
    dispatch({
      type: 'updateState',
      payload: {
        buildTaxSubjectIdModalVisible: false,
      },
    });
  };

  const sureModal = async () => {
    if (!value) {
      message.error('请选择未认证发票税费科目');
      return;
    }
    await dispatch({
      type: 'setVoucherBuildSetting',
      payload: {
        buildTaxSubjectId: value,
      },
    });
    await dispatch({
      type: 'updateVoucherBuildSetting',
      payload: {
        success: hideModal,
      },
    });
    await dispatch({
      type: 'prepareVoucher',
      payload: {
        ...prepareVoucherCondition,
      },
    });
  };
  return (
    <Modal visible title="系统设置" footer={null} onCancel={hideModal}>
      <Form {...formItemLayout}>
        <FormItem label="未认证发票税费科目指定" colon style={{ marginTop: 20 }}>
          <Select
            placeholder="请填写税号"
            style={{ width: 260 }}
            value={value}
            onChange={valueChange}
            showSearch
            filterOption={(input, option) => option.props.children.includes(input)}
          >
            {leafSubject.map((v) => (
              <Option value={v.subjectId} key={v.subjectId}>
                {`${v.subjectCode} ${v.subjectName}`}
              </Option>
            ))}
          </Select>
        </FormItem>
      </Form>
      <div
        className="ui-empower-div"
        style={{ textAlign: 'center', paddingBottom: 5, color: '#f5a623' }}
      >
        <Icon type="exclamation-circle" theme="filled" style={{ marginRight: 5 }} />
        提示：请选择未认证发票，未认证税额的入账科目
      </div>
      <div style={{ textAlign: 'center' }}>
        <Button style={{ width: 80, marginRight: 5 }} type="primary" ghost onClick={hideModal}>
          取消
        </Button>
        <Button style={{ width: 80 }} type="primary" onClick={sureModal}>
          确定
        </Button>
      </div>
    </Modal>
  );
};
BuildTaxSubjectIdTip.propTypes = {
  leafSubject: PropTypes.arrayOf(PropTypes.object).isRequired,
  prepareVoucherCondition: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ leafSubject, prepareVoucherCondition }) => ({
  leafSubject,
  prepareVoucherCondition,
}))(BuildTaxSubjectIdTip);
