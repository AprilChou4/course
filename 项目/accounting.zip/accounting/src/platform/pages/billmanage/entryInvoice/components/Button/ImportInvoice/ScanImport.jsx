import React, { useState, useRef, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Modal, Icon, message,Input } from 'antd';
import './scanImport.less';
import ScanBookModal from './ScanBookModal';

const ScanImport = ({dispatch}) => {
  const showDialog = () => {
    dispatch({type: 'scanBookInit'})
  }
  
  return (
    <>
      <div className="e-mt10" styleName="scan-import-container">
        <div styleName="scan-import-content">
          <div className="scan-import-form">
            <Input placeholder="扫码过程中，请保持光标聚集在输入框" styleName="scan-input" onClick={showDialog}/>
            <div styleName="scan-info">请确认扫描设备已链接到我的电脑</div>
          </div>
        </div>
      </div>
      <ScanBookModal/>
    </>
  );
};
ScanImport.defaultProps = {
};
ScanImport.propTypes = {
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ }) => ({
}))(ScanImport);
