import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Icon, Button } from 'antd';
import Ico from '@/Icon';
import './fpcyMessage.less';

const FpcyMessage = ({ isShowFpcyModal, failCount, successCount, list, dispatch }) => {
  const [isShow, setIsShow] = useState(false);
  const cancelModal = () => {
    dispatch({
      type: 'updateState',
      payload: {
        isShowFpcyModal: false,
      },
    });
    dispatch({
      type: '$getList',
      payload: 'noReset',
    });
  };

  const modalProps = {
    visible: isShowFpcyModal,
    title: '获取明细结果',
    className: 'fpcy-message',
    onCancel: cancelModal,
    zIndex: 200001,
    footer: (
      <div>
        <Button type="primary" onClick={cancelModal}>
          知道了
        </Button>
      </div>
    ),
  };
  return (
    <Modal {...modalProps}>
      <div>
        <div className="fpcy-info">
          <Icon type="exclamation-circle" theme="filled" />
          成功获取{successCount}条明细，<span className="special-color">{failCount}</span>条获取失败
        </div>
        {isShow ? (
          <div className="message-area">
            <div>
              失败原因
              <span className="click-area fr" onClick={() => setIsShow(false)}>
                收起
                <Ico type="up2" />
              </span>
            </div>
            <div style={{ marginTop: 12 }}>
              {list.map((v) => (
                <div key={v.message}>
                  <p>{`以下发票，${v.message}：`}</p>
                  {v.invoiceCode.map((h) => (
                    <p key={h}>{h}</p>
                  ))}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="close-area" onClick={() => setIsShow(true)}>
            失败原因
            <span className="click-area fr">
              展开
              <Ico type="down2" />
            </span>
          </div>
        )}
      </div>
    </Modal>
  );
};
FpcyMessage.propTypes = {
  failCount: PropTypes.number.isRequired,
  successCount: PropTypes.number.isRequired,
  list: PropTypes.arrayOf(PropTypes.any).isRequired,
  isShowFpcyModal: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ isShowFpcyModal, progressArgs: { failCount, successCount, list } }) => ({
  isShowFpcyModal,
  failCount,
  successCount,
  list,
}))(FpcyMessage);
