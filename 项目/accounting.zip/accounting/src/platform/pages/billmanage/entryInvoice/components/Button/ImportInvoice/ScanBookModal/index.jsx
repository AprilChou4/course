/**
 * 核对总账
 */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Table } from 'antd';
import  { ConfirmModal } from '@/modal';
import './style.less';

const ScanBookModal = ({ dispatch, isShowScanResModal, scanInvoiceData }) => {
  const [accountInterval, setAccountInterval] = useState("2020-06");
  const toFixed2 = (text) => (text ? text.toFixed(2) : text);
  const changeType = (rowData) => {
    ConfirmModal({
      title: '发票购方名称或税号与企业不一致，是否继续录入？',
      width: '380',
      okText: '录入',
      cancelText: '不录入',
      centered: true,
      onOk: () => {
      },
    });
  }
  const columns = [
    {
      title: '发票类型',
      width: 80,
      dataIndex: 'typeName',
      align: 'center',
    },
    {
      title: '发票号码',
      width: 80,
      dataIndex: 'invoiceNumber',
      align: 'center',
    },
    {
      title: '开票日期',
      width: 80,
      dataIndex: 'date',
      align: 'center',
    },
    {
      title: '金额',
      width: 80,
      dataIndex: 'amt',
      align: 'center',
    },
    {
      title: '税额',
      width: 80,
      dataIndex: 'tax',
      align: 'center',
    },
    {
      title: '价税合计',
      width: 80,
      dataIndex: 'taxTotal',
      align: 'center',
    },
    {
      title: '状态',
      width: 80,
      dataIndex: 'state',
      align: 'center',
    },
    {
      title: '说明',
      width: 110,
      dataIndex: 'errorMsg',
      align: 'center',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      width: 80,
      align: 'center',
      render: (value, row, index) => {
        return (
          <a className="opertation-icon" onClick={changeType.bind(this, row, index)}>
            录入
          </a>
        );
      },
    },
  ];

  return isShowScanResModal ? (
    <Modal
      width={840}
      title={`扫码录入 会计区间：${accountInterval}`}
      visible
      maskClosable={false}
      footer={false}
      className="scan-table-popup"
      onCancel={() => {
        dispatch({ type: 'setState', payload: { isShowScanResModal: false } });
      }}
    >
      <div styleName="scan-table-content">
        <Table
          dataSource={scanInvoiceData || []}
          pagination={false}
          columns={columns}
          size="middle"
          styleName="table"
          bordered
          rowKey={(record, i) => record.itemName || i}
        />
      </div>
    </Modal>
  ) : null;
};

ScanBookModal.propTypes = {
  dispatch: PropTypes.func.isRequired,
  isShowScanResModal: PropTypes.bool.isRequired,
  scanInvoiceData: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default connect()(ScanBookModal);
