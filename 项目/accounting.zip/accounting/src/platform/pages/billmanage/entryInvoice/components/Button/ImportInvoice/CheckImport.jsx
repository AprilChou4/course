import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import moment from 'moment';
import { Form, Input, DatePicker, Button } from 'antd';
import InputNumber from '@/NumberInput';
import './checkImport.less';
import util from 'util';

const services = util.createRequest({
  getQuato: 'invoice/bill/getQuota',
});

const formWrap = {
  wrapperCol: { span: 16 },
  labelCol: { span: 8 },
};

const placeholderObj = {
  校验码后六位: '校验码后六位(普)',
  不含税金额: '不含税金额(专)',
  不含税价: '不含税价(机动车)',
  车价合计: '车价合计(二手车)',
};

/**
 * 普通发票，规则：
 *  符合发票代码规则的10位发票代码，第8位为3、6时, label: 不含税金额
 *  12位，1位==0，末尾为['04','05','06','07','11','12'] label: 不含税金额
 *
 * 默认专票，专票规则
 *  12位代码，8位==2，1位==1，机动车发票，label: 不含税价
 *  12位代码，1位==0，11==1，12==7， 二手车发票，label: 车价合计
 */
const getLabel = (invoiceCode = '') => {
  const len = invoiceCode?.length;
  const index1 = invoiceCode[0];

  const isPlain =
    len === 12 &&
    index1 === '0' &&
    ['04', '05', '06', '07', '11', '12'].includes(invoiceCode.substr(10));

  if ((len === 10 && ['3', '6'].includes(invoiceCode[7])) || isPlain) {
    return '校验码后六位';
  }

  // 专票以下
  if (len === 12) {
    if (invoiceCode[0] === '1' && invoiceCode[7] === '2') {
      return '不含税价';
    }
    if (invoiceCode[0] === '0' && invoiceCode[10] === '1' && invoiceCode[11] === '7') {
      return '车价合计';
    }
  }

  return '不含税金额';
};


const CheckImport = ({ tabsKey, invoiceType, currentTime, form, dateValue, dispatch,isCompanyType,companyId}) => {
  const [plainLabel, setPlainLabel] = useState('不含税金额');

  useEffect(() => {
    const invoiceCode = form.getFieldValue('invoiceCode');

    const label = getLabel(invoiceCode);
    setPlainLabel(label);
  }, [form]);

  const clearForm = () => {
    form.resetFields();
  };

  useEffect(() => {
    clearForm();
  }, [tabsKey]);

  const CheckQuota = async () => {
    const res = await services.getQuato({ companyId, productType: 5 });
    const { freeQuota, paymentQuota, totalPaymentQuota } = res || {};
    const usedNum = totalPaymentQuota - paymentQuota;
    const resultData =  { usedNum, freeQuota, paymentQuota, totalPaymentQuota };
    dispatch({ type: 'setState', payload: { quotaData: resultData }})
  }

  const sureFunc = () => {
    form.validateFields(async (errors, values) => {
      if (errors) return;
      await dispatch({
        type: 'manualEntryInvoice',
        payload: {
          noTaxAmount: '',
          checkCode: '',
          ...values,
          type: plainLabel ? '1' : '0',
          invoiceDate: values.invoiceDate.format('YYYY-MM-DD'),
          period: dateValue.split('-').join(''),
        },
      }).then(() => {
        
        clearForm();
        // 企业版检测
        if (isCompanyType) {
          CheckQuota();
        }
        
      });
    });
  };

  const datePickedProps = {
    style: { width: '100%' },
    defaultPickerValue: moment(`${dateValue}-01`),
    disabledDate: (value) => {
      if (invoiceType === 'vat') {
        return dateValue !== value.format('YYYY-MM') || currentTime < value.format('YYYY-MM-DD');
      }
      return currentTime < value.format('YYYY-MM-DD');
    },
  };

  return (
    <>
      <div className="e-mt10" styleName="check-import-container">
        <div styleName="check-import-content">
          <Form {...formWrap} styleName="check-import-form">
            <Form.Item label="发票代码">
              {form.getFieldDecorator('invoiceCode', {
                rules: [
                  { required: true, message: '发票代码不能为空' },
                  { min: 10, message: '发票代码为10-12位数字' },
                ],
                normalize: (val) => {
                  return val ? val.replace(/[^\d]/gi, '').slice(0, 12) : '';
                },
              })(<Input placeholder="10或12位数字" />)}
            </Form.Item>
            <Form.Item label="发票号码">
              {form.getFieldDecorator('invoiceNum', {
                rules: [
                  { required: true, message: '发票号码不能为空' },
                  { min: 8, message: '发票号码为8位数字' },
                ],
                normalize: (val) => {
                  return val ? val.replace(/[^\d]/gi, '').slice(0, 8) : '';
                },
              })(<Input placeholder="8位数字" />)}
            </Form.Item>
            <Form.Item label="开票日期">
              {form.getFieldDecorator('invoiceDate', {
                rules: [{ required: true, message: '开票日期不能为空' }],
              })(<DatePicker {...datePickedProps} />)}
            </Form.Item>

            {plainLabel === '校验码后六位' ? (
              <Form.Item label="校验码后六位">
                {form.getFieldDecorator('checkCode', {
                  rules: [
                    { required: true, message: '校验码后六位不能为空' },
                    { min: 6, message: '校验码后六位为6位数字' },
                  ],
                  normalize: (val) => {
                    return val ? val.replace(/[^\d]/gi, '').slice(0, 6) : '';
                  },
                })(<Input placeholder={placeholderObj[plainLabel]} />)}
              </Form.Item>
            ) : (
              <Form.Item label={plainLabel}>
                {form.getFieldDecorator('noTaxAmount', {
                  rules: [{ required: true, message: `${plainLabel}不能为空` }],
                })(<InputNumber placeholder={placeholderObj[plainLabel]} />)}
              </Form.Item>
            )}
          </Form>
        </div>
      </div>
      <div styleName="check-import-footer">
        <Button type="primary" onClick={clearForm} ghost>
          清空
        </Button>
        <Button className="e-ml10" type="primary" onClick={sureFunc}>
          查验
        </Button>
      </div>
    </>
  );
};

CheckImport.defaultProps = {
  invoiceType: '',
  dateValue: '',
};

CheckImport.propTypes = {
  tabsKey: PropTypes.string.isRequired,
  dateValue: PropTypes.string,
  invoiceType: PropTypes.string,
  currentTime: PropTypes.string.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};

export default connect(({ invoiceType }, {account: {versionType, user: { companyId,currentTime } },...rest }) => {
    return {
    invoiceType,
    companyId,
    isCompanyType: versionType === '2',
    currentTime,
  }
})(Form.create()(CheckImport));
