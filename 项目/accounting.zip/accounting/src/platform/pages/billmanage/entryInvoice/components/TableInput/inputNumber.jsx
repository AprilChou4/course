import React, { useState } from 'react';
import PropTypes from 'prop-types';
import util from 'util';
import InputNumber from '@/NumberInput';
import './style.less';

const PopoverContent = ({ onBlur, initValue, isError, precision, ...InputNumberProps }) => {
  const [isBlur, setIsBlur] = useState(false);

  const valueBlur = (e) => {
    const { value } = e.target;
    setIsBlur(false);
    initValue !== value && onBlur(value);
  };
  return (
    <div styleName="ywy-table-input">
      {isBlur ? (
        <InputNumber
          defaultValue={initValue}
          onBlur={valueBlur}
          autoFocus
          precision={precision}
          {...InputNumberProps}
        />
      ) : (
        <div styleName={isError ? 'show-div error' : 'show-div'} onClick={() => setIsBlur(true)}>
          {initValue || initValue === 0 ? util.toFixed(initValue, precision, precision) : ''}
        </div>
      )}
    </div>
  );
};
PopoverContent.defaultProps = {
  initValue: '',
  isError: false,
  precision: 2,
};
PopoverContent.propTypes = {
  onBlur: PropTypes.func.isRequired,
  isError: PropTypes.bool,
  initValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  precision: PropTypes.number,
};
export default PopoverContent;
