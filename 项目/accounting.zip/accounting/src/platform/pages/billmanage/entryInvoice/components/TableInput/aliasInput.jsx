import React, { useState, useCallback, useEffect } from 'react';
import PropTypes from 'prop-types';
import util from 'util';
import TaxNameSelect from 'pages/stockModule/common/StockAliasTable/TaxNameSelect';
import './style.less';

const PopoverContent = ({ onBlur, initValue, isError, precision }) => {
  const [isBlur, setIsBlur] = useState(false);
  const [rowData, setRowData] = useState({});
  const [searchValue, setSearchValue] = useState('');

  const valueBlur = useCallback(() => {
    const { taxName, bm } = rowData;
    setIsBlur(false);
    if (taxName) {
      initValue !== taxName && onBlur(taxName, { taxCode: bm });
    }
  }, [rowData, initValue, onBlur, setIsBlur]);

  const onSelect = (e) => {
    setRowData(e);
  };

  const onSearch = (e) => {
    setSearchValue(e);
  };

  return (
    <div styleName="ywy-table-input">
      {isBlur ? (
        <TaxNameSelect
          defaultSearchName={searchValue}
          value={initValue}
          onBlur={valueBlur}
          onChange={() => {}}
          onSelect={onSelect}
          onSearch={onSearch}
        />
      ) : (
        <div
          styleName={isError ? 'show-div error' : 'show-div'}
          onClick={() => setIsBlur(true)}
          title={initValue}
        >
          {initValue || initValue === 0 ? util.toFixed(initValue, precision, precision) : ''}
        </div>
      )}
    </div>
  );
};
PopoverContent.defaultProps = {
  initValue: '',
  isError: false,
  precision: 2,
};
PopoverContent.propTypes = {
  onBlur: PropTypes.func.isRequired,
  isError: PropTypes.bool,
  initValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  precision: PropTypes.number,
};
export default PopoverContent;
