import React from 'react';
import PropTypes from 'prop-types';
import { Form, Checkbox } from 'antd';
import { create } from 'layer';

const FormItem = Form.Item;
const Empower = ({ form }) => {
  return (
    <div>
      <div
        className="ui-empower-div"
        style={{ padding: '20px 20px 10px', color: '#333', lineHeight: '22px' }}
      >
        系统检测到您未进行数据同步授权，如需同步数据，请先申请授权!
      </div>
      <Form>
        <FormItem>
          {form.getFieldDecorator('value')(
            <Checkbox style={{ paddingLeft: 20, fontSize: '12px' }}>下次不再提示</Checkbox>,
          )}
        </FormItem>
      </Form>
    </div>
  );
};
Empower.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default Form.create()(create(Empower));
