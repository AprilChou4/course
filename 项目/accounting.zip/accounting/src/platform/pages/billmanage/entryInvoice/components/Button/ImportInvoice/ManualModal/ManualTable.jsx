import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
// import { Icon, Select, message, AutoComplete, Input } from 'antd';
import { Icon, message, AutoComplete, Input } from 'antd';
import SuperTable from '@/SuperTable';
import InputNumber from '@/NumberInput';
import AliasInput from '../../../TableInput/aliasInput';
import TableInputNumber from '../../../TableInput/inputNumber';
import TableInput from '../../../TableInput';
import { taxData } from '../../../static';
import { allKeys, mustKeys } from './config';
import './style.less';

const { Option } = AutoComplete;
const ManualTable = ({
  manualImportData,
  unitPricePrecision,
  quantityPrecision,
  dispatch,
  modal,
}) => {
  const [taxTotal1, setTaxTotal1] = useState('');
  const { details, taxTotal } = manualImportData;
  const getDataSource = () => {
    return details.map((v, k) => {
      const obj = {
        lineSort: k,
      };
      if (allKeys.some((h) => !!v[h])) {
        mustKeys.forEach((key) => {
          if (!v[key] && v[key] !== 0) {
            obj[`${key}Error`] = true;
          }
          if (key === 'taxRate' && !/^([0-9][0-9]{0,1}|100)$/.test(v[key])) {
            obj[`${key}Error`] = true;
          }
        });
      }
      return {
        ...v,
        ...obj,
      };
    });
  };
  const setList = (list, taxTotal2) => {
    dispatch({
      type: 'updateState',
      payload: {
        manualImportState: '',
        manualImportData: {
          ...manualImportData,
          details: list.map((v, i) => ({ ...v, lineSort: i + 1 })),
          taxTotal: taxTotal1 || taxTotal2,
        },
      },
    });
  };
  const taxTotalBlur = () => {
    setList(details);
  };
  const taxTotalFocus = (e) => {
    const { value } = e.target;
    setTaxTotal1(value);
  };
  const taxTotalChange = (val) => {
    setTaxTotal1(`${val}`);
  };
  const inputBlur = (val, index, name, extra) => {
    let row = {};
    row[name] = val;
    if (name === 'taxName') {
      row = { ...row, ...extra };
    }
    const newList = details.map((v, i) => (i === index ? { ...v, ...row } : v));
    let newTaxTotal = 0;
    newList.forEach((v) => {
      newTaxTotal += Number(v.amt || 0) + Number(v.tax || 0);
    });
    setList(newList, newTaxTotal);
  };
  const addRow = () => {
    if (details.length > 29) {
      message.warn('超过30条不能新增');
      // 最大30条
      return;
    }
    setList([].concat(details, {}));
  };
  const delRow = (index) => {
    if (details.length === 5) {
      // 最小5条
      setList(details.map((v, i) => (i !== index ? v : {})));
      return;
    }
    setList(details.filter((v, i) => i !== index));
  };

  const childrenNodes = taxData.map((item) => {
    return (
      <Option key={item.key} value={item.value}>
        {item.value}
      </Option>
    );
  });

  const handleFilterOption = (inputValue, option) => {
    return option.props.children.indexOf(inputValue) > -1;
  };

  const manualTableColumns = [
    {
      title: '',
      dataIndex: 'delete',
      key: 'delete',
      fixed: 'left',
      width: 0,
      minWidth: 0,
      dragCell: false,
      render: (txt, row, index) => {
        return (
          <span className="cell-nowrap">
            <span className="cell-text">
              <Icon type="plus-circle" onClick={addRow} />
              <Icon type="close-circle" onClick={() => delRow(index)} />
            </span>
          </span>
        );
      },
    },
    {
      title: (
        <span>
          <em style={{ color: 'red' }}>*</em>税收分类简称
        </span>
      ),
      dataIndex: 'taxName',
      key: 'taxName',
      align: 'center',
      width: 130,
      minWidth: 150,
      render: (txt, row, index) => {
        const { taxNameError } = row;
        return (
          <AliasInput
            initValue={txt}
            isError={taxNameError}
            maxLength={120}
            onBlur={(val, extra) => inputBlur(val, index, 'taxName', extra)}
          />
        );
      },
    },
    {
      title: (
        <span>
          <em style={{ color: 'red' }}>*</em>商品名称
        </span>
      ),
      dataIndex: 'invoiceContent',
      key: 'invoiceContent',
      align: 'center',
      width: 120,
      minWidth: 150,
      render: (txt, row, index) => {
        const { invoiceContentError } = row;
        return (
          <TableInput
            initValue={txt}
            isError={invoiceContentError}
            maxLength={120}
            onBlur={(val) => inputBlur(val, index, 'invoiceContent')}
          />
        );
      },
    },
    {
      title: '规格型号',
      dataIndex: 'model',
      key: 'model',
      align: 'center',
      render: (txt, row, index) => {
        return (
          <TableInput
            initValue={txt}
            maxLength={40}
            onBlur={(val) => inputBlur(val, index, 'model')}
          />
        );
      },
    },
    {
      title: '单位',
      dataIndex: 'unit',
      key: 'unit',
      width: 50,
      align: 'center',
      render: (txt, row, index) => {
        return (
          <TableInput
            initValue={txt}
            maxLength={22}
            onBlur={(val) => inputBlur(val, index, 'unit')}
          />
        );
      },
    },
    {
      title: '数量',
      dataIndex: 'number',
      key: 'number',
      align: 'center',
      render: (txt, row, index) => {
        return (
          <TableInputNumber
            initValue={txt}
            onBlur={(val) => inputBlur(val, index, 'number')}
            precision={quantityPrecision}
          />
        );
      },
    },
    {
      title: '单价',
      dataIndex: 'price',
      key: 'price',
      align: 'center',
      render: (txt, row, index) => {
        return (
          <TableInputNumber
            initValue={txt}
            onBlur={(val) => inputBlur(val, index, 'price')}
            precision={unitPricePrecision}
          />
        );
      },
    },
    {
      title: (
        <span>
          <em style={{ color: 'red' }}>*</em>金额
        </span>
      ),
      dataIndex: 'amt',
      key: 'amt',
      align: 'center',
      render: (txt, row, index) => {
        const { amtError } = row;
        return (
          <TableInputNumber
            initValue={txt}
            isError={amtError}
            onBlur={(val) => inputBlur(val, index, 'amt')}
            precision={2}
          />
        );
      },
    },
    {
      title: (
        <span>
          <em style={{ color: 'red' }}>*</em>税率
        </span>
      ),
      dataIndex: 'taxRate',
      key: 'taxRate',
      width: 85,
      align: 'center',
      render: (txt, row, index) => {
        const { taxRateError } = row;
        return (
          <>
            <AutoComplete
              dataSource={childrenNodes}
              backfill
              filterOption={handleFilterOption}
              style={{ width: '65px', height: '32px', verticalAlign: 'top' }}
              value={`${txt === 0 || txt ? txt : ''}`}
              onChange={(val) => {
                inputBlur(val, index, 'taxRate');
              }}
            >
              <Input
                placeholder="0~100"
                autoComplete="off"
                style={taxRateError ? { borderColor: '#ff0000', transition: 'none' } : {}}
              />
            </AutoComplete>
            <em
              style={{
                display: 'inline-block',
                height: '32px',
                lineHeight: '32px',
                paddingLeft: '2px',
              }}
            >
              %
            </em>
          </>
          // <Select
          //   className={taxRateError && 'error'}
          //   value={
          //     ['0', '3', '4', '5', '6', '9', '10', '11', '13', '16', '17'].includes(`${txt}`)
          //       ? `${txt}`
          //       : ''
          //   }
          //   onChange={(val) => inputBlur(val, index, 'taxRate')}
          // >
          //   {taxData.map((v) => (
          //     <Option key={v.key} value={v.value}>
          //       {v.title}
          //     </Option>
          //   ))}
          // </Select>
        );
      },
    },
    {
      title: (
        <span>
          <em style={{ color: 'red' }}>*</em>税额
        </span>
      ),
      dataIndex: 'tax',
      key: 'tax',
      align: 'center',
      render: (txt, row, index) => {
        const { taxError } = row;
        return (
          <TableInputNumber
            initValue={txt}
            isError={taxError}
            onBlur={(val) => inputBlur(val, index, 'tax')}
            precision={2}
          />
        );
      },
    },
  ];
  const top = modal ? 165 : 230;
  const tableFooterWidth = modal ? 791 : 774;
  const contentWidth = modal ? 632 : 617;
  return (
    <div style={{ position: 'absolute', top, padding: '0 27px 0 6px' }}>
      <div style={{ height: 222 }}>
        <SuperTable
          noLazyLoading
          setRecalculate={details.length}
          className="manual-import-table"
          columns={manualTableColumns}
          dataSource={getDataSource()}
          rowKey="lineSort"
          bordered
          pagination={false}
        />
      </div>
      <div styleName="table-footer-manual" style={{ width: tableFooterWidth }}>
        <div styleName="title">价税合计</div>
        <div styleName="content" style={{ width: contentWidth }}>
          <InputNumber
            value={taxTotal}
            onFocus={taxTotalFocus}
            onChange={taxTotalChange}
            onBlur={taxTotalBlur}
            precision={2}
          />
        </div>
      </div>
    </div>
  );
};
ManualTable.propTypes = {
  manualImportData: PropTypes.objectOf(PropTypes.any).isRequired,
  unitPricePrecision: PropTypes.number.isRequired,
  quantityPrecision: PropTypes.number.isRequired,
  modal: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(
  ({ manualImportData }, { account: { unitPricePrecision, quantityPrecision } }) => ({
    manualImportData,
    unitPricePrecision,
    quantityPrecision,
  }),
)(ManualTable);
