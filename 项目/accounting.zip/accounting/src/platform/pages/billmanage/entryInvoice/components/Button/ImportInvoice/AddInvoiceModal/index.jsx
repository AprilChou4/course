import React, { useState, useRef, useEffect } from 'react';
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import { Modal, Tabs, DatePicker, Radio, Button, Icon } from 'antd';
import moment from 'moment';
import CheckImport from '../CheckImport';
// import ScanImport from '../ScanImport';
import Import from '../Import';
import ManualImport from '../ManualModal';
import ManualContent from '../ManualModal/ManualContent';
import './index.less';
import MiniScanBookModal from '../MiniScanBookModal';
import services from '../../../../services';

const RadioGroup = Radio.Group;
const { MonthPicker } = DatePicker;
const { TabPane } = Tabs;
const modalBodyStyle = { padding: '10px 16px 18px' };

const AddInvoiceModal = ({
  dispatch,
  onCancel,
  invoiceType,
  endDate,
  // currentDate,
  // period,
  currentYear,
  currentMonth,
  currentTime,
  quotaData,
  addInvoiceModalVisible,
}) => {
  const [importMethod, setImportMethod] = useState(0);
  const [dateValue, setDateValue] = useState(endDate);
  const [tabsKey, setTabsKey] = useState('0');

  useEffect(() => {
    setTabsKey('0');
    if (addInvoiceModalVisible === true) {
      setDateValue(endDate);
    }
  }, [addInvoiceModalVisible]);

  // const allowDates = useMemo(() => {
  //   const maxDates = [];
  //   period.forEach((v) => {
  //     maxDates.push(v);
  //   });
  //   for (let i = currentYear; i <= currentYear + 1; i += 1) {
  //     const initMonth = i === currentYear ? currentMonth : 1; // 从1开始或从当前会计期间开始
  //     let maxMonth = 1;
  //     if (i === currentYear) {
  //       maxMonth = 12;
  //     } else {
  //       maxMonth =
  //         currentDate.split('-')[1] > currentMonth ? currentMonth : currentDate.split('-')[1];
  //     }
  //     for (let j = initMonth; j <= maxMonth; j += 1) {
  //       const date = `${i}-${j < 10 ? `0${j}` : j}`;
  //       if (!maxDates.includes(date)) {
  //         maxDates.push(date);
  //       }
  //     }
  //   }
  //   return maxDates;
  // }, [period, currentYear, currentMonth, currentDate]);

  const childRef = useRef();
  const showDialog = async () => {
    const res = await services.wxGetQRCode({ invoiceType: invoiceType === 'vat' ? 0 : 1, period: dateValue });
    await dispatch({ type: 'setState', payload: { wxQRCodeData: res, isShowMiniResModal: true } });
    childRef.current?.ref.current?.parentTabStatus?.();
  };
  const disabledDate = (current) => {
    if (current && currentTime < current.format('YYYY-MM-DD')) {
      return true;
    }
    // return current && !allowDates.includes(current.format('YYYY-MM'));
    return (
      current &&
      `${currentYear}-${currentMonth < 10 ? `0${currentMonth}` : currentMonth}` >
      current.format('YYYY-MM')
    );
  };

  const monthChange = (time) => {
    setDateValue(time.format('YYYY-MM'));
  };

  const importMethodChange = (e) => {
    setImportMethod(e.target.value);
  };

  function tabsChange(key) {
    setTabsKey(key);
    if (key === '1') {
      setImportMethod(0);
    }
  }

  const { usedNum, freeQuota, paymentQuota, totalPaymentQuota } = quotaData || {};
  const quotaHtml = () => {
    return JSON.stringify(quotaData) !== '{}' ? (
      <div className="g-charge-tips">
        {freeQuota !== 0? (
          <span className="orange">亲！您有{freeQuota}张免费体验的优惠哦！</span>
        ) : (
            <span>
              总额度：{totalPaymentQuota}张 &nbsp;&nbsp;
              <span className="used">已使用：{usedNum}张</span> &nbsp;&nbsp;
              <span className="nouse">未使用：{paymentQuota}张</span>
            </span>
          )}
      </div>
    ) : null;
  };

  return (
    <>
      {addInvoiceModalVisible && (
        <Modal
          visible
          // title="录入发票"
          width="840px"
          onCancel={onCancel}
          footer={null}
          bodyStyle={modalBodyStyle}
          maskClosable={false}
          className="add-invoice-modal"
        >
          <Tabs defaultActiveKey="0" onChange={tabsChange}>
            {/* <TabPane className="e-mt10" tab="扫码查验" key="0">
                <span>会计期间：</span>
                <MonthPicker
                  allowClear={false}
                  value={moment(dateValue || endDate)}
                  disabledDate={disabledDate}
                  onChange={monthChange}
                />
                <MiniImport/>
                <ScanImport/>
              </TabPane> */}
            <TabPane className="e-mt10" tab="手动查验" key="0">
              {quotaHtml()}
              <span>会计期间：</span>
              <MonthPicker
                allowClear={false}
                value={moment(dateValue || endDate)}
                disabledDate={disabledDate}
                onChange={monthChange}
              />
              <div styleName="button-group-qrcode">
                <Button type="primary" ghost styleName="green-qrcode-btn" onClick={showDialog}>
                  <Icon type="qrcode" />
                  微信小程序录入
                </Button>
              </div>
              <CheckImport tabsKey={tabsKey} dateValue={dateValue} />
            </TabPane>
            <TabPane className="e-mt10" tab="Excel导入" key="1">
              {quotaHtml()}
              <span>会计期间：</span>
              <MonthPicker
                allowClear={false}
                value={moment(dateValue || endDate)}
                disabledDate={disabledDate}
                onChange={monthChange}
              />
              <RadioGroup
                style={{ marginLeft: '15px' }}
                onChange={importMethodChange}
                value={importMethod}
              >
                <Radio value={0}>{invoiceType !== 'vat' ? '进项Excel导入' : '发票明细导入'} </Radio>
                {invoiceType !== 'vat' && <Radio value={2}>发票明细导入</Radio>}
                <Radio value={1}>查验导入</Radio>
              </RadioGroup>
              <div styleName="button-group-qrcode">
                <Button type="primary" ghost styleName="green-qrcode-btn" onClick={showDialog}>
                  <Icon type="qrcode" />
                  微信小程序录入
                </Button>
              </div>
              <Import tabsKey={tabsKey} importMethod={importMethod} dateValue={dateValue} />
            </TabPane>
            <TabPane className="e-mt10" tab="手工填制" key="2">
              {/* {quotaHtml()} */}
              <span>会计期间：</span>
              <MonthPicker
                allowClear={false}
                value={moment(dateValue || endDate)}
                disabledDate={disabledDate}
                onChange={monthChange}
              />
              <span style={{ marginLeft: '15px', marginRight: '15px' }}>发票类型</span>
              <div styleName="button-group-qrcode">
                <Button type="primary" ghost styleName="green-qrcode-btn" onClick={showDialog}>
                  <Icon type="qrcode" />
                  微信小程序录入
                </Button>
              </div>
              <ManualImport dateValue={dateValue} />
            </TabPane>
          </Tabs>
          {tabsKey === '2' && <ManualContent tabsKey={tabsKey} dateValue={dateValue} />}
        </Modal>
      )}
      <MiniScanBookModal ref={childRef} dateValue={dateValue} />
    </>
  );
};

AddInvoiceModal.defaultProps = {
  endDate: '',
  // currentDate: '',
  invoiceType: '',
};

AddInvoiceModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  invoiceType: PropTypes.string,
  endDate: PropTypes.string,
  // currentDate: PropTypes.string,
  // period: PropTypes.arrayOf(PropTypes.string).isRequired,
  currentYear: PropTypes.number.isRequired,
  currentMonth: PropTypes.number.isRequired,
  currentTime: PropTypes.string.isRequired,
};

export default connect(
  (
    { invoiceType, query: { endDate }, quotaData, addInvoiceModalVisible },
    {
      account: {
        // currentDate,
        // period,
        currentYear,
        currentMonth,
        user: { currentTime },
      },
    },
  ) => ({
    invoiceType,
    endDate,
    // currentDate,
    // period,
    currentYear,
    currentMonth,
    currentTime,
    quotaData,
    addInvoiceModalVisible,
  }),
)(AddInvoiceModal);
