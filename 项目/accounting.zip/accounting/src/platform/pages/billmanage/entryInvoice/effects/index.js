import React from 'react';
import moment from 'moment';
import { layer } from 'nuijs';
import { message, Checkbox, Modal } from 'antd';
import { store } from 'nuomi';
import util from 'util';
import { ConfirmModal } from '@/modal';
import services from '../services';
import { formLayer, reactLayer, superLayer } from '../../../../public/layer';
import TaxNum from '../components/Layer/TaxNum';
import TaxBureauLogin from '../components/Layer/TaxBureauLogin';
import TransformInvoiceEffects from '../../transformInvoiceList/effects';
import '../css/index.less';

export default class Effects extends TransformInvoiceEffects {
  constructor(props) {
    super(props);
    this.times = null;
  }

  // ---------------- 常用条件 ------------------
  async queryCommonly(type) {
    const { query, invoiceType } = this.getState();
    const data = await services.queryCommonly({
      bookType: invoiceType === 'vat' ? 11 : 10,
    });
    if (type === 'init' && data.length > 0) {
      const Item = data.find((v) => v.isDefault);
      if (Item) {
        this.setState({
          query: {
            ...query,
            ...JSON.parse(Item.commonlyContent),
          },
          commonlyId: Item.commonlyId,
        });
      }
    }
    this.setState({ commonlyList: data });
  }

  async saveCommonly(state) {
    const { invoiceType } = this.getState();
    const { onSuccess, ...rest } = state;
    await services.saveCommonly(
      { ...rest, bookType: invoiceType === 'vat' ? 11 : 10 },
      { loading: true },
    );
    onSuccess && onSuccess();
    this.queryCommonly();
  }

  async deleteCommonly(state) {
    await services.deleteCommonly(state);
    this.queryCommonly();
  }

  async defaultCommonly(state) {
    await services.defaultCommonly(state);
    this.queryCommonly();
  }
  // ---------------- 常用条件 ------------------

  setVoucherBuildSetting(state) {
    const { voucherBuildSetting } = this.getState();
    this.updateState({
      voucherBuildSetting: { ...voucherBuildSetting, ...state },
    });
  }

  async setQuery(state) {
    this.dispatch({
      type: 'updateQuery',
      payload: state,
    });
    await this.$getList();
  }

  // 维护登录信息
  updateTaxInfo = async (query) => {
    await services.updateTaxInfo(query);
    message.success('电子税务局登录信息维护成功！');
    this.times = true;
    this.getNoDiskExtractState();
  };

  updateTaxNum = async (query) => {
    await services.updateTaxNum(query);
    message.success('税号维护成功！');
    await this.getAuthState();
    await this.extractEntryInvoiceList();
  };

  addAuthCodeRelation = async (query) => {
    await services.addAuthCodeRelation(query);
    message.success('授权成功！');
    await this.getAuthState();
    await this.extractEntryInvoiceList();
  };

  async autoAuthCodeRelation(state) {
    try {
      const { guid, crypdata: encryptString } = state;
      const data = await services.autoAuthCodeRelation({ guid, encryptString });
      this.updateState({
        powerNumber: data.authCode,
        autoPowerNumber: data.authCode,
        clientPowerInfo: '您已插入税盘，已为您自动填写了授权码',
      });
    } catch (e) {
      if (e.message) {
        this.updateState({
          clientPowerInfo: e.message,
        });
      }
      // setTimeout(async () => {
      //   await this.isClient();
      // }, 5000);
    }
  }

  // 获取生成凭证设置
  getVoucherBuildSetting = async () => {
    const { invoiceType, allSubject } = this.getState();
    const buildType = invoiceType === 'vat' ? 0 : 1;
    const data = await services.getVoucherBuildSetting({ buildType });
    let voucherBuildSetting = {
      ...data,
    };
    if (invoiceType !== 'vat') {
      const { buildVoucherDate, buildTaxSubjectId } = data;
      const subjectItem = allSubject.find((v) => v.subjectId === buildTaxSubjectId);
      voucherBuildSetting = {
        ...data,
        buildVoucherDate: buildVoucherDate || '0,0',
        buildTaxSubjectId: subjectItem ? buildTaxSubjectId : '',
      };
    }
    this.updateState({
      voucherBuildSetting,
    });
  };

  updateVoucherBuildSetting = async (state) => {
    const { voucherBuildSetting } = this.getState();
    const { success } = state;
    await services.updateVoucherBuildSetting(voucherBuildSetting);
    message.success('修改凭证生成方式成功');
    success && success();
  };

  // 判断是否是客户端
  checkInsertKey = (data) => {
    if (data) {
      return Object.keys(data).some((v) => !!data[v]);
    }
    return false;
  };

  async isClient() {
    const that = this;
    if (typeof ExternService === 'object') {
      // 客户端
      let source = window.readTaxDevice('kingTax');
      let checkInsertKey = that.checkInsertKey(source) || source.crypdata;

      if (!checkInsertKey) {
        // 百旺盘
        source = window.readTaxDevice('taxDev');
      }
      // 没有插入金税盘
      // 找个地方在页面加载完成后执行一次Gxpt.login
      // 然后开个定时器定时执行check
      checkInsertKey = that.checkInsertKey(source) || source.crypdata;
      if (!checkInsertKey) {
        // eslint-disable-next-line
        Gxpt.check({
          // 插入USB-KEY
          async success(data) {
            await that.autoAuthCodeRelation(data);
          },
          // 没有插入USB-KEY
          failed() {
            setTimeout(() => {
              that.isClient();
            }, 5000);
          },
        });
      } else {
        await that.autoAuthCodeRelation(source);
      }
    }
  }

  async getAuthState() {
    const data = await services.getAuthState();
    const { authState, expireDays } = data;
    if (expireDays <= 20 && expireDays > 0) {
      Modal.warning({
        title: '温馨提醒',
        icon: null,
        className: 'ywy-modal-info',
        okText: '我知道了',
        content: `该账套的授权关系即将到期，剩余${expireDays}天。为了避免耽误您的工作，请在授权关系到期前重新授权～`,
      });
    }
    this.updateState({
      noPower: authState === 3 ? false : 2,
      expireDays,
    });
  }

  async expireAuthState() {
    await services.expireAuthState();
    await this.initData();
  }

  // 同步权限
  async getNoDiskExtractState(accountPeriod, type) {
    const {
      query: { endDate },
    } = this.getState();

    const data = await services.getNoDiskExtractState({
      accountPeriod: (accountPeriod || endDate).replace('-', ''),
    });
    if (data.status === 3) {
      const newDate = moment().format('YYYY-MM-DD HH:mm:ss');
      message.destroy();
      message.success(`${newDate} 数据提取完成！`);
      this.extractEntryInvoiceList(type, true);
    } else if ([1, 2].includes(data.status)) {
      if (endDate && endDate === accountPeriod) {
        if (this.times) {
          clearTimeout(this.times);
          this.times = setTimeout(() => {
            const {
              account: { extractType },
            } = store.getState();
            if (extractType === 1 && this.times) {
              this.getNoDiskExtractState(accountPeriod, type);
            }
          }, 2000);
        }
      }
    } else if (data.status === 6) {
      this.TaxNumInfo();
    } else if (data.status === 7) {
      this.taxBureauLogin();
    } else if (data.status !== 0) {
      const newDate = moment().format('YYYY-MM-DD HH:mm:ss');
      ConfirmModal({
        title: `${newDate} 数据提取失败！`,
        content: `失败原因：${data.message}`,
        okText: '确定',
      });
    }
    // false 没有权限 1、税号未绑定 2、没有授权 noPower
    // const noPower = data.status === 6 ? 1 : false;
    this.updateState({
      noDiskExtract: data.status,
      noPower: false,
      // noPower: data.status === 7 ? 2 : noPower,
    });
  }

  // 取消同步
  async stopNoDiskExtract(query) {
    this.times = null;
    await services.stopNoDiskExtract(query);
    this.updateState({
      noDiskExtract: 5,
    });
  }

  // 切换日期
  async switchingDate() {
    await this.extractEntryInvoiceList('dateInit', null, true);
  }

  // 数据同步
  async extractEntryInvoiceList(type, fig, switchs) {
    const {
      account: { extractType, currentDate },
    } = store.getState();
    const { invoiceType, query } = this.getState();
    const { endDate = currentDate } = query;
    clearTimeout(this.times);
    this.times = null;
    if (extractType === 1 && !fig) {
      if (!switchs && !['init', 'dateInit'].includes(type)) {
        const data = await services.triggerNoDiskExtract({
          accountPeriod: (endDate || currentDate).replace('-', ''),
        });
        if (data.status === 6) {
          this.TaxNumInfo();
          this.updateState({
            noDiskExtract: data.status,
            noPower: false,
          });
          await this.$getList(type);
          return;
        }
        if (data.status === 7) {
          this.updateState({
            noDiskExtract: data.status,
            noPower: false,
          });
          this.taxBureauLogin();
          await this.$getList(type);
          return;
        }
        message.success('正在同步数据，您可关闭当前页或进行其他操作！');
      }
      this.times = true;
      await this.getNoDiskExtractState(endDate, type);
      await this.$getList(type);
    } else {
      this.times = null;
      try {
        // const { invoiceType, query } = this.getState();
        // const { endDate } = query;
        const [year, month] = endDate.split('-');
        const data =
          invoiceType === 'vat'
            ? await services.extractVATInvoiceList(
                { year, month },
                { status: { '^300': null }, loading: true },
              )
            : await services.extractEntryInvoiceList(
                { year, month },
                { status: { '^300': null }, loading: true },
              );
        // 进销项无盘取数后 需要同时更新进销项，偷偷的调用进销项另同步一个接口（暂时我们前端这样做，后面后端优化点再去掉）
        if (extractType === 1 && fig) {
          if (invoiceType === 'vat') {
            services.extractEntryInvoiceList({ year, month }, { status: { '^300': null } });
          } else {
            services.extractVATInvoiceList({ year, month }, { status: { '^300': null } });
          }
        }
        await this.updateState({
          noPower: false,
        });
        await this.$getList(type);
        this.extractInvoiceMessage(data);
      } catch (e) {
        if (e.status === '30006010014') {
          await this.updateState({
            noPower: 1,
          });
          this.TaxNumInfo();
          return;
        }
        if (e.status === '30006010005') {
          await this.getAuthState();
          // 初始化的时候不需要提示申请授权
          if (!['init', 'dateInit'].includes(type)) {
            this.updateState({
              powerModalVisible: true,
            });
          }
        }
        if (e.status !== '30006010005') {
          message.error(e.message);
        }
        if (e.status === '30006010004') {
          this.updateState({
            dataSource: [],
            dataSourceOriginal: {
              invoiceList: [],
            },
          });
          return;
        }
        await this.$getList(type);
      }
    }
  }

  //扫码录入的表格
  async scanBookInit() {
    const res = await services.scanInvoiceDataList({});
    this.updateState({
      isShowScanResModal: true,
      scanInvoiceData: res,
    });
  }

  // async miniScanBookInit() {
  //   const { invoiceType } = this.getState();
  //   const res = await services.wxGetQRCode({invoiceType:invoiceType==="vat"?0:1});
  //   this.updateState({
  //     isShowMiniResModal: true,
  //     wxQRCodeData: res
  //   });
  // }

  extractInvoiceMessage = (data) => {
    const { invoiceType } = this.getState();
    const {
      cancelList = [],
      stateChangeList = [],
      confirmCancelList = [],
      addSizeForU,
      addSizeForT,
      addSizeForJ,
      addSizeForBuy,
      addSize,
      msg,
    } = data;
    // 和下面invoiceTypeName一一对应
    const invoiceTypeNumber = [addSize, addSizeForBuy, addSizeForJ, addSizeForU, addSizeForT];
    const invoiceTypeName = ['销售发票', '收购发票', '机动车发票', '二手车发票', '通行费发票'];
    const invoiceNumbers = [];
    const confirmInvoiceNumbers = [];
    let invoiceMsgInfo = '本期成功提取';
    let invoiceIndex = 0;
    invoiceTypeNumber.forEach((v, i) => {
      if (v > 0) {
        invoiceIndex && (invoiceMsgInfo += ',');
        invoiceMsgInfo += `${invoiceType === 'vat' ? invoiceTypeName[i] : '进项发票'}${v}张`;
        invoiceIndex += 1;
      }
    });
    invoiceIndex > 1 && (invoiceMsgInfo += ',请在发票类型切换查看');
    if (cancelList.length > 0 || confirmCancelList.length > 0) {
      const voucherIds = [];
      const voucherInfos = [];
      const confirmVoucherIds = [];
      const confirmVoucherInfos = [];
      cancelList.forEach((val) => {
        invoiceNumbers.push(val.invoiceNumber);
        if (val.voucherId || val.unVoucherId) {
          voucherIds.push(val.voucherId || val.unVoucherId);
          voucherInfos.push(val.voucherInfo);
        }
      });
      confirmCancelList.forEach((val) => {
        confirmInvoiceNumbers.push(val.invoiceNumber);
        if (val.voucherId) {
          confirmVoucherIds.push(val.voucherId);
          confirmVoucherInfos.push(val.voucherInfo);
        }
      });
      let invoHtml = `发票号${invoiceNumbers.slice(0, 3).join(',')}`;
      const confirmInvoHtml = `发票号${confirmInvoiceNumbers.slice(0, 3).join(',')}`;
      let entryHtml = '';
      if (invoiceType === 'vat') {
        // 销项发票
        if (voucherIds.length > 0) {
          invoHtml = `本次提取成功${addSize}张发票,其中${invoHtml}已经作废，请删除该张凭证。`;
        } else {
          invoHtml += ',已经作废，请重新检查。';
        }
      } else {
        if (cancelList.length > 0) {
          entryHtml += `<p style="padding: 20px; line-height: 20px">${invoHtml}发票状态由未认证变为了抵扣认证/退税认证，请检查并修改${voucherInfos
            .slice(0, 3)
            .join(',')}${voucherInfos.length > 3 ? '...' : ''}凭证。</p>`;
        }
        if (confirmCancelList.length > 0) {
          entryHtml += `<p style="padding: 20px; line-height: 20px">${confirmInvoHtml}发票状态已由抵扣认证/退税认证变为了未认证，请检查并修改${confirmVoucherInfos
            .slice(0, 3)
            .join(',')}${voucherInfos.length > 3 ? '...' : ''}凭证</p>`;
        }
      }
      if (invoiceType === 'vat') {
        layer({
          template: `<p class="e-p20 f-lh20">${invoHtml}</p>`,
          id: 'ondelvch',
          cancel: {
            enable: true,
            callback() {},
          },
          confirm: {
            enable: true,
            text: voucherIds.length > 0 ? '去删除' : '确定',
            callback() {
              layer.hide('ondelvch');
              if (voucherIds.length > 0) {
                superLayer('voucher/record', {
                  data: {
                    title: '删除凭证',
                    voucherId: voucherIds.join(','),
                    isDelete: 1,
                    isDisable: 1,
                    isBillManage: true,
                  },
                  onDestroy() {
                    // 回调
                    if (this.saveData) {
                      this.$getList();
                    }
                  },
                  onSave(layerData) {
                    this.saveData = layerData;
                  },
                });
              }
            },
          },
        });
      } else {
        if (invoiceIndex > 0) {
          message.success(invoiceMsgInfo);
        }
        layer({
          template: entryHtml,
          id: 'billReminder',
          title: '温馨提示',
          width: '515',
          cancel: {
            enable: true,
            text: '取消',
            callback() {},
          },
          confirm: {
            enable: true,
            text: '确定',
            callback() {
              layer.hide('billReminder');
            },
          },
        });
      }
    } else if (stateChangeList && stateChangeList.length) {
      const text = stateChangeList
        .map((item) => {
          return item.invoiceNumber;
        })
        .join('、');
      layer({
        template: `<p class="e-p20 f-lh20">${text}发票状态变为了${
          invoiceType === 'vat' ? `作废` : `异常`
        },请调整相应的单据或凭证。</p>`,
        id: 'billReminder',
        title: '温馨提示',
        // width: '515',
        cancel: {
          enable: true,
          text: '取消',
          callback() {},
        },
        confirm: {
          enable: true,
          text: '确定',
          callback() {
            layer.hide('billReminder');
          },
        },
      });
    } else if (invoiceIndex > 0) {
      message.success(invoiceMsgInfo);
    } else if (msg) {
      message.warning(msg);
    } else {
      message.success('发票已经是最新的了');
    }
  };

  /**
   * 获取列表，（导入）进、销项
   * 参数：type （init: 初始化，noReset: 不重置分页）
   * */
  async $getList(type) {
    try {
      const that = this;
      const { invoiceType, paginationProps, query } = this.getState();
      const { endDate } = query;
      const [year, month] = endDate.split('-');
      const serviceName = invoiceType === 'vat' ? 'getVatInvoiceList' : 'getEntryInvoiceList';
      const data = await services[serviceName](
        { ...query, year, month, type: Number(invoiceType !== 'vat') },
        { loading: true },
      );
      const { notPerfectInvoiceCount, taxNum } = data;
      if (!taxNum) {
        this.updateState({
          noPower: 1,
          dataSource: [],
          dataSourceOriginal: {
            invoiceList: [],
          },
        });
        this.TaxNumInfo();
      }
      const storage = window.localStorage; // 存储
      const { unShowPerfectInvoiceCount } = storage;
      const accountToken = util.getAccountToken();
      const show = unShowPerfectInvoiceCount && JSON.parse(unShowPerfectInvoiceCount)[accountToken];
      if (notPerfectInvoiceCount > 0 && ['init', 'likeInit'].includes(type) && !show) {
        let isRemember = false;
        reactLayer({
          width: 360,
          title: '温馨提示',
          id: 'notPerfect',
          zIndex: 109998,
          confirm: {
            enable: true,
            text: '获取明细',
            callback: async () => {
              await that.batchFpcyEntryInvoiceList({ invoiceIds: [] });
            },
          },
          onDestroy() {
            isRemember && util.store('unShowPerfectInvoiceCount', true);
          },
          render() {
            return (
              <div>
                <p className="e-p20 f-tal">
                  有{notPerfectInvoiceCount}张发票未取得发票明细，请点击获取明细
                </p>
                <Checkbox
                  style={{ paddingLeft: 20, fontSize: '12px' }}
                  onChange={(e) => {
                    const { checked } = e.target;
                    isRemember = checked;
                  }}
                >
                  下次不再提示
                </Checkbox>
              </div>
            );
          },
        });
      }
      await this.updateState({
        loadings: { $getList: false },
        dataSourceOriginal: data,
        paginationProps: {
          ...paginationProps,
          current: ['noReset', 'keepSelects'].includes(type) ? paginationProps.current : 1,
          total: 0,
        },
      });
      await this.paginationChange(type);
    } catch (e) {
      this.updateState({
        dataSource: [],
        dataSourceOriginal: {
          invoiceList: [],
        },
      });
    }
  }

  async updatePagination(state) {
    const { paginationProps } = this.getState();
    await this.updateState({
      paginationProps: {
        ...paginationProps,
        ...state,
      },
    });
    await this.paginationChange('keepSelects');
  }

  async paginationChange(type) {
    const { dataSourceOriginal, paginationProps, selectedRowKeys, selectedRows } = this.getState();
    const { invoiceList } = dataSourceOriginal;
    const { current, pageSize } = paginationProps;
    const begin = (current - 1) * pageSize;
    const end = current * pageSize;
    let dataSource = [];
    let sumAmt = 0;
    let sumTax = 0;
    let sumTaxTotal = 0;
    let sumEffectiveTax = 0;
    if (invoiceList.length > 0) {
      dataSource = invoiceList.slice(begin, end);
      dataSource.forEach((v) => {
        if (Number(v.invoiceState) === 2) {
          return;
        }
        sumAmt += v.amt;
        sumTax += v.tax;
        sumTaxTotal += v.taxTotal;
        sumEffectiveTax += v.effectiveTax || 0;
      });
      dataSource.push({
        invoiceId: 'total',
        isTotal: true,
        auxiliaryName: '合计',
        amt: sumAmt,
        tax: sumTax,
        effectiveTax: sumEffectiveTax,
        taxTotal: sumTaxTotal,
      });
    }
    this.updateState({
      selectedRowKeys: type === 'keepSelects' ? selectedRowKeys : [],
      selectedRows: type === 'keepSelects' ? selectedRows : [],
      dataSource: dataSource.map((v) => ({ ...v, key: v.invoiceId })),
      paginationProps: {
        ...paginationProps,
        total: invoiceList.length,
      },
    });
  }

  TaxNumInfo() {
    if (inAuth() === false) return;
    const that = this;
    layer.hide('taxNum');
    formLayer({
      id: 'taxNum',
      width: 450,
      title: '温馨提示',
      confirm: {
        enable: true,
        text: '确定',
        callback: (self) => {
          self.handleSubmit((val) => {
            const {
              noDiskExtract,
              // query: { endDate },
            } = this.getState();
            that.updateTaxNum({ taxNumber: val.value });
            if (noDiskExtract === 6) {
              this.times = true;
              this.getNoDiskExtractState();
            }
            layer.hide();
          });
        },
      },
      render() {
        return <TaxNum />;
      },
    });
  }

  taxBureauLogin() {
    if (inAuth() === false) return;
    const that = this;
    layer.hide('taxBureauLogin');
    // TODO: 改为接口调用
    const usernameLoginIdentity = [
      { name: '法人', value: 1 },
      { name: '财务负责人', value: 2 },
      { name: '办税员', value: 3 },
    ];
    formLayer({
      id: 'taxBureauLogin',
      width: 439,
      title: '电子税务局登录信息',
      confirm: {
        enable: true,
        text: '确定',
        callback: (self) => {
          self.handleSubmit((val) => {
            that.updateTaxInfo(val);
            layer.hide();
          });
        },
      },
      zIndex: 109999,
      render() {
        return <TaxBureauLogin usernameLoginIdentity={usernameLoginIdentity} />;
      },
    });
  }

  empowerInfo() {
    const that = this;
    let isRemember = false;
    reactLayer({
      width: 400,
      height: '100px',
      title: '温馨提示',
      id: 'empowerInfo',
      confirm: {
        enable: true,
        text: '申请授权',
        callback: () => {
          layer.hide('empowerInfo');
          that.empowerInfoNext();
        },
      },
      onDestroy() {
        isRemember && util.storeForUser('_POWER_WARN_', '_POWER_WARN_');
      },
      render() {
        return (
          <div>
            <div
              className="ui-empower-div"
              style={{ padding: '20px 20px 10px', color: '#333', lineHeight: '22px' }}
            >
              系统检测到您未进行数据同步授权，如需同步数据，请先申请授权!
            </div>
            <Checkbox
              style={{ paddingLeft: 20, fontSize: '12px' }}
              onChange={(e) => {
                const { checked } = e.target;
                isRemember = checked;
              }}
            >
              下次不再提示
            </Checkbox>
          </div>
        );
      },
    });
  }

  empowerInfoNext() {
    const client = typeof ExternService === 'object';
    if (client) {
      this.isClient();
    }
    this.updateState({
      powerModalVisible: true,
    });
  }

  async getCustomerAuxCols() {
    const { invoiceType } = this.getState();
    const data = await services.getCustomerAuxCols({
      module: invoiceType === 'vat' ? 2 : 1,
    });
    this.updateState({
      columnsDefine: data,
    });
  }

  async updCustomerAuxCols(state) {
    const { columnsDefine } = state;
    await services.updCustomerAuxCols(columnsDefine);
    message.success('保存成功');
    await this.getCustomerAuxCols();
  }

  async restoreDefaultCustomerCols() {
    const { invoiceType } = this.getState();
    await services.restoreDefaultCustomerCols({
      module: invoiceType === 'vat' ? 2 : 1,
    });
    await this.getCustomerAuxCols();
  }

  async queryAllSubject() {
    const data = await services.queryAllSubject();
    this.updateState({
      allSubject: data.list,
    });
  }

  async queryLeafSubject() {
    const data = await services.queryLeafSubject();
    this.updateState({
      leafSubject: data,
    });
  }

  getGeneralConvertRuleByCondition = () => {
    return services.getGeneralConvertRuleByCondition();
  };

  // 删除发票
  async deleteInvoice(state) {
    const { ids, allIds = [], deleteIds = [] } = state;
    await services.deleteInvoice({ ids });
    message.success(
      deleteIds.length === allIds.length
        ? '所选发票删除成功'
        : '系统自动提取的发票不允许删除，其余发票删除成功！',
    );
    await this.$getList();
  }

  // 清空手动新增发票
  async delManualEntryInvoice() {
    const { query, invoiceType } = this.getState();
    const { endDate } = query;
    await services.delManualEntryInvoice(
      {
        period: endDate.split('-').join(''),
        type: Number(invoiceType !== 'vat'),
      },
      { loading: true },
    );
    await this.$getList();
  }

  // 四要素查验录入
  async manualEntryInvoice(state) {
    const {
      invoiceType,
      query: { endDate },
    } = this.getState();
    await services.manualEntryInvoice(
      {
        period: endDate.split('-').join(''),
        ...state,
        invoiceType: Number(invoiceType !== 'vat'),
      },
      {
        loading: true,
        status: {
          // 确定回调弹窗
          '201': (res) => {
            const tId = res.data;
            ConfirmModal({
              title: `${res.message}`,
              centered: true,
              width: 380,
              okText: '录入',
              cancelText: '不录入',
              onOk: async () => {
                await services.continueCommit({ tId });
                message.success('导入成功！');
                await this.$getList();
              },
            });
          },
          '^300': (res) => {
            message.error(res.message);
          },
        },
      },
    );
    message.success('导入成功！');
    await this.$getList();
  }

  async confirmImportExcelInvoice(payload) {
    const res = await services.confirmImportExcelInvoice(payload);
    this.$getList();
    return res;
  }

  async getInvoiceInfo(state) {
    const { invoiceId, source } = state;
    const data = await services.getInvoiceInfo({ invoiceId });
    const { details } = data;
    while (details.length < 5) {
      details.push({});
    }
    this.updateState({
      manualImportVisible: true,
      manualImportState: 'edit',
      manualImportInvoiceSource: source,
      manualImportData: data,
    });
  }

  defendInvoiceInfo = async (state) => {
    await services.defendInvoiceInfo(state, { loading: true });
    return true;
  };

  // 凭证相关
  async queryOriginalVoucher(state) {
    const {
      invoiceType,
      query: { invoiceType: queryInvoiceType },
    } = this.getState();
    // 发票类型改变传参为准
    const { invoiceType: stateInvoiceType } = state || {};
    const invoiceTypes =
      invoiceType === 'vat' && !(stateInvoiceType || queryInvoiceType).includes('3') ? '3' : '1,2';
    const data = await services.queryOriginalVoucher({ templateType: 1, invoiceTypes });
    let { templateList } = data;
    templateList = templateList.map((v) => {
      let { templateLineList } = v;
      const index = templateLineList.findIndex((h) => h.direction === '借');
      const debitObj = templateLineList.find((h) => h.direction === '借');
      if (index > 0) {
        templateLineList.splice(index, 1);
        templateLineList = [debitObj, ...templateLineList];
      }
      return {
        ...v,
        templateLineList,
      };
    });
    this.updateState({
      allTemplateList: templateList,
    });
    return templateList;
  }

  // 获取明细单个
  async fpcyEntryInvoiceList(state) {
    const { checkCodeProps } = this.getState();
    await services.fpcyEntryInvoiceList(state, { loading: true });
    this.updateState({
      checkCodeProps: {
        ...checkCodeProps,
        checkCodeVisible: false,
      },
    });
    message.success('发票明细已更新');
    await this.$getList('noReset');
  }

  // 获取明细批量
  async batchFpcyEntryInvoiceList(state) {
    const { invoiceIds } = state;
    const { invoiceType } = this.getState();
    const { endDate } = this.getState().query;
    const accountPeriod = Number(endDate.split('-').join(''));
    const data = await services.batchFpcyEntryInvoiceList(
      { invoiceIds, accountPeriod, invoiceType: Number(invoiceType !== 'vat') },
      { loading: true },
    );
    await this.getFpcyProcess(data);
    // const { message: msg } = data;
    // message.success(msg || '发票明细已更新');
    // await this.$getList();
  }

  async getFpcyProcess(resultKey) {
    setTimeout(async () => {
      const data = await services.getFpcyProcess({ resultKey });
      const { failCount, successCount, totalCount } = data;
      this.updateState({
        isShowProgress: failCount + successCount < totalCount,
        isShowFpcyModal: failCount + successCount === totalCount && failCount > 0,
        progressArgs: data,
      });
      if (failCount + successCount < totalCount) {
        this.getFpcyProcess(resultKey);
      } else if (failCount === 0) {
        message.success('发票明细已更新');
        this.$getList('noReset');
      }
    }, 1000);
  }

  // 开票限额提醒
  async getVatInvoiceLimitSetting() {
    const data = await services.getVatInvoiceLimitSetting();
    this.updateState({
      limitSetting: data,
    });
  }

  async updateVatInvoiceLimitSetting() {
    const { limitSetting } = this.getState();
    await services.updateVatInvoiceLimitSetting(limitSetting);
    message.success('开票限额设置成功');
    await this.$getList();
  }

  // 补充销项开票分机号
  async replenishMachineNo(state) {
    await services.replenishMachineNo(state, { loading: true });
    message.success('开票机号补充成功');
    await this.$getList('noReset');
  }

  async isPageSize() {
    const isPageSize = util.getPageSize();
    const { paginationProps } = this.getState();

    await this.updateState({
      paginationProps: {
        ...paginationProps,
        pageSize: isPageSize,
      },
    });
  }

  periodWrong(payload) {
    let {
      query: { endDate },
    } = this.getState();
    const {
      account: {
        currentDate,
        isCheckOut,
        user: { currentTime },
      },
    } = store.getState();
    const { endDate: payloadEndDate } = payload || {};
    endDate = endDate || payloadEndDate;
    const currentTimeValue = moment(currentTime, 'YYYY-MM').valueOf(); // 当前自然月时间戳
    const currentDateValue = moment(currentDate, 'YYYY-MM').valueOf(); // 当前期间的时间戳
    const endDateValue = moment(endDate, 'YYYY-MM').valueOf(); // 选择时间的时间戳
    let isPeriodWrong = false;
    if (currentTimeValue > currentDateValue) {
      // 自然月大于当前期间
      if (endDateValue >= currentDateValue && endDateValue <= currentTimeValue) {
        isPeriodWrong = true;
      }
    } else if (endDateValue === currentTimeValue && currentDateValue <= currentTimeValue) {
      // 自然月小于或等于当前会计期间
      isPeriodWrong = true;
    }
    if (isCheckOut === true && currentDateValue === endDateValue) {
      isPeriodWrong = false;
    }
    this.updateState({
      isPeriodWrong,
      isCheckOutDate: endDateValue < currentDateValue,
    });
  }

  // 初始化页面
  async initData() {
    // 初始化页码
    this.isPageSize();
    // extractType
    const { invoiceType } = this.getState();
    const {
      account: { extractType },
    } = store.getState();
    this.initPeriod();
    if (extractType === 0) {
      await this.getAuthState();
    }
    await this.getCustomerAuxCols();
    await this.queryLeafSubject();
    await this.queryAllSubject();
    await this.queryOriginalVoucher();
    invoiceType === 'vat' && (await this.getVatInvoiceLimitSetting());
    await this.getVoucherBuildSetting();
    await this.queryCommonly('init');
    await this.extractEntryInvoiceList('init');
    await this.periodWrong();
  }
}
