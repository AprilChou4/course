import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import '../../../css/voucherForm.less';

const nameArr = ['', '发票号码', '开票日期', '发票内容', '客商信息', '价税合计', '自定义摘要'];
const VoucherForm = ({ voucherBuildSetting, invoiceType }) => {
  const {
    buildSummary,
    isSaveSpec,
    buildMode,
    isAmtMerge,
    isAmtTaxMerge,
    isTaxMerge,
    buildLineSort,
    buildVoucherDate,
  } = voucherBuildSetting;
  const buildSummaryArray = useMemo(() => (buildSummary || '').split(','), [buildSummary]);
  const [buildVoucherDate1, buildVoucherDate2] = useMemo(
    () => (buildVoucherDate || '0,0').split(','),
    [buildVoucherDate],
  );
  return (
    <div className="pop-over">
      <p className="pop-over-p1">
        摘要组合：
        {buildSummaryArray.map((v) => {
          let name = '';
          if (['1', '2', '3', '4', '5', '6'].includes(v)) {
            name = nameArr[v];
          }
          return (
            <span key={v} style={{ marginRight: 5 }}>
              {name}
            </span>
          );
        })}
      </p>
      <p className="pop-over-p1">
        存货设置：{isSaveSpec === 0 ? '规格型号系统不带出' : '规格型号系统带出'}
      </p>
      <p className="pop-over-p2">
        生成方式：
        {buildMode === 1 && <span style={{ marginRight: 5 }}>每张发票生成一张凭证</span>}
        {buildMode === 2 && <span style={{ marginRight: 5 }}>所有发票生成一张凭证</span>}
        {buildMode === 3 && <span style={{ marginRight: 5 }}>相同单位生成一张凭证</span>}
        {buildMode === 4 && <span style={{ marginRight: 5 }}>相同日期生成一张凭证</span>}
        {buildMode === 5 && <span style={{ marginRight: 5 }}>同单位同日期生成一张凭证</span>}
      </p>
      <p className="pop-over-p2">
        分录显示顺序：
        {buildLineSort === 2 ? '一借一贷' : '先借后贷'}
      </p>

      {isAmtMerge || isTaxMerge || isAmtTaxMerge ? (
        <p className="pop-over-p2">
          相同科目分录汇总：
          {isAmtMerge ? <span style={{ marginRight: 5 }}>金额科目汇总</span> : null}
          {isTaxMerge ? <span style={{ marginRight: 5 }}>税额科目汇总</span> : null}
          {isAmtTaxMerge ? <span style={{ marginRight: 5 }}>价税合计科目汇总</span> : null}
        </p>
      ) : null}
      {invoiceType !== 'vat' ? (
        <>
          <p className="pop-over-p2">
            凭证日期设置--发票日期在当前会计期间：
            {buildVoucherDate1 === '0' && <span>当月最后一天</span>}
            {buildVoucherDate1 === '1' && <span>发票日期</span>}
            {buildVoucherDate1 === '2' && <span>系统当前日期</span>}
          </p>
          <p className="pop-over-p2">
            凭证日期设置--发票日期不在当前会计期间：
            {buildVoucherDate2 === '0' && <span>当月最后一天</span>}
            {buildVoucherDate2 === '2' && <span>系统当前日期</span>}
          </p>
        </>
      ) : (
        <p className="pop-over-p2">
          凭证日期设置--发票日期在当前会计期间：
          {buildVoucherDate1 === '0' && <span>当月最后一天</span>}
          {buildVoucherDate1 === '1' && <span>发票日期</span>}
          {buildVoucherDate1 === '2' && <span>系统当前日期</span>}
        </p>
      )}
    </div>
  );
};
VoucherForm.defaultProps = {
  invoiceType: '',
};
VoucherForm.propTypes = {
  invoiceType: PropTypes.string,
  voucherBuildSetting: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default connect(({ invoiceType, voucherBuildSetting }) => ({
  invoiceType,
  voucherBuildSetting,
}))(VoucherForm);
