/**
 * 生成凭证时新增辅助核算
 */
import { connect } from 'nuomi';
import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';
import { Checkbox, Modal, Button, message, Tooltip } from 'antd';
import './style.less';

const CreateAuxiliary = ({
  dispatch,
  isShowCreateAuxiliary,
  supplierAuxiliaryResponse,
  customerAuxiliaryResponse,
}) => {
  const [auxData, setAuxData] = useState([]);
  useEffect(() => {
    const arr = [];
    const obj = { supplierAuxiliaryResponse, customerAuxiliaryResponse };
    ['customerAuxiliary', 'supplierAuxiliary'].forEach((v) => {
      const Item = obj[`${v}Response`];
      if (Item.auxiliaryTypeId) {
        arr.push({
          ...Item,
          options: Item.auxiliaryNames.map((h) => ({
            name: h,
            checked: true,
          })),
          indeterminate: false,
          checked: true,
          type: `${v}Request`,
        });
      }
    });
    setAuxData(arr);
  }, [supplierAuxiliaryResponse, customerAuxiliaryResponse]);

  const cancelModal = () => {
    dispatch({
      type: 'updateState',
      payload: { isShowCreateAuxiliary: false },
    });
  };

  const onCreate = async () => {
    const params = {};
    let length = 0;
    auxData.forEach((v) => {
      length += v.options.filter((h) => h.checked).length;
      params[v.type] = {
        auxiliaryNames: v.options.filter((h) => h.checked).map((h) => h.name),
        auxiliaryTypeId: v.auxiliaryTypeId,
      };
    });
    if (length < 1) {
      message.error('请至少选择一个新增的客户或供应商');
      return;
    }
    cancelModal();
    dispatch({
      type: 'batchAddAuxiliary',
      payload: {
        ...params,
        cb: () => {
          dispatch({
            type: 'prepareOperation',
            payload: 'auxiliaryNext',
          });
        },
      },
    });
  };

  const cancelCreate = () => {
    cancelModal();
    dispatch({
      type: 'prepareOperation',
      payload: 'auxiliaryNext',
    });
  };

  const modalProps = {
    title: '生成凭证',
    visible: true,
    maskClosable: false,
    width: 500,
    onCancel: cancelModal,
    footer: (
      <div>
        <Button onClick={cancelCreate}>暂不新增</Button>
        <Button type="primary" onClick={onCreate}>
          确定新增
        </Button>
      </div>
    ),
  };

  const checkAll = (id) => {
    let Item = auxData.find((v) => v.auxiliaryTypeId === id);
    Item = {
      ...Item,
      options: Item.options.map((v) => ({ ...v, checked: !Item.checked })),
      indeterminate: false,
      checked: !Item.checked,
    };
    setAuxData(auxData.map((v) => (v.auxiliaryTypeId === id ? Item : v)));
  };

  const checkItem = (val, id) => {
    const Item = auxData.find((v) => v.auxiliaryTypeId === id);
    Item.options = Item.options.map((v) =>
      v.name === val
        ? {
            ...v,
            checked: !v.checked,
          }
        : v,
    );
    const checkedLength = Item.options.filter((v) => v.checked).length;
    setAuxData(
      auxData.map((v) =>
        v.auxiliaryTypeId === id
          ? {
              ...Item,
              indeterminate: checkedLength && checkedLength < Item.auxiliaryNames.length,
              checked: checkedLength === Item.auxiliaryNames.length,
            }
          : v,
      ),
    );
  };

  return isShowCreateAuxiliary ? (
    <Modal styleName="aux-modal" {...modalProps}>
      <p styleName="aux-info">
        未检测到以下
        {auxData.map((item, key) => (
          <em key={item.auxiliaryTypeName}>
            {key > 0 ? '、' : ''}
            {item.auxiliaryTypeName}
          </em>
        ))}
        ，确定后系统将自动为您新增。
      </p>
      {auxData.map((v) => (
        <div styleName="aux-area" key={v.auxiliaryTypeId}>
          <Checkbox
            checked={v.checked}
            indeterminate={v.indeterminate}
            onChange={() => {
              checkAll(v.auxiliaryTypeId);
            }}
          >
            新增{v.auxiliaryTypeName}
          </Checkbox>
          <div styleName="aux-list">
            {v.options.map((h) => (
              <Tooltip placement="topLeft" title={h.name} key={h.name}>
                <div
                  styleName={h.checked ? 'aux-item active' : 'aux-item'}
                  onClick={() => {
                    checkItem(h.name, v.auxiliaryTypeId);
                  }}
                >
                  {h.name}
                </div>
              </Tooltip>
            ))}
          </div>
        </div>
      ))}
    </Modal>
  ) : null;
};

CreateAuxiliary.propTypes = {
  dispatch: PropTypes.func.isRequired,
  isShowCreateAuxiliary: PropTypes.bool.isRequired,
  supplierAuxiliaryResponse: PropTypes.objectOf(PropTypes.any).isRequired,
  customerAuxiliaryResponse: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(
  ({ isShowCreateAuxiliary, supplierAuxiliaryResponse, customerAuxiliaryResponse }) => ({
    isShowCreateAuxiliary,
    supplierAuxiliaryResponse,
    customerAuxiliaryResponse,
  }),
)(CreateAuxiliary);
