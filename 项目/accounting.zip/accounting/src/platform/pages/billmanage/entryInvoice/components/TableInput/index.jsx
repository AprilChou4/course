import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Input } from 'antd';
import './style.less';

const PopoverContent = ({ onBlur, initValue, isError, maxLength }) => {
  const [isBlur, setIsBlur] = useState(false);

  const valueBlur = (e) => {
    const { value } = e.currentTarget;
    setIsBlur(false);
    initValue !== value && onBlur(maxLength ? value.slice(0, maxLength) : value);
  };
  return (
    <div styleName="ywy-table-input">
      {isBlur ? (
        <Input defaultValue={initValue} onBlur={valueBlur} autoFocus style={{ padding: 4 }} />
      ) : (
        <div styleName={isError ? 'show-div error' : 'show-div'} onClick={() => setIsBlur(true)}>
          {initValue}
        </div>
      )}
    </div>
  );
};
PopoverContent.defaultProps = {
  initValue: '',
  isError: false,
  maxLength: undefined,
};
PopoverContent.propTypes = {
  onBlur: PropTypes.func.isRequired,
  isError: PropTypes.bool,
  initValue: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  maxLength: PropTypes.number,
};
export default PopoverContent;
