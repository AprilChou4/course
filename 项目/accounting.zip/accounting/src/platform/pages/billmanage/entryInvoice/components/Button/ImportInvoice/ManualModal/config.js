export const allKeys = [
  'taxName',
  'invoiceContent',
  'model',
  'unit',
  'number',
  'price',
  'amt',
  'tax',
  'taxRate',
];
export const mustKeys = ['taxName', 'invoiceContent', 'amt', 'tax', 'taxRate'];
