import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Menu } from 'antd';
import Ico from '@/Icon';
import Delete from '@/buttons/SearchButton/Delete';
import './style.less';

const CommonlyConditions = ({
  commonlyId,
  commonlyList,
  getContent,
  onSelect,
  onSearch,
  onReset,
  onSave,
  onDelete,
  onDefault,
  ...rest
}) => {
  const { showPreset } = rest;
  const [isOpen, setIsOpen] = useState(false);
  // const [commonlyId, setCommonlyId] = useState('0');
  const [isDefault, setIsDefault] = useState(0);
  useEffect(() => {
    const { isDefault: newIsDefault } = commonlyList.find((v) => v.commonlyId === commonlyId) || {
      isDefault: false,
    };
    setIsDefault(newIsDefault);
  }, [commonlyId, commonlyList]);

  const deleteCnd = (data) => {
    onDelete({ commonlyId: data.commonlyId });
  };

  const setDefault = () => {
    onDefault({
      commonlyId,
      isDefault: Number(!isDefault),
    });
  };

  const menuClick = (e) => {
    const {
      key,
      item: {
        props: { data },
      },
    } = e;
    // setCommonlyId(key);
    // data && setIsDefault(data.isDefault);
    onSelect && onSelect(key, data);
  };
  return (
    <div styleName="commonly-conditions">
      {commonlyList.length > 0 && (
        <div styleName="conditions-list">
          <div>
            <Button
              type="link"
              icon={isOpen ? 'double-left' : 'double-right'}
              className="conditions-btn"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? '收起' : '展开'}
            </Button>
          </div>
          <Menu selectedKeys={[commonlyId ? commonlyId.toString() : '0']} onClick={menuClick}>
            {showPreset && (
              <Menu.Item key="0">
                <span>预置</span>
              </Menu.Item>
            )}
            {commonlyList.map((ele) => (
              <Menu.Item key={ele.commonlyId} data={ele}>
                <span>{ele.commonlyName}</span>
                <Delete data={ele} onDelete={deleteCnd} />
              </Menu.Item>
            ))}
          </Menu>
        </div>
      )}

      <div
        styleName="conditions-contain"
        style={{ display: isOpen || commonlyList.length === 0 ? 'block' : 'none' }}
      >
        {getContent()}
        {!!isDefault && <Ico type="default" />}
        <div styleName="bottom-buttons">
          {commonlyId !== '0' && commonlyList.length > 0 && (
            <Button onClick={setDefault}>{isDefault ? '取消默认' : '设为默认'}</Button>
          )}
          <Button onClick={onSave}>
            {commonlyId && commonlyId !== '0' && commonlyList.length > 0
              ? '另存为常用条件'
              : '存为常用条件'}
          </Button>
          <Button onClick={onReset}>重置</Button>
          <Button type="primary" onClick={onSearch}>
            查询
          </Button>
        </div>
      </div>
    </div>
  );
};
CommonlyConditions.defaultProps = {
  showPreset: true,
};
CommonlyConditions.propTypes = {
  commonlyId: PropTypes.string.isRequired,
  commonlyList: PropTypes.arrayOf(PropTypes.any).isRequired,
  getContent: PropTypes.func.isRequired,
  onSelect: PropTypes.func.isRequired,
  onSearch: PropTypes.func.isRequired,
  onReset: PropTypes.func.isRequired,
  onSave: PropTypes.func.isRequired,
  onDelete: PropTypes.func.isRequired,
  onDefault: PropTypes.func.isRequired,
  showPreset: PropTypes.bool,
};
export default CommonlyConditions;
