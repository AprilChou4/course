import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import moment from 'moment';
import { Form, DatePicker, Input, Row, Col, Select, message } from 'antd';
import InputNumber from '@/NumberInput';
import { invoiceStateData } from '../../../static';
import { allKeys, mustKeys } from './config';
import './style.less';

const { Option } = Select;
const fieldsName = [
  'date',
  'invoiceCode',
  'invoiceNumber',
  'invoiceState',
  'auxiliaryName',
  'effectiveTax',
  'remarks',
  'machineNo',
  'taxTotal',
];
const formItemCol = {
  labelCol: { span: 10 },
  wrapperCol: { span: 14 },
};
const defaultDetails = [
  { lineSort: 1 },
  { lineSort: 2 },
  { lineSort: 3 },
  { lineSort: 4 },
  { lineSort: 5 },
];
const setFormData = (formData) => {
  const obj = {};
  fieldsName.forEach((v) => {
    if (v === 'date') {
      obj[v] = moment(formData[v]);
    } else if (v === 'invoiceState') {
      obj[v] = `${formData[v]}`;
    } else {
      obj[v] = formData[v];
    }
  });
  return obj;
};
const ManualForm = ({
  modal,
  invoiceType,
  manualImportState,
  manualImportData,
  endDate,
  manualImportInvoiceSource,
  dateValue,
  currentTime,
  form,
  dispatch,
}) => {
  const [originalData, setOriginalData] = useState({ details: defaultDetails });
  const [modalType, setModalType] = useState('add');
  const setManualImportData = (obj) => {
    dispatch({
      type: 'updateState',
      payload: {
        manualImportData: obj,
      },
    });
  };
  const clearModal = () => {
    form.resetFields();
    setManualImportData({
      ...manualImportData,
      details: defaultDetails,
      type: manualImportData.type ? manualImportData.type : 's',
      invoiceId: '',
      taxTotal: '',
      invoiceType: Number(invoiceType !== 'vat'),
      accountPeriod: dateValue ? dateValue.split('-').join('') : endDate.split('-').join(''),
    });
  };
  useEffect(() => {
    if (manualImportState === 'reset') {
      if (modalType === 'add') {
        clearModal();
      } else {
        form.setFieldsValue(setFormData(originalData));
        setManualImportData(originalData);
      }
    }
    if (manualImportState === 'edit') {
      form.setFieldsValue(setFormData(manualImportData));
      setOriginalData(manualImportData);
      setModalType('edit');
    }
    if (['save', 'saveAndAdd'].includes(manualImportState)) {
      form.validateFields((errors, val) => {
        if (!errors) {
          const { details } = manualImportData;
          const tableData = [];
          let tableValidate = true;
          details.forEach((v) => {
            if (allKeys.some((h) => !!v[h])) {
              tableData.push(v);
              if (
                !mustKeys.every(
                  (h) =>
                    (h === 'taxRate' && /^([0-9][0-9]{0,1}|100)$/.test(v[h])) ||
                    ((!!v[h] || v[h] === 0) && h !== 'taxRate'),
                )
              ) {
                tableValidate = false;
              }
            }
          });
          if (!tableValidate) {
            return;
          }
          if (tableData.length < 0) {
            message.error('请至少维护一条发票明细');
            return;
          }
          dispatch({
            type: 'defendInvoiceInfo',
            payload: {
              ...manualImportData,
              ...val,
              details: tableData,
              date: val.date.format('YYYY-MM-DD'),
            },
          }).then((res) => {
            if (!res) {
              dispatch({
                type: 'updateState',
                payload: {
                  manualImportState: '',
                },
              });
              return;
            }
            message.success('保存成功！');
            const initialObj =
              manualImportState !== 'save'
                ? {
                    invoiceId: '',
                    taxTotal: '',
                    invoiceType: Number(invoiceType !== 'vat'),
                    accountPeriod: dateValue.split('-').join(''),
                  }
                : {};
            manualImportState !== 'save' && setModalType('add');
            dispatch({
              type: 'updateState',
              payload: {
                manualImportState: manualImportState !== 'save' ? 'reset' : '',
                manualImportData: {
                  ...manualImportData,
                  ...initialObj,
                },
              },
            });
            dispatch({ type: '$getList', payload: 'keepSelects' });
          });
        }
      });
    }
  }, [manualImportState]);
  const onFormChange = () => {
    dispatch({ type: 'updateState', payload: { manualImportState: '' } });
  };
  return (
    <Form style={{ overflow: 'hidden' }}>
      <Col span={8}>
        <Form.Item label="开票日期" {...formItemCol}>
          {form.getFieldDecorator('date', {
            rules: [{ required: true, message: '开票日期不能为空' }],
          })(
            <DatePicker
              style={{ width: '100%' }}
              onChange={onFormChange}
              defaultPickerValue={moment(dateValue)}
              disabled={[1, 2].includes(manualImportInvoiceSource)}
              disabledDate={(value) => {
                if (invoiceType === 'vat') {
                  return dateValue !== value.format('YYYY-MM');
                }
                return currentTime < value.format('YYYY-MM-DD');
              }}
            />,
          )}
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="发票代码" {...formItemCol}>
          {form.getFieldDecorator('invoiceCode', {
            rules: [
              { required: true, message: '发票代码不能为空' },
              { min: 10, message: '发票代码为10-12位数字' },
            ],
            normalize: (val) => {
              return val ? val.replace(/[^\d]/gi, '').slice(0, 12) : '';
            },
          })(
            <Input
              placeholder="10或12位数字"
              style={{ width: '100%' }}
              onChange={onFormChange}
              autoComplete="off"
              disabled={modalType === 'edit' || [1, 2].includes(manualImportInvoiceSource)}
            />,
          )}
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="发票号码" {...formItemCol}>
          {form.getFieldDecorator('invoiceNumber', {
            rules: [
              { required: true, message: '发票号码不能为空' },
              { min: 8, message: '发票号码为8位数字' },
            ],
            normalize: (val) => {
              return val ? val.replace(/[^\d]/gi, '').slice(0, 8) : '';
            },
          })(
            <Input
              placeholder="8位数字"
              style={{ width: '100%' }}
              onChange={onFormChange}
              autoComplete="off"
              disabled={modalType === 'edit' || [1, 2].includes(manualImportInvoiceSource)}
            />,
          )}
        </Form.Item>
      </Col>
      <Col span={8}>
        {invoiceType !== 'vat' ? (
          <Form.Item label="发票状态" {...formItemCol}>
            {form.getFieldDecorator('invoiceState', {
              rules: [{ required: true, message: '发票状态不能为空' }],
              normalize: (val) => {
                return val ? val.toString() : '';
              },
            })(
              <Select
                placeholder="请选择发票状态"
                style={{ width: '100%' }}
                onChange={onFormChange}
                disabled={[1, 2].includes(manualImportInvoiceSource)}
              >
                {invoiceStateData
                  .filter((v) => v.value !== '6' && v.value !== '2')
                  .map((v) => (
                    <Option key={v.key} value={v.value}>
                      {v.title}
                    </Option>
                  ))}
              </Select>,
            )}
          </Form.Item>
        ) : (
          <Form.Item label="开票机号" {...formItemCol}>
            {form.getFieldDecorator('machineNo', {
              normalize: (val) => {
                return val ? val.replace(/[\D]/gi, '').slice(0, 10) : '';
              },
            })(
              <Input
                style={{ width: '100%' }}
                onChange={onFormChange}
                autoComplete="off"
                disabled={[1, 2].includes(manualImportInvoiceSource)}
              />,
            )}
          </Form.Item>
        )}
      </Col>
      <Col span={16}>
        <Form.Item
          label={invoiceType !== 'vat' ? '供应商名称' : '客户名称'}
          labelCol={{ span: 5 }}
          wrapperCol={{ span: 19 }}
        >
          {form.getFieldDecorator('auxiliaryName', {
            rules: [
              {
                required: true,
                message: invoiceType !== 'vat' ? '供应商名称不能为空' : '客户名称不能为空',
              },
            ],
            normalize: (val) => {
              return val ? val.slice(0, 100) : '';
            },
          })(
            <Input
              placeholder={invoiceType !== 'vat' ? '供应商名称不能为空' : '客户名称不能为空'}
              style={{ width: '100%' }}
              onChange={onFormChange}
              autoComplete="off"
              disabled={[1, 2].includes(manualImportInvoiceSource)}
            />,
          )}
        </Form.Item>
      </Col>
      <Row style={{ marginTop: modal ? 368 : 388 }} className="manual-form-bottom">
        {invoiceType !== 'vat' && (
          <Col span={8}>
            <Form.Item label="有效税额" {...formItemCol}>
              {form.getFieldDecorator('effectiveTax')(
                <InputNumber
                  placeholder="请输入有效税额"
                  style={{ width: '100%' }}
                  onChange={onFormChange}
                  disabled={[1, 2].includes(manualImportInvoiceSource)}
                  precision={2}
                />,
              )}
            </Form.Item>
          </Col>
        )}
        <Col span={invoiceType !== 'vat' ? 16 : 24}>
          <Form.Item
            label="备注"
            labelCol={{ span: invoiceType !== 'vat' ? 5 : 2 }}
            wrapperCol={{ span: invoiceType !== 'vat' ? 19 : 22 }}
          >
            {form.getFieldDecorator('remarks', {
              normalize: (val) => {
                return val ? val.slice(0, 200) : '';
              },
            })(
              <Input
                placeholder="请输入备注"
                style={{ width: '100%' }}
                onChange={onFormChange}
                autoComplete="off"
                disabled={[1, 2].includes(manualImportInvoiceSource)}
              />,
            )}
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};
ManualForm.defaultProps = {
  invoiceType: '',
  dateValue: '',
  endDate: '',
};
ManualForm.propTypes = {
  modal: PropTypes.number.isRequired,
  invoiceType: PropTypes.string,
  dateValue: PropTypes.string,
  manualImportState: PropTypes.string.isRequired,
  manualImportData: PropTypes.objectOf(PropTypes.any).isRequired,
  manualImportInvoiceSource: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  endDate: PropTypes.string,
  currentTime: PropTypes.string.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(
  (
    {
      invoiceType,
      manualImportState,
      manualImportData,
      manualImportInvoiceSource,
      query: { endDate },
    },
    {
      account: {
        user: { currentTime },
      },
    },
  ) => ({
    endDate,
    invoiceType,
    manualImportState,
    manualImportData,
    manualImportInvoiceSource,
    currentTime,
  }),
)(Form.create()(ManualForm));
