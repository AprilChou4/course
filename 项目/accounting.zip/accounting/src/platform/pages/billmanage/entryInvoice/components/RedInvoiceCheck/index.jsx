import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Radio, Button } from 'antd';
import util from 'util';
import './style.less';

const radioStyle = {
  display: 'block',
  height: '30px',
  lineHeight: '30px',
};
const RedInvoiceCheck = ({
  isShowRedInvoiceCheck,
  redInvoices,
  createVoucherCondition,
  dispatch,
}) => {
  const [radioValue, setRadioValue] = useState([]);
  useEffect(() => {
    setRadioValue(
      redInvoices.map((v) => {
        if (v.blueInvoices && v.blueInvoices.length > 0) {
          return v.blueInvoices[0].invoiceId;
        }
        return '0';
      }),
    );
  }, [redInvoices]);
  const cancelModal = () => {
    dispatch({ type: 'updateState', payload: { isShowRedInvoiceCheck: false } });
  };
  const skipModal = () => {
    cancelModal();
    dispatch({ type: 'prepareVoucherCommon', payload: createVoucherCondition });
  };
  const sureModal = () => {
    const list = [];
    const filterList = [];
    radioValue.forEach((v, i) => {
      if (v !== '0') {
        list.push({
          invoiceId: redInvoices[i].invoiceId,
          blueInvoiceId: v,
        });
        filterList.push(redInvoices[i].invoiceId);
      }
    });
    if (list.length > 0) {
      dispatch({ type: 'prepareVoucherCommon', payload: { ...createVoucherCondition, list } });
      cancelModal();
    } else {
      skipModal();
    }
  };
  const modalProps = {
    title: '红蓝发票勾稽',
    visible: isShowRedInvoiceCheck,
    destroyOnClose: true,
    width: 460,
    bodyStyle: { padding: '0' },
    maskClosable: false,
    onCancel: cancelModal,
    footer: (
      <>
        <Button onClick={cancelModal}>取消</Button>
        <Button onClick={skipModal}>跳过</Button>
        <Button type="primary" onClick={sureModal}>
          确定
        </Button>
      </>
    ),
  };
  const radioGroupChange = (e, index) => {
    const { value } = e.target;
    setRadioValue(radioValue.map((v, i) => (i === index ? value : v)));
  };
  return (
    <Modal {...modalProps}>
      <div styleName="red-invoice-check">
        {redInvoices.map((v, i) => {
          return (
            <React.Fragment key={v.invoiceId}>
              <div styleName="red-invoice-title">
                请选择<span styleName="invoice-number">{v.invoiceNumber}</span>
                发票对应的蓝字发票：
              </div>
              <Radio.Group value={radioValue[i]} onChange={(e) => radioGroupChange(e, i)}>
                {v.blueInvoices.map((h) => (
                  <Radio
                    key={`${v.invoiceId},${h.invoiceId}`}
                    style={radioStyle}
                    value={h.invoiceId}
                  >
                    <span className="invoice-info">日期：{h.date}</span>
                    <span className="invoice-info">发票：{h.invoiceNumber}</span>
                    <span className="invoice-info">价税合计：{util.toFixed(h.taxTotal, 2)}</span>
                  </Radio>
                ))}
                <Radio value="0">未找到对应的蓝字发票</Radio>
              </Radio.Group>
            </React.Fragment>
          );
        })}
      </div>
    </Modal>
  );
};
RedInvoiceCheck.propTypes = {
  isShowRedInvoiceCheck: PropTypes.bool.isRequired,
  redInvoices: PropTypes.arrayOf(PropTypes.any).isRequired,
  createVoucherCondition: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ isShowRedInvoiceCheck, redInvoices, createVoucherCondition }) => ({
  isShowRedInvoiceCheck,
  redInvoices,
  createVoucherCondition,
}))(RedInvoiceCheck);
