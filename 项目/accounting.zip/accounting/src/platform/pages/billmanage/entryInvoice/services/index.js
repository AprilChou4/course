import util from 'util';
// import mock from './mock';

export default util.createRequest({
  // 查询进销项生成凭证设置
  getVoucherBuildSetting: 'invoice/setting/getVoucherBuildSetting',
  // 更新进销项生成凭证设置
  updateVoucherBuildSetting: 'invoice/setting/updateVoucherBuildSetting:postJSON',
  // 填写授权码
  addAuthCodeRelation: 'invoice/auth/addAuthCodeRelation:post',
  autoAuthCodeRelation: 'invoice/auth/autoAuthCodeRelation:post',
  // 判断授权情况
  getAuthState: 'invoice/auth/getAuthState',
  expireAuthState: 'invoice/auth/expireAuthState', // 解除授权
  // 进项发票提取
  extractEntryInvoiceList: 'invoice/bill/extractEntryInvoiceList',
  extractVATInvoiceList: 'invoice/vat/extractVATInvoiceList:post',
  // 批量获取明细
  batchFpcyEntryInvoiceList: 'invoice/bill/batchFpcyEntryInvoiceList:postJSON',
  getFpcyProcess: 'invoice/bill/getFpcyProcess',
  // 单个获取明细
  fpcyEntryInvoiceList: 'invoice/bill/fpcyEntryInvoiceList:post',
  // 进项发票列表
  getEntryInvoiceList: 'invoice/bill/getEntryInvoiceList:postJSON',
  getVatInvoiceList: 'invoice/vat/getVatInvoiceList:postJSON',
  // 发票删除
  deleteInvoice: 'invoice/bill/delInvoice:post',
  delManualEntryInvoice: 'invoice/bill/delManualEntryInvoice:post',
  // 按发票号码和代码查询发票
  queryInvoiceByCodeAndNumber: 'invoice/bill/queryInvoiceInfo:post',

  // 校验发票税号是否和账套一致
  checkTaxNumber: 'invoice/bill/checkTaxNumber:postJSON',
  // 生成凭证预处理
  prepareVoucher: 'invoice/bill/prepareVoucher:postJSON',
  // 存辅助核算
  batchAddAuxiliary: 'invoice/bill/batchAddAuxiliary:postJSON',
  // 生成凭证
  createVoucher: 'invoice/bill/createVoucher:postJSON',

  // 获取所有末级科目
  queryLeafSubject: 'account/subject/queryLeafSubject',
  // 获取所有科目
  queryAllSubject: 'account/subject/list',
  // 获取所有存货辅助核算
  getStockAuxiliaryList: 'account/auxiliary/getStockAuxiliaryList', // 'invoice/bill/getStockAuxiliaryList', //
  getGeneralConvertRuleByCondition: 'invoice/bill/getGeneralConvertRuleByCondition',

  // 查询原始凭证列表
  queryOriginalVoucher: 'account/originalTemplate/getList',
  // 批量更新进项匹配的模板
  batchUpdateTemplate: 'invoice/bill/batchUpdateTemplate:postJSON',

  // 维护税号
  updateTaxNum: 'invoice/bill/updateTaxNum:post',

  // 二级科目
  batchAdd: 'account/subject/batchAdd:postJSON',
  // 切换模板后判断是否触发模板记忆功能
  getSettings: 'invoice/memory/getSettings.do:postJSON',
  // 开票限额提醒
  getVatInvoiceLimitSetting: 'invoice/vatlimit/getVatInvoiceLimitSetting',
  updateVatInvoiceLimitSetting: 'invoice/vatlimit/updateVatInvoiceLimitSetting:post',

  // 自定义列相关
  getCustomerAuxCols: 'account/auxiliary/getCustomerAuxCols',
  updCustomerAuxCols: 'account/auxiliary/updCustomerAuxCols:postJSON',
  restoreDefaultCustomerCols: 'account/auxiliary/restoreDefaultCustomerCols',

  // 补充销项开票分机号
  replenishMachineNo: 'invoice/vat/replenishMachineNo:postJSON',
  // 四要素查验录入
  manualEntryInvoice: 'invoice/fpcy/manualEntryInvoice:postJSON',
  // 手工录入
  getInvoiceInfo: 'invoice/manualInput/getInvoiceInfo',
  defendInvoiceInfo: 'invoice/manualInput/defendInvoiceInfo:postJSON',
  // 存货新增相关
  getAuxTypeIdByType: 'account/auxiliary/type/getAuxTypeIdByType',
  generateCode: 'account/auxiliary/generateCode', // 存货编码
  getStdClassifies: 'account/auxiliary/classify/getStdClassifies', // 存货类别
  addAuxiliary: 'account/auxiliary/add:postJSON', // 添加辅助核算
  matchStockAuxiliary: 'invoice/bill/matchStockAuxiliary:postJSON', // 匹配存货
  // 红蓝票
  prepareRedInvoiceVoucher: 'invoice/bill/prepareRedInvoiceVoucher:postJSON',
  createRedInvoiceVoucher: 'invoice/bill/createRedInvoiceVoucher:postJSON',

  // 查询常用查询条件
  queryCommonly: 'accountbook/book/commonly/settings',
  // 删除常用查询条件
  deleteCommonly: 'accountbook/book/commonly/deleting:post',
  // 保存常用查询条件
  saveCommonly: 'accountbook/book/commonly/saving:post',
  // 设置常用查询条件为查询条件/非默认查询条件
  defaultCommonly: 'accountbook/book/commonly/default:post',
  // 更新账薄的常用查询条件
  updateCommonly: 'accountbook/book/commonly/updating:post',

  // 存货相关
  // 获取辅助核算类型
  getAuxiliaryTypes: 'account/auxiliary/type/getAuxiliaryTypes:post',
  getUnitList: 'account/unit/list', // 获取单位列表
  getStockAlias: 'account/stockAlias/list', // 查询所有的存货别名
  // generateCode: 'account/auxiliary/generateCode', // 获取编码
  // 类别
  getCategory: 'account/archiveCategory/list',
  // 获取辅助核算
  queryAuxiliaries: 'account/auxiliary/queryAuxiliaries.do:postJSON',

  // 无盘取数
  getNoDiskExtractState: `invoice/bill/getNoDiskExtractState.do`, // 无盘取数数据拉取状态查询
  stopNoDiskExtract: `invoice/bill/stopNoDiskExtract.do`, // 取消无盘取数
  updateTaxInfo: `invoice/bill/updateTaxInfo.do:postJSON`, // 维护登陆信息

  triggerNoDiskExtract: `invoice/bill/triggerNoDiskExtract`,
  addUnit: 'account/unit/add:postJSON', // 新增单位
  updateUnit: 'account/unit/update:postJSON',

  continueCommit: 'invoice/bill/continueCommit:post', // 查验录入 继续提交
  confirmImportExcelInvoice: 'invoice/import/confirmImportExcelInvoice:post', // excel数据继续录入

  wxContinueCommit: 'invoice/wx/continueCommit:postJSON', // 小程序继续录入
  wxGetQRCode: 'invoice/wx/getQRCode', // 获取二维码
  queryWxEnterResult: 'invoice/wx/queryWxEnterResult', // 查询微信扫码录入的票
  clearWxEnterInvoiceCache: 'invoice/wx/clearWxEnterInvoiceCache', // 清空缓存
  // ...mock,
});
