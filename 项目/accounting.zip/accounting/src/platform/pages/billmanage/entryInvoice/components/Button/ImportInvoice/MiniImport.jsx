import React, { useState, useRef, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button, Modal, Icon, message,Input } from 'antd';
import './MiniImport.less';

const ButtonGroup = Button.Group;
const MiniImport = ({ dispatch,dateValue }) => {
  //const childRef = useRef();
  const showDialog = async () => {
    //await dispatch({type: 'miniScanBookInit'})
    //childRef.current?.ref.current?.parentTabStatus?.();
  }
  return (
    <div styleName="button-group-qrcode">
      <Button type="primary" ghost styleName="green-qrcode-btn" onClick={showDialog}>
        <Icon type="qrcode" />
        微信小程序录入
      </Button>
      {/* <MiniScanBookModal ref={childRef} dateValue={dateValue}/> */}
    </div>
  );
};
MiniImport.propTypes = {
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ }) => ({
}))(MiniImport);
