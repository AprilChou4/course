import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Select } from 'antd';
import { invoiceTypeData } from '../../../static';
import './style.less';

const ManualImport = ({ dateValue, invoiceType, manualImportData, endDate, dispatch }) => {
  const [type, setType] = useState('s');

  const invoiceTypeDataSource = invoiceTypeData.filter((v) => {
    if (invoiceType === 'vat') {
      return ['4', '14', '6', '7', '8', '9'].includes(v.value);
    }
    return ['3', '4', '5', '6', '7', '8', '9'].includes(v.value);
  });

  const handleSelectChange = (value) => {
    setType(value);
    dispatch({
      type: 'updateState',
      payload: {
        manualImportInvoiceSource: '',
        manualImportData: {
          ...manualImportData,
          type: value,
          invoiceType: Number(invoiceType !== 'vat'),
          accountPeriod: dateValue ? dateValue.split('-').join('') : endDate.split('-').join(''),
        },
      },
    });
  };

  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        manualImportState: 'reset',
        manualImportInvoiceSource: '',
        manualImportData: {
          ...manualImportData,
          type: 's',
          invoiceId: '',
          taxTotal: '',
          invoiceType: Number(invoiceType !== 'vat'),
          accountPeriod: dateValue ? dateValue.split('-').join('') : endDate.split('-').join(''),
        },
      },
    });
    setType('s');
  }, [dateValue]);

  return (
    <Select
      placeholder="请选择发票"
      optionFilterProp="children"
      showSearch
      // allowClear
      onChange={handleSelectChange}
      value={type}
      style={{ width: '150px' }}
    >
      {invoiceTypeDataSource.map((v) => (
        <Select.Option key={v.key} value={v.sign}>
          {v.title}
        </Select.Option>
      ))}
    </Select>
  );
};
ManualImport.defaultProps = {
  invoiceType: '',
  endDate: '',
};
ManualImport.propTypes = {
  dateValue: PropTypes.string.isRequired,
  invoiceType: PropTypes.string,
  manualImportData: PropTypes.objectOf(PropTypes.any).isRequired,
  endDate: PropTypes.string,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ invoiceType, manualImportData, query: { endDate } }) => ({
  invoiceType,
  manualImportData,
  endDate,
}))(ManualImport);
