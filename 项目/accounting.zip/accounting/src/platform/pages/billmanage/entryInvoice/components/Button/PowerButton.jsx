import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Button } from 'antd';
import EmpowerNextModal from '../Layer/EmpowerNext';

const PowerButton = ({ noPower, isPeriodWrong, powerModalVisible, dispatch }) => {
  const applyPower = () => {
    if (noPower === 1) {
      dispatch({ type: 'TaxNumInfo' });
    } else if (noPower === 2) {
      dispatch({ type: 'empowerInfoNext' });
    }
  };

  return (
    <>
      <Button type="primary" className="e-ml5" onClick={applyPower} disabled={!isPeriodWrong}>
        申请授权
      </Button>
      {powerModalVisible && <EmpowerNextModal />}
    </>
  );
};
PowerButton.propTypes = {
  noPower: PropTypes.oneOfType([PropTypes.bool, PropTypes.number]).isRequired,
  isPeriodWrong: PropTypes.bool.isRequired,
  powerModalVisible: PropTypes.bool.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ noPower, isPeriodWrong, powerModalVisible }) => ({
  noPower,
  isPeriodWrong,
  powerModalVisible,
}))(PowerButton);
