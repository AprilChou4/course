import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import { Modal, Input, message } from 'antd';

const CheckCode = ({ checkCodeProps, dispatch }) => {
  const { checkCodeVisible } = checkCodeProps;
  const [isComplete, setIsComplete] = useState(false);
  useEffect(() => {
    if (!checkCodeVisible) {
      setIsComplete(false);
    }
  }, [checkCodeVisible]);
  const cancelCheckCode = () => {
    dispatch({
      type: 'updateState',
      payload: {
        checkCodeProps: {
          ...checkCodeProps,
          checkCodeVisible: false,
        },
      },
    });
    if (isComplete) {
      dispatch({ type: '$getList', payload: 'noReset' });
    }
  };

  const completeInvoice = () => {
    const { invoiceId, checkCode } = checkCodeProps;
    if (!checkCode) {
      message.error('校验码不能为空');
      return;
    }
    if (checkCode.length < 6) {
      message.error('请输入正确的验证码');
      return;
    }
    setIsComplete(true);
    dispatch({
      type: 'fpcyEntryInvoiceList',
      payload: {
        invoiceId,
        checkCode,
      },
    });
  };

  const checkCodeChange = (e) => {
    const { value } = e.currentTarget;
    dispatch({
      type: 'updateState',
      payload: {
        checkCodeProps: {
          ...checkCodeProps,
          checkCode: value.replace(/[^\d]/gi, '').slice(0, 6),
        },
      },
    });
  };

  return (
    <Modal
      visible={checkCodeVisible}
      title="校验码录入"
      width={320}
      okText="补全发票"
      onCancel={cancelCheckCode}
      onOk={completeInvoice}
    >
      <div>
        请输入发票校验码后六位：
        <Input style={{ width: 90 }} value={checkCodeProps.checkCode} onChange={checkCodeChange} />
      </div>
    </Modal>
  );
};
CheckCode.propTypes = {
  checkCodeProps: PropTypes.objectOf(PropTypes.any).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(({ checkCodeProps }) => ({ checkCodeProps }))(CheckCode);
