import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'nuomi';
import Pagination from '@/Pagination';
import util from 'util';
import '../../css/index.less';

const CustomPagination = ({ current, pageSize, total, dispatch }) => {
  const onShowSizeChange = (newCurrent, newPageSize) => {
    const { hash } = window.location;
    const pageSizeList = JSON.parse(localStorage.getItem('_pageSizeList') || '{}');
    const newPageSizeList = { ...pageSizeList, [`${hash}s${util.getAccountToken()}`]: newPageSize };
    localStorage.setItem('_pageSizeList', JSON.stringify(newPageSizeList));
    dispatch({
      type: 'updateTransformInvoicePagination',
      payload: {
        current: 1,
        pageSize: newPageSize,
      },
    });
  };

  const onChange = (newCurrent) => {
    dispatch({
      type: 'updateTransformInvoicePagination',
      payload: {
        current: newCurrent,
      },
    });
  };

  return (
    <Pagination
      style={{ marginTop: 10 }}
      pageSizeOptions={['15', '30', '50', '100']}
      onShowSizeChange={onShowSizeChange}
      onChange={onChange}
      current={current}
      total={total}
      pageSize={pageSize}
    />
  );
};
CustomPagination.propTypes = {
  current: PropTypes.number.isRequired,
  pageSize: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(
  ({
    transformInvoiceProps: {
      paginationProps: { current, pageSize, total },
    },
  }) => ({
    current,
    pageSize,
    total,
  }),
)(CustomPagination);
