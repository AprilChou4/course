import React from 'react';
import Proptypes from 'prop-types';
import { connect } from 'nuomi';
import { Icon } from 'antd';
import { renderTableCell } from 'utils';
import { Content } from '@/Layout';
import SuperTable from '@/SuperTable';
import TableCell from '@/TableCell';
import Footer from './footer';
import StockModal from '../../../../stock/common/StockModal';
import { superLayer } from '../../../../../public/layer';
import '../../css/index.less';

const invoiceTable = ({
  invoiceNumberDesc,
  dateDesc,
  voucherDesc,
  endDate,
  dataSource,
  selectedRowKeys,
  currentDate,
  dispatch,
}) => {
  const sortChange = (key) => {
    const valueObj = { invoiceNumber: invoiceNumberDesc, date: dateDesc, voucher: voucherDesc };
    const valueArr = ['date', 'invoiceNumber', 'voucher'];
    const obj = {};
    obj[`${key}Desc`] = Number(valueObj[key] === 0);
    dispatch({
      type: 'setTransformInvoiceQuery',
      payload: {
        ...obj,
        invoiceNumberSortFirst: valueArr.indexOf(key),
      },
    });
  };
  const sortElement = (name, key, isDesc) => {
    return (
      <div onClick={() => sortChange(key)} style={{ cursor: 'pointer' }}>
        <span style={{ lineHeight: '38px', verticalAlign: 'bottom', display: 'inline-block' }}>
          {name}
        </span>
        <div style={{ display: 'inline-block' }}>
          <div>
            <Icon
              type="caret-up"
              style={{
                verticalAlign: 'bottom',
                marginBottom: -3,
                color: isDesc === 0 ? '#3f91f1' : '#bfbfbf',
              }}
            />
          </div>
          <div>
            <Icon
              type="caret-down"
              style={{
                verticalAlign: 'top',
                marginTop: -3,
                color: isDesc === 0 ? '#bfbfbf' : '#3f91f1',
              }}
            />
          </div>
        </div>
      </div>
    );
  };

  const onSelectChange = (selectedRowKeysArg, selectedRows) => {
    dispatch({
      type: 'setTransformInvoice',
      payload: {
        selectedRowKeys: selectedRowKeysArg,
        selectedRows,
      },
    });
  };

  const showInvoice = (row) => {
    const { invoiceId } = row;
    dispatch({
      type: 'queryInvoiceByCodeAndNumber',
      payload: {
        invoiceIds: invoiceId,
        success: (data) => {
          StockModal({ invoiceJson: data });
        },
      },
    });
  };

  const toVoucherPage = (voucherId) => {
    superLayer('voucher/record', {
      data: {
        title: '记账凭证',
        voucherId,
        isBillManage: true,
      },
      getVoucherIds: () => dataSource.filter((v) => !!v.voucherId).map((v) => v.voucherId),
      async onDestroy() {
        await dispatch({ type: 'queryTransferOutList', payload: 'noReset' });
      },
    });
  };

  const generateVoucher = (row) => {
    const { invoiceId } = row;
    dispatch({
      type: 'prepareVoucher',
      payload: {
        invoiceType: 1,
        invoiceIdList: [invoiceId],
        accountPeriod: Number(endDate.split('-').join('')),
      },
    });
  };

  const newColumns = [
    {
      title: '发票状态',
      dataIndex: 'invoiceStateName',
      key: 'invoiceStateName',
      align: 'center',
      width: 75,
      minWidth: 70,
      render: renderTableCell('text'),
    },
    {
      title: '发票类型',
      dataIndex: 'typeName',
      key: 'typeName',
      align: 'center',
      width: 100,
      minWidth: 100,
      render: renderTableCell('text'),
    },
    {
      title: sortElement('发票号码', 'invoiceNumber', invoiceNumberDesc),
      dataIndex: 'invoiceNumber',
      key: 'invoiceNumber',
      align: 'center',
      width: 95,
      minWidth: 95,
      render: (value, record) => {
        return (
          <TableCell>
            <span styleName="like-a" onClick={() => showInvoice(record)}>
              {value}
            </span>
          </TableCell>
        );
      },
    },
    {
      title: sortElement('开票日期', 'date', dateDesc),
      dataIndex: 'date',
      key: 'date',
      align: 'center',
      width: 95,
      minWidth: 95,
      render: renderTableCell('text'),
    },
    {
      title: '供应商名称',
      dataIndex: 'auxiliaryName',
      key: 'auxiliaryName',
      width: 215,
      minWidth: 100,
      render: renderTableCell('text'),
    },
    {
      title: '金额',
      dataIndex: 'amt',
      key: 'amt',
      width: 130,
      minWidth: 50,
      align: 'right',
      render: renderTableCell({ type: 'number', showZero: true }),
    },
    {
      title: '税额',
      dataIndex: 'tax',
      key: 'tax',
      className: 'total-line-need-border',
      width: 135,
      minWidth: 50,
      align: 'right',
      render: renderTableCell({ type: 'number', showZero: true }),
    },
    {
      title: '有效税额',
      dataIndex: 'effectiveTax',
      key: 'effectiveTax',
      className: 'total-line-need-border',
      width: 135,
      minWidth: 50,
      align: 'right',
      render: renderTableCell({ type: 'number', showZero: true }),
    },
    {
      title: '价税合计',
      dataIndex: 'taxTotal',
      key: 'taxTotal',
      className: 'total-line-need-border',
      width: 145,
      minWidth: 70,
      align: 'right',
      render: renderTableCell({ type: 'number', showZero: true }),
    },
    {
      title: '凭证模板',
      dataIndex: 'templateName',
      align: 'center',
      key: 'templateName',
      width: 120,
      minWidth: 120,
      render: (val, row) => {
        const { isTotal } = row;
        return (
          inAuth(101) &&
          !isTotal && (
            <TableCell>
              <span>待认证进项转出</span>
            </TableCell>
          )
        );
      },
    },
    {
      title: sortElement('凭证', 'voucherId', voucherDesc),
      dataIndex: 'voucherId',
      align: 'center',
      key: 'voucherId',
      width: 100,
      minWidth: 100,
      render: (value, row) => {
        const { voucherCode, isTotal } = row;
        let HTMLDOM = '';
        if (voucherCode) {
          HTMLDOM = (
            <span styleName="like-a" onClick={() => toVoucherPage(value)}>
              {voucherCode}
            </span>
          );
        } else {
          HTMLDOM =
            endDate === currentDate ? (
              <span styleName="like-a" onClick={() => generateVoucher(row)}>
                生成凭证
              </span>
            ) : (
              <span style={{ color: '#ccc' }}>生成凭证</span>
            );
        }
        return inAuth(101) && !isTotal && <TableCell>{HTMLDOM}</TableCell>;
      },
    },
  ];
  const rowSelection = {
    selectedRowKeys,
    onChange: (selectedRowKeysArg, selectedRows) => {
      if (
        !selectedRowKeysArg.includes('total') &&
        selectedRowKeysArg.length === dataSource.length - 1
      ) {
        selectedRowKeysArg.push('total');
      }
      if (selectedRowKeysArg.includes('total') && selectedRowKeysArg.length === 1) {
        selectedRowKeysArg.pop();
        selectedRows.pop();
      }
      onSelectChange(selectedRowKeysArg, selectedRows);
    },
    getCheckboxProps: (record) => ({
      style: { display: record.isTotal ? 'none' : 'block', borderRightColor: 'transparent' },
      disabled: !!record.voucherId || record.invoiceState === 2,
    }),
  };
  const onRowRender = (record) => {
    return {
      onDoubleClick: () => record.invoiceId && !record.isTotal && showInvoice(record),
    };
  };

  return (
    <Content>
      <SuperTable
        draglast
        dragCell
        noLazyLoading
        className="total-table"
        setRecalculate={new Date().getTime()}
        rowSelection={rowSelection}
        columns={newColumns}
        dataSource={dataSource}
        onRow={(record) => onRowRender(record)}
        footer={() => <Footer />}
        scroll={{ x: '100%' }}
        rowClassName={(record) => {
          const { invoiceState, isTotal } = record;
          let lineClassName = '';
          if (isTotal) {
            lineClassName = 'total-line';
          } else if (invoiceState === 2) {
            lineClassName = 'disabled-line';
          }
          return lineClassName;
        }}
        bordered
        pagination={false}
      />
    </Content>
  );
};
invoiceTable.propTypes = {
  dataSource: Proptypes.arrayOf(Proptypes.any).isRequired,
  selectedRowKeys: Proptypes.arrayOf(Proptypes.any).isRequired,
  invoiceNumberDesc: Proptypes.number.isRequired,
  dateDesc: Proptypes.number.isRequired,
  voucherDesc: Proptypes.number.isRequired,
  endDate: Proptypes.string.isRequired,
  currentDate: Proptypes.string.isRequired,
  dispatch: Proptypes.func.isRequired,
};
export default connect(
  (
    {
      transformInvoiceProps: {
        dataSource,
        selectedRowKeys,
        query: { invoiceNumberDesc, dateDesc, endDate, voucherDesc },
      },
    },
    { account: { currentDate } },
  ) => ({
    dataSource,
    selectedRowKeys,
    invoiceNumberDesc,
    dateDesc,
    voucherDesc,
    endDate,
    currentDate,
  }),
)(invoiceTable);
