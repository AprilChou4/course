import React from 'react';
import { Layout } from '@/Layout';
import Header from './commponents/Header';
import Table from './commponents/Table';

const TransformInvoiceList = ({ ...props }) => {
  return (
    <Layout {...props}>
      <Header />
      <Table />
    </Layout>
  );
};
export default TransformInvoiceList;
