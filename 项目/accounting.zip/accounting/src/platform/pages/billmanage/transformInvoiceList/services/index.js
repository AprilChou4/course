import util from 'util';
// import mock from './mock';

export default util.createRequest({
  queryTransferOutList: 'invoice/bill/getEntryInvoiceList:postJSON',
  // ...mock,
});
