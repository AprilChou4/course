import util from 'util';

const { hash } = window.location;

export default {
  isTransform: false, // 未认证转已认证
  transformInvoiceProps: {
    // 表格数据源
    dataSourceOriginal: {},
    dataSource: [],
    paginationProps: {
      current: 1,
      total: 0,
      pageSize: util.getPageSize(`${hash}s`),
    },
    // 表格选中数据
    selectedRowKeys: [],
    selectedRows: [],
    // 查询条件
    query: {
      invoiceNumberDesc: 0,
      dateDesc: 0,
      voucherDesc: 0,
      invoiceNumberSortFirst: 1,
      endDate: '',
    },
  },
};
