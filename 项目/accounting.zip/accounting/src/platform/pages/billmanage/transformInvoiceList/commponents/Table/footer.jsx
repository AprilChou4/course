import React from 'react';
import Proptypes from 'prop-types';
import { connect } from 'nuomi';
import { formatNumber } from 'utils';
import CustomPagination from './pagination';
import '../../css/index.less';

const Footer = ({ invoiceList, sumTaxTotal, sumAmt, sumTax, sumEffectiveTax, totalCount }) => {
  return (
    <div>
      {invoiceList.length > 0 && (
        <p>
          发票总计{totalCount}张，金额{formatNumber(sumAmt)}元，税额{formatNumber(sumTax)}
          元，有效税额{formatNumber(sumEffectiveTax)}元，价税合计{formatNumber(sumTaxTotal)}元
        </p>
      )}
      {invoiceList.length > 0 && <CustomPagination />}
    </div>
  );
};
Footer.defaultProps = {
  sumTaxTotal: undefined,
  sumAmt: undefined,
  sumTax: undefined,
  sumEffectiveTax: undefined,
  totalCount: undefined,
  invoiceList: [],
};
Footer.propTypes = {
  sumTaxTotal: Proptypes.number,
  sumAmt: Proptypes.number,
  sumTax: Proptypes.number,
  sumEffectiveTax: Proptypes.number,
  totalCount: Proptypes.number,
  invoiceList: Proptypes.arrayOf(Proptypes.any),
};
export default connect(
  ({
    transformInvoiceProps: {
      dataSourceOriginal: { sumTaxTotal, sumAmt, sumTax, sumEffectiveTax, totalCount, invoiceList },
    },
  }) => ({
    invoiceList,
    sumTaxTotal,
    sumAmt,
    sumTax,
    sumEffectiveTax,
    totalCount,
  }),
)(Footer);
