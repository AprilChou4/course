import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect, router } from 'nuomi';
import { Button, message } from 'antd';
import { Head, Center, Title, Left, Right } from '@/Layout';
import Period from '@/Period';
import { ConfirmModal } from '@/modal';
import Icon from '@/Icon';
import '../../css/index.less';

const Header = ({ selectedRows, endDate, account, dispatch }) => {
  const [returnName, setReturnName] = useState('');
  const [maxDates, setMaxDates] = useState([]);
  const {
    currentDate,
    user: { useStatus },
  } = account;
  const maxDatesCreate = (bln) => {
    const { period, currentYear, currentMonth } = account;
    const dates = [];
    period.forEach((v) => {
      dates.push(v);
    });
    if (bln) {
      for (let i = currentYear; i <= currentYear + 1; i += 1) {
        const initMonth = i === currentYear ? currentMonth : 1; // 从1开始或从当前会计期间开始
        let maxMonth = 1;
        if (i === currentYear) {
          maxMonth = 12;
        } else {
          maxMonth =
            currentDate.split('-')[1] > currentMonth ? currentMonth : currentDate.split('-')[1];
        }
        for (let j = initMonth; j <= maxMonth; j += 1) {
          const date = `${i}-${j < 10 ? `0${j}` : j}`;
          if (!dates.includes(date)) {
            dates.push(date);
          }
        }
      }
    }
    setMaxDates(dates);
  };
  useEffect(() => {
    const hashUrl = router.location().url;
    if (hashUrl.includes('entry-invoice')) {
      setReturnName('进项发票');
      maxDatesCreate(true);
    } else if (hashUrl.includes('carryover')) {
      setReturnName('结转');
      maxDatesCreate();
    }
  }, []);

  const periodChange = (e) => {
    dispatch({ type: 'setTransformInvoiceQuery', payload: e });
  };

  const VoucherCreate = (invoiceIdList) => {
    dispatch({
      type: 'prepareVoucher',
      payload: {
        invoiceType: 1,
        invoiceIdList,
        accountPeriod: Number(endDate.split('-').join('')),
      },
    });
  };

  const createVoucher = () => {
    const invoiceIdList = selectedRows
      .filter((v) => v.invoiceId !== 'total')
      .map((v) => v.invoiceId);
    if (invoiceIdList.length < 1) {
      message.error('请选择要生成凭证的发票');
      return;
    }
    if (invoiceIdList.length > 50) {
      ConfirmModal({
        title: '温馨提示',
        content: (
          <div>
            <p style={{ lineHeight: '24px' }}>
              当前您选中了{invoiceIdList.length}
              条数据生成凭证，大批量生成将会造成数据压力，耗时较久。
            </p>
            <p>建议您取消当前操作，重新选择50条数据以内生成，无需漫长等待</p>
          </div>
        ),
        width: 600,
        okText: '继续生成',
        cancelText: '取消',
        onOk: () => {
          VoucherCreate(invoiceIdList);
        },
      });
    } else {
      VoucherCreate(invoiceIdList);
    }
  };

  const returnInvoice = () => {
    dispatch({
      type: 'updateState',
      payload: {
        isTransform: false,
      },
    });
    if (returnName === '结转') {
      dispatch({ type: 'query' });
    }
  };
  return (
    <Head>
      <Center>
        <div styleName="return-btn" onClick={returnInvoice}>
          <Icon type="fanhui1" />
          <span style={{ marginLeft: 5 }}>{`返回${returnName}`}</span>
        </div>
        <Title text="未认证转已认证发票清单" />
      </Center>
      <Left>
        <Period
          periods={maxDates}
          autoChange={false}
          value={endDate}
          limit
          onChange={periodChange}
        />
      </Left>
      <Right>
        {useStatus !== 3 && inAuth() && (
          <Button type="primary" onClick={createVoucher} disabled={currentDate !== endDate}>
            生成凭证
          </Button>
        )}
      </Right>
    </Head>
  );
};
Header.defaultProps = {
  endDate: '',
};
Header.propTypes = {
  account: PropTypes.objectOf(PropTypes.any).isRequired,
  endDate: PropTypes.string,
  selectedRows: PropTypes.arrayOf(PropTypes.object).isRequired,
  dispatch: PropTypes.func.isRequired,
};
export default connect(
  (
    {
      transformInvoiceProps: {
        selectedRows,
        query: { endDate },
      },
    },
    { account },
  ) => ({
    selectedRows,
    endDate,
    account,
  }),
)(Header);
