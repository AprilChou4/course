import VoucherEffects from '../../entryInvoice/effects/voucher';
import services from '../services';

export default class TransformInvoice extends VoucherEffects {
  setTransformInvoice(state) {
    const { transformInvoiceProps } = this.getState();
    this.updateState({
      transformInvoiceProps: {
        ...transformInvoiceProps,
        ...state,
      },
    });
  }

  async setTransformInvoiceQuery(state) {
    const {
      transformInvoiceProps: { query },
    } = this.getState();
    await this.setTransformInvoice({
      query: {
        ...query,
        ...state,
      },
    });
    await this.queryTransferOutList();
  }

  async updateTransformInvoicePagination(state) {
    const { paginationProps } = this.getState().transformInvoiceProps;
    await this.setTransformInvoice({
      paginationProps: {
        ...paginationProps,
        ...state,
      },
    });
    await this.transformInvoicePaginationChange();
  }

  async transformInvoicePaginationChange() {
    const { dataSourceOriginal, paginationProps } = this.getState().transformInvoiceProps;
    const { invoiceList } = dataSourceOriginal;
    const { current, pageSize } = paginationProps;
    const begin = (current - 1) * pageSize;
    const end = current * pageSize;
    let dataSource = [];
    let sumTaxTotal = 0;
    let sumEffectiveTax = 0;
    if (invoiceList.length > 0) {
      dataSource = invoiceList.slice(begin, end);
      dataSource.forEach((v) => {
        sumTaxTotal += v.taxTotal;
        sumEffectiveTax += v.effectiveTax || 0;
      });
      dataSource.push({
        invoiceId: 'total',
        isTotal: true,
        auxiliaryName: '合计',
        taxTotal: sumTaxTotal,
        effectiveTax: sumEffectiveTax,
      });
    }
    this.setTransformInvoice({
      selectedRowKeys: [],
      selectedRows: [],
      dataSource: dataSource.map((v) => ({ ...v, key: v.invoiceId })),
      paginationProps: {
        ...paginationProps,
        total: invoiceList.length,
      },
    });
  }

  async queryTransferOutList() {
    const { paginationProps, query } = this.getState().transformInvoiceProps;
    const [year, month] = query.endDate.split('-');
    const data = await services.queryTransferOutList({ ...query, year, month, type: '' });
    await this.setTransformInvoice({
      dataSourceOriginal: data,
      paginationProps: {
        ...paginationProps,
        total: 0,
      },
    });
    await this.transformInvoicePaginationChange();
  }
}
