import dictionary from './dictionary';

// 初始的表格列（全部选中）
const initColumnsSource = [
  { key: 'number', name: '票据编号', value: 1 },
  { key: 'name', name: '票据名称', value: 1 },
  { key: 'billStatus', name: '票据状态', value: 1 },
  { key: 'invalidStatus', name: '作废状态', value: 1 },
  { key: 'bookStatus', name: '记账状态', value: 1 },
  { key: 'printStatus', name: '打印状态', value: 1 },
  { key: 'payerName', name: '付款人名称', value: 1 },
  { key: 'payerAccount', name: '付款人账号', value: 1 },
  { key: 'payerOpenBank', name: '付款人开户行', value: 1 },
  { key: 'payeeName', name: '收款人名称', value: 1 },
  { key: 'payeeAccount', name: '收款人账号', value: 1 },
  { key: 'payeeOpenBank', name: '收款人开户行', value: 1 },
  { key: 'amount', name: '金额', value: 1 },
  { key: 'limitAmt', name: '限额', value: 1 },
  { key: 'content', name: '用途内容', value: 1 },
  { key: 'creator', name: '登记人', value: 1 },
  { key: 'registerDate', name: '登记日期', value: 1 },
  { key: 'recipient', name: '领用人', value: 1 },
  { key: 'receiveDate', name: '领用日期', value: 1 },
  { key: 'user', name: '使用人', value: 1 },
  { key: 'useDate', name: '使用日期', value: 1 },
  { key: 'invalidCreator', name: '作废人', value: 1 },
  { key: 'invalidDate', name: '作废日期', value: 1 },
  { key: 'checker', name: '核销人', value: 1 },
  { key: 'checkDate', name: '核销日期', value: 1 },
  { key: 'remark', name: '备注', value: 1 },
];

export { dictionary, initColumnsSource };
