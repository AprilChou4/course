import React, { useMemo, useImperativeHandle, forwardRef } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Form, DatePicker } from 'antd';
import moment from 'moment';
import useFormFix from 'hooks/useFormFix';

const dateFormat = 'YYYY-MM-DD';
const formItemStyle = { width: '100%' };
const formItemLayout = {
  labelCol: { span: 7 },
  wrapperCol: { span: 17 },
};

const Content = forwardRef(({ form, selectedRows }, ref) => {
  useFormFix();
  const { getFieldDecorator } = form;

  const initialValues = useMemo(() => ({ checkDate: moment() }), []);
  const record = selectedRows?.[0]; // 勾选行数据

  // 核销日期 不能早于建账日期 且 不能超过自然日(今天)
  const disabledCheckDate = usePersistFn((current) => {
    if (!current) return false;
    const registerDate = record?.registerDate;
    return (
      (!!registerDate && current < moment(registerDate, dateFormat)) || current > moment().valueOf()
    );
  });

  // 传给父组件
  useImperativeHandle(ref, () => ({ form }), [form]);

  return (
    <Form {...formItemLayout}>
      <Form.Item label="核销日期">
        {getFieldDecorator('checkDate', {
          initialValue: initialValues.checkDate,
          rules: [{ required: true, message: '请选择核销日期' }],
        })(
          <DatePicker
            placeholder="请选择核销日期"
            allowClear={false}
            style={formItemStyle}
            disabledDate={disabledCheckDate}
          />,
        )}
      </Form.Item>
    </Form>
  );
});

export default connect(({ table: { selectedRows } }) => ({ selectedRows }))(Form.create()(Content));
