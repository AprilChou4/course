/**
 * 票据核销弹窗
 * 只能勾选单条，不可批量操作
 */
import React, { useRef } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import moment from 'moment';
import AntdModal from '@/AntdModal';
import Content from './Content';

const dateFormat = 'YYYY-MM-DD';

const BillCheckModal = ({ visible, dispatch }) => {
  const contentRef = useRef();

  const handleCancel = usePersistFn(() => {
    dispatch({
      type: 'updateBillCheckModal',
      payload: { visible: false },
    });
  });

  const handleOk = usePersistFn(() => {
    const { form } = contentRef.current;
    form.validateFields((err, { checkDate, ...restValues }) => {
      if (err) return;

      dispatch({
        type: 'billCheck',
        payload: {
          ...restValues,
          checkDate: checkDate ? moment(checkDate).format(dateFormat) : undefined,
        },
      });
    });
  });

  return (
    <AntdModal
      title="票据核销"
      width={320}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      onOk={handleOk}
      className="modal-with-form"
    >
      <Content wrappedComponentRef={contentRef} />
    </AntdModal>
  );
};

export default connect(({ billCheckModal: { visible } }) => ({
  visible,
}))(BillCheckModal);
