/**
 * 票据-管理
 */
import React from 'react';
import Layout from './components/Layout';
import effects from './effects';

const initQuery = {
  pageNo: 1,
  pageSize: +localStorage.getItem('bills_manage_pagesize') || 20,
};

export default {
  state: {
    headerSearchFormData: {}, // 头部搜索表单
    query: initQuery, // 表格的查询条件
    // 账套相关设置
    accountSetting: {
      billPrintType: 1, // 票据打印状态（0不可打印，1可打印）
      checkPrintType: 0, // 支票打印设置（0使用支票后，1凭证审核后）
    },
    bankInfoList: [], // 银行账户列表
    payeeNames: [], // 收款人名称列表
    payeeAccounts: [], // 收款人账号列表
    payerNames: [], // 付款人名称列表
    payerAccounts: [], // 付款人账号列表
    contentsList: [], // 票据用途/收据内容列表
    // 表格
    table: {
      rowKey: 'billInfoId',
      selectedRowKeys: [],
      selectedRows: [],
      columnSource: [], // 自定义列
      dataSource: [],
      pagination: {
        total: 0, // 数据总数
        current: initQuery.pageNo, // 当前页
        pageSize: initQuery.pageSize, // 每页条数
        pageSizeOptions: ['20', '50', '100', '300'],
      },
    },
    // 自定义列弹窗
    customColModal: { visible: false },
    // 票据核销弹窗
    billCheckModal: { visible: false },
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    this.store.dispatch({ type: 'initData' });
  },
};
