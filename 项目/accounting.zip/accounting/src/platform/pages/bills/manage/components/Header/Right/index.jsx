import React from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Button } from 'antd';
import ButtonGroup from '@/ButtonGroup';

const HeaderRight = ({ dispatch }) => {
  const handleInvalid = usePersistFn(async () => {
    dispatch({ type: 'handleInvalid' });
  });

  const handleUnInvalid = usePersistFn(async () => {
    dispatch({ type: 'handleUnInvalid' });
  });

  const handleCheck = usePersistFn(async () => {
    dispatch({ type: 'showBillCheckModal' });
  });

  const handleUnCheck = usePersistFn(async () => {
    dispatch({ type: 'handleUnCheck' });
  });

  const handleCustomColumns = usePersistFn(async () => {
    dispatch({
      type: 'updateState',
      payload: {
        customColModal: { visible: true },
      },
    });
  });

  const handleExport = usePersistFn(() => {
    dispatch({ type: 'handleBillExport' });
  });

  return (
    <>
      {inAuth(768) && (
        <Button type="primary" onClick={handleInvalid}>
          作废
        </Button>
      )}
      {inAuth(769) && <Button onClick={handleUnInvalid}>取消作废</Button>}
      {inAuth(770) && <Button onClick={handleCheck}>核销</Button>}
      {inAuth(771) && <Button onClick={handleUnCheck}>取消核销</Button>}
      <ButtonGroup count={1}>
        <Button onClick={handleCustomColumns}>自定义列</Button>
        {inAuth(767) && <Button onClick={handleExport}>导出</Button>}
      </ButtonGroup>
    </>
  );
};

export default connect()(HeaderRight);
