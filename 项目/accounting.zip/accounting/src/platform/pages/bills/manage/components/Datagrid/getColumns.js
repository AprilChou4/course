import currency from 'currency.js';
import { dictionary } from '../../../utils';

export default ({ columnSource, billPrintType }) => {
  const allowBillPrint = billPrintType === 1; // 是否开启打印功能
  const columnsMap = {
    number: {
      title: '票据编号',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    name: {
      title: '票据名称',
      width: 120,
      ellipsis: true,
    },
    billStatus: {
      title: '票据状态',
      width: 80,
      ellipsis: true,
      align: 'center',
      render: (value) => dictionary.billStatus.map[value],
    },
    invalidStatus: {
      title: '作废状态',
      width: 80,
      ellipsis: true,
      align: 'center',
      render: (value) => dictionary.invalidStatus.map[value],
    },
    bookStatus: {
      title: '记账状态',
      width: 80,
      ellipsis: true,
      align: 'center',
      render: (value) => dictionary.bookStatus.map[value],
    },
    printStatus: {
      title: '打印状态',
      width: 80,
      ellipsis: true,
      align: 'center',
      render: (value) => dictionary.printStatus.map[value],
    },
    payerName: {
      title: '付款人名称',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    payerAccount: {
      title: '付款人账号',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    payerOpenBank: {
      title: '付款人开户行',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    payeeName: {
      title: '收款人名称',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    payeeAccount: {
      title: '收款人账号',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    payeeOpenBank: {
      title: '收款人开户行',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    amount: {
      title: '金额',
      width: 100,
      ellipsis: true,
      align: 'right',
      render: (value) => currency(value).format(),
    },
    limitAmt: {
      title: '限额',
      width: 100,
      ellipsis: true,
      align: 'right',
      render: (value) => currency(value).format(),
    },
    content: {
      title: '用途内容',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    creator: {
      title: '登记人',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    registerDate: {
      title: '登记日期',
      width: 90,
      ellipsis: true,
      align: 'center',
    },
    recipient: {
      title: '领用人',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    receiveDate: {
      title: '领用日期',
      width: 90,
      ellipsis: true,
      align: 'center',
    },
    user: {
      title: '使用人',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    useDate: {
      title: '使用日期',
      width: 90,
      ellipsis: true,
      align: 'center',
    },
    invalidCreator: {
      title: '作废人',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    invalidDate: {
      title: '作废日期',
      width: 90,
      ellipsis: true,
      align: 'center',
    },
    checker: {
      title: '核销人',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    checkDate: {
      title: '核销日期',
      width: 90,
      ellipsis: true,
      align: 'center',
    },
    remark: {
      title: '备注',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
  };
  // 根据columnSource生成columns
  const basicColSetting = { width: 100, align: 'center', ellipsis: true };
  const columns = columnSource.reduce((acc, cur) => {
    // 关闭打印插件时，不显示打印状态列
    if (cur.value && !(!allowBillPrint && cur?.key === 'printStatus')) {
      acc.push({
        title: cur?.name,
        ...(columnsMap[cur?.key] || basicColSetting),
        dataIndex: cur?.key,
      });
    }
    return acc;
  }, []);

  return columns;
};
