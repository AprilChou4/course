import React, { useRef } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import Content from './Content';
import MoreSearch from '../../../../../components/MoreSearch';

const Search = ({ simpleQuery, dispatch }) => {
  const moreSearchRef = useRef();

  const handleSearch = usePersistFn((val) => {
    dispatch({
      type: 'updateQuery',
      payload: { init: true, simpleQuery: val },
    });
  });

  // 自动关闭时恢复form的值
  const handleRestore = usePersistFn(() => {
    dispatch({ type: 'resetHeaderSearchFormData' });
  });

  const setVisible = usePersistFn((v) => {
    moreSearchRef.current?.setVisible?.(v);
  });

  return (
    <MoreSearch
      placeholder="票据名称/编号"
      content={<Content setVisible={setVisible} />}
      value={simpleQuery}
      onSearch={handleSearch}
      onRestore={handleRestore}
      ref={moreSearchRef}
    />
  );
};

export default connect(({ query: { simpleQuery } }) => ({
  simpleQuery,
}))(Search);
