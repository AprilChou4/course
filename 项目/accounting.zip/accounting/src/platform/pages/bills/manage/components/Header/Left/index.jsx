import React from 'react';
import Search from './Search';

const HeaderLeft = () => {
  return <Search />;
};

export default HeaderLeft;
