import React from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import CustomColModal from '@/CustomColModal';
import { initColumnsSource } from '../../utils';

const CustomColModals = ({ visible, columnSource, dispatch }) => {
  const handleCancel = usePersistFn(() => {
    dispatch({
      type: 'updateState',
      payload: {
        customColModal: { visible: false },
      },
    });
  });

  const handleOk = usePersistFn(({ dataSource }) => {
    dispatch({
      type: 'setCustomColumns',
      payload: { list: dataSource },
    });
    dispatch({ type: '$query' });
  });

  return (
    <CustomColModal
      selectedPropName="value"
      visible={visible}
      tableProps={{
        rowKey: 'key',
        disabledRowKeys: ['number'],
        dataSource: columnSource,
        defaultDataSource: initColumnsSource,
      }}
      onCancel={handleCancel}
      onOk={handleOk}
    />
  );
};

export default connect(({ customColModal: { visible }, table: { columnSource } }) => ({
  visible,
  columnSource,
}))(CustomColModals);
