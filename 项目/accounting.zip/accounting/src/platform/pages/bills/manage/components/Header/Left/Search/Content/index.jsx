import React, { useEffect } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Form, Button, AutoComplete } from 'antd';
import AntdSelect from '@/AntdSelect';
import { dictionary } from '../../../../../../utils';
import styles from './style.less';

const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

const Content = ({
  setVisible,
  form: { getFieldDecorator, validateFields, resetFields, setFieldsValue },
  headerSearchFormData,
  payeeNames,
  payeeAccounts,
  payerNames,
  payerAccounts,
  contentsList,
  billPrintType,
  dispatch,
}) => {
  const allowBillPrint = billPrintType === 1; // 是否开启打印功能

  const filterOption = usePersistFn((inputValue, option) =>
    option.props.children.toUpperCase().includes(inputValue.toUpperCase()),
  );

  const handleReset = usePersistFn(() => {
    resetFields();
  });

  const handleSubmit = usePersistFn(() => {
    validateFields((err, values) => {
      if (err) return;

      setVisible(false);
      dispatch({
        type: 'updateSearchData',
        payload: values,
      });
    });
  });

  useEffect(() => {
    setFieldsValue(headerSearchFormData);
  }, [headerSearchFormData, setFieldsValue]);

  return (
    <Form {...formItemLayout} className={styles.form}>
      <Form.Item label="票据状态" className={styles.mb1}>
        {getFieldDecorator('status')(
          <AntdSelect
            allowClear
            placeholder="请选择"
            showSearch={false}
            dataSource={dictionary.billStatus.list}
          />,
        )}
      </Form.Item>
      <Form.Item label="作废状态" className={styles.mb1}>
        {getFieldDecorator('invalidStatus')(
          <AntdSelect
            allowClear
            placeholder="请选择"
            showSearch={false}
            dataSource={dictionary.invalidStatus.list}
          />,
        )}
      </Form.Item>
      <Form.Item label="记账状态" className={styles.mb1}>
        {getFieldDecorator('bookStatus')(
          <AntdSelect
            allowClear
            placeholder="请选择"
            showSearch={false}
            dataSource={dictionary.bookStatus.list}
          />,
        )}
      </Form.Item>
      {allowBillPrint && (
        <Form.Item label="打印状态" className={styles.mb1}>
          {getFieldDecorator('printStatus')(
            <AntdSelect
              allowClear
              placeholder="请选择"
              showSearch={false}
              dataSource={dictionary.printStatus.list}
            />,
          )}
        </Form.Item>
      )}
      <Form.Item label="付款人名称" className={styles.mb1}>
        {getFieldDecorator('payerName')(
          <AutoComplete filterOption={filterOption} dataSource={payerNames} />,
        )}
      </Form.Item>
      <Form.Item label="付款人账号" className={styles.mb1}>
        {getFieldDecorator('payerAccount')(
          <AutoComplete filterOption={filterOption} dataSource={payerAccounts} />,
        )}
      </Form.Item>
      <Form.Item label="收款人名称" className={styles.mb1}>
        {getFieldDecorator('payeeName')(
          <AutoComplete filterOption={filterOption} dataSource={payeeNames} />,
        )}
      </Form.Item>
      <Form.Item label="收款人账号" className={styles.mb1}>
        {getFieldDecorator('payeeAccount')(
          <AutoComplete filterOption={filterOption} dataSource={payeeAccounts} />,
        )}
      </Form.Item>
      <Form.Item label="用途内容" className={styles.mb1}>
        {getFieldDecorator('content')(
          <AutoComplete
            placeholder="请输入"
            filterOption={filterOption}
            dataSource={contentsList}
          />,
        )}
      </Form.Item>
      <div className={styles.footer}>
        <Button onClick={handleReset}>重置</Button>
        <Button type="primary" onClick={handleSubmit}>
          查询
        </Button>
      </div>
    </Form>
  );
};

export default connect(
  ({
    headerSearchFormData,
    payeeNames,
    payeeAccounts,
    payerNames,
    payerAccounts,
    contentsList,
    accountSetting: { billPrintType },
  }) => ({
    headerSearchFormData,
    payeeNames,
    payeeAccounts,
    payerNames,
    payerAccounts,
    contentsList,
    billPrintType,
  }),
)(Form.create()(Content));
