import { util } from 'nuijs';

export default util.createRequest({
  // 获取票据管理列表
  getBillManageList: 'cashier/bill/manage/queryPageData:postJSON',
  // 票据作废
  billInvalid: 'cashier/bill/manage/invalid:postJSON',
  // 票据取消作废
  billUnInvalid: 'cashier/bill/manage/unInvalid:postJSON',
  // 票据核销
  billCheck: 'cashier/bill/manage/check:postJSON',
  // 票据取消核销
  billUnCheck: 'cashier/bill/manage/uncheck:postJSON',
});
