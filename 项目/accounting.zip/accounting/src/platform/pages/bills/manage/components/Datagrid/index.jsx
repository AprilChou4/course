import React, { useMemo } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Pagination } from 'antd';
import SuperTable from '@/SuperTable';
import getColumns from './getColumns';
import styles from './style.less';

const scroll = { x: '100%' };

const Datagrid = ({
  rowKey,
  columnSource,
  dataSource,
  selectedRowKeys,
  pagination,
  billPrintType,
  tableLoading,
  dispatch,
}) => {
  const columns = useMemo(() => getColumns({ billPrintType, columnSource }), [
    billPrintType,
    columnSource,
  ]);

  const rowSelection = useMemo(
    () => ({
      columnWidth: 36,
      selectedRowKeys,
      onChange(sRowKeys, sRows) {
        dispatch({
          type: 'updateDatagrid',
          payload: { selectedRowKeys: sRowKeys, selectedRows: sRows },
        });
      },
    }),
    [dispatch, selectedRowKeys],
  );

  const showTotal = usePersistFn((total) => `共${total}条`);

  const handleTableChange = usePersistFn(async ({ current, pageSize }) => {
    dispatch({
      type: 'updateQuery',
      payload: { pageNo: current, pageSize },
    });
  });

  const handleChange = usePersistFn((current, pageSize) => {
    handleTableChange({ current, pageSize });
  });

  const handleonShowSizeChange = usePersistFn((_, pageSize) => {
    localStorage.setItem('bills_manage_pagesize', pageSize);
    handleTableChange({ current: 1, pageSize });
  });

  return (
    <div style={{ height: `calc(100% - 56px)` }}>
      <SuperTable
        bordered
        pagination={false}
        rowKey={rowKey}
        scroll={scroll}
        loading={tableLoading}
        rowSelection={rowSelection}
        columns={columns}
        dataSource={dataSource}
      />
      <Pagination
        className={styles.pagination}
        showSizeChanger
        {...pagination}
        showTotal={showTotal}
        onChange={handleChange}
        onShowSizeChange={handleonShowSizeChange}
      />
    </div>
  );
};

export default connect(
  ({
    accountSetting: { billPrintType },
    table: { rowKey, columnSource, dataSource, selectedRowKeys, pagination },
    loadings: { $query: tableLoading },
  }) => ({
    billPrintType,
    rowKey,
    columnSource,
    dataSource,
    selectedRowKeys,
    pagination,
    tableLoading,
  }),
)(Datagrid);
