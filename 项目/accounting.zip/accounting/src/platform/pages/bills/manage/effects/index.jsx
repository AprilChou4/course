import React from 'react';
import { message } from 'antd';
import moment from 'moment';
import omitBy from 'lodash/omitBy';
import util from 'util';
import isEmpty from 'utils/isEmpty';
import { superLayer } from 'layer';
import LinkButton from '@/LinkButton';
import ShowConfirm from '@/ShowConfirm';
import AsyncShowConfirm from '@/ShowConfirm/AsyncShowConfirm';
import getArrayLength from 'utils/getArrayLength';
import commonServices from '../../services';
import services from '../services';
import { initColumnsSource } from '../utils';

const dateFormat = 'YYYY-MM-DD';

export default {
  async initData() {
    await this.query({ init: true });
  },

  // 查询
  async query(payload) {
    this.getAccountSetting();
    this.getCustomColumns();
    await this.$query(payload);
  },

  // 更新query内容
  async updateQuery(payload = {}) {
    const { init, ...rest } = payload;
    const { query } = this.getState();
    this.updateState({
      query: { ...query, ...rest },
    });
    await this.$query({ init });
  },

  // 获取表格查询参数
  getQueryParams(payload = {}) {
    const {
      query: { registerDate, receiveDate, ...restQuery },
    } = this.getState();
    return omitBy(
      {
        ...restQuery,
        registerDateFrom: registerDate?.[0]
          ? moment(registerDate[0]).format(dateFormat)
          : undefined,
        registerDateTo: registerDate?.[1] ? moment(registerDate[1]).format(dateFormat) : undefined,
        receiveDateFrom: receiveDate?.[0] ? moment(receiveDate[0]).format(dateFormat) : undefined,
        receiveDateTo: receiveDate?.[1] ? moment(receiveDate[1]).format(dateFormat) : undefined,
        ...payload,
      },
      isEmpty,
    );
  },

  // 表格查询
  async $query(payload = {}) {
    const { init, ...restPayload } = payload;
    const param = this.getQueryParams();
    const params = {
      ...param,
      ...restPayload,
      ...(init ? { pageNo: 1 } : {}),
    };

    const {
      billInfoList,
      payeeNames,
      payeeAccounts,
      payerNames,
      payerAccounts,
      contents,
      total,
    } = await services.getBillManageList(params);
    const { table } = this.getState(); // 要在异步请求后再获取，否则可能会覆盖掉最新数据
    this.updateState({
      payeeNames: payeeNames || [],
      payeeAccounts: payeeAccounts || [],
      payerNames: payerNames || [],
      payerAccounts: payerAccounts || [],
      contentsList: contents || [],
      table: {
        ...table,
        dataSource: billInfoList || [],
        selectedRowKeys: [],
        selectedRows: [],
        pagination: {
          ...table.pagination,
          current: params.pageNo,
          pageSize: params.pageSize,
          total,
        },
      },
    });
  },

  // 查询自定义列
  async getCustomColumns() {
    const res = await commonServices
      .getCustomColumns({ type: 3 }, { returnAll: true })
      .catch((err) => err);
    const result = getArrayLength(res?.data) ? res.data : initColumnsSource;
    this.updateDatagrid({ columnSource: result });
    return result;
  },

  // 设置自定义列
  async setCustomColumns(payload = {}) {
    await commonServices.setCustomColumns(
      { ...payload, type: 3 },
      { loading: true, successMsg: '保存成功' },
    );
    this.updateState({
      customColModal: { visible: false },
    });
    this.getCustomColumns();
  },

  // 获取银行信息设置
  async getBankInfoList() {
    const data = await services.getBankInfoList();
    this.updateState({ bankInfoList: data || [] });
  },

  // 票据作废
  async handleInvalid() {
    const {
      table: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = getArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请勾选票据！');
    } else if (length > 1) {
      message.warning('暂仅支持单条操作！');
    } else {
      const { bookStatus, printStatus, billInfoId } = selectedRows[0];
      const hasBook = bookStatus === 1; // 是否已记账
      const hasPrint = printStatus === 1; // 是否已打印
      let result;
      if (!hasBook) {
        // 未记账
        const ck = await AsyncShowConfirm({ width: 260, title: '是否作废所选票据？' });
        if (!ck) return;
        result = await services
          .billInvalid(
            { billInfoId },
            {
              returnAll: true,
              loading: true,
              successMsg: '作废成功！',
              status: { 30004000126() {}, 30004000127() {} },
            },
          )
          .catch((err) => err);
      } else if (hasBook && !hasPrint) {
        // 已记账未打印
        const ck = await AsyncShowConfirm({
          title: '是否作废所选票据？作废时将同步删除日记账！',
        });
        if (!ck) return;
        result = await services
          .billInvalid(
            { billInfoId },
            {
              returnAll: true,
              loading: true,
              successMsg: '作废成功，相关日记账已删除！',
              status: { 30004000126() {}, 30004000127() {} },
            },
          )
          .catch((err) => err);
      } else if (hasBook && hasPrint) {
        // 已记账已打印
        const ck = await AsyncShowConfirm({
          title: '是否顺延票据信息，保留日记账及凭证进行重新打印？否则将同步删除日记账！',
          cancelText: '直接作废',
          okText: '顺延信息',
        });
        result = await services
          .billInvalid(
            { billInfoId, isInherit: +ck },
            { returnAll: true, loading: true, status: { 30004000126() {}, 30004000127() {} } },
          )
          .catch((err) => err);
      }

      if (!result) return;
      if (+result.status === 30004000126) {
        const data = JSON.parse(result?.message || '{}');
        const modal = ShowConfirm({
          type: 'warning',
          title: (
            <>
              作废失败，日记账已生成凭证，
              <br />
              请先处理
              <LinkButton
                onClick={() => {
                  modal.destroy();
                  superLayer('voucher/record', {
                    data: { title: '记账凭证', voucherId: data.id },
                  });
                }}
              >
                {data.code}
              </LinkButton>
              凭证！
            </>
          ),
        });
      } else if (+result.status === 30004000127) {
        message.success(`作废成功，已将原票据信息顺延至${result.message || ''}票据，可重新打印！`);
      }
      await this.$query();
    }
  },

  // 票据取消作废
  async handleUnInvalid() {
    const {
      table: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = getArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请勾选票据！');
    } else if (length > 1) {
      message.warning('暂仅支持单条操作！');
    } else {
      const { printStatus, invalidStatus } = selectedRows[0];
      const {
        accountSetting: { billPrintType, checkPrintType },
      } = this.getState();
      if (billPrintType === 1) {
        // 若选择使用后打印，要求已作废
        // 若选择审核后打印，要求未打印已作废
        if (
          (checkPrintType === 0 && !(invalidStatus === 1)) ||
          (checkPrintType === 1 && !(printStatus === 0 && invalidStatus === 1))
        ) {
          message.warning('票据不满足取消作废条件，请核对！');
          return;
        }
      }
      const ck = await AsyncShowConfirm({ title: '是否确定取消所选票据作废操作？' });
      if (!ck) return;
      await services.billUnInvalid(selectedRowKeys[0], { loading: true, successMsg: '取消成功！' });
      await this.$query();
    }
  },

  // 票据核销
  async billCheck(payload = {}) {
    const {
      table: { selectedRowKeys },
    } = this.getState();
    await services.billCheck(
      { ...payload, billInfoIdList: selectedRowKeys },
      { loading: true, successMsg: '核销成功！' },
    );
    this.updateBillCheckModal({ visible: false });
    await this.$query();
  },

  // 票据取消核销
  async handleUnCheck() {
    const ck = await AsyncShowConfirm({ title: '是否确定取消所选票据核销操作？' });
    if (!ck) return;
    const {
      table: { selectedRowKeys },
    } = this.getState();
    await services.billUnCheck(selectedRowKeys, { loading: true, successMsg: '取消成功！' });
    await this.$query();
  },

  // 导出
  handleBillExport() {
    const params = this.getQueryParams({
      pageNo: undefined,
      pageSize: undefined,
    });
    util.submit('cashier/bill/manage/export', params, '_blank', 'download');
  },

  // 查询账套设置
  async getAccountSetting() {
    const data = await commonServices.getAccountSetting();
    this.updateState({
      accountSetting: {
        billPrintType: data?.accountSetting?.billPrintType,
        checkPrintType: data?.accountSetting?.checkPrintType,
      },
    });
  },

  // 更新头部搜索框表单数据
  async updateSearchData(payload) {
    this.updateState({ headerSearchFormData: payload });
    await this.updateQuery({
      init: true,
      ...payload,
    });
  },

  // 恢复头部搜索框的值
  resetHeaderSearchFormData() {
    const { headerSearchFormData } = this.getState();
    this.updateState({
      headerSearchFormData: { ...headerSearchFormData },
    });
  },

  // 更新表格相关数据
  updateDatagrid(payload = {}) {
    const { table } = this.getState();
    this.updateState({
      table: { ...table, ...payload },
    });
  },

  // 更新表格分页
  updateDatagridPagination(payload = {}) {
    const { table } = this.getState();
    this.updateDatagrid({
      pagination: { ...table.pagination, ...payload },
    });
  },

  // 更新票据核销弹窗
  updateBillCheckModal(payload = {}) {
    const { billCheckModal } = this.getState();
    this.updateState({
      billCheckModal: { ...billCheckModal, ...payload },
    });
  },

  // 显示票据核销弹窗
  showBillCheckModal() {
    const {
      table: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = getArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请勾选票据！');
    } else if (
      !selectedRows.every(
        (item) => (item.billStatus === 3 && item.invalidStatus === 0) || item.invalidStatus === 1,
      )
    ) {
      // 核销要求：已使用未作废或已作废
      message.warning('票据不满足核销条件，请核对！');
    } else {
      this.updateBillCheckModal({ visible: true });
    }
  },
};
