/**
 * @object 数据字典
 */

const getData = (params) => {
  const map = {};
  params.list.forEach(({ value, name, label, data }) => {
    map[value] = data || name || label;
  });
  return { ...params, map };
};

export default {};
