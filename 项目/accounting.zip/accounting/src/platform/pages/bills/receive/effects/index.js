import { message } from 'antd';
import moment from 'moment';
import omitBy from 'lodash/omitBy';
import isEmpty from 'utils/isEmpty';
import getArrayLength from 'utils/getArrayLength';
import services from '../services';

const dateFormat = 'YYYY-MM-DD';

export default {
  async initData() {
    await this.query({ init: true });
  },

  // 查询
  async query(payload) {
    await this.$query(payload);
  },

  // 更新query内容
  async updateQuery(payload = {}) {
    const { init, ...rest } = payload;
    const { query } = this.getState();
    this.updateState({
      query: { ...query, ...rest },
    });
    await this.$query({ init });
  },

  // 获取表格查询参数
  getQueryParams(payload = {}) {
    const {
      query: { registerDate, receiveDate, ...restQuery },
    } = this.getState();
    return omitBy(
      {
        ...restQuery,
        registerDateFrom: registerDate?.[0]
          ? moment(registerDate[0]).format(dateFormat)
          : undefined,
        registerDateTo: registerDate?.[1] ? moment(registerDate[1]).format(dateFormat) : undefined,
        receiveDateFrom: receiveDate?.[0] ? moment(receiveDate[0]).format(dateFormat) : undefined,
        receiveDateTo: receiveDate?.[1] ? moment(receiveDate[1]).format(dateFormat) : undefined,
        ...payload,
      },
      isEmpty,
    );
  },

  // 表格查询
  async $query(payload = {}) {
    const { init, ...restPayload } = payload;
    const param = this.getQueryParams();
    const params = {
      ...param,
      ...restPayload,
      ...(init ? { pageNo: 1 } : {}),
    };

    const { billInfoList, contents, total } = await services.getReceiveList(params);
    const { table } = this.getState(); // 要在异步请求后再获取，否则可能会覆盖掉最新数据
    this.updateState({
      contentsList: contents || [],
      table: {
        ...table,
        dataSource: billInfoList,
        selectedRowKeys: [],
        selectedRows: [],
        pagination: {
          ...table.pagination,
          current: params.pageNo,
          pageSize: params.pageSize,
          total,
        },
      },
    });
  },

  // 获取银行信息设置
  async getBankInfoList() {
    const data = await services.getBankInfoList();
    this.updateState({ bankInfoList: data || [] });
  },

  // 票据领用
  async billReceive(payload = {}) {
    const {
      table: { selectedRowKeys },
    } = this.getState();
    await services.billReceive(
      { ...payload, billInfoIdList: selectedRowKeys },
      { loading: true, successMsg: '领用成功！' },
    );
    this.updateReceiveModal({ visible: false });
    await this.$query();
  },

  // 更新头部搜索框表单数据
  async updateSearchData(payload) {
    this.updateState({ headerSearchFormData: payload });
    await this.updateQuery({ init: true, ...payload });
  },

  // 恢复头部搜索框的值
  resetHeaderSearchFormData() {
    const { headerSearchFormData } = this.getState();
    this.updateState({ headerSearchFormData: { ...headerSearchFormData } });
  },

  // 更新表格相关数据
  updateDatagrid(payload = {}) {
    const { table } = this.getState();
    this.updateState({
      table: { ...table, ...payload },
    });
  },

  // 更新表格分页
  updateDatagridPagination(payload = {}) {
    const { table } = this.getState();
    this.updateDatagrid({
      pagination: { ...table.pagination, ...payload },
    });
  },

  // 更新票据领用弹窗
  updateReceiveModal(payload = {}) {
    const { receiveModal } = this.getState();
    this.updateState({
      receiveModal: { ...receiveModal, ...payload },
    });
  },

  // 显示票据领用弹窗
  showReceiveModal() {
    const {
      table: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = getArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请勾选票据！');
    } else {
      if (length > 1 && selectedRows.some((item) => item.type !== selectedRows[0].type)) {
        message.warning('所选票据类型存在差异，请核对！');
        return;
      }
      this.updateReceiveModal({ visible: true });
    }
  },
};
