import React from 'react';
import Search from './Search';
import BillStatus from './BillStatus';

const HeaderLeft = () => {
  return (
    <>
      <BillStatus />
      <Search />
    </>
  );
};

export default HeaderLeft;
