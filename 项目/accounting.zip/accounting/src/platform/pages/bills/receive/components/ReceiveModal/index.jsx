/**
 * 票据领用弹窗
 * 只能勾选单条，不可批量操作
 */
import React, { useRef } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import moment from 'moment';
import AntdModal from '@/AntdModal';
import Content from './Content';
import { dictionary } from '../../../utils';

const dateFormat = 'YYYY-MM-DD';

const ReceiveModal = ({ visible, selectedRows, dispatch }) => {
  const contentRef = useRef();

  const handleCancel = usePersistFn(() => {
    dispatch({
      type: 'updateReceiveModal',
      payload: { visible: false },
    });
  });

  const handleOk = usePersistFn(() => {
    const { form } = contentRef.current;
    form.validateFields((err, { receiveDate, ...restValues }) => {
      if (err) return;

      dispatch({
        type: 'billReceive',
        payload: {
          ...restValues,
          receiveDate: receiveDate ? moment(receiveDate).format(dateFormat) : undefined,
        },
      });
    });
  });

  const billType = selectedRows[0]?.type;

  return (
    <AntdModal
      title={`${dictionary.billType.map[billType] || ''}领用`}
      width={418}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      onOk={handleOk}
      className="modal-with-form"
    >
      <Content wrappedComponentRef={contentRef} selectedRows={selectedRows} />
    </AntdModal>
  );
};

export default connect(({ receiveModal: { visible }, table: { selectedRows } }) => ({
  visible,
  selectedRows,
}))(ReceiveModal);
