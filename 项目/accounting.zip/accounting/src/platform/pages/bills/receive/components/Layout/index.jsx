import React from 'react';
import { Content, Layout, Head, Title, Center, Left, Right } from '@/Layout';
import HeaderLeft from '../Header/Left';
import HeaderRight from '../Header/Right';
import DataGrid from '../Datagrid';
import ReceiveModal from '../ReceiveModal';
import styles from './style.less';

function Layouts() {
  return (
    <Layout>
      <Head>
        <Left>
          <HeaderLeft />
        </Left>
        <Center>
          <Title />
        </Center>
        <Right className={styles.right}>
          <HeaderRight />
        </Right>
      </Head>
      <Content>
        <DataGrid />
      </Content>
      <ReceiveModal />
    </Layout>
  );
}

export default Layouts;
