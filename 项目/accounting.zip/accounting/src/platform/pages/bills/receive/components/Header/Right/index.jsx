import React from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Button } from 'antd';

const HeaderRight = ({ status, dispatch }) => {
  const handleReceive = usePersistFn(async () => {
    dispatch({ type: 'showReceiveModal' });
  });

  return (
    inAuth(761) && (
      <Button type="primary" disabled={status === 2} onClick={handleReceive}>
        领用
      </Button>
    )
  );
};

export default connect(({ query: { status } }) => ({ status }))(HeaderRight);
