import React, { useMemo, useImperativeHandle, forwardRef } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Form, DatePicker, AutoComplete, Popover } from 'antd';
import moment from 'moment';
import LinkButton from '@/LinkButton';
import NumberInput from '@/NumberInput';
import useFormFix from 'hooks/useFormFix';
import getArrayLength from 'utils/getArrayLength';
import isNil from 'utils/isNil';
import LimitInput from '@/LimitInput';
import styles from './style.less';

const dateFormat = 'YYYY-MM-DD';
const formItemStyle = { width: '100%' };
const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const Content = forwardRef(({ form, selectedRows, realName, contentsList }, ref) => {
  useFormFix();
  const { getFieldDecorator } = form;

  const record = selectedRows?.[0]; // 勾选行数据
  const billType = record?.type; // 票据类型

  const initialValues = useMemo(() => ({ receiveDate: moment(), recipient: realName }), [realName]);

  const filterOption = usePersistFn((inputValue, option) =>
    option.props.children.toUpperCase().includes(inputValue.toUpperCase()),
  );

  // 领用日期 不能早于登记日期 且 不能超过自然日(今天)
  const disabledRegisterDate = usePersistFn((current) => {
    if (!current) return false;
    const registerDate = record?.registerDate;
    return (
      (!!registerDate && current < moment(registerDate, dateFormat)) || current > moment().valueOf()
    );
  });

  const billNumberContent = useMemo(() => {
    const viewNumber = record?.number;
    const length = getArrayLength(selectedRows);
    return (
      <div>
        {length > 1 ? (
          <span>
            {viewNumber}；
            <Popover
              placement="right"
              overlayClassName={styles.numberPopover}
              content={selectedRows.map((item) => (
                <span key={item.number}>{item.number}；</span>
              ))}
            >
              <LinkButton>...(共{length}张)</LinkButton>
            </Popover>
          </span>
        ) : (
          viewNumber
        )}
      </div>
    );
  }, [record, selectedRows]);

  const validateAmount = usePersistFn((callback) => {
    const formValues = form.getFieldsValue();
    const limit = Number(formValues.limitAmt || 0);
    const errMsg =
      limit && Number(formValues.amount) > limit ? '支票金额需小于支票限额' : undefined;
    if (callback) {
      callback(errMsg);
    } else {
      form.setFields({
        amount: {
          value: formValues.amount,
          errors: errMsg ? [new Error(errMsg)] : null,
        },
      });
    }
  });

  const handleAmountValidator = usePersistFn((rule, value, callback) => {
    if (isNil(value, '')) {
      callback();
    } else if (!(Number(value) > 0)) {
      callback('金额必须大于零');
    } else if (billType === 1) {
      validateAmount(callback);
    } else {
      callback();
    }
  });

  const handleLimitAmtValidator = usePersistFn((rule, value, callback) => {
    if (isNil(value, '')) {
      callback();
    } else if (!(Number(value) > 0)) {
      callback('金额必须大于零');
    } else {
      callback();
      validateAmount();
    }
  });

  // 传给父组件
  useImperativeHandle(ref, () => ({ form }), [form]);

  return (
    <Form {...formItemLayout}>
      <Form.Item label="票据编号">{billNumberContent}</Form.Item>
      {billType === 1 && (
        <>
          <Form.Item label="支票金额">
            {getFieldDecorator('amount', { rules: [{ validator: handleAmountValidator }] })(
              <NumberInput placeholder="请输入" precision={2} />,
            )}
          </Form.Item>
          <Form.Item label="支票限额">
            {getFieldDecorator('limitAmt', { rules: [{ validator: handleLimitAmtValidator }] })(
              <NumberInput placeholder="请输入" precision={2} min={0} />,
            )}
          </Form.Item>
          <Form.Item label="票据用途">
            {getFieldDecorator('content', {
              rules: [{ max: 50, message: '不能超过50字' }],
            })(
              <AutoComplete filterOption={filterOption} dataSource={contentsList}>
                <LimitInput placeholder="请输入" maxLength={50} />
              </AutoComplete>,
            )}
          </Form.Item>
        </>
      )}
      {billType === 2 && (
        <>
          <Form.Item label="收据金额">
            {getFieldDecorator('amount', { rules: [{ validator: handleAmountValidator }] })(
              <NumberInput placeholder="请输入" precision={2} />,
            )}
          </Form.Item>
          <Form.Item label="收据内容">
            {getFieldDecorator('content', {
              rules: [{ max: 200, message: '不能超过200字' }],
            })(<LimitInput placeholder="请输入" maxLength={200} />)}
          </Form.Item>
        </>
      )}
      <Form.Item label="领用人">
        {getFieldDecorator('recipient', {
          initialValue: initialValues.recipient,
          rules: [
            { required: true, whitespace: true, message: '请输入领用人' },
            { max: 50, message: '不能超过50字' },
          ],
        })(<LimitInput placeholder="请输入" maxLength={50} />)}
      </Form.Item>
      <Form.Item label="领用日期">
        {getFieldDecorator('receiveDate', {
          initialValue: initialValues.receiveDate,
          rules: [{ required: true, message: '请选择登记日期' }],
        })(
          <DatePicker
            placeholder="请选择登记日期"
            allowClear={false}
            style={formItemStyle}
            disabledDate={disabledRegisterDate}
          />,
        )}
      </Form.Item>
      <Form.Item label="备注">
        {getFieldDecorator('remark', {
          rules: [{ max: 200, message: '不能超过200字' }],
        })(<LimitInput placeholder="请输入" maxLength={200} />)}
      </Form.Item>
    </Form>
  );
});

export default connect(({ contentsList }, { account: { user: { realName } } }) => ({
  realName,
  contentsList,
}))(Form.create()(Content));
