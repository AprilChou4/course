import React, { useEffect } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import { Form, Button, Input, DatePicker, AutoComplete } from 'antd';
import styles from './style.less';

const { RangePicker } = DatePicker;
const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

const Content = ({
  setVisible,
  form: { getFieldDecorator, validateFields, resetFields, setFieldsValue },
  headerSearchFormData,
  contentsList,
  dispatch,
}) => {
  const filterOption = usePersistFn((inputValue, option) =>
    option.props.children.toUpperCase().includes(inputValue.toUpperCase()),
  );

  const handleReset = usePersistFn(() => {
    resetFields();
  });

  const handleSubmit = usePersistFn(() => {
    validateFields((err, values) => {
      if (err) return;

      setVisible(false);
      dispatch({
        type: 'updateSearchData',
        payload: values,
      });
    });
  });

  useEffect(() => {
    setFieldsValue(headerSearchFormData);
  }, [headerSearchFormData, setFieldsValue]);

  return (
    <Form {...formItemLayout} className={styles.form}>
      <Form.Item label="登记人" className={styles.mb1}>
        {getFieldDecorator('creator')(<Input placeholder="请输入" />)}
      </Form.Item>
      <Form.Item label="登记日期" className={styles.mb1}>
        {getFieldDecorator('registerDate')(<RangePicker />)}
      </Form.Item>
      <Form.Item label="领用人" className={styles.mb1}>
        {getFieldDecorator('recipient')(<Input placeholder="请输入" />)}
      </Form.Item>
      <Form.Item label="领用日期" className={styles.mb1}>
        {getFieldDecorator('receiveDate')(<RangePicker />)}
      </Form.Item>
      <Form.Item label="用途内容" className={styles.mb1}>
        {getFieldDecorator('content')(
          <AutoComplete
            placeholder="请输入"
            filterOption={filterOption}
            dataSource={contentsList}
          />,
        )}
      </Form.Item>
      <div className={styles.footer}>
        <Button onClick={handleReset}>重置</Button>
        <Button type="primary" onClick={handleSubmit}>
          查询
        </Button>
      </div>
    </Form>
  );
};

export default connect(({ headerSearchFormData, contentsList }) => ({
  headerSearchFormData,
  contentsList,
}))(Form.create()(Content));
