/**
 * 票据-领用
 */
import React from 'react';
import Layout from './components/Layout';
import effects from './effects';

const initQuery = {
  pageNo: 1,
  pageSize: +localStorage.getItem('bills_receive_pagesize') || 20,
  status: 1, // 顶部的票据状态，默认 已登记
};

export default {
  state: {
    // 头部搜索表单
    headerSearchFormData: {},
    // 表格的查询条件
    query: initQuery,
    // 银行账户列表
    bankInfoList: [],
    // 票据用途/收据内容列表
    contentsList: [],
    // 表格
    table: {
      rowKey: 'billInfoId',
      selectedRowKeys: [],
      selectedRows: [],
      dataSource: [],
      pagination: {
        total: 0, // 数据总数
        current: initQuery.pageNo, // 当前页
        pageSize: initQuery.pageSize, // 每页条数
        pageSizeOptions: ['20', '50', '100', '300'],
      },
    },
    // 票据领用弹窗
    receiveModal: { visible: false },
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    this.store.dispatch({ type: 'initData' });
  },
};
