/**
 * 票据状态
 */
import React, { useMemo } from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import AntdSelect from '@/AntdSelect';
import { dictionary } from '../../../../../utils';
import styles from './style.less';

const BillStatus = ({ status, dispatch }) => {
  const handleSelect = usePersistFn((value) => {
    dispatch({
      type: 'updateQuery',
      payload: { status: value },
    });
  });

  const dataSource = useMemo(
    () => dictionary.billStatus.list.filter((item) => [1, 2].includes(item.value)),
    [],
  );

  return (
    <div className={styles.select}>
      <span>票据状态：</span>
      <AntdSelect
        placeholder="请选择票据状态"
        showSearch={false}
        dataSource={dataSource}
        value={status}
        onSelect={handleSelect}
      />
    </div>
  );
};

export default connect(({ query: { status } }) => ({ status }))(BillStatus);
