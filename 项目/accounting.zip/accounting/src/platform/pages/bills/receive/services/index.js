import { util } from 'nuijs';

export default util.createRequest({
  // 获取票据领用列表
  getReceiveList: 'cashier/bill/info/queryRcvPageData:postJSON',
  // 票据领用
  billReceive: 'cashier/bill/info/receive:postJSON',
});
