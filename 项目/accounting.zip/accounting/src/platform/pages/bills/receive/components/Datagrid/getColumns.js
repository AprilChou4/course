import currency from 'currency.js';
import isNil from 'utils/isNil';

export default () => {
  return [
    {
      title: '票据编号',
      dataIndex: 'number',
      width: 90,
      ellipsis: true,
      align: 'center',
    },
    {
      title: '票据名称',
      dataIndex: 'name',
      width: 220,
      ellipsis: true,
    },
    {
      title: '登记人',
      dataIndex: 'creator',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    {
      title: '登记日期',
      dataIndex: 'registerDate',
      width: 96,
      ellipsis: true,
      align: 'center',
    },
    {
      title: '金额',
      dataIndex: 'amount',
      width: 100,
      ellipsis: true,
      align: 'right',
      render: (value) => (isNil(value, '') ? '' : currency(value).format()),
    },
    {
      title: '限额',
      dataIndex: 'limitAmt',
      width: 100,
      ellipsis: true,
      align: 'right',
      render: (value) => (isNil(value, '') ? '' : currency(value).format()),
    },
    {
      title: '用途内容',
      dataIndex: 'content',
      width: 100,
      ellipsis: true,
      align: 'center',
    },
    {
      title: '领用人',
      dataIndex: 'recipient',
      width: 110,
      ellipsis: true,
      align: 'center',
    },
    {
      title: '领用日期',
      dataIndex: 'receiveDate',
      width: 96,
      ellipsis: true,
      align: 'center',
    },
    {
      title: '备注',
      dataIndex: 'remark',
      width: 156,
      ellipsis: true,
      align: 'center',
    },
  ];
};
