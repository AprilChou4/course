/**
 * 更多条件搜索
 */
import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { usePersistFn } from 'ahooks';
import { Popover } from 'antd';
import AntdSearch from '@/AntdSearch';
import LinkButton from '@/LinkButton';
import styles from './style.less';

const MoreSearch = ({ placeholder, value: propsValue, onSearch, onRestore, ...restProps }, ref) => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState(propsValue);

  const handleVisibleChange = usePersistFn((vsb) => {
    if (!vsb) {
      setVisible(vsb);
      onRestore?.();
    }
  });

  const handleChange = usePersistFn((e) => {
    setValue(e.target.value);
  });

  const handleClick = usePersistFn(() => {
    setVisible((v) => !v);
  });

  useEffect(() => {
    setValue(propsValue);
  }, [propsValue]);

  // 传给父组件
  useImperativeHandle(ref, () => ({ setVisible }), [setVisible]);

  return (
    <Popover
      placement="bottomLeft"
      trigger="click"
      overlayClassName={styles.overlay}
      visible={visible}
      onVisibleChange={handleVisibleChange}
      {...restProps}
    >
      <AntdSearch
        placeholder={placeholder}
        suffix={<LinkButton onClick={handleClick}>更多条件</LinkButton>}
        className={styles.search}
        value={value}
        onChange={handleChange}
        onSearch={onSearch}
      />
    </Popover>
  );
};

export default forwardRef(MoreSearch);
