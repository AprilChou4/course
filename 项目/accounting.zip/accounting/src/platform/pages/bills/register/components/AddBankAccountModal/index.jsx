/**
 * 新增银行账户弹窗
 */
import React from 'react';
import { usePersistFn } from 'ahooks';
import { connect } from 'nuomi';
import EditBankModal from '@/EditBankAccountModal';

const AddBankAccountModal = ({ visible, dispatch }) => {
  const handleCancel = usePersistFn(() => {
    // 刷新一下银行账户列表
    dispatch({ type: 'getBankInfoList' });

    dispatch({
      type: 'updateState',
      payload: { addBankAccountModal: { visible: false } },
    });
  });
  return visible && <EditBankModal onCancel={handleCancel} />;
};

export default connect(({ addBankAccountModal: { visible } }) => ({ visible }))(
  AddBankAccountModal,
);
