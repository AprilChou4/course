## 数据流规范

> 参考 `src/platform/initialBalance/` 模块写法
