## 说明

数字输入时即时格式化，自动校验输入内容，不符合格式即时处理，超过小数点位数或最大值即不可再输入

## 使用

同 antd InputNumber

> 新增一个属性 `thousand`，为 `true` 时输入框内显示为千分符分隔样式

```js
import NumberInput from '@/NumberInput';

const moneyInput = () => <NumberInput thousand precision={2} max={999999999.99} min={0} />;
```
