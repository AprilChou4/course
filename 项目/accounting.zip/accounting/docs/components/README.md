## 项目公共组件

## 文件路径

src/platform/public/components/

## 功能按钮

1. ButtonGroup

topbar 右侧功能按钮组，超过指定数量自动转为 dropdown

2. buttons

- ExportButton 导出功能按钮
- ImportButton 导入
- PrintButton 打印
- RequestButton 请求功能按钮
- SearchButton 查找
  ...

## 大数据渲染优化

1. SuperTable

大数据渲染优化 Table，用法同 antd Table

> 自适应增加父元素高度（如用在 modal 中) 需设置父元素内联样式 max-height)

2. SuperSelect

大数据渲染优化 Select，用法同 antd Select

## Modal 扩展

1. SuperModal 温馨提示 confirm

默认 title 为 '温馨提示'

```js
import { SuperModal } from '@/modal';

SuperModal({
  content: <div>您好，您正在跨期间结账，是否继续结账</div>, // 提示文本，string 或 jsx
  width: 360,
  okText: '结账',
  cancelText: '取消',
  onOk: () => {},
  onCancel: () => {},
});
```

> 接口方法同 antd Modal.confirm

2. FormModal
3. ModalTip Modal 内部黄色背景提示文本

用法详见 components/modal/README

## 选择器业务组件 components/selects

1. CurrencySelect

科目外币、辅助管理外币编辑 Select
各种选择组件。。。

## 其他

1. Progress

模拟进度条，自动增加，到 99 停止

2. Period

页面 TopBar 栏左侧日期选择、切换组件

3. SearchSelect

selects/SearchSelect 下面

```js
import { SearchSelect } from '@/selects';

用于带搜索的Select
科目下拉
<SearchSelect dataSource={dataSource} type="subject"  />
辅助核算下拉
<SearchSelect dataSource={dataSource} type="auxiliary"  />
外币下拉
<SearchSelect dataSource={dataSource} type="currency"  />
也可以自定义，具体参数看组件defaultProps
```
