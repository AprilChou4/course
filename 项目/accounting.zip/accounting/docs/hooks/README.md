## 项目公共组件

## useRequest

```js
/**
 * 组件内请求数据 hook
 *
 * @param {*} initValue
 * @param {*} { request } request - 请求函数 promise，如 services.getList({type: 1});
 * @returns
 */
const useRequest = (initValue, { request }) => {
  const [data, setData] = useState(initValue);

  const fetchData = async () => {
    const res = await request;
    setData(res || null);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return [data, setData];
};

// 使用
const Test = (props) => {
  const [subjectList] = useRequest([], {
    request: services.getSubjectList({ type: 1 }),
  });

  return subjectList.map((item) => <div key={item.id}>{item.titel}</div>);
};
```

## useSummaryTableScroll

### 引入方式

```js
import useSummaryTableScroll from 'hooks/useSummaryTableScroll';
```

### 使用方式

```js
const tableRef = useRef(null); // tableRef 主体表格ref
const footerTableRef = useRef(null); // footerTableRef 表尾ref

useSummaryTableScroll(tableRef, footerTableRef, dataSource);

const tableProps = {
  idName: 'id',
  dataSource,
  columns,
  bordered: true,
  pagination: false,
  scroll: { x: '100%' },
  rowKey: (record, index) => record.id || index,
  footer: () => (
    <SuperTable
      className={summaryData.length <= 0 && 'summary-table-footer-no-data'}
      ref={footerTableRef}
      columns={summaryColumns}
      dataSource={summaryData}
      scroll={{ x: '100%' }}
      pagination={false}
      showHeader={false}
    />
  ),
  rowSelection,
};

return <EditableTable className="summary-table" ref={tableRef} {...tableProps} />;
```

可以参考 src\platform\pages\stockModule\stock\stockSetup\initialBalance\components\Table\index.jsx

### 注意事项

className="summary-table" 样式类必须加上 className={summaryData.length <= 0 && 'summary-table-footer-no-data'} 合计数据为空时加上该类名

表尾的列配置中各列的宽度需和表格主体列宽度一致。
