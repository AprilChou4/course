module.exports = {
  title: 'accounting doc',
  description: '',
  port: '8888',

  // nav
  themeConfig: {
    sidebar: {
      '/components/': ['', 'editTable', 'upload', 'superSelect'],
      '/utils/': [''],
      '/redux/': [''],
      '/rules/': ['', 'airbnb_jsx_rules'],
      '/chore/': ['', 'point'],
      '/': ['' /* /contact.html */],
    },
    displayAllHeaders: true, // 默认值：false
    nav: [
      { text: '首页', link: '/' },
      { text: '组件', link: '/components/' },
      { text: 'hooks', link: '/hooks/' },
      { text: '规范', link: '/rules/' },
      { text: '工具函数', link: '/utils/' },
      { text: '数据流', link: '/redux/' },
      { text: '其他', link: '/chore/' },
      // {
      //   text: 'External',
      //   items: [
      //     { text: 'Chinese', link: '/language/chinese/' },
      //     { text: 'Japanese', link: '/language/japanese/' },
      //   ],
      // },
    ],
    lastUpdated: 'Last Updated', // string | boolean
  },
};
