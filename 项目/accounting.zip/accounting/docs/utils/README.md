## 工具函数

## 请求

```js
util.createRequest = (services = {}) => {
  const requests = {};
  for (const i in services) {
    const service = services[i];
    if (typeof service === 'function') {
      requests[i] = (data = {}, options = {}) =>
        new Promise((resolve, reject) => {
          setTimeout(() => {
            data = service(data);
            if (data.status === '200') {
              resolve(data.data);
            } else {
              reject(data);
            }
          }, options.delay || 500);
        });
    } else {
      const temp = service.split(':');
      const url = temp[0];
      const type = temp[1] || 'get';
      requests[i] = (data = {}, options = {}) => {
        try {
          return new Promise((resolve, reject) => {
            request[type](
              url,
              data,
              {
                '200': (res) => {
                  resolve(res.data);
                },
              },
              null,
              null,
              options,
            )
              .done((res) => {
                const { status } = res;
                if (status !== '200') {
                  reject(res);
                }
              })
              .error((res) => reject(res));
          });
        } catch (e) {
          return '';
        }
      };
    }
  }
  return requests;
};
```

## 打印 pdf

...
