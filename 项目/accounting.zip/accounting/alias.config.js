const path = require('path');

const platformPublic = 'src/platform/public';
const public = 'src/public';
const resolvePath = (uri) => path.resolve(__dirname, uri);

module.exports = {
  '@': resolvePath(`${platformPublic}/components`),
  constant: resolvePath(`${platformPublic}/constant`),
  layer: resolvePath(`${platformPublic}/layer`),
  effects: resolvePath(`${platformPublic}/effects`),
  SuperTable: resolvePath(`${platformPublic}/components/SuperTable`),
  Icon: resolvePath(`${platformPublic}/components/Icon`),
  utils: resolvePath(`${platformPublic}/utils/`),
  util: resolvePath(`${public}/util`),
  data: resolvePath(`${public}/data`),
  config: resolvePath(`${public}/config`),
  method: resolvePath(`${public}/method`),
  sensitive: resolvePath(`${public}/backup/index`),
  hooks: resolvePath(`${platformPublic}/hooks`),
  public: resolvePath(public),
  pages: resolvePath('src/platform/pages'),
  services: resolvePath('src/platform/services'),
  customReport: resolvePath('src/cloudAccount'),
  crservices: resolvePath('src/cloudAccount/services'),
  crPublic: resolvePath('src/cloudAccount/public'),
};
