## 开始

### 开发环境

```shell
  yarn install
  yarn start
```

> 静态资源的根路径为 /resource/

### nginx 配置

```nginx

  location =/accounting.html {
    proxy_pass http://127.0.0.1:8893/index.html;
  }

  location /resource/ {
    proxy_pass http://127.0.0.1:8893/resource/;
  }

  # hmr websocket 服务代理
  location /sockjs-node {
    proxy_pass http://127.0.0.1:8893;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
  }

```

> npm run docs (http://localhost:8888/) 查看项目文档

### 测试环境/生产环境

```shell
  yarn install
  npm run build
```

## 公共函数

- 请求函数创建 createRequest

  ```js
  // path: src/utils/createRequest
  import createRequest from 'utils/createRequest';
  ```

- 请求配置

```js
const res = await services.getUsers(params, {
  // 默认 false，返回 res.data，为 true 时返回 res
  returnAll: true,
  // 请求显示全局 loading 提示
  loading: '请稍后...',
  // 自定义 status 对应业务逻辑
  status: {
    '^300': (res) => {
      message.error(res.message);
    },
    '30000000082': () => {
      // do something...
    },
  },
  // 去除请求中默认添加的 accountToken 参数，默认 false
  disabledAccountToken: true,
});
```

## css modules

```html
import './style.less' import styles from './style2.less'

<!-- 模块化 class -->
<div styleName="class1 class2" className="{styles.test}">test</div>

<!-- 模块化 class + 全局 class -->
<div styleName="class1 class2" className="global-class">test</div>
```

## currency.js

> https://github.com/scurker/currency.js

```js
import currency from 'currency.js';

var n = 12345678.123456;

var r1 = currency(n).format();
r1; // 12,345,678.12

var r2 = currency(n, { separator: '' }).format();
r2; // 12345678.12

var r3 = currency(n, { precision: 4 }).format();
r3; // 12,345,678.1235

var r4 = currency(n)
  .add(1.1)
  .format();
r4; // 12,345,679.22

// .multiply    x
// .divide    ÷
```

## 主要标记变量释义

````js
// account
versionType 1 代账版，0 个人版, 2 企业版

```

## 模块目录结构

```json
|-- components    // ui 组件
|-- effects       // effects 独立管理
|-- services      // 异步请求 services
|-- constant      // 模块常量
|-- utils         // 模块工具函数
|-- index.js      // 模块入口
````

## 公共组件

- select
- Textarea
- sidebartree
- NumberInput
- Input
- TableCell

## TODO

- 金额计算函数
