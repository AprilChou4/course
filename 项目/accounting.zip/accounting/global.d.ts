/**
 * @param {string|number} code 权限代码
 * @param {string|number} code 0: '小企业会计准则-一般纳税人',
 * @param {string|number} code 1: '企业会计准则-一般纳税人',
 * @param {string|number} code 2: '民间非营利组织-一般纳税人',
 * @param {string|number} code 3: '民间非营利组织-小规模纳税人',
 * @param {string|number} code 4: '小企业会计准则-小规模纳税人',
 * @param {string|number} code 5: '企业会计准则-小规模纳税人',
 * @param {string|number} code 6: '个体工商户（复式账）-一般纳税人',
 * @param {string|number} code 7: '个体工商户（复式账）-小规模纳税人',
 * @param {string|number} code 8: '企业会计准则-房地产-一般纳税人',
 * @param {string|number} code 9: '企业会计准则-房地产-小规模纳税人',
 * @param {string|number} code 10: '小企业会计准则-房地产-一般纳税人',
 * @param {string|number} code 11: '小企业会计准则-房地产-小规模纳税人',
 * @param {string|number} code 12: '农民专业合作社准则-一般纳税人',
 * @param {string|number} code 13: '农民专业合作社准则-小规模纳税人',
 * @param {string|number} code 14: '政府-一般纳税人',
 * @param {string|number} code 15: '政府-小规模纳税人',
 * @param {string|number} code 16: '国有基础建设单位',
 * @param {string} type 会计制度：accounting，权限默认为空
 */
declare function inAuth(code: number | string, type?: string): boolean;
