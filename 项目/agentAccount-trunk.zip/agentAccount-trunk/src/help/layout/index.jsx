import React, { Component } from 'react';
import { connect } from 'react-redux';
import { request } from 'nuijs';
import Head from './Head';
import Main from './Main';
// import Fixed from '../../platform/layout/Main/Fixed';//待补充

class Layout extends Component {
  componentDidMount() {
    const { SetAccout } = this.props;
    request.get('user/getCurrent.do', {}, (res) => {
      if (res.data.versionType === '1') {
        document.title = '诺诺.云代账.记账平台.帮助中心';
        window.sessionStorage.setItem('listId', '[]');
      }
      SetAccout(res.data);
    });
  }

  render() {
    return (
      <div
        className={typeof ExternService === 'object' ? 'client-container' : ''}
        style={{ height: '100%', overflow: 'hidden' }}
      >
        <Head />
        <Main />
        {/* <Fixed
          data={{
            // size:this.props.versionType == '0'?1:2,
            size: 2, // 这期只有2  代账
            type: 10,
          }}
        /> */}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  // versionType:state.account.versionType
});
const mapDispatchToProps = (dispatch) => {
  return {
    SetAccout: (account) => {
      dispatch({
        type: 'SET_ACCOUNT',
        account,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Layout);
