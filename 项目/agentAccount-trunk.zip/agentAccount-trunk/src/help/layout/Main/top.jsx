import React from 'react';
import { connect } from 'react-redux';
import dataList from '../../public/list';

const Content = ({ selectedKeys, versionType }) => {
  //   render() {
  //   const { selectedKeys, versionType } = this.props;
  const { bagNavigation } = dataList(versionType);
  return (
    selectedKeys.indexOf('/search/') === -1 && (
      <div className="docs-navigation">
        {bagNavigation.map((val, key) => {
          const fig =
            selectedKeys.indexOf('/list/') !== -1
              ? selectedKeys.indexOf(val.url) !== -1
              : val.url === selectedKeys;
          return (
            <a key={key} href={`#${val.url}`} className={fig ? 'on' : ''}>
              {val.name}
            </a>
          );
        })}
      </div>
    )
  );
  //   }
};
const mapStateToProps = (state) => ({
  selectedKeys: state.dhselecteds.selectedKeys,
  versionType: state.account.versionType,
});
export default connect(mapStateToProps)(Content);
