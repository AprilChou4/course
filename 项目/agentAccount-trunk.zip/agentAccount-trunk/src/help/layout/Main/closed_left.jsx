import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Menu, Icon } from 'antd';
import { Link } from 'react-router-dom';

const { SubMenu } = Menu;
const { Item } = Menu;

class Content extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  onSelect = (item) => {
    this.props.changeMenus({
      selectedKeys: item.selectedKeys,
    });
  };

  onOpenChange = (data) => {
    this.props.changeMenus({
      openKeys: data,
    });
  };

  render() {
    const { selectedKeys, openKeys } = this.props.dhselecteds;
    return selectedKeys.indexOf('/index') == -1 ? (
      <Menu
        mode="inline"
        selectedKeys={selectedKeys}
        openKeys={openKeys}
        onOpenChange={this.onOpenChange}
        className="docs-main-left-ul"
        onSelect={this.onSelect}
      >
        <SubMenu
          key="operation"
          title={
            <span>
              <Icon type="appstore" />
              运营管理模块
            </span>
          }
        >
          <Item key="/operation/operation">
            <Link to="/operation/operation">运营管理模块</Link>
          </Item>
        </SubMenu>
        <SubMenu
          key="build"
          title={
            <span>
              <Icon type="appstore" />
              建账操作流程
            </span>
          }
        >
          <Item key="/build/subject">
            <Link to="/build/subject">科目管理设置</Link>
          </Item>
          <Item key="/build/balance">
            <Link to="/build/balance">初始余额录入</Link>
          </Item>
        </SubMenu>
        <SubMenu
          key="daily"
          title={
            <span>
              <Icon type="appstore" />
              日常处理流程
            </span>
          }
        >
          <Item key="/daily/voucher">
            <Link to="/daily/voucher">凭证</Link>
          </Item>
          <Item key="/daily/carryover">
            <Link to="/daily/carryover">期末-结转</Link>
          </Item>
          <Item key="/daily/books">
            <Link to="/daily/books">账簿、报表</Link>
          </Item>
          <Item key="/daily/checkout">
            <Link to="/daily/checkout">结账至下月</Link>
          </Item>
        </SubMenu>
        <SubMenu
          key="added"
          title={
            <span>
              <Icon type="appstore" />
              难点功能操作
            </span>
          }
        >
          <Item key="/added/stock">
            <Link to="/added/stock" />
            存货模块
          </Item>
          <Item key="/added/auxiliary">
            <Link to="/added/auxiliary">辅助核算</Link>
          </Item>
          <Item key="/added/assets">
            <Link to="/added/assets">固定资产管理</Link>
          </Item>
          <Item key="/added/currency">
            <Link to="/added/currency">外币核算</Link>
          </Item>
          <Item key="/added/original">
            <Link to="/added/original">原始凭证管理</Link>
          </Item>
          <Item key="/added/intelligent">
            <Link to="/added/intelligent">智能凭证</Link>
          </Item>
          <Item key="/added/wipCompletion">
            <Link to="/added/wipCompletion">完工入库</Link>
          </Item>
        </SubMenu>
      </Menu>
    ) : (
      ''
    );
  }
}
const mapStateToProps = (state) => {
  return {
    // versionType:state.account.versionType,
    dhselecteds: state.dhselecteds,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    changeMenus: (menus) => {
      dispatch({
        type: 'SET_SELECTED',
        selected: menus,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Content);
