import index from '../../index/index';
import list from '../../list/index';
import videoList from '../../videoList/index';
import Download from '../../download/index';
import Search from '../../searchList/index';

export default {
  '/index': index,
  '/list/core/:id': list,
  '/list/common/:id': list,
  '/list/guide/:id': list,
  '/details/:id': list,
  '/video/index': videoList,
  '/download/index': Download,
  '/search/:id': Search,
};
