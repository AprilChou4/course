// import React ,{Component} from 'react'
// import { connect } from 'react-redux';
// import {Route,HashRouter} from 'react-router-dom'
// import Operation from '../../insteadCloud/operation/operation';

// import Subject from '../../insteadCloud/build/subject'
// import Balance from '../../insteadCloud/build/balance';

// import voucher from '../../insteadCloud/daily/voucher';
// import carryover from '../../insteadCloud/daily/carryover';
// import books from '../../insteadCloud/daily/books';
// import checkout from '../../insteadCloud/daily/checkout';

// import stock from '../../insteadCloud/added/stock';
// import auxiliary from '../../insteadCloud/added/auxiliary';
// import assets from '../../insteadCloud/added/assets';
// import currency from '../../insteadCloud/added/currency';
// import original from '../../insteadCloud/added/original';
// import intelligent from '../../insteadCloud/added/intelligent';
// import wipCompletion from '../../insteadCloud/added/wipCompletion';

// import index from '../../insteadCloud/index/index';
// import details from '../../details';
// import videoList from '../../insteadCloud/videoList/index';

// import Menu from './left';
// import Download from '../../download/index';

// import Search from '../../searchList/index';


// class Content extends Component {
//     constructor(props){
//         super(props);
//         this.state={
            
//         }
//     }
//     render(){
//         console.log(this.props.selectedKeys)
//         const style = this.props.selectedKeys.indexOf('/index') != -1?{
//             display:'none'
//         }:{}
        
//         return (
//             <HashRouter>
//                 <div className="docs-main" style={{
//                     background:this.props.selectedKeys.indexOf('/index') != -1?( (this.props.selectedKeys == '/download/index' || this.props.selectedKeys == '/search/index')?'#FFFFFF':'#F2F2F2') : '#FFFFFF',
//                     minWidth:this.props.selectedKeys == '/index'?'1200px':'1030px'
//                 }}>
//                     <Route path="/index" component={index} />
//                     <Route path="/video/index" component={videoList} />
//                     <Route path="/download/index" component={Download} />
//                     <Route path="/search/index" component={Search} />
                    
//                     <div className="docs-main-left" style={style} >
//                         <Menu/>
//                     </div>
//                     <div className="docs-main-right" style={style} >
//                         <Route path="/operation/operation" component={Operation} />
//                         <Route path="/build/subject" component={Subject} />
//                         <Route path="/build/balance" component={Balance} />
//                         <Route path="/daily/voucher" component={voucher} />
//                         <Route path="/daily/carryover" component={carryover} />
//                         <Route path="/daily/books" component={books} />
//                         <Route path="/daily/checkout" component={checkout} />
//                         <Route path="/added/stock" component={stock} />
//                         <Route path="/added/auxiliary" component={auxiliary} />
//                         <Route path="/added/assets" component={assets} />
//                         <Route path="/added/currency" component={currency} />
//                         <Route path="/added/original" component={original} />
//                         <Route path="/added/intelligent" component={intelligent} />
//                         <Route path="/added/wipCompletion" component={wipCompletion} />

//                         <Route path="/details/:id" component={details} />

//                     </div>
//                 </div>
//             </HashRouter>
//         )
//     }
// }
// const mapStateToProps =(state)=>({
//     selectedKeys:state.dhselecteds.selectedKeys[0]
// })
// export default connect(mapStateToProps)(Content);