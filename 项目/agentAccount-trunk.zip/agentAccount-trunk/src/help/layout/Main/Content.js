import React ,{Component} from 'react';
import { connect } from 'react-redux';
import routes from './Routes';

class Content extends Component {
    componentDidMount(){
        this.props.SetAccout({
            selectedKeys:this.props.match.url,
        });
        this.props.SetTopShow({
            topshow:true,
        });
    }
    render(){
        const path = this.props.match.path;
        const Html = routes[path];
        return (
            <React.Fragment>
                <Html {...this.props}/>
            </React.Fragment>
        );
    }
}
const mapStateToProps =(state)=>{
    return {};
};
const mapDispatchToProps=(dispatch)=>{
    return{
        SetAccout:(data)=>{
            dispatch({
                type:'SET_SELECTED',
                data,
            });
        },
        SetTopShow:(data)=>{
            dispatch({
                type:'SET_TOPSHOW',
                data,
            });
        },
    };
};
export default connect(mapStateToProps,mapDispatchToProps)(Content);
