import React, { Component } from 'react';

import './index.less';

class Footer extends Component {
    render() {
        return (
            <footer className="help-center-footer">
                <div className="products-list">
                    <a className="item" href="/">云财税首页</a>
                    <a className="item" href="/agent.html">云代账</a>
                    <a className="item" href="/personal.html">云记账</a>
                    <a className="item" href="https://sds.jss.com.cn" target="_blank">智汇算</a>
                </div>
                <div className="contact">
                    mail：nnycs@nnuo.com 地址：杭州市西湖区双龙街199号金色西溪A座 | Copyright&copy;-2019 〖浙江诺诺网络科技有限公司〗版权所有 浙ICP备18004495号
                </div>
                <p> 
                    <img src="https://rs.jss.com.cn/libs/images/emblem.gif?v=c6a59b6" />
                    &nbsp; &nbsp;
                    浙公网安备  33010602000456号
                </p>
            </footer>
        );
    }
}
export default Footer;