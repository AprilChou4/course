import React, { Component } from 'react';
import { Icon, Button, Input, AutoComplete } from 'antd';
import { request } from 'nuijs';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
      value: '',
    };
  }

  goSearch = (data) => {
    request.postJSON(
      // 'helpcenter/menu/queryTip',
      'instead/v2/user/helpercenter/queryTip.do',
      {
        type: 2, // 1记账   2代账
        keyWord: data,
      },
      {
        200: (res) => {
          this.setState({
            list: res.data,
            value: data,
          });
        },
      },
      null,
    );
  };

  onChange = (data, time) => {
    if (data && time.props.text === undefined) {
      this.goSearch(data);
    } else {
      this.setState({
        list: [],
        value: '',
      });
    }
  };

  onSelect = (value, option) => {
    this.AutoRef.blur();
    window.location.href = `#/search/${option.props.text}`;
  };

  onFocus = (e) => {
    if (this.state.value != this.AutoRef.props.value) {
      this.goSearch(this.AutoRef.props.value);
    }
  };

  onClick = (e) => {
    const { value } = this.state;
    $(e.target).blur();
    if (value !== '') {
      window.location.href = `#/search/${value}`;
    }
  };

  onValue = (name) => {
    this.AutoRefMain.select.rcSelect.setInputValue(name);
  };

  renderOption = (item, key) => {
    const { Option } = AutoComplete;
    const timestamp = new Date().getTime();
    const _conter = item.title.replace(
      this.state.value,
      `<span style="color:#3F91F1;">${this.state.value}</span>`,
    );
    return (
      <Option key={`${timestamp}-${key}`} text={item.title}>
        {/* <a dangerouslySetInnerHTML={{__html: _conter}}></a> */}
        <div dangerouslySetInnerHTML={{ __html: _conter }} />
      </Option>
    );
  };

  render() {
    const { list } = this.state;
    const { searchList } = this.props;
    return (
      <>
        <AutoComplete
          style={{ width: '100%' }}
          ref={(ele) => {
            this.AutoRefMain = ele;
          }}
          dataSource={list.map((val, key) => this.renderOption(val, key))}
          onChange={this.onChange}
          onSelect={this.onSelect}
          optionLabelProp="text"
          onFocus={this.onFocus}
          allowClear
          defaultActiveFirstOption={false}
        >
          <Input
            ref={(ele) => {
              this.AutoRef = ele;
            }}
            placeholder="请输入关键字进行搜索"
            onPressEnter={this.onClick}
            suffix={
              <Button className="search-btn" size="large" type="primary" onClick={this.onClick}>
                <Icon type="search" />
              </Button>
            }
          />
        </AutoComplete>
        <div className="docs-search-quick">
          {searchList.map((val, key) => {
            return (
              <a
                onClick={() => {
                  this.onValue(val.name);
                }}
                key={key}
                href={`#/search/${val.name}`}
              >
                {val.name}
              </a>
            );
          })}
        </div>
      </>
    );
  }
}
export default Header;
