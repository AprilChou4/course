import React, { Component } from 'react';
import { Card } from 'antd';
import { request } from 'nuijs';
import Iconfont from '@components/Iconfont';
import Modal from '../public/component/ModalVideo/index';
import style from './style/index.less';

class Indexs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
      visible: false,
      // videoPath: '',
      videoThumbnailPath: '',
      modalUrl: {},
      name: '',
    };
  }

  componentDidMount() {
    this.goList();
    this.getVideo();
  }

  goList = () => {
    request.postJSON(
      // 'helpcenter/menu/getMenuTree.do',
      'instead/v2/user/helpercenter/getMenuList.do',
      {
        type: 2, // 1记账   2代账
        classify: 1, // 1=新手引导页面
        isHome: 1,
      },
      {
        200: (res) => {
          const colors = ['#5EB6FF', '#FFC135', '#43D081', '#F5765B', '#C367DC'];
          const icons = ['\uec5f', '\uec5d', '\uec5e', '\uec60', '\uec5c'];
          const list = res.data.map((item, index) => ({
            ...item,
            backgroundColor: colors[index],
            code: icons[index],
          }));
          this.setState({
            list,
          });
        },
      },
      '正在加载数据',
    );
  };

  getVideo = () => {
    request.post(
      'instead/v2/user/helpercenter/getHomepageVideo.do',
      {
        type: 2, // 1记账   2代账
      },
      {
        200: (res) => {
          if (res.result === 'success' && res.data && res.data.videoPath) {
            const { videoPath, videoThumbnailPath, videoId, videoName } = res.data;
            this.setState({
              modalUrl: {
                videoUrl: videoPath,
                msgUrl: videoThumbnailPath,
                videoId,
              },
              videoThumbnailPath,
              name: videoName,
            });
          }
        },
      },
      '正在加载数据',
    );
  };

  onClick = () => {
    this.setState({
      visible: true,
    });
  };

  onCancel = () => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { list, videoThumbnailPath, name, modalUrl, visible } = this.state;
    const imgUrl = videoThumbnailPath || '/static/images/videoimg.jpg';
    return (
      <div
        className="docs-main"
        style={{
          background: '#F2F2F2',
        }}
      >
        <div className={style['ui-docs-index']}>
          <h3 className="title">快速入门</h3>
          <div className="ui-docs-index-rq">
            {list.map((val) => {
              return (
                <Card bordered={false} key={val.sort}>
                  <div className="icon-wrap" style={{ background: val.backgroundColor }}>
                    <Iconfont className="i-point" type={val.iconClass} code={val.code} />
                  </div>
                  <p className="menu-name">{val.menuName}</p>
                  <p className="menu-list">
                    {val.child.map((v, k) => {
                      return (
                        <a key={k} href={`#/list/guide/1-${v.pid}-${v.menuId}`} title={v.menuName}>
                          {v.menuName}
                        </a>
                      );
                    })}
                  </p>
                </Card>
              );
            })}
          </div>
          {modalUrl.videoUrl && (
            <div className="ui-docs-index-video">
              <div>
                <h3 className="title">{name}</h3>
                <div className="ui-media-div">
                  <Card bordered={false}>
                    <div className="videoList-imgp" onClick={() => this.onClick()}>
                      <img src={imgUrl} alt="图片" />
                      <a>
                        <Iconfont code="&#xeb2d;" name="kaishi" />
                        <span />
                      </a>
                    </div>
                  </Card>

                  <Modal visible={visible} modalUrl={modalUrl} onCancel={this.onCancel} />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default Indexs;
