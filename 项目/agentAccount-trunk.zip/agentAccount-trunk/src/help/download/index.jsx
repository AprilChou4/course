import React, { Component } from 'react';
import { connect } from 'react-redux';
import ReactDom from 'react-dom';
import { Button } from 'antd';
import { request } from 'nuijs';
import style from './style/index.less';

class Details extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
    };
  }

  componentDidMount() {
    this.goList();
  }

  goList = () => {
    request.post(
      // 'helpcenter/menu/getDownloadlList',
      'instead/v2/user/helpercenter/getDownloadlList',
      {
        type: 2, // 1记账   2代账
      },
      {
        200: (res) => {
          this.setState({
            list: res.data || [],
          });
        },
      },
      '正在加载数据',
    );
  };

  onClick = (val) => {
    request.postJSON('instead/v2/user/helpercenter/operateStatistics.do', {
      type: 2, // 1记账   2代账
      operateObjectType: 2,
      objectId: val.downloadId,
    });
  };

  render() {
    const { list } = this.state;
    return (
      <>
        <div
          className="docs-main"
          style={{
            background: '#FFFFFF',
            width: '1200px',
            margin: '28px auto',
            overflow: 'hidden',
          }}
        >
          <div className={style['ui-docs-download']}>
            {list.map((val, key) => {
              return (
                <div key={key} className="docs-download-list">
                  <span className="download-list-left">
                    <img src={val.icon} alt="图片" />
                  </span>
                  <div className="download-list-mian">
                    <h6>{val.title}</h6>
                    <p>{val.des}</p>
                  </div>
                  <a href={val.filePath} target="_blank" rel="noreferrer">
                    <Button
                      onClick={() => this.onClick(val)}
                      className="download-list-right"
                      type="primary"
                    >
                      立即下载
                    </Button>
                  </a>
                </div>
              );
            })}
          </div>
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({});
const mapDispatchToProps = (dispatch) => {
  return {
    changeMenus: (menus) => {
      dispatch({
        type: 'SET_SELECTED',
        selected: menus,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Details);
