import React, { Component } from 'react';
import { connect } from 'react-redux';
import { request } from 'nuijs';
// import { reactLayer } from 'layer'; //待补充
import style from './style/index.less';
// import Send from '../../platform/pages/message/send/feedback'; //待补充
import AdviseModal from '../list/AdviseModal';

class Details extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      list: [],
      classifyList: {
        '1': '/list/guide/',
        '2': '/list/core/',
        '3': '/list/common/',
        '4': '/video/index/',
        '5': '/download/index/',
      },
      adviseModalVisible: false,
    };
  }

  componentDidMount() {
    const { match } = this.props;
    const { params } = match;
    this.getUrl(params.id);
  }

  UNSAFE_componentWillReceiveProps = (nextProps) => {
    const { match } = this.props;
    if (match.params.id !== nextProps.match.params.id) {
      this.getUrl(nextProps.match.params.id);
    }
  };

  // 建议反馈
  openAdvise = () => {
    this.setState({
      adviseModalVisible: true,
    });
    // reactLayer({
    //   width: 620,
    //   id: 'feedbacks',
    //   // height:'300',
    //   height: 520,
    //   // under:_this.self,
    //   title: '建议反馈',
    //   render() {
    //     return <Send self={this.self} />;
    //   },
    //   cancel: {
    //     enable: false,
    //     text: '取消',
    //   },
    //   confirm: {
    //     enable: false,
    //     text: '提交',
    //     callback(self) {},
    //   },
    // });
  };

  // 关闭建议反馈弹窗
  closeAdvise = () => {
    this.setState({
      adviseModalVisible: false,
    });
  };

  getUrl = (name) => {
    const that = this;
    request.postJSON(
      'instead/v2/user/helpercenter/queryTip.do',
      {
        type: 2, // 1记账   2代账
        keyWord: name,
      },
      {
        200: (res) => {
          that.setState({
            list: res.data,
            name,
          });
        },
      },
      '正在加载数据',
    );
  };

  render() {
    const { name, list, classifyList, adviseModalVisible } = this.state;
    return (
      <>
        <div className={style['ui-docs-searchList']}>
          {list.length > 0 && (
            <p className="docs-searchList-tit">共搜索出 {list.length} 条相关内容</p>
          )}
          {list.length > 0 ? (
            <div className="docs-searchList-mian">
              {list.map((val, key) => {
                let _conter = val.title.replace(name, `<span>${name}</span>`);
                let _href = `#${classifyList[val.classify]}${val.classify}`;
                if (val.menuIdList && val.menuIdList.length) {
                  _href = `${_href}-${val.menuIdList.join('-')}`;
                }
                _href = `${_href}/${val.id}`;
                if (val.has_video == 1) {
                  _conter +=
                    '<i style="margin-left:8px;" class="iconfont icon-shipinbiaoshi i-point"></i>';
                }
                return (
                  <p key={key}>
                    <a href={_href} dangerouslySetInnerHTML={{ __html: _conter }} />
                  </p>
                );
              })}
            </div>
          ) : (
            <div className="no-result">
              <img src="/static/images/void.5aa99ff.png" alt="img" />
              <p>
                很抱歉，没有找到搜索的结果，请试试别的关键词或点击这里填写{' '}
                <a onClick={this.openAdvise}>建议反馈</a> 给我们吧~
                {adviseModalVisible && (
                  <AdviseModal visible={adviseModalVisible} close={this.closeAdvise} />
                )}
              </p>
            </div>
          )}
        </div>
      </>
    );
  }
}
const mapStateToProps = (state) => ({});
const mapDispatchToProps = (dispatch) => {
  return {
    changeMenus: (menus) => {
      dispatch({
        type: 'SET_SELECTED',
        selected: menus,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Details);
