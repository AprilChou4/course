import React, { Component } from 'react';
import { connect } from 'react-redux';
import { request } from 'nuijs';
import { Icon, Popover, Tooltip, Button } from 'antd';
import Iconfont from '@components/Iconfont';
import './style/index.less';
// import { reactLayer } from 'layer'; //待补充
import ModalVideo from '../../public/component/ModalVideo/index';
// import Send from '../../../platform/pages/message/send/feedback'; //待补充
import AdviseModal from '../AdviseModal';

class Doc extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      modalUrl: {},
      feedback: {},
      // 建议反馈弹窗是否显示
      adviseModalVisible: false,
    };
  }

  componentDidMount() {
    this.scrollDiv.onscroll = () => {
      const { topshow, SetTopShow } = this.props;
      const t = this.scrollDiv.scrollTop;
      if (t > 225 && topshow.topshow) {
        SetTopShow({
          topshow: false,
        });
      } else if (t === 0 && !topshow.topshow) {
        SetTopShow({
          topshow: true,
        });
      }
    };

    document.addEventListener(
      'click',
      (this.onClick = (e) => {
        if ($(e.target).parents('.main-details-list').length > 0 && e.target.localName === 'img') {
          const url = $(e.target).attr('src');
          //   reactLayer({
          //     width: '100%',
          //     id: 'help-ui-imgs',
          //     height: '100%',
          //     title: null,
          //     events: {
          //       'click .layer-body': function () {
          //         layer.hide('help-ui-imgs');
          //       },
          //       'click .component-container img': function (e) {
          //         e.stopPropagation();
          //       },
          //     },
          //     render() {
          //       return (
          //         <div>
          //           <span />
          //           <img src={url} />
          //         </div>
          //       );
          //     },
          //     cancel: {
          //       enable: false,
          //       text: '取消',
          //     },
          //     confirm: {
          //       enable: false,
          //       text: '提交',
          //       callback(self) {},
          //     },
          //   });
        }
      }),
    );
  }

  UNSAFE_componentWillReceiveProps = (nextProps) => {
    const { detailsList } = this.props;
    const { detailId } = detailsList;
    if (nextProps.detailsList && nextProps.detailsList.detailId !== detailId) {
      this.setState({
        feedback: {},
      });
    }
  };

  componentWillUnmount() {
    clearTimeout(this.tiem);
    document.removeEventListener('click', this.onClick);
  }

  goBack = () => {
    const { history } = this.props;
    history.go(-1);
  };

  plays = (data) => {
    const { videoPath, videoThumbnailPath, videoId } = data;
    this.setState({
      visible: true,
      modalUrl: {
        videoUrl: videoPath,
        msgUrl: videoThumbnailPath,
        videoId,
      },
    });
  };

  onCancel = () => {
    this.setState({
      visible: false,
    });
  };

  feedback = (type) => {
    const { detailsList } = this.props;
    const { feedback } = this.state;
    const { detailId } = detailsList;
    if (!feedback[detailId]) {
      this.onPractical(type);
      this.setState(
        {
          feedback: {
            [detailId]: type,
          },
        },
        () => {
          if (type === 1) {
            this.tiem = setTimeout(() => {
              this.setState({
                feedback: {
                  [detailId]: type + 10,
                },
              });
            }, 5000);
          }
        },
      );
    }
  };

  onVisibleChange = () => {
    const { detailsList } = this.props;
    const { feedback } = this.state;
    const { detailId } = detailsList;
    if (feedback[detailId] === 1) {
      clearTimeout(this.tiem);
      this.setState({
        feedback: {
          [detailId]: feedback[detailId] + 10,
        },
      });
    }
  };

  onPractical = (type) => {
    const { detailsList } = this.props;
    const { detailId } = detailsList;
    request.postJSON('instead/v2/user/helpercenter/operateStatistics.do', {
      type: 2, // 1记账   2代账
      use: type === 1 ? 1 : 0,
      operateObjectType: 1,
      objectId: detailId,
    });
  };

  // 打开建议反馈弹窗
  openAdvise = () => {
    const { detailsList } = this.props;
    const { detailId } = detailsList;
    this.setState({
      feedback: {
        [detailId]: 12,
      },
      adviseModalVisible: true,
    });
    // reactLayer({
    //   width: 620,
    //   id: 'feedbacks',
    //   // height:'300',
    //   height: 520,
    //   // under:_this.self,
    //   title: '建议反馈',
    //   render() {
    //     // return <Send self={this.self} />;
    //   },
    //   cancel: {
    //     enable: false,
    //     text: '取消',
    //   },
    //   confirm: {
    //     enable: false,
    //     text: '提交',
    //     callback(self) {},
    //   },
    // });
  };

  // 关闭建议反馈弹窗
  closeAdvise = () => {
    this.setState({
      adviseModalVisible: false,
    });
  };

  render() {
    const { detailsList, url } = this.props;
    const { feedback, visible, modalUrl, adviseModalVisible } = this.state;
    const { title, hasVideo, videoList, content, detailId, pre, next } = detailsList;
    let contents = '';
    if (content) {
      contents = content;
      // contents = content.replace(/(<img .*?>)/g,'<span class="j-pop-img"><em class="ui-pop-img"><i class="iconfont ui-pop-i">&#xe6ab;</i></em>$1</span>');
    }

    const content1 = (
      <span>
        <img
          width={20}
          style={{
            verticalAlign: 'top',
            marginRight: '5px',
          }}
          src="/static/images/xiaolian.png"
          alt="图片"
        />
        <i>感谢您的反馈</i>
      </span>
    );
    const content2 = (
      <div>
        <p
          style={{
            fontSize: 14,
            fontWeight: 'bold',
            marginBottom: 4,
          }}
        >
          是否填写建议反馈？
        </p>
        <p>您的反馈可以帮助我们更好的服务</p>
        <p
          style={{
            textAlign: 'center',
            margin: '0px',
          }}
        >
          <Button
            onClick={() => {
              this.setState({
                feedback: {
                  [detailId]: 12,
                },
              });
            }}
            style={{
              marginRight: 4,
            }}
          >
            否
          </Button>
          <a onClick={this.openAdvise} target="_blank">
            <Button
              type="primary"
              style={{
                marginLeft: 4,
              }}
            >
              是
            </Button>
          </a>
        </p>
      </div>
    );

    return (
      <div className="docs-main-right">
        <div className="main-top">
          <a className="main-ui-goBack" onClick={this.goBack}>
            <Icon type="arrow-left" />
            返回上一页
          </a>
        </div>
        <div
          className="main-details"
          ref={(e) => {
            this.scrollDiv = e;
          }}
        >
          <h5>
            {title}
            {hasVideo === 1 && <Iconfont className="i-point" type="shipinbiaoshi" />}
          </h5>
          <div className="main-details-list">
            {hasVideo === 1 &&
              videoList &&
              videoList.map((val, key) => (
                <div key={key}>
                  <p>{val.title}</p>
                  <div className="main-details-list-img" onClick={() => this.plays(val)}>
                    <img
                      src={val.video_thumbnail_path || '/static/images/videoimg.jpg'}
                      alt="图片"
                    />
                    <a>
                      <Iconfont className="i-point" type="kaishi" />
                      <span />
                    </a>
                  </div>
                </div>
              ))}
            {hasVideo === 1 && videoList.length && (
              <ModalVideo visible={visible} modalUrl={modalUrl} onCancel={this.onCancel} />
            )}
            <div className="main-details-list-div" dangerouslySetInnerHTML={{ __html: contents }} />
          </div>
          <div className="main-details-bottom">
            <p className="main-details-bottom-p1">
              以上内容对您来说有用吗？
              <Tooltip
                trigger="click"
                overlayClassName="help-tooltip"
                onVisibleChange={this.onVisibleChange}
                visible={feedback[detailId] === 1}
                placement="top"
                title={content1}
              >
                <Iconfont
                  title="有用"
                  onClick={() => this.feedback(1)}
                  className={
                    feedback[detailId] === 1 || feedback[detailId] === 11 ? 'i-point on' : 'i-point'
                  }
                  code="&#xeb26;"
                />
              </Tooltip>
              <Popover
                trigger="click"
                onVisibleChange={this.onVisibleChange}
                visible={feedback[detailId] === 2}
                content={content2}
                title={null}
              >
                <Iconfont
                  title="无用"
                  onClick={() => this.feedback(2)}
                  className={
                    feedback[detailId] === 2 || feedback[detailId] === 12 ? 'i-point on' : 'i-point'
                  }
                  code="&#xeb27;"
                />
              </Popover>
            </p>
            <p className="main-details-bottom-p2">
              {!!pre && (
                <a href={`#${url}/${pre.detailId}`}>
                  <Iconfont className="i-point" type="left-small" code="&#xe857;" />
                  <span>上一篇：{pre.title}</span>
                </a>
              )}
              {!!next && (
                <a style={{ textAlign: 'right', float: 'right' }} href={`#${url}/${next.detailId}`}>
                  <span>下一篇：{next.title}</span>
                  <Iconfont className="i-point" type="right-small" code="&#xe858;" />
                </a>
              )}
            </p>
          </div>
        </div>
        {adviseModalVisible && (
          <AdviseModal visible={adviseModalVisible} close={this.closeAdvise} />
        )}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  topshow: state.topshow,
});
const mapDispatchToProps = (dispatch) => {
  return {
    SetTopShow: (account) => {
      dispatch({
        type: 'SET_TOPSHOW',
        data: account,
      });
    },
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Doc);
