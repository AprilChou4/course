import React, { Component } from 'react';
import { connect } from 'react-redux';
import Icon from 'Icon';
import style from './index.less';
import 'nuonuo-libs/script/axnui/jquery.lazyload.min.js';

export default function (Elem) {
  class Doc extends Component {
    constructor(props) {
      super(props);
      this.state = {};
    }

    componentDidMount() {
      this.changeMenus();
    }

    changeMenus = () => {
      const _openKeys = this.props.dhselecteds.openKeys;
      const selectedKeys = location.hash.substring(1);
      const openKeys = location.hash.substring(1).split('/')[1];
      if (_openKeys.indexOf(openKeys) == -1) {
        _openKeys.push(openKeys);
      }
      this.props.changeMenus({
        selectedKeys: [selectedKeys],
        openKeys: _openKeys,
      });
    };

    componentWillUnmount() {}

    render() {
      return (
        <>
          <div className="main">
            <div className="main-top">
              <p>
                <a href="#/build/subject">导入员工</a>
                <span>/</span>
                <a href="#/build/subject">员工赋权</a>
                <span>/</span>
                <a className="main-top-a-current">员工分配角色</a>
              </p>
            </div>
            <div className="main-list">
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div on">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
              <div className="main-list-div">
                <h5>
                  <a>
                    员工分配角色员工分配角色员工分配角色员工分配角色{' '}
                    <Icon className="i-point" type="kehu" />
                  </a>
                </h5>
                <a className="main-list-div-a">
                  进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增员工信息。进入【我的企业-部门员工】新增...
                </a>
              </div>
            </div>
          </div>
        </>
      );
    }
  }
  const mapStateToProps = (state) => ({
    dhselecteds: state.dhselecteds,
  });
  const mapDispatchToProps = (dispatch) => {
    return {
      changeMenus: (menus) => {
        dispatch({
          type: 'SET_SELECTED',
          selected: menus,
        });
      },
    };
  };
  return connect(mapStateToProps, mapDispatchToProps)(Doc);
}
