import React, { Component } from 'react';
import { connect } from 'react-redux';
import videojs from 'video.js';
import 'video.js/dist/video-js.css';
import { request } from 'nuijs';

class Videos extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    // {...this.props,...{
    //     children:{
    //         controlBar: {
    //             volumePanel: {
    //                 inline: false //默认是true,横着的
    //             }
    //         }
    //         // bigPlayButton,
    //         // volumePanel: {
    //         //     inline: false //默认是true,横着的
    //         // }
    //     }
    // }}
    const { thatVideo } = this.props;
    thatVideo.player = videojs(this.videoNode, this.props, () => {
      this.onPlays();
    });
  }

  UNSAFE_componentWillReceiveProps = () => {
    this.onPlays();
  };

  onPlays = () => {
    const { thatVideo, modalUrl } = this.props;
    thatVideo.player.play();
    const objectId = modalUrl.videoId;
    // 操作对象 1:菜单详情;2插件;3视频
    request.postJSON('instead/v2/user/helpercenter/operateStatistics', {
      type: 2, // 1记账   2代账
      operateObjectType: 3,
      objectId,
    });
  };

  render() {
    const { modalUrl } = this.props;
    const { videoUrl, msgUrl } = modalUrl;
    return (
      <video
        ref={(node) => {
          this.videoNode = node;
        }}
        id="my-video"
        className="video-js vjs-big-play-centered"
        controls
        preload="auto"
        poster={msgUrl || '/static/images/videoimg.jpg'}
        data-setup="{}"
        width={680}
        height={384}
        muted
      >
        <source src={videoUrl} type="video/mp4" />
        <source src={videoUrl} type="video/webm" />
        <source src={videoUrl} type="video/ogg" />
        {/* <source src="http://vjs.zencdn.net/v/oceans.mp4" type="video/mp4" />
        <source src="http://vjs.zencdn.net/v/oceans.webm" type="video/webm" />
        <source src="http://vjs.zencdn.net/v/oceans.ogv" type="video/ogg" /> */}
      </video>
    );
  }
}
export default connect()(Videos);
