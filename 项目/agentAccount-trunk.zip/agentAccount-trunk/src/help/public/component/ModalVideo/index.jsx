import React, { Component } from 'react';
import { Modal } from 'antd';
import Videos from './video';

class Details extends Component {
  afterClose = () => {
    if (this.player) {
      this.player.dispose();
    }
  };

  render() {
    const { visible, onCancel, modalUrl } = this.props;
    return (
      <>
        <Modal
          wrapClassName="video-div-modal"
          visible={visible}
          title={null}
          footer={null}
          centered
          onCancel={onCancel}
          maskClosable={false}
          width={680}
          afterClose={this.afterClose}
          destroyOnClose
        >
          <Videos thatVideo={this} modalUrl={modalUrl} />
        </Modal>
      </>
    );
  }
}

export default Details;
