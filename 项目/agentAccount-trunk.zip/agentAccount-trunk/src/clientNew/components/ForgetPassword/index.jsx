// 忘记密码
import React from 'react';
import style from './style.less';
import ForgetModal from './ForgetModal';

const ForgetPassword = () => {
  const forget = () => {};
  return (
    <>
      <a onClick={forget}>忘记密码--new？</a>
      <ForgetModal />
    </>
  );
};
export default ForgetPassword;
