// 忘记密码
import React from 'react';
import { Modal, Form, Input, Button } from 'antd';
import Iconfont from '@components/Iconfont';
import VertifyCode from '@components/VertifyCode';
import Style from './style.less';

const ForgetModal = ({ form }) => {
  const onFinish = (values) => {
    console.log('Received values of form: ', values);
  };
  return (
    <Modal
      visible
      centered
      width={328}
      title={null}
      maskClosable={false}
      className={Style.resetPassword}
    >
      <h3>重 置 密 码</h3>
      <Form
        name="normal_login"
        className="login-form"
        initialValues={{ remember: true }}
        onFinish={onFinish}
      >
        {/* <!-- 阻止浏览器的自动填充 -->  */}
        <div style={{ position: 'absolute', top: '-999px' }}>
          <input type="text" />
          <input type="password" autoComplete="new-password" />
          <input type="text" />
        </div>
        <Form.Item name="mobile" rules={[{ required: true, message: '请输入手机号' }]}>
          <Input prefix={<Iconfont code="&#xe687;" />} placeholder="请输入手机号" />
        </Form.Item>
        <VertifyCode
          isHasImgCode
          imgCodeUrl="instead/v2/user/allow/verification/code/updatePwdImageCode.do"
          // checkImgCode={checkImgCode}
          // sendMobileCode={sendMobileCode}
          placeholder="请输入短信验证码"
          prefix={<Iconfont code="&#xe67e;" />}
          isNeedCheckMobile={false}
          form={form}
          className={Style.messageCode}
        />
        <Form.Item name="password" rules={[{ required: true, message: '请输入6-35位字符密码' }]}>
          <Input
            prefix={<Iconfont code="&#xe622;" />}
            type="password"
            placeholder="请输入6-35位字符密码"
            maxLength={35}
          />
        </Form.Item>

        <Form.Item
          name="repassword"
          rules={[
            {
              required: true,
              message: '请输入重复密码',
            },
            ({ getFieldValue }) => ({
              validator(rule, value) {
                if (!value || getFieldValue('password') === value) {
                  return Promise.resolve();
                }
                return Promise.reject('两次密码输入不一致');
              },
            }),
          ]}
        >
          <Input
            prefix={<Iconfont code="&#xe622;" />}
            type="password"
            placeholder="请输入重复密码"
            maxLength={35}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" className="login-form-button">
            重置密码
          </Button>
        </Form.Item>
      </Form>
    </Modal>
  );
};
const ForgetModalForm = Form.create()(ForgetModal);
export default ForgetModalForm;
