/* *
 * 这是选择企业列表弹层
 * 参数说明
 *
 */
import { request, layer } from 'nuijs';
import { util } from '@utils';
import { message } from 'antd';
import './style/entList.less';

export default function (cb, listData) {
  layer.hide();
  const url = 'instead/v2/user/company/list.do';
  const setUrl = 'instead/v2/user/company/change.do';
  const setCloudEnterprise = 'instead/v2/user/cloudEnterprise.do';
  const client = typeof ExternService === 'object';
  function entListLayers(lists) {
    const list = [];
    lists.forEach((val) => {
      if (client) {
        // 0 记账版 3=查账版 4企业版 过滤掉
        if (val.versionType !== 0 && val.versionType !== 4 && !val.notActive) {
          list.push(val);
        }
      }
    });

    // 客户端环境 and 列表为空（列表中都是企业版、记账版）也提示错误“客户端仅支持代账用户”
    if (typeof ExternService === 'object' && !list.length) {
      message.error('客户端仅支持代账用户');
      return;
    }
    //  #173864
    if (list.length === 1) {
      const { companyId, versionType } = list[0];
      request.post(
        setUrl,
        {
          companyId,
        },
        {
          200() {
            if (cb) {
              cb(companyId);
            } else if (versionType === 1) {
              localStorage.setItem('versionType', '1');
              util.location(`${basePath}cloud/index.html`);
            }
          },
          300(res) {
            loginError(res);
          },
        },
        '正在登陆中...',
      );
      return;
    }

    layer({
      id: 'entlists',
      title: null,
      width: 598,
      height: 455,
      data: {
        list,
      },
      template: `<div class="m-changeCompany">
        <h3>选择企业</h3>
        <ul class="m-list">
            <% each list val key%>
                <li data-enterpriseCompanyId="<%val.enterpriseCompanyId%>" data-userEnable="<%val.userEnable%>"  data-companyId="<% val.companyId %>" data-companyName="<% val.companyName %>" data-versionType="<% val.versionType %>" class="<%  val.notReview || val.notActive ? 'm-notEntry' : ''%>">
                    <div class="m-item">
                        <span class="m-name text-overflow" title="<% val.companyName %>">
                            <i class="m-name-type m-name-type1"><%val.versionType === 0 ? '个' : val.versionType === 4 ? '企' : '代'%></i>
                            <%val.companyName%>
                            <%if val.versionType === 3%>
                              <i class="m-name-type m-name-type2">查</i>
                            <%/if%>
                        </span>

                        <%if !val.notReview  && !val.notActive %>
                            <a href="javascript:;" class="ui-blue f-fr">进入企业 >></a>
                        <%/if%>
                        <% if val.notReview || val.notActive %>
                            <div class="m-vertify">
                                <% if val.notReview %>
                                    <span><i class="iconfont yellow-dot"></i>审核中</span>
                                    <a href="javascript:;" class="ui-blue f-fr f-dn j-recallApply">撤回申请</a>
                                    <a href="javascript:;" class="ui-blue f-fr f-dn j-reApply">重新申请</a>
                                <%/if%>
                                <%if val.notActive %>
                                    <span><i class="iconfont yellow-dot"></i>待激活</span>
                                    <a href="javascript:;" class="ui-blue f-fr f-dn j-delCompany">删除企业</a>
                                    <a href="javascript:;" class="ui-blue f-fr f-dn j-activeCompany">激活企业</a>
                                <%/if%>
                            </div>
                        <%/if%>

                    </div>
                </li>
            <%/each%>
        </ul>
      </div>`,
      cancel: {
        enable: false,
      },
      events: {
        // 'click .j-recallApply': function (e, elem) {
        //   const data = elem.closest('li').data();
        //   const param = {
        //     phoneNum: phoneNum || datas.mobile,
        //     companyId: data.companyid,
        //   };
        //   request.postJSON(
        //     'instead/v2/user/dz/allow/cancelJoinStatus.do',
        //     param,
        //     {
        //       200() {
        //         message('撤回成功');
        //         elem.closest('li').remove();
        //       },
        //       other(res) {
        //         message('error', res.message);
        //       },
        //     },
        //     '正在撤销...',
        //     this.self,
        //   );
        // },
        // 'click .j-reApply': function (e, elem) {
        //   const data = elem.closest('li').data();
        //   const param = {
        //     phoneNum: phoneNum || datas.mobile,
        //     companyId: data.companyid,
        //   };
        //   request.postJSON(
        //     'instead/v2/user/dz/allow/reJoinStatus.do',
        //     param,
        //     {
        //       200() {
        //         message('重新申请成功');
        //       },
        //       other(res) {
        //         message('error', res.message);
        //       },
        //     },
        //     '正在重新申请...',
        //     this.self,
        //   );
        // },
        'click .m-changeCompany li:not(".s-crt"):not(".m-notEntry")': function (e, elem) {
          const id = elem.attr('data-companyId');
          const versionType = elem.attr('data-versionType');
          const enterpriseCompanyId = elem.attr('data-enterpriseCompanyId');
          if (versionType === '4') {
            const userEnable = elem.attr('data-userEnable');
            if (userEnable === 'false') {
              message('error', '您的账号未启用，请联系管理员！');
              return;
            }
            request.get(
              setCloudEnterprise,
              {},
              {
                200(res) {
                  location.replace(`${res.data}/list#!/index?companyId=${enterpriseCompanyId}`);
                },
                300(res) {
                  loginError(res);
                },
              },
              '正在登陆中...',
            );
            return;
          }
          request.post(
            setUrl,
            {
              companyId: id,
            },
            {
              200(res) {
                if (cb) {
                  cb(id);
                } else if (!id && versionType == 0) {
                  // // id为空 versionType=0 跳转记账
                  // localStorage.setItem('versionType', '0');
                  // location.replace(`${basePath}accounts.html`);
                } else {
                  localStorage.setItem('versionType', '1');
                  util.location(`${basePath}cloud/index.html`);
                }
              },
              300(res) {
                loginError(res);
              },
            },
            '正在登陆中...',
          );
        },
      },
    });
  }
  if (listData) {
    entListLayers(listData);
  } else {
    request.postJSON(
      url,
      {},
      {
        200(res) {
          entListLayers(res.data);
        },
      },
      '正在获取企业列表...',
    );
  }
}
