import React, { Component } from 'react';
import { Form, Input, Button, Row, Col, Checkbox, AutoComplete, message } from 'antd';
// import { encode, decode } from 'nuonuo-libs/script/polyfill/base64'; //待补充
import { util } from '@utils';
import { Base64 } from 'js-base64';
import Iconfont from '@components/Iconfont';
// import api from 'clientAPI'; // 待补充
import clientAPI from '@public/script/clientAPI';
import Code from './Code';
import style from './style/index.less';
import forget from './forget';
import ForgetPassword from '../ForgetPassword';
import entList from './entList';

const FormItem = Form.Item;
const { Option } = AutoComplete;

class Login extends Component {
  storageName = 'login_accounts';

  constructor() {
    super();
    const keepData = localStorage.getItem(this.storageName) || '';
    let keepPassword = {};
    try {
      const keep = JSON.parse(keepData) || [];
      keepPassword = keep;
    } catch (e) {
      keepPassword = JSON.parse(Base64.decode(keepData) || '[]');
    }

    this.state = {
      visible: false,
      showPassword: false,
      accounts: keepPassword,
    };
  }

  componentDidMount() {
    const { visible } = this.state;
    document.addEventListener(
      'click',
      () => {
        if (visible) {
          this.setState({
            visible: false,
          });
        }
      },
      false,
    );
  }

  inputChange = (value) => {
    const { accounts } = this.state;
    const { input } = this.input;
    value = value.trim();
    const account = accounts.find((v) => {
      return v.username.indexOf(value) === 0;
    });
    if (account && this.keyCode !== 8) {
      const { selectionStart } = input;
      const { username } = account;
      setTimeout(() => {
        this.setValue(account);
        if (value !== username) {
          input.setSelectionRange(selectionStart, username.length);
        }
      });
    } else {
      this.setValue({
        remember: false,
        password: '',
      });
    }
    this.keyCode = null;
  };

  inputKeyDown = (e) => {
    this.keyCode = e.keyCode;
  };

  setValue(data) {
    const { form } = this.props;
    form.setFieldsValue({
      ...data,
      remember: !!data.remember,
    });
  }

  setAccounts(accounts, cb) {
    this.setState(
      {
        accounts,
      },
      () => {
        cb && cb();
        localStorage.setItem(this.storageName, Base64.encode(JSON.stringify(accounts)));
      },
    );
  }

  removeAccount = (e, index, data) => {
    e.stopPropagation();
    e.nativeEvent.stopImmediatePropagation();
    const { form } = this.props;
    const { accounts } = this.state;
    this.setAccounts(accounts.slice(0, index).concat(accounts.slice(index + 1)), () => {
      const value = form.getFieldValue('username');
      if (value === data.username) {
        this.setValue({
          remember: false,
          username: '',
          password: '',
        });
      }
    });
  };

  showDropdown = (e) => {
    e.nativeEvent.stopImmediatePropagation();
    this.setState({
      visible: true,
    });
  };

  showPassword = () => {
    const { showPassword } = this.state;
    this.setState({
      showPassword: !showPassword,
    });
  };

  goCloud = (data) => {
    const { username, password, remember } = data;

    let { accounts } = this.state;
    const index = accounts.findIndex((v) => {
      return v.username === username;
    });
    if (index !== -1) {
      accounts = accounts.slice(0, index).concat(accounts.slice(index + 1));
    }
    accounts.unshift({
      username,
      password: remember ? password : '',
      remember: remember ? '1' : '',
    });
    this.setAccounts(accounts, () => {
      // 临时解决登录后，又跳转回登录界面的问题
      localStorage.setItem('loginStatus', 1);
      if (typeof ExternService === 'object') {
        clientAPI.maxScreen();
      }
      // location.replace(`${basePath}cloud/index.html`);
      util.location(`${basePath}cloud/index.html`);
    });
  };

  handleSubmit = (e) => {
    const { form } = this.props;
    e.preventDefault();
    form.validateFields((err, data) => {
      if (!err) {
        Object.keys(data).forEach((key) => {
          const value = data[key];
          if (value.trim) {
            data[key] = value.trim();
          }
        });
        const { username, password, code } = data;

        this.request.postJSON(
          'instead/v2/user/allow/login.do',
          {
            versionType: 2,
            password: Base64.encode(password),
            username,
            code,
          },
          {
            200: (res) => {
              this.request.get('instead/v2/user/allow/sso/ssoWan.do', {}, (ssoData) => {
                this.request(
                  {
                    url: `${ssoData.data}/u/v1/auth/check_login`,
                    ext: false,
                    data: {
                      resfunc: res.data.resfunc,
                    },
                    dataType: 'jsonp',
                    jsonp: 'callback',
                    jsonpCallback: 'user_lbn_jsonpResponse',
                    timeout: 30000,
                  },
                  '正在登录...',
                )
                  .done(() => {
                    // 当前是新用户为开通代账记账时。
                    if (res.data.newUser) {
                      this.errorHint({
                        message: '当前账号未开通云代账',
                      });
                      return;
                    }
                    if (res.data.versionType == 1) {
                      this.goCloud(data);
                    } else if (res.data.versionType == 0) {
                      message.error('客户端仅支持代账用户');
                    } else {
                      entList(
                        () => {
                          this.goCloud(data);
                        },
                        null,
                        username,
                      );
                    }
                  })
                  .fail(() => {
                    message.error('登录失败');
                  });
              });
            },
            300: (res) => {
              this.errorHint(res);
            },
            304: () => {
              message.error('当前企业尚未激活，请去网页端激活');
            },
          },
          '正在登录...',
        );
      }
    });
  };

  errorHint(res) {
    message.error(res.message);
    this.code.setState({
      _: new Date().getTime(),
    });
  }

  forget = () => {
    forget();
  };

  render() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    const { accounts, visible, showPassword } = this.state;
    const { remember, username, password } = accounts[0] || {};
    const showPasswordIconStyle = {
      fontSize: 12,
      display: 'inline-block',
    };

    if (!showPassword) {
      showPasswordIconStyle.transform = 'scale(0.8)';
    }

    return (
      <Form onSubmit={this.handleSubmit} className={style.form}>
        <h3 className={style.title}>欢 迎 登 录23423423</h3>
        <FormItem>
          {getFieldDecorator('username', {
            initialValue: username,
            rules: [
              {
                required: true,
                message: '请输入用户名',
              },
            ],
          })(
            <AutoComplete
              open={visible}
              defaultActiveFirstOption={false}
              optionLabelProp="value"
              onChange={this.inputChange}
              dataSource={accounts.map((v, i) => {
                return (
                  <Option key={i} value={v.username} {...v}>
                    <Row type="flex" justify="space-between">
                      <Col>{v.username}</Col>
                      <Col>
                        <Iconfont
                          name="guanbi"
                          code="&#xe690;"
                          style={{ fontSize: 12 }}
                          onClick={(e) => this.removeAccount(e, i, v)}
                        />
                      </Col>
                    </Row>
                  </Option>
                );
              })}
            >
              <Input
                ref={(ele) => {
                  this.input = ele;
                }}
                onKeyDown={this.inputKeyDown}
                prefix={<Iconfont name="yonghuming" code="&#xe687;" />}
                suffix={
                  !!accounts.length && (
                    <Iconfont
                      style={{ fontSize: 14 }}
                      name={visible ? 'up' : 'down'}
                      code={visible ? '\ue98a' : '\ue614'}
                      onClick={this.showDropdown}
                    />
                  )
                }
                placeholder="请输入用户名"
                autoComplete="off"
              />
            </AutoComplete>,
          )}
        </FormItem>
        <FormItem>
          {getFieldDecorator('password', {
            initialValue: password,
            rules: [
              {
                required: true,
                message: '请输入密码',
              },
            ],
          })(
            <Input
              type={showPassword ? 'text' : 'password'}
              prefix={<Iconfont name="mima" code="&#xe622;" />}
              suffix={
                <Iconfont
                  style={showPasswordIconStyle}
                  name={showPassword ? 'zhengyan' : 'biyan'}
                  code={showPassword ? '\ue693' : '\ue691'}
                  onClick={this.showPassword}
                />
              }
              placeholder="请输入密码"
              autoComplete="off"
            />,
          )}
        </FormItem>
        <Row type="flex">
          <Col style={{ flex: 1 }}>
            <FormItem>
              {getFieldDecorator('code', {
                rules: [
                  {
                    required: true,
                    message: '请输入验证码',
                  },
                ],
              })(
                <Input
                  prefix={<Iconfont name="jiance" code="&#xe67e;" />}
                  placeholder="请输入验证码"
                  autoComplete="off"
                />,
              )}
            </FormItem>
          </Col>
          <Col className={style.code}>
            <Code
              ref={(ele) => {
                this.code = ele;
              }}
            />
          </Col>
        </Row>
        <div>
          <Button type="primary" htmlType="submit" className={style.submit}>
            登录
          </Button>
        </div>
        <Row type="flex" justify="space-between" style={{ marginTop: 6 }}>
          <Col>
            {getFieldDecorator('remember', {
              initialValue: !!remember,
              valuePropName: 'checked',
            })(<Checkbox>记住密码</Checkbox>)}
          </Col>
          <Col>
            <a onClick={this.forget}>忘记密码？</a>
            <ForgetPassword />
          </Col>
        </Row>
      </Form>
    );
  }
}

export default Form.create()(Login);
