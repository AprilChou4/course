// import { template, util } from 'nuijs/core';
import { request } from 'nuijs';
import form from 'nuijs/components/layer/form';
// import { encode } from 'nuonuo-libs/script/polyfill/base64'; //待补充
// import clientAPI from 'clientAPI'; //待补充
import Base64 from 'js-base64';
import clientAPI from '@public/script/clientAPI';

// import 'nuonuo-libs/script/plugins/countdown'; //待补充，验证倒计时
import './countdown';
import { message } from 'antd';
import './style/forget.less';
import sendVerifyCode from './sendVerifyCode';

export default function () {
  // Nui.use('//g.alicdn.com/sd/ncpc/nc.js', function(){
  // action="instead/v2/user/allow/updatePassword.do"
  const id = `slider-valid-${new Date().getTime()}`;
  form({
    width: 'auto',
    loading: '正在提交...',
    template: {
      main: `<form class="ui-form ui-form-forget"  onsubmit="return false">
                        <h3>重 置 密 码</h3>
                        <div class="ui-item">
                            <i class="iconfont">&#xe687;</i>
                            <input
                                type="text"
                                name="mobile"
                                data-rule="{required:true, mobile:true}"
                                data-message="{required:'请输入手机号', mobile:'手机号格式有误'}"
                                autocomplete="off"
                                placeholder="请输入手机号"
                                maxlength="11"
                                class="ui-input" />
                            <em class="ui-err"></em>
                        </div>
                        <div class="ui-item">
                            <i class="iconfont">&#xe67e;</i>
                            <a class="send-btn">发送</a>
                            <input
                                type="text"
                                name="verificationCode"
                                data-rule="{required:true, rangelength:[6,6]}"
                                data-message="{required:'请输入短信验证码', rangelength:'短信验证码格式有误'}"
                                autocomplete="off"
                                placeholder="请输入短信验证码"
                                maxlength="6"
                                class="ui-input" />
                            <em class="ui-err"></em>
                        </div>
                        <div class="ui-item">
                            <i class="iconfont">&#xe622;</i>
                            <input
                                type="password"
                                name="password"
                                id="reset-password"
                                data-rule="{required:true, rangelength:[6,35]}"
                                data-message="{required:'请输入6-35位字符密码', rangelength:'请输入6-35位字符密码'}"
                                autocomplete="off"
                                placeholder="请输入6-35位字符密码"
                                maxlength="35"
                                class="ui-input" />
                            <em class="ui-err"></em>
                        </div>
                        <div class="ui-item">
                            <i class="iconfont">&#xe622;</i>
                            <input
                                type="password"
                                name="repassword"
                                data-rule="{required:true, equalTo:'#reset-password'}"
                                data-message="{required:'请输入重复密码', equalTo:'两次密码输入不一致'}"
                                autocomplete="off"
                                placeholder="请输入重复密码"
                                maxlength="35"
                                class="ui-input" />
                            <em class="ui-err"></em>
                        </div>
                        <div>
                            <button type="button" class="ui-button ui-button-normal ui-button-full submit-btn">重置密码</button>
                        </div>
                    </form>`,
      hidden: `<input type="hidden" name="scene" value="nc_register" />
                    <input type="hidden" name="token" value="<%token??%>" />
                    <input type="hidden" name="sessionId" value="<%csessionid??%>" data-rule="{required:true}" data-message="{required:'请拖动滑动验证码'}" />
                    <input type="hidden" name="sig" value="<%sig??%>" />`,
    },
    title: null,
    button: null,
    cancel: {
      enable: false,
    },
    events: {
      'click .ui-button-full': function () {
        const form = this.self.main.children('form');
        if (!form.valid()) return;
        const params = {
          phoneNum: form.find('[name="mobile"]').val(),
          code: form.find('[name="verificationCode"]').val(),
          password: Base64.encode(form.find('[name="password"]').val()),
          repassword: Base64.encode(form.find('[name="repassword"]').val()),
        };
        request.postJSON(
          'instead/v2/user/allow/updatePassword',
          params,
          (res) => {
            if (res.result === 'success') {
              this.self.main.find('.send-btn').data('stop', true);
              message.success('重置密码成功');
              this.self.destroy();
              if (location.pathname !== '/client.html') {
                clientAPI.resScreen();
                location.replace('/client.html');
              }
            } else {
              message.error(res.message);
              this.reset();
            }
          },
          '正在提交...',
        );
      },
    },
    valid: {
      focusCleanup: false,
      onkeyup(elem) {
        $(elem).valid();
      },
      success(error, element) {
        error.text(error.attr('error')).addClass('hide');
        setTimeout(function () {
          error.remove();
        }, 200);
        $(element).addClass('s-succ');
      },
      errorPlacement(error, element) {
        element.removeClass('s-succ');
        if (error.text()) {
          error.attr('error', error.text());
          element.closest('.ui-item').find('.ui-err').html(error);
        }
      },
    },
    onInit(self) {
      const that = this;
      // var tpl = this.template;
      const $mobile = self.main.find('[name="mobile"]');
      // var appkey = "FFFF0N0000000000702A";
      // var nc_token = [appkey, (new Date()).getTime(), Math.random()].join(':');
      // self.$hidden = self.main.find('.hidden');
      // self.nc = new noCaptcha({
      //     renderTo: '#' + id,
      //     appkey: appkey,
      //     scene: "nc_register",
      //     token: nc_token,
      //     customWidth: 230,
      //     trans:{"key1":"code0"},
      //     elementID: ["usernameID"],
      //     is_Opt: 0,
      //     language: "cn",
      //     isEnabled: true,
      //     timeout: 3000,
      //     times: 5,
      //     callback: function (data) {
      //         self.$hidden.html(template.render(tpl.hidden, data))
      //         self.$hidden.find('[name="sessionId"]').valid()
      //     }
      // })

      // self.nc.upLang('cn', {
      //     _startTEXT: "请按住滑块，拖动到最右边",
      //     _yesTEXT: "验证通过",
      //     _error300: "哎呀，出错了，点击<a href=\"javascript:__nc.reset()\">刷新</a>再来一次",
      //     _errorNetwork: "网络不给力，请<a href=\"javascript:__nc.reset()\">点击刷新</a>",
      // })

      self.main.find('.send-btn').countdown({
        time: 60000,
        text: 's',
        target: self.main.find('[name="mobile"]'),
        ajaxrun: true,
        ajax(me, target, run) {
          sendVerifyCode.call(
            that,
            self.main.find('.send-btn'),
            'instead/v2/user/allow/verification/code/updatePwdMobileCode.do',
            {
              phoneNum: $mobile.val(),
            },
            function () {
              run();
            },
          );
        },
        startCallback() {
          const validMobile = $mobile.valid();
          // var validSessionid = self.$hidden.find('[name="sessionId"]').valid();
          return validMobile;
        },
        endCallback(elem) {
          elem.text('重新发送');
        },
      });

      self.resize();
    },
    reset() {
      // this.self.nc.reload()
      // this.self.$hidden.html(template.render(this.template.hidden, {}))
    },
    onBeforeSubmit(self, param) {
      param.password = Base64.encode(param.password);
      param.repassword = param.password;
      return param;
    },
    onSuccess(self, res) {
      if (res.result === 'success') {
        self.main.find('.send-btn').data('stop', true);
        message.success('重置密码成功');
        self.destroy();
        if (location.pathname !== '/client.html') {
          clientAPI.resScreen();
          location.replace('/client.html');
        }
      } else {
        message.error(res.msg);
        this.reset();
      }
    },
    onError() {
      message.error('重置密码失败');
      this.reset();
    },
    onDestroy(self) {
      // self.nc.destroy()
    },
  });
  // })
}
