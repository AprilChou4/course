import React from 'react';
import { Row, Col } from 'antd';
import Login from '../Login';
import Backdrop from '../Backdrop';
import style from './style.less';

const Layout = () => {
  return (
    <Row className={style.box}>
      <Col className={style.left}>
        <Backdrop />
      </Col>
      <Col className={style.right}>
        <Login />
      </Col>
    </Row>
  );
};
export default Layout;
