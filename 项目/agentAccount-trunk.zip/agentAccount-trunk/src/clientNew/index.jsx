import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { request } from 'nuijs/core';
import Layout from './components/Layout';
import './public/style/index.less';
// import './public/config'; //待补充
import '../home/public/config';

Component.prototype.request = request;
if (typeof ExternService === 'object') {
  changeLogo('登陆');
}

ReactDOM.render(<Layout />, document.getElementById('app'));
