import { request } from 'nuijs/core';
import layer from 'nuijs/components/layer/layer';
import { message } from 'antd';

request.config({
  name: 'status',
  value: '200',
  ext: '.do',
  preurl(url) {
    if (/^(https?:)?\/\//.test(url)) {
      return '';
    }
    if (/^(accinfo|instead|clouduser)/.test(url)) {
      return '/';
    }
    return '/jz/';
  },
  status: {
    300: (res) => {
      message.error(res.message);
    },
    other: (res) => {
      message.error(res.message);
    },
  },
});

layer.config({
  width: 360,
  align: 'center',
  button: [
    {
      id: 'cancel',
    },
    {
      id: 'confirm',
      name: 'normal',
    },
  ],
});
