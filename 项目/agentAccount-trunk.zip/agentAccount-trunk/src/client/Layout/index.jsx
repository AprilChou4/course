import React, { Component } from 'react';
import { Row, Col } from 'antd';
// import api from 'clientAPI'; // 待补充
import clientAPI from '@public/script/clientAPI';
import Login from '../Login';
import Backdrop from '../Backdrop';
import style from './style.less';

class Layout extends Component {
  min = () => {
    clientAPI.minScreen();
  };

  close = () => {
    clientAPI.close();
  };

  render() {
    return (
      <Row className={style.box}>
        <Col className={style.left}>
          <Backdrop />
        </Col>
        <Col className={style.right}>
          <Login />
        </Col>
      </Row>
    );
  }
}

export default Layout;
