import React from 'react';
import style from './style.less';

const Backdrop = () => {
  return (
    <div className={`${style.backdrop} backdrop`}>
      {/* <h2>诺诺·云代账</h2>
          <div>
              <h3>为财税服务机构提供一站式解决方案</h3>
              <h4>集中管理客户及员工、记账开票税务工具高效易用</h4>
          </div> */}
    </div>
  );
};
export default Backdrop;
