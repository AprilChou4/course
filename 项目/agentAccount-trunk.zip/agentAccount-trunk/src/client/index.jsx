import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { message } from 'antd';
import { request } from 'nuijs/core';
import Layout from './Layout';
import './public/style/index.less';
import './public/config';

message.config({
  top: 0,
});

Component.prototype.request = request;
if (typeof ExternService === 'object') {
  changeLogo('登陆');
}

ReactDOM.render(<Layout />, document.getElementById('app'));
