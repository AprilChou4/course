import { request, confirm } from 'nuijs';
import { message } from 'antd';
// import verifyCode from 'nuonuo-libs/script/modules/refreshVerifyCode'; //待补充 验证刷新验证码

const tpl = `<form class="ui-form" onsubmit="return false" style="padding-left:10px;padding-top:20px;padding-bott
10px;">
                <div class="ui-item">
                    <input type="text" name="code" class="ui-input ui-input ui-input-small ui-input-focus" maxlength="4" autocomplete="off"
                    style="width:190px; float:left; padding-left:8px;height: 32px; line-height: 32px; border: 1px solid #e6e6e6;"
                    data-placeholder-options='{"text":"请输入验证码"}'
                    data-rule-required="true"
                    data-rule-minlength="4"
                    data-msg-required="请输入验证码"
                    data-msg-minlength="验证码错误"
                    >
                    <img src="<%url%>.do?type=<%type??%>&_=<%new Date().getTime()%>" width="80" height="35" class="f-fl e-ml10 code">
                    <em class="ui-err ui-err-normal"></em>
                </div>
            </form>`;

export default function (elem, url, data, callback) {
  const that = this;
  confirm({
    template: tpl,
    title: '请输入验证码',
    data: { ...data, url: '/instead/v2/user/allow/verification/code/updatePwdImageCode' },
    under: that.self,
    events: {
      // 'click .code': verifyCode,
      'click .code': function (e, elem) {
        const src = elem.attr('src');
        // elem.attr('src', util.setParam('_', new Date().getTime(), src))
        elem.attr('src', `${src}?_${Date.now()}`);
      },
      'keydown :text': function (e) {
        if (e.keyCode === 13) {
          this.submit();
        }
      },
    },
    close: {
      callback() {
        this.closed();
      },
    },
    button: [
      {
        id: 'cancel',
        text: '关闭',
        callback() {
          this.closed();
        },
      },
      {
        id: 'confirm',
        callback() {
          this.submit();
        },
      },
    ],
    submit() {
      const _that = this;
      const { self } = this;
      // if (this.valid.form()) {
      const code = Nui.trim(self.element.find(':text').val());
      request.post(
        'instead/v2/user/allow/verification/code/updatePwdImageCodeCheck',
        {
          code,
        },
        (res) => {
          if ((res.status !== undefined && res.status === 200) || res !== 'error') {
            data.code = code;
            request.post(
              url,
              data,
              function (res) {
                if (res.status === 200 || res.result === 'success') {
                  message.success('已发送验证码到手机');
                  callback();
                } else {
                  _that.closed();
                  message.error(res.message || '');
                }
              },
              null,
            );
            self.destroy();
          } else {
            message.error(res.message || '验证码错误');
          }
        },
        '正在提交...',
        self,
      );
      // }
    },
    onInit(self) {
      // this.valid = validate(self.element.find('form'));
    },
    closed() {
      elem.removeClass('s-dis');
    },
  });
}
