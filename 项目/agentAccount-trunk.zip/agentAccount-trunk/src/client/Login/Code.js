import React, {Component} from 'react';

class Code extends Component {

    state = {
        _:new Date().getTime()
    }

    click = ()=>{
        this.setState({
            _:new Date().getTime()
        })
    }

    ///clouduser/allow/check.do

    render(){
        return (
          <img
            src={`/instead/v2/user/allow/verification/code/loginImageCode.do?type=2&_=${this.state._}`}
            onClick={this.click}
          />
        );
    }
}

export default Code
