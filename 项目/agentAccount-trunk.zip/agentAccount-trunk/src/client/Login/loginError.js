import { request } from 'nuijs/core';
import alert from 'nuijs/components/layer/alert';
import { Modal, message } from 'antd';

export default function (res) {
  if (res.message) {
    if (res.message.indexOf('用户被禁用') === 0) {
      alert({
        content: '您的账号已被您所在公司管理员停用，如需继续使用，请与其联系重新启用！',
        under: self,
        cancel: {
          text: '知道了',
        },
      });
      return;
    }
    if (res.message.indexOf('已过期') !== -1 || res.message.indexOf('版本') !== -1) {
      request.sync('instead/order/product/getUserInfo', (res) => {
        let telephone = '0571-8713 1850';
        if (res && res.clouduser && res.clouduser.areaid) {
          // 浙江温州
          const areaCode = [
            '330300',
            '330301',
            '330302',
            '330303',
            '330304',
            '330322',
            '330324',
            '330326',
            '330327',
            '330328',
            '330329',
            '330381',
            '330382',
          ];
          if (areaCode.includes(res.clouduser.areaid)) {
            telephone = '0577-8809 5807';
          }
        }

        Modal.warning({
          title: `谢谢您使用云代账，您当前试用期/使用期已结束，如需继续使用请联系${telephone}  购买/续费！`,
          okText: '知道了',
          centered: true,
          className: 'login-modal-warning',
          zIndex: '100001',
        });
      });
    } else {
      message.error(res.message);
    }
  } else {
    message.error('登录失败');
  }
}
