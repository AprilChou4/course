/* eslint-disable no-restricted-syntax */
/* eslint-disable guard-for-in */
import { router } from 'nuomi';
import moment from 'moment';
import { message } from 'antd';
import ShowConfirm from '@components/ShowConfirm';
import { get, isNil, validateArrayLength } from '@utils';
import globalServices from '@home/services';
import { storeForUser, dictionary } from '../utils';
import services from '../services';

const MonthFormat = 'YYYY-MM';

export default {
  getLocalData() {
    /**
     * sort: 0, 建账期间排序，默认倒序
     * sortByCode:0  客户编码排序
     */
    const order = localStorage.getItem('ACCOUNT_COLUMN_SORT');
    // columnSource = columnSource.filter((ele) => {
    //   if (['记账会计', '会计助理'].includes(ele.key)) {
    //     if (
    //       role === 0 ||
    //       (role === 1 && ele.key === '会计助理') ||
    //       (role !== 1 && ele.key === '记账会计')
    //     ) {
    //       return true;
    //     }
    //     return false;
    //   }
    //   return true;
    // });

    // 助理会计不显示风险监测
    // if (role === 3) {
    //   columnSource = columnSource.filter((ele) => ele.key !== '风险检测');
    // }

    const pageSize = parseInt(storeForUser('account_table_pagesize') || '20', 0);
    this.updateState({
      // 每页显示数量
      pageSize,
      // 排序查询条件
      order,
    });
  },

  async initData() {
    this.getLocalData();
    this.getCustomCols();
    this.getVerifySetting();

    const { accType, startDate } = router.location().query || {};
    // 先获取日期，再请求列表和统计
    await this.getDate(isNil(startDate) ? {} : { startDate });
    this.updateAccQueryType({
      ...(isNil(accType) ? {} : { accountListQueryType: accType }),
      ...(isNil(startDate) ? {} : { startDate }),
    });
    this.getAccountStatistics();
    // this.isShowreCycle();
  },

  // 是否展开回收站
  // isShowreCycle() {
  //   const {
  //     query: { visible },
  //   } = router.location();
  //   this.dispatch({
  //     type: 'accountRecycleBin/updateState',
  //     payload: {
  //       visible: !!visible,
  //     },
  //   });
  // },

  async getSearchOptions() {
    const [creators = [], roleList = []] = await Promise.all([
      this.getAccountingList(),
      this.getAccountingAssistantList(),
    ]);

    const creatorMap = {};
    const operatorMap = {};
    creators.forEach((ele) => {
      creatorMap[ele.staffId] = ele.realName;
    });
    // operators.forEach((ele) => {
    //   operatorMap[ele.staffId] = ele.realName;
    // });
    let operators = [];
    // 查询会计助理=2、开票员=3、报税会计=4、客户顾问=5、
    roleList.forEach((item) => {
      switch (item.roleType) {
        case 2:
          operators = item.treeList;
          break;
        default:
          break;
      }
    });

    this.updateState({
      operators,
      creators,
      operatorMap,
      creatorMap,
    });
  },

  // 更新记账平台主页面相关数据
  updateMainDatas(init) {
    this.query(init);
    this.getAccountStatistics();
  },

  // 获取记账会计
  async getAccountingList() {
    const data = await services.getAccountingList();
    return data || [];
  },

  // 获取会计助理
  async getAccountingAssistantList() {
    const data = await services.getAccountingAssistantList();
    return data || [];
  },

  // 查询日期
  async getDate(payload = {}) {
    const { startDate } = payload || this.getState();
    const { defaultDate, maxDate, minDate } = await services.getDate();
    this.updateState({
      startDate: startDate || defaultDate,
      maxDate: moment(maxDate).format(MonthFormat),
      minDate: moment(minDate).format(MonthFormat),
    });
  },

  // 设置查询数据
  // TODO: 应该放到reducers里
  setQuery(payload = {}) {
    this.updateState({
      query: payload,
    });
  },

  // 处理查询参数
  getQueryParams() {
    const {
      startDate,
      query,
      order,
      // operatorMap,
      columnSource,
    } = this.getState();

    const param = {};
    for (const i in query) {
      const value = query[i];
      if (Array.isArray(value)) {
        param[i] = value.join(',');
      } else if (typeof value === 'boolean') {
        param[i] = value ? 1 : 0;
      } else {
        param[i] = value;
      }
    }

    const params = {
      searchDate: startDate,
      order: order || undefined,
      ...param,
    };

    // 没有建账期间列，删除排序
    if (columnSource.find((ele) => ele.key === '建账期间' && ele.selected === false)) {
      delete params.sort;
    }

    // FIXME: 临时处理传参
    // 账套名称
    params.accountName = params.name;
    delete params.name;
    // 账套状态
    params.statusList = params.statusList
      ? params.statusList.split(',').map((val) => Number(val))
      : undefined;
    // 账套进度
    params.scheduleList = params.schedules
      ? params.schedules.split(',').map((val) => Number(val))
      : undefined;
    delete params.schedules;
    // 报税类型（纳税性质）
    params.vatTypeList = params.vatType
      ? params.vatType.split(',').map((val) => Number(val))
      : undefined;
    delete params.vatType;
    // 纳税性质
    params.taxTypeList = params.taxType
      ? params.taxType.split(',').map((val) => Number(val))
      : undefined;
    delete params.taxType;
    // 记账会计
    params.bookkeepingAccounting = params.creator ? params.creator.split(',') : undefined;
    delete params.creator;
    // 会计助理
    params.accountingAssistant = params.operator ? params.operator.split(',') : undefined;
    delete params.operator;
    // 审核状态
    params.reviewStatusList = params.reviewStatus
      ? params.reviewStatus.split(',').map((val) => Number(val))
      : undefined;
    delete params.reviewStatus;
    // 结账状态
    params.checkOutList = params.isCheckOut
      ? params.isCheckOut.split(',').map((val) => Number(val))
      : undefined;
    delete params.isCheckOut;
    // 业务形态
    params.businessPatternList = params.businessPattern
      ? params.businessPattern.split(',').map((val) => Number(val))
      : undefined;
    delete params.businessPattern;

    return params;
  },

  // FIXME: 待优化
  // 获取账套列表
  async query(init) {
    const {
      current,
      pageSize,
      creatorMap,
      // operatorMap,
    } = this.getState();

    const params = this.getQueryParams();

    try {
      const { pageNum, total, list } = await services.getAccountList(
        {
          ...params,
          current: init ? 1 : current,
          pageSize,
        },
        {
          loading: '正在获取账套列表...',
        },
      );
      this.updateState({
        selectedRowKeys: [],
        dataSource: list.map((ele, i) => {
          const data = {};
          if (ele.createPeriod) {
            data.createPeriod = ele.createPeriod.replace(/-(\d{1})$/, '-0$1');
          }
          if (ele.currentPeriod) {
            data.currentPeriod = ele.currentPeriod.replace(/-(\d{1})$/, '-0$1');
          }
          if (ele.creator) {
            data.creator = ele.creator
              .split(',')
              .map((el) => creatorMap[el] || '')
              .join(',');
          }
          // if (ele.operator) {
          //     ele.operator = ele.operator.split(',').map(ele => operatorMap[ele] || '').join(',');
          // }
          return {
            ...ele,
            key: ele.accountId,
            index: i + 1 + (pageNum - 1) * pageSize,
            ...data,
          };
        }),
        current: pageNum,
        total,
      });
    } catch (error) {
      message.error('获取账套列表失败！');
    }
  },

  // 获取统计数据
  async getAccountStatistics() {
    const { startDate, totalData } = this.getState();
    const data = await services.getAccountStatistics(
      {
        currentDate: startDate,
      },
      { errMsg: '获取账套统计数据失败！' },
    );
    this.updateState({
      totalData: {
        ...totalData,
        ...data,
      },
    });
  },

  // 删除账套
  async deleteAccount(payload = {}) {
    await services.deleteAccount(payload);
    this.updateMainDatas();
    message.success('删除成功');
  },

  // 编辑账套弹层
  updateEditAccount(payload = {}) {
    const { editAccount } = this.getState();
    this.updateState({
      editAccount: {
        ...editAccount,
        ...payload,
      },
    });
  },

  // 编辑账套
  async editAccount(payload = {}) {
    const that = this;
    const data = await services.editAccount(payload, { loading: '正在保存中...' });
    message.success('保存成功');
    this.updateEditAccount({ visible: false });
    this.updateMainDatas();
    if (get(data, 'changeName')) {
      ShowConfirm({
        title: '账套名称发生变更，是否同步修改客户名称？',
        cancelText: '修改',
        okText: '忽略',
        onCancel() {
          that.syncCustomerName({ accountId: data.accountId || payload.accountId });
        },
      });
    }
  },

  // 同步客户名称
  async syncCustomerName(payload = {}) {
    await globalServices.syncCustomerName(payload, { successMsg: '修改成功' });
    this.updateMainDatas();
  },

  // 查询账套信息
  async getAccountInfo(payload) {
    const data = await services.getAccountInfo(payload, { errMsg: '查询账套信息失败' });
    return data;
  },

  // 查询会计科目列表
  async getSubjectTemplateList(payload) {
    const data = await services.getSubjectTemplateList(payload, {
      errMsg: '查询会计科目列表失败！',
    });
    return data;
  },

  // 账套结账前提示信息
  async beforeCheck(payload) {
    const data = await services.beforeCheck(payload, {
      status: {
        300: (res) => {
          message.warning(res.message);
        },
      },
    });
    return data;
  },

  // 账套结账
  async checkOut(payload) {
    const data = await services.checkOut(payload);
    return data || true;
  },

  // 账套结账进度
  async checkOutProcess(payload) {
    const data = await services.checkOutProcess(payload);
    return data;
  },

  // 账套审核前提示信息
  async beforeReview(payload) {
    const data = await services.beforeReview(payload);
    return data;
  },

  // 账套审核
  async review(payload) {
    const data = await services.review(payload);
    return data || true;
  },

  // 账套审核进度
  async reviewProcess(payload) {
    const data = await services.reviewProcess(payload, {
      returnAll: true,
    });
    return data;
  },

  // 查询所有员工集合
  async getAllEmployeeList(payload) {
    const data = await globalServices.getAllEmployeeList(payload);
    return data;
  },

  // 账户状态更新查询参数
  updateAccQueryType(payload = {}) {
    // 页面header与Table.Title的搜索互斥
    this.updateState({
      ...payload,
      ...(validateArrayLength(Object.values(payload))
        ? {
            query: get(
              dictionary.accountListQueryTypeMap,
              `${payload.accountListQueryType}.data`,
              {},
            ),
          }
        : {}),
    });
    this.query(true);
  },

  // 查询记账设置中是否开启审核 0不用审核 1 要审核
  async getVerifySetting() {
    const data = await globalServices.getVerifySetting();
    this.updateState({
      needVerify: !!data?.needVerify,
    });
  },

  // 处理批量审核设置
  handleBatchVerifySetting() {
    const { selectedRowKeys } = this.getState();
    const length = validateArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请先选择账套');
    } else {
      this.updateState({
        batchVerifySettingModal: { visible: true },
      });
    }
  },

  // 批量审核设置
  async verifySetting(payload = {}) {
    const { selectedRowKeys } = this.getState();
    await services.verifySetting(
      {
        accIds: selectedRowKeys,
        ...payload,
      },
      { successMsg: `已${payload.isNeedVerify ? '开启' : '关闭'}审核` },
    );
    // 如果是批量设置 关闭弹窗
    !payload.accIds &&
      this.updateState({
        batchVerifySettingModal: { visible: false },
      });

    return true;
  },

  // 查询自定义列
  async getCustomCols(payload = {}) {
    const data = await services.getCustomCols(payload);
    !payload.isInit &&
      this.updateState({
        columnSource: data || [],
      });
    return data;
  },

  // 更新自定义列
  async updateCustomCols(payload = {}) {
    await services.updateCustomCols(payload, { loading: '正在保存...', successMsg: '保存成功' });
    this.updateState({
      customColModal: { visible: false },
    });
    this.getCustomCols();
  },
  // 4.0 获取用户账套升级提醒状态
  async updateTips() {
    const data = await services.updateTips();
    return data || false;
  },
};
