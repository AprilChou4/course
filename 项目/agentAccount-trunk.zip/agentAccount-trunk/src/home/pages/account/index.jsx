// 记账平台
import React from 'react';
import { router, Nuomi } from 'nuomi';
import pubData from 'data';
import NoAuthPage from '@components/NoAuthPage';
import { storeForUser } from './utils';
import effects from './effects';
import Layout from './components/Layout';
import recycleBin from './recycleBin';

const pageSize = parseInt(storeForUser('account_table_pagesize') || 20, 0);

export default {
  id: 'account',
  state: {
    key: 1,
    // 会计助理列表
    operators: [],
    operatorMap: {},
    // 主管会计列表
    creators: [],
    creatorMap: {},
    // 查询条件
    query: { statusList: ['0'] },
    // 记账平台列表header搜索框的ref
    searchInputRef: null,
    // 账套列表表格头部查询类型
    accountListQueryType: 0,
    // 开始时间
    startDate: '',
    // 结束时间
    endDate: '',
    // 自定义列
    columnSource: [],
    // 当前页码
    current: 1,
    // 数据总数
    total: 0,
    // 每页显示数量
    pageSize,
    // 加载数据时loading状态
    loading: false,
    // 表格数据
    dataSource: [],
    // 表格选中数据
    selectedRowKeys: [],
    selectedRows: [],
    // 排序查询条件
    order: '',
    // 汇总数据（选择月份）
    totalData: {
      // 建账数量
      createdNum: 0,
      // 未开始数量
      notStartNum: 0,
      // 进行中数量
      ongoingNum: 0,
      // 待审核数量
      auditingNum: 0,
      // 未结账数量
      notCheckOutNum: 0,
      // 已结账数量
      checkOutNum: 0,
      // 理票中数量
      arrangingNum: 0,
      // 已理票数量
      arrangedNum: 0,
      // 待审核数量
      noReviewNum: 0,
      // 记账中数量
      registeringNum: 0,
      // 已停止数量
      stopNum: 0,
    },
    // 编辑账套
    editAccount: {
      visible: false,
      record: {},
    },
    // 账套移交
    accountHandover: {
      visible: false,
    },
    // 记账设置中的是否需要审核
    needVerify: false,
    // 批量审核设置弹窗
    batchVerifySettingModal: { visible: false },
    // 自定义列弹窗
    customColModal: {
      visible: false,
    },
  },
  effects,
  render() {
    const userAuth = pubData.get('authority');
    return userAuth[56] ? (
      <>
        <Layout />
        {userAuth[673] && <Nuomi {...recycleBin} />}
      </>
    ) : (
      <NoAuthPage />
    );
  },
  onChange: {
    $isShowRecycleBin() {
      const {
        query: { visible },
      } = router.location();
      this.store.dispatch({
        type: 'accountRecycleBin/updateState',
        payload: {
          visible: !!visible,
        },
      });
    },
    query() {
      this.store.dispatch({
        type: 'initData',
      });
    },
  },
  onInit() {
    const userAuth = pubData.get('authority');
    if (!userAuth[56]) return;

    this.store.dispatch({
      type: 'updateState',
      payload: {
        key: new Date().getTime(),
      },
    });
  },
};
