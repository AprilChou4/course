/**
 * @func 数据字典
 */

const getData = (data) => {
  const datas = data;
  datas.map = {};
  datas.list.forEach((ele) => {
    datas.map[ele.value] = ele.name;
  });
  return datas;
};

const statusList = {
  title: '账套状态',
  list: [
    {
      name: '在用',
      value: '0',
    },
    {
      name: '停用',
      value: '1',
    },
  ],
};

const schedules = {
  title: '账套进度',
  list: [
    {
      name: '未开始',
      value: '1',
    },
    {
      name: '理票中',
      value: '2',
    },
    {
      name: '理票完成',
      value: '3',
    },
    {
      name: '记账中',
      value: '4',
    },
    {
      name: '待审核',
      value: '5',
    },
    {
      name: '待结账',
      value: '6',
    },
    {
      name: '已结账',
      value: '7',
    },
  ],
};

const vatType = {
  title: '报税类型',
  list: [
    {
      name: '一般纳税人',
      value: '0',
    },
    {
      name: '小规模纳税人',
      value: '1',
    },
  ],
};

const taxType = {
  title: '申报类型',
  list: [
    {
      name: '零申报',
      value: '1',
    },
    {
      name: '非零申报',
      value: '0',
    },
  ],
};

const reviewStatus = {
  title: '审核状态',
  list: [
    {
      name: '未审核',
      value: '0',
    },
    {
      name: '已审核',
      value: '1',
    },
    {
      name: '无凭证',
      value: '-1',
    },
  ],
};

const checkStatus = {
  title: '风险检测状态',
  list: [
    {
      name: '未检测',
      value: '0',
    },
    {
      name: '已通过',
      value: '1',
    },
    {
      name: '低风险',
      value: '2',
    },
    {
      name: '高风险',
      value: '3',
    },
  ],
};

const isCheckOut = {
  title: '结账状态',
  list: [
    {
      name: '未结账',
      value: '0',
    },
    {
      name: '已结账',
      value: '1',
    },
  ],
};

const businessPattern = {
  title: '业务形态',
  list: [
    {
      name: '经典包干模式',
      value: '0',
    },
    {
      name: '会计工厂模式',
      value: '1',
    },
  ],
};

const isTransfer = {
  title: '交接状态',
  list: [
    {
      name: '未交接',
      value: '0',
    },
    {
      name: '交接中',
      value: '1',
    },
  ],
};

// 账套列表表格头部查询类型
const accountListQueryTypeMap = {
  1: {
    text: '在用',
    // data: { create: 1 },
    data: { statusList: [0] },
  },
  2: {
    text: '未开始',
    data: { schedules: '1' },
  },
  3: {
    text: '进行中',
    data: { schedules: '2,3,4,5,6' },
  },
  4: {
    text: '待结账',
    data: { schedules: '6' },
  },
  5: {
    text: '已结账',
    data: { schedules: '7' },
  },
  6: {
    text: '理票中',
    data: { schedules: '2' },
  },
  7: {
    text: '理票完成',
    data: { schedules: '3' },
  },
  8: {
    text: '记账中',
    data: { schedules: '4' },
  },
  9: {
    text: '待审核',
    data: { schedules: '5' },
  },
  10: {
    text: '停用',
    // data: { status: 1 },
    data: {
      statusList: [1],
    },
  },
};

export default {
  accountListQueryTypeMap,
  statusList: getData(statusList),
  schedules: getData(schedules),
  vatType: getData(vatType),
  taxType: getData(taxType),
  reviewStatus: getData(reviewStatus),
  isCheckOut: getData(isCheckOut),
  businessPattern: getData(businessPattern),
  checkStatus: getData(checkStatus),
  isTransfer: getData(isTransfer),
};
