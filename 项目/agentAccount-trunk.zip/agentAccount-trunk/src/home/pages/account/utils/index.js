import pubData from 'data';
import { message } from 'antd';
import { request } from 'nuijs';
import dictionary from './dictionary';
import role from './role';

const authoritys = pubData.get('authority');
const userid = pubData.get('userInfo_userId');

const openUrl = async (data, path = 'home') => {
  const { transfer, accountSource, accountId } = data;
  if (authoritys['236']) {
    if (transfer) {
      message.error('账套交接中，请先完成交接');
      return;
    }
    // if (data.status === 1) {
    //   message.error('账套已被停用，请先恢复账套');
    //   return;
    // }

    // #149988
    let url = '';
    if (accountSource === 1) {
      request.sync('jz/accounting/account/backup/checkBackup', { accId: accountId }, (res) => {
        if (!res.data) {
          url = '/accounting.html';
        } else {
          message.error('账套正在备份/还原，暂时无法访问');
          return false;
        }
      });
    } else {
      request.sync('jz/backups/checkStatus', { accId: accountId }, (res) => {
        if (res.data) {
          url = '/platform.html';
        } else {
          message.error('账套正在备份/还原，暂时无法访问');
          return false;
        }
      });
    }
    const a = document.createElement('a');
    const span = document.createElement('span');
    a.appendChild(span);
    a.href = `${url}?id=${data.accountId}#!/${path}`;
    a.target = '_blank';
    document.body.appendChild(a);
    span.click();
    a.remove();
  } else {
    message.error('您无权打开记账平台');
  }
};

const storeForUser = (...args) => {
  const [name, storeData] = args;
  const data = JSON.parse(localStorage.getItem(name) || '{}');
  if (args.length > 1) {
    data[userid] = storeData;
    localStorage.setItem(name, JSON.stringify(data));
  } else {
    return data[userid];
  }
  // eslint
  return true;
};

export { role, authoritys, openUrl, dictionary, storeForUser };
