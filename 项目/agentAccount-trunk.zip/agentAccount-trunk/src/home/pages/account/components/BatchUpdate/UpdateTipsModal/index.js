// /* eslint-disable react/jsx-filename-extension */
// import React, { useState } from 'react';
// import { Modal, Checkbox } from 'antd';

// import './style.less';

// const UpdateTipsModal = ({ onCancel }) => {
//   const [checked, setChecked] = useState(false);

//   const onClose = () => {
//     onCancel({ noTips: checked });
//   };

//   return (
//     <Modal
//       visible
//       maskClosable={false}
//       width={560}
//       footer={null}
//       wrapClassName="update-tips-modal"
//       closable={false}
//     >
//       <div styleName="update-tips-footer">
//         <span styleName="update-tips-close" onClick={onClose} />
//         <Checkbox
//           styleName="update-tips-check"
//           checked={checked}
//           onChange={(e) => {
//             setChecked(e.target.checked);
//           }}
//         >
//           下次不再提示
//         </Checkbox>
//       </div>
//     </Modal>
//   );
// };

// export default UpdateTipsModal;
