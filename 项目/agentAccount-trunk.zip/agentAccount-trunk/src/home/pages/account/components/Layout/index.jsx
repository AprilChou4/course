import React from 'react';
import { connect } from 'nuomi';
import Authority from '@components/Authority';
import Layout from '@components/Layout';
import ContentWrapper from '@components/ContentWrapper';
import pubData from 'data';
import Search from '../Search';
import Table from '../Table';
import DateMonth from '../DateMonth';
import ReviewButton from '../ReviewBtn';
import CheckoutBtn from '../CheckoutBtn';
import BatchUpdateBtn from '../BatchUpdate';
import More from '../More';
import AccountHandover from '../AccountHandover';
import BatchVerifySetting from '../BatchVerifySetting';
import CustomColModal from '../CustomColModal';
import EditAccount from '../EditAccount';
import UpdateTipsModal from '../UpdateTipsModal';

// 任务 #167838
const isSystemManage = pubData.get('userInfo_isSystemManage');
const roleName = pubData.get('userInfo_roleName');

const App = () => (
  <Layout.Container>
    <ContentWrapper
      header={{
        left: (
          <>
            <DateMonth />
            <Authority code="56">
              <Search />
            </Authority>
          </>
        ),
        right: (
          <>
            <BatchUpdateBtn />
            <ReviewButton />
            <CheckoutBtn />
            <More />
          </>
        ),
      }}
      content={<Table />}
    />
    {(isSystemManage || roleName.indexOf('公司管理员') > -1) && <AccountHandover />}
    <BatchVerifySetting />
    <CustomColModal />
    <EditAccount />
    <UpdateTipsModal />
  </Layout.Container>
);

export default connect(({ key }) => ({
  key,
}))(App);
