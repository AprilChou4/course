/* eslint-disable import/no-cycle */
import React, { createContext, useState, useCallback } from 'react';
import DropDown from '@components/DropDown';
import Authority from '@components/Authority';
import pubData from 'data';
import AccountHandover from './AccountHandover';
import BatchVerifySetting from './BatchVerifySetting';
import RecycleBin from './RecycleBin';
import Unlock from './Unlock';
import Export from './Export';

export const VisibleContext = createContext(false);
// 任务 #167838
const isSystemManage = pubData.get('userInfo_isSystemManage');
const roleName = pubData.get('userInfo_roleName');
const More = () => {
  const [visible, setVisible] = useState(false);

  const handleVisibleChange = useCallback((status) => {
    setVisible(status);
  }, []);

  return (
    <VisibleContext.Provider value={visible}>
      <DropDown onVisibleChange={handleVisibleChange}>
        <Authority code="635">
          <Export />
        </Authority>
        {(isSystemManage || roleName.indexOf('公司管理员') > -1) && <AccountHandover />}
        <Authority code="692">
          <BatchVerifySetting />
        </Authority>
        <Authority code="673">
          <RecycleBin />
        </Authority>
        <Authority code="495">
          <Unlock />
        </Authority>
      </DropDown>
    </VisibleContext.Provider>
  );
};

export default More;
