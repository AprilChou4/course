import React, { useState, useEffect, useCallback } from 'react';
import { connect } from 'nuomi';
import { Switch } from 'antd';
import styles from './style.less';

const VerifySetting = ({ accountId, isNeedVerify, dispatch }) => {
  const [checked, setChecked] = useState(false);

  const handleChange = useCallback(
    async (c) => {
      const res = await dispatch({
        type: 'verifySetting',
        payload: {
          isNeedVerify: c ? 1 : 0,
          accIds: [accountId],
        },
      });
      res && setChecked(c);
    },
    [accountId, dispatch],
  );

  useEffect(() => {
    setChecked(!!isNeedVerify);
  }, [isNeedVerify]);

  // // 记账设置中的是否需要审核
  // useEffect(() => {
  //   dispatch({
  //     type: 'getVerifySetting',
  //   });
  // }, [dispatch]);

  return (
    <div className={styles.verifySetting}>
      <span>
        <span className={styles.label}>是否需要审核</span>
        <span className={styles.subLabel}>（开启后月末结账前，当前凭证必须经过审核）</span>
      </span>
      <Switch className={styles.switch} checked={checked} onChange={handleChange} />
    </div>
  );
};

export default connect()(VerifySetting);
