/* eslint-disable react/jsx-filename-extension */
import React, { useState, useEffect } from 'react';
import { Modal } from 'antd';
import { connect } from 'nuomi';

import Style from './style.less';

const UpdateTipsModal = ({ dispatch }) => {
  const [tipData, setTipData] = useState({
    reminder: false,
    date: '2020年8月18日',
  });
  const { reminder, date } = tipData;
  const onClose = () => {
    setTipData({
      ...tipData,
      reminder: false,
    });
  };
  useEffect(() => {
    const getData = async () => {
      const data = await dispatch({
        type: 'updateTips',
      });
      setTipData(data);
    };
    getData();
  }, [dispatch]);
  return (
    <Modal
      visible={reminder}
      maskClosable={false}
      centered
      width={412}
      footer={null}
      wrapClassName={Style['update-tips-modal']}
      closable={false}
      getContainer={false}
    >
      <div styleName="update-tips-content">
        <div styleName="m-title">升级公告</div>
        <h3>尊敬的云记账用户</h3>
        <div className="f-clearfix">
          为了给您提供更优质的服务，云记账将于<em>{date}</em>
          进行<em>系统升级</em>
          ，届时线上所有旧版本账套将全部升级至4.0版本（该版本支持复制分录行次、凭证账簿打印自由设置等强大功能）。由此给您带来的不便敬请谅解，如有疑问可咨询在线客服。
          <div>特此公告，望广大用户周知！</div>
          <div className={Style.footer}>
            <p>云记账团队</p>
            <p>2020年7月28日</p>
          </div>
        </div>
      </div>
      <div styleName="update-tips-footer">
        <span styleName="update-tips-close" onClick={onClose} />
      </div>
    </Modal>
  );
};

export default connect()(UpdateTipsModal);
