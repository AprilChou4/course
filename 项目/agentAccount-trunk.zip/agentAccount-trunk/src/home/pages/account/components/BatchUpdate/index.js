/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/jsx-fragments */
/**
 * 批量结账 btn，结账结果，结账进度
 */
import React, { useState, useCallback } from 'react';
import { Button } from 'antd';
import pubData from 'data';

import ShowConfirm from '@components/ShowConfirm';
import DetailModal from './UpdateDetailModal';
import services from '../../services';
import newImg from './style/new.png';

import './style/index.less';

const noTipsName = 'no_batch_update_tips';

const BatchUpdate = () => {
  const [isShowDetail, setIsShowDetail] = useState(false);
  const [tipsData, setTipsData] = useState({});

  const [loading, setLoading] = useState(false);

  const onCloseModal = useCallback((opt = {}) => {
    // 记录不再提示
    if (opt.noTips) localStorage.setItem(noTipsName, '1');

    setIsShowDetail(false);
  }, []);

  const showMsg = ({ title, content }) => {
    ShowConfirm({
      title,
      content: content || '',
      okText: '知道了',
      cancelButtonProps: {
        style: {
          display: 'none',
        },
      },
      okButtonProps: {
        style: {
          marginLeft: 0,
        },
      },
    });
  };

  const onStartUpdate = async ({ isConfirm } = { isConfirm: false }) => {
    const { companyId } = pubData.get('userInfo_company');

    setLoading(true);
    const res = await services.batchUpdate({ companyId, isConfirm }).catch(() => {});
    setLoading(false);

    if (!res) return;

    const { upgradePlanTime, total, oldNum, result, msg } = res;

    if (result === 'fail') {
      showMsg({ title: msg });
      return;
    }

    // 提示信息，预约
    if (result === 'tips') {
      setTipsData({ upgradePlanTime, total, oldNum });
      setIsShowDetail(true);
      return;
    }

    // 预约成功
    if (result === 'ok') {
      showMsg({
        title: `成功提交预约！公司已预约批量升级，计划 ${upgradePlanTime} 进行批量升级，届时请勿操作账套，升级完成后将通过系统消息提示管理员！`,
      });
    }
  };

  // 提交预约
  const onSubmit = () => {
    onStartUpdate({ isConfirm: true });
    setIsShowDetail(false);
  };

  return (
    <>
      <Button loading={loading} styleName="update" type="primary" onClick={onStartUpdate}>
        批量升级
        <img styleName="new" src={newImg} alt="new" />
        <div styleName="white-bg" />
      </Button>

      {isShowDetail && <DetailModal onCancel={onCloseModal} onOk={onSubmit} data={tipsData} />}
    </>
  );
};

export default BatchUpdate;
