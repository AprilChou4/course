/**
 * 任务执行单
 */
import React from 'react';
import Main from './components/Main';
import effects from './effects';

export default {
  id: 'taskExecution',
  state: {
    title: '任务执行单',
    // 待执行的任务单id
    taskIds: [],
    // 完成人列表
    completeUserList: [],
    // 是否必须上传附件
    shouldUploadAttachment: false,
    // 任务执行设置 是否为严格按流程执行
    isTaskRuleStrict: false,
    // 执行单步骤的key
    taskStepKey: 'taskStepId',
    // 执行单信息
    taskInfo: {
      // 执行步骤的表单内容是否有变化
      isFormValuesChange: false,
      // 任务单id
      taskId: '',
      // 任务状态(1:未开始，1:进行中，2:已完成)
      taskStatus: 0,
      // 任务步骤列表
      taskStepVOList: [],
      // 当前选中的步骤id
      selectStepId: '',
      // 展示内容的步骤id
      shouldOpenStepIds: [],
      // // 当前选中的步骤序号
      // selectStepOrder: '',
    },
  },
  effects,
  render() {
    return <Main />;
  },
  onChange: {
    // 这里加上$让它在初始化的时候不执行，initData里再手动的去执行 query，否则 initData中无法拿到 query中请求得到的数据
    $query() {
      // 控制查看权限
      // if (!getAuth()) {
      //   return;
      // }
      this.store.dispatch({
        type: 'initData',
      });
    },
  },
  onInit() {
    // 控制查看权限
    // if (!getAuth()) {
    //   return;
    // }
    this.store.dispatch({
      type: 'initData',
      payload: true,
    });
  },
};
