/**
 * 上传附件
 */
import React, { forwardRef, useCallback, useMemo } from 'react';
import { Upload, Button, Icon, message, Typography } from 'antd';
import classnames from 'classnames';
import ShowConfirm from '@components/ShowConfirm';
import Iconfont from '@components/Iconfont';
import { get, validateArrayLength } from '@utils';
import styles from './style.less';

const { Paragraph } = Typography;
// const AccFileType = 'doc|docx|txt|ppt|xls|xlsx|jpg|png|pdf|bmp|jpeg|gif|rar|zip';
const AccFileType = [
  'doc',
  'docx',
  'txt',
  'ppt',
  'xls',
  'xlsx',
  'jpg',
  'png',
  'pdf',
  'bmp',
  'jpeg',
  'gif',
  'rar',
  'zip',
];
const handleFileName = (name = '') => {
  let dotIndex = name.lastIndexOf('.');
  dotIndex = dotIndex > 0 ? dotIndex : name.length;
  return (
    <>
      <Paragraph ellipsis title={name}>
        {name.slice(0, dotIndex)}
      </Paragraph>
      {name.slice(dotIndex)}
    </>
  );
};

const UploadAttachment = forwardRef(({ value = [], onChange }) => {
  // 上传前验证
  const handleBeforeUpload = useCallback(
    ({ name, size }, fileList) => {
      // 文件最多支持上传10个
      if (Number(validateArrayLength(value) + Number(validateArrayLength(fileList))) > 10) {
        message.warn('文件最多支持上传10个');
        return false;
      }
      // 验证文件格式
      const reg = new RegExp(`^.+.(${AccFileType.join('|')})$`);
      const isValidFormat = reg.test(name);
      if (!isValidFormat) {
        ShowConfirm({
          type: 'warning',
          title: '上传文件格式错误',
          content: `仅支持文档(doc 、docx、txt、ppt)、表格(xls、xlsx)、图片(jpg、png、pdf、bmp、jpeg、gif)、压缩包(rar、zip)`,
        });
        return false;
      }
      // 单个文件最大支持10M
      const isValidSize = size / 1024 / 1024 < 10;
      if (!isValidSize) {
        message.warn('单个文件最大支持10M');
        return false;
      }
      return true;
    },
    [value],
  );

  // 合并数据
  const mergeUploadList = useCallback(
    (data) => {
      onChange(value.concat(data));
    },
    [onChange, value],
  );

  const handleChange = useCallback(
    ({ file }) => {
      if (['done', 'error'].includes(file.status)) {
        const response = get(file, 'response', {});
        if (response.status !== 200) {
          message.error(response.message || '上传失败!');
        }
        mergeUploadList(file);
      }
    },
    [mergeUploadList],
  );

  // 移除文件
  const handleRemoveFile = useCallback(
    (file) => {
      onChange(value.filter((i) => i.uid !== file.uid));
    },
    [onChange, value],
  );

  const uploadResultContent = useMemo(
    () =>
      validateArrayLength(value) ? (
        <div className={styles.files}>
          {value.map((item) => {
            const isSuccess = get(item, 'response.status') === 200;
            return (
              <div
                key={item.uid}
                className={classnames(styles.file, {
                  [styles['file-success']]: isSuccess,
                  [styles['file-error']]: !isSuccess,
                })}
              >
                <Iconfont type="iconfujian" className={styles['icon-file']} />
                {handleFileName(item.name)}
                <Iconfont
                  type={isSuccess ? 'iconchenggong' : 'iconjingshi'}
                  className={styles['icon-result']}
                />
                <Iconfont
                  type="iconshanchu6"
                  className={styles['icon-remove']}
                  onClick={() => handleRemoveFile(item)}
                />
              </div>
            );
          })}
        </div>
      ) : null,
    [handleRemoveFile, value],
  );

  return (
    <>
      <Upload
        multiple
        name="file"
        accept={`.${AccFileType.join(',.')}`}
        showUploadList={false}
        beforeUpload={handleBeforeUpload}
        onChange={handleChange}
        action={`${basePath}instead/v2/customer/task/business/uploadFile.do`}
      >
        <Button>
          <Icon type="upload" />
          上传附件
        </Button>
      </Upload>
      <span className={styles.tip}>按住CTRL可多选上传！</span>
      {uploadResultContent}
    </>
  );
});

export default UploadAttachment;
