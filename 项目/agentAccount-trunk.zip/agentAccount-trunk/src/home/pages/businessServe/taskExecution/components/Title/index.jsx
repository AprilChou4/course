/**
 * 标题
 */
import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import { first, last } from 'lodash';
import classnames from 'classnames';
import If from '@components/If';
import ShowConfirm from '@components/ShowConfirm';
import { validateArrayLength } from '@utils';
import styles from './style.less';

const Title = ({
  title,
  taskIds,
  taskId,
  taskStatus,
  emergencyLevel,
  dispatch,
  shouldUploadAttachment,
  isTaskRuleStrict,
}) => {
  const prevDisabled = useMemo(() => {
    const firstId = first(taskIds);
    return !taskId || !firstId || firstId === taskId;
  }, [taskId, taskIds]);

  const nextDisabled = useMemo(() => {
    const lastId = last(taskIds);
    return !taskId || !lastId || lastId === taskId;
  }, [taskId, taskIds]);

  // 切换任务执行单
  const switchTask = (status) =>
    dispatch({
      type: 'handleSwitchTask',
      payload: {
        status,
      },
    });
  // 任务完成
  const completeTask = () => {
    ShowConfirm({
      title: '确定对自己负责的全部步骤标记为完成吗？ ',
      width: 324,
      onOk: () => {
        dispatch({
          type: '$batchComplete',
          payload: {
            taskId,
          },
        });
      },
    });
  };
  return (
    <div className={styles.box}>
      <If condition={taskStatus === 2}>
        <span className={styles.mark} />
      </If>
      <span
        className={classnames(styles.title, {
          [styles.tag]: emergencyLevel === 1,
        })}
      >
        {title}
      </span>

      <div className={styles.operations}>
        {taskStatus !== 2 && !shouldUploadAttachment && !isTaskRuleStrict && (
          <Button type="primary" ghost onClick={completeTask}>
            任务完成
          </Button>
        )}
        <If condition={validateArrayLength(taskIds) > 1}>
          <Button disabled={prevDisabled} onClick={() => switchTask(0)} className={styles.prevBtn}>
            {'<'}
          </Button>
          <Button disabled={nextDisabled} onClick={() => switchTask(1)} className={styles.nextBtn}>
            {'>'}
          </Button>
        </If>
      </div>
      {/* <If condition={validateArrayLength(taskIds) > 1}>
        <div className={styles.operations}>
          <Button disabled={prevDisabled} onClick={() => switchTask(0)}>
            {'<'}
          </Button>
          <Button disabled={nextDisabled} onClick={() => switchTask(1)}>
            {'>'}
          </Button>
        </div>
      </If> */}
    </div>
  );
};

export default connect(
  ({
    title,
    taskIds,
    taskInfo: { taskId, taskStatus, emergencyLevel },
    shouldUploadAttachment,
    isTaskRuleStrict,
  }) => ({
    title,
    taskIds,
    taskId,
    taskStatus,
    emergencyLevel,
    shouldUploadAttachment,
    isTaskRuleStrict,
  }),
)(Title);
