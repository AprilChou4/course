/**
 * 头部
 */
import React, { useMemo } from 'react';
import moment from 'moment';
import { connect } from 'nuomi';
import { Descriptions, Typography } from 'antd';
import styles from './style.less';

const { Paragraph } = Typography;
const DescriptionsItem = Descriptions.Item;
const dateFormat = 'YYYY-MM-DD';

const Header = ({
  customerName,
  serviceProductName,
  contactName,
  contactPhone,
  completeTime,
  taskRemark,
}) => {
  const content = useMemo(() => {
    const data = [
      {
        key: 'customerName',
        label: '客户名称',
        span: 3,
        content: customerName,
      },
      {
        key: 'serviceProductName',
        label: '服务内容',
        span: 3,
        content: serviceProductName,
      },
      {
        key: 'contactName',
        label: '联系人',
        span: 2,
        content: contactName,
      },
      {
        key: 'contactPhone',
        label: '联系电话',
        span: 2,
        content: contactPhone,
      },
      {
        key: 'completeTime',
        label: '截止时间',
        span: 3,
        content: completeTime ? moment(completeTime, 'YYYY-MM-DD HH:mm:ss').format(dateFormat) : '',
      },
      {
        key: 'taskRemark',
        label: '任务说明',
        span: 7,
        content: taskRemark,
      },
    ];

    return data.map((item) => (
      <DescriptionsItem key={item.key} label={item.label} span={item.span}>
        <Paragraph ellipsis title={item.content}>
          {item.content}
        </Paragraph>
      </DescriptionsItem>
    ));
  }, [completeTime, contactName, contactPhone, customerName, serviceProductName, taskRemark]);

  return (
    <Descriptions column={10} className={styles.descriptions}>
      {content}
    </Descriptions>
  );
};

export default connect(
  ({
    taskInfo: {
      customerName,
      serviceProductName,
      contactName,
      contactPhone,
      completeTime,
      taskRemark,
    },
  }) => ({
    customerName,
    serviceProductName,
    contactName,
    contactPhone,
    completeTime,
    taskRemark,
  }),
)(Header);
