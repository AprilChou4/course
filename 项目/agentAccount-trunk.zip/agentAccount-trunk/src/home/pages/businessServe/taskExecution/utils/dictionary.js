/**
 * @object 数据字典
 */

const getData = (params) => {
  const map = {};
  params.list.forEach(({ value, name, label, data }) => {
    map[value] = data || name || label;
  });
  return { ...params, map };
};

// 任务单步骤的状态
const taskStepStatus = {
  title: '任务单步骤状态',
  list: [
    {
      value: 0,
      name: '未开始',
    },
    {
      value: 1,
      name: '进行中',
    },
    {
      value: 2,
      name: '已完成',
    },
  ],
};

export default {
  taskStepStatus: getData(taskStepStatus),
};
