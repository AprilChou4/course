/**
 * 无步骤-未完成的内容
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import If from '@components/If';
import styles from './styles.less';

const UnComplete = ({ execute, dispatch }) => {
  const handleComplete = useCallback(() => {
    dispatch({
      type: '$taskComplete',
    });
  }, [dispatch]);

  return (
    <div className={styles.unComplete}>
      <If condition={execute}>
        <div className={styles.placeholder}>
          若当前任务已完成，可点击下方【完成】按钮，标记任务完成哦~
        </div>
        <div className={styles.operation}>
          <Button type="primary" onClick={handleComplete}>
            完成
          </Button>
        </div>
      </If>
    </div>
  );
};

export default connect(({ taskInfo: { execute } }) => ({ execute }))(UnComplete);
