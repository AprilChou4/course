// 收起、展开伸缩框
import React from 'react';
import { Tag, Tooltip } from 'antd';
import { connect } from 'nuomi';
import CollapseItem from '@components/CollapseItem';
import Style from './style.less';

const Collapse = ({ dispatch, selectedRows, selectedRowKeys, taskAssignData, isSingleAssign }) => {
  // 删除任务
  const close = (taskId) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedRows: selectedRows.filter((v) => v.taskId !== taskId),
        selectedRowKeys: selectedRowKeys.filter((v) => v !== taskId),
      },
    });
  };
  const getContent = (selectList) => {
    return (
      <div className={Style['m-list']}>
        {selectList.map((item) => (
          <Tag
            {...(selectedRowKeys.length === 1 ? {} : { closable: true })}
            key={item.taskId}
            onClose={() => close(item.taskId)}
          >
            {item.taskStatus === 2 || !item.edit ? (
              <Tooltip
                title={item.taskStatus === 2 ? '任务已完成' : '无派工权限'}
                overlayClassName={Style['m-tooltip']}
                placement="bottom"
              >
                <span className={Style['m-gray']}>
                  {item.taskNumber} ({item.customerName})
                </span>
              </Tooltip>
            ) : (
              <span>
                {item.taskNumber} ({item.customerName})
              </span>
            )}
          </Tag>
        ))}
      </div>
    );
  };
  return (
    <>
      {!isSingleAssign ? (
        <CollapseItem
          getContent={() => getContent(selectedRows)}
          header={`共选择${selectedRows.length}个任务`}
        />
      ) : (
        <>
          {taskAssignData.taskStatus === 2 || !taskAssignData.edit ? (
            <div className={`${Style['m-gray']} ${Style['m-single']}`}>
              <Tooltip
                title={taskAssignData.taskStatus === 2 ? '任务已完成' : '无派工权限'}
                overlayClassName={Style['m-tooltip']}
                placement="bottom"
              >
                {taskAssignData.taskNumber} ({taskAssignData.customerName})
              </Tooltip>
            </div>
          ) : (
            <div className={Style['m-single']}>
              {taskAssignData.taskNumber} ({taskAssignData.customerName})
            </div>
          )}
        </>
      )}
    </>
  );
};
export default connect(({ selectedRows, selectedRowKeys, taskAssignData, isSingleAssign }) => ({
  selectedRows,
  selectedRowKeys,
  taskAssignData,
  isSingleAssign,
}))(Collapse);
