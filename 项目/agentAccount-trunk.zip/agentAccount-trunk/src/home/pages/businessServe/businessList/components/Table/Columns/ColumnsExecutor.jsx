// 执行者列
import React from 'react';
import { Tag } from 'antd';
import { postMessageRouter } from '@utils';
import Style from './style.less';

const goTask = (taskId) => {
  postMessageRouter({
    type: 'agentAccount/routerLocation',
    payload: {
      url: '/businessServe/viewTask',
      query: {
        id: taskId,
      },
    },
  });
};
const ColumnsExecutor = [
  {
    title: '序号',
    key: 'index',
    render: (text, record, index) => <span>{index + 1}</span>,
    align: 'center',
    width: 50,
  },
  {
    title: '任务单号',
    dataIndex: 'taskNumber',
    align: 'center',
    width: 190,
    render: (text, record) => (
      <div className={Style['m-taskNumber']}>
        <a className="f-ellipsis" onClick={() => goTask(record.taskId)}>
          {text || '-'}
        </a>
        {!!record.emergencyLevel && (
          <Tag className={Style['m-tag']} color="#FF0000">
            急
          </Tag>
        )}
      </div>
    ),
  },
  {
    title: '客户名称',
    dataIndex: 'customerName',
    align: 'center',
    width: 260,
    render: (text) => (
      <div className="f-tal f-ellipsis" title={text}>
        {text}
      </div>
    ),
  },

  {
    title: '服务内容',
    dataIndex: 'serviceProductName',
    align: 'center',
    width: 260,
    render: (text) => (
      <div className="f-tal f-ellipsis" title={text}>
        {text}
      </div>
    ),
  },
  {
    title: '任务状态',
    dataIndex: 'taskStatus',
    align: 'center',
    width: 90,
    render: (text) => {
      // 任务状态（-1无状态，0未开始，1进行中/2已完成/3已终止/4移交中/5待处理)
      return [-1, 0, 1, 2, 3, 4, 5].includes(text) ? (
        <span className={`${Style[`m-taskStatus`]} ${Style[`m-taskStatus${text}`]}`}>
          {['-', '未开始', '进行中', '已完成', '已终止', '-', '-'][text + 1]}
        </span>
      ) : (
        '-'
      );
    },
  },
  {
    title: '步骤状态',
    dataIndex: 'stepProcess',
    align: 'center',
    width: 145,
    render: (text) => (
      <div className="f-tal f-ellipsis" title={text}>
        {text || '-'}
      </div>
    ),
  },
];
export default ColumnsExecutor;
