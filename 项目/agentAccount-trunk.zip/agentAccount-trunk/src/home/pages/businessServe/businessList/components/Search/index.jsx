import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { Form, Checkbox, TreeSelect, Select } from 'antd';
import { connect } from 'nuomi';
import SearchInput from '@components/SearchInput';
import SearchTreeSelect from '@components/select/SearchTreeSelect';
import dictionary from '../../../utils';
import Style from './style.less';

const { Option } = Select;
const formItemLayout = {
  labelCol: {
    sm: { span: 5 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};

const formItemStyle = {
  marginBottom: 8,
};

const checkboxItemStyle = {
  width: 90,
  marginTop: 6,
};

const wrapperStyle = {
  width: 432,
  padding: '20px 0',
};

const Search = ({
  tableConditions,
  taskAuth,
  executorList,
  productList,
  allEmployeeList,
  dispatch,
}) => {
  const [operateType, setType] = useState(1);
  const [inputValue, setInputValue] = useState('');
  // 获取操作类型 0=输入框清空 1=更多条件查询 2= 3=更多条件旁边的查询 4= 重置
  const getOperateType = (type) => {
    if (type === 4) {
      window.businessListParams = {};
      dispatch({
        type: 'updateState',
        payload: {
          tableConditions: {
            current: tableConditions.current,
            pageSize: tableConditions.pageSize,
          },
        },
      });
    }
    setType(type);
  };

  // 执行人数据
  const treeData = useMemo(() => {
    return productList.map((item) => ({
      title: item.serviceName,
      value: item.serviceTypeId,
      selectable: false,
      children: item.serviceProductVOList.map((it) => ({
        title: it.serviceProductName,
        name: it.serviceProductName,
        value: it.serviceProductId,
        splicingLabel: `${item.serviceName}-${it.serviceProductName}`,
        selectable: true,
      })),
    }));
  }, [productList]);

  const onSearch = async (data) => {
    // 如果值为空字符串则不传，处理掉空的和undefined的
    let newData = {};
    Object.keys(data).forEach((key) => {
      if (
        (!Array.isArray(data[key]) && data[key]) ||
        (Array.isArray(data[key]) && !!data[key].length)
      ) {
        newData[key] = data[key];
      }
    });
    if (operateType === 0) {
      newData = {};
    } else if (operateType === 3) {
      newData.executorOperator = tableConditions.executorOperator;
    } else if (operateType === 1) {
      newData.executorOperator = tableConditions.executorOperator;
    }
    // 查询清空后，原来的条件没有清空
    const leftQuery = {
      current: tableConditions.current,
      pageSize: tableConditions.pageSize,
      // executorOperator: tableConditions.executorOperator,
    };
    dispatch({
      type: 'updateState',
      payload: {
        tableConditions: leftQuery,
      },
    });
    await dispatch({
      type: 'updateCondition',
      payload: newData,
    });
  };

  const getSearchData = useCallback(
    (data) => {
      const searchData = [];
      // 获取部门等树选中的名字
      /**
       *
       * @param {*array} treeData  树结构数据
       * @param {*array} matchArr  选中值的value数组
       * @param {*array} nameArr   返回的名称数组，默认值为[]
       */
      const getNames = (treeDatas, matchArr, nameArr = []) => {
        const treeArr = [...treeDatas];
        treeArr.forEach((item) => {
          if (item.children && item.children.length) {
            getNames(item.children, matchArr, nameArr, false);
          }
          if (matchArr.includes(item.value) || matchArr.includes(item.id)) {
            // splicingLabel服务内容专属
            nameArr.push(item.splicingLabel || item.name || item.title);
          }
        });
        return nameArr.join(',');
      };
      Object.keys(data).forEach((i) => {
        const value = data[i];
        if (value) {
          switch (i) {
            case 'executorOperator': {
              searchData.push({
                title: '经办人执行人',
                text: []
                  .concat(value)
                  .map(
                    (ele) =>
                      allEmployeeList.find((item) => item.staffId === ele) &&
                      allEmployeeList.find((item) => item.staffId === ele).realName,
                  ),
              });
              break;
            }
            // 任务状态
            case 'taskStatusList':
              searchData.push({
                title: dictionary.taskStatus.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.taskStatus.list.find((item) => item.value === ele)?.name,
                  ),
              });
              break;
            // 派工状态
            case 'assignStatusList':
              searchData.push({
                title: dictionary.assignStatus.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.assignStatus.list.find((item) => item.value === ele).name,
                  ),
              });
              break;
            // 步骤状态
            case 'stepProcessList':
              searchData.push({
                title: dictionary.stepProcess.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.stepProcess.list.find((item) => item.value === ele).name,
                  ),
              });
              break;
            // 紧急程度
            case 'emergencyLevelList':
              searchData.push({
                title: dictionary.emergencyLevel.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.emergencyLevel.list.find((item) => item.value === ele).name,
                  ),
              });
              break;
            case 'serviceProductId':
              searchData.push({
                title: '服务内容',
                text: getNames(treeData, [].concat(value)),
              });
              break;
            case 'executorId':
              searchData.push({
                title: '执行人',
                text: getNames(executorList, [].concat(value)),
              });
              break;
            default:
              break;
          }
        }
      });
      return searchData;
    },
    [allEmployeeList, executorList, treeData],
  );

  const getValue = useCallback(
    (searchData) => {
      const values = [];
      if (searchData.length) {
        searchData.forEach((ele) => {
          const text = Array.isArray(ele.text) ? ele.text.join('、') : ele.text;
          if (text) {
            values.push(`${ele.title}：${text}`);
          }
        });
        return values.join('；');
      }
      return tableConditions.name;
    },
    [tableConditions.name],
  );

  useEffect(() => {
    setInputValue(getValue(getSearchData(tableConditions)));
  }, [getSearchData, getValue, tableConditions]);
  // 执行者内容
  /**
   * 管理者1-任务状态、派工状态、服务内容、执行人
   * 执行者2-任务状态、步骤状态、紧急程度、服务内容
   * 双重3--任务状态、派工状态、步骤状态、紧急程度、服务内容、执行人
   */
  const getContent = ({ getFieldDecorator }) => {
    return (
      <div style={wrapperStyle} className={Style['m-search']}>
        {/* 执行人或经办人id，从停用员工跳转过来 */}
        {getFieldDecorator('executorOperator', {
          initialValue: tableConditions.executorOperator,
        })(
          <Select style={{ display: 'none' }}>
            {allEmployeeList.map(({ staffId, realName }) => (
              <Option value={staffId} key={staffId}>
                {realName}
              </Option>
            ))}
          </Select>,
        )}
        {/* 任务状态 */}
        <Form.Item label={dictionary.taskStatus.title} {...formItemLayout} style={formItemStyle}>
          {getFieldDecorator('taskStatusList', {
            initialValue: tableConditions.taskStatusList,
          })(
            <Checkbox.Group>
              {dictionary.taskStatus.list.map(({ value, name }) => (
                <Checkbox style={checkboxItemStyle} key={value} value={value}>
                  {name}
                </Checkbox>
              ))}
            </Checkbox.Group>,
          )}
        </Form.Item>
        {/* 派工状态 */}
        {[1, 3].includes(taskAuth) && (
          <Form.Item
            label={dictionary.assignStatus.title}
            {...formItemLayout}
            style={formItemStyle}
          >
            {getFieldDecorator('assignStatusList', {
              initialValue: tableConditions.assignStatusList,
            })(
              <Checkbox.Group>
                {dictionary.assignStatus.list.map(({ value, name }) => (
                  <Checkbox style={checkboxItemStyle} key={value} value={value}>
                    {name}
                  </Checkbox>
                ))}
              </Checkbox.Group>,
            )}
          </Form.Item>
        )}
        {/* 步骤状态 */}
        {[2, 3].includes(taskAuth) && (
          <>
            <Form.Item
              label={dictionary.stepProcess.title}
              {...formItemLayout}
              style={formItemStyle}
            >
              {getFieldDecorator('stepProcessList', {
                initialValue: tableConditions.stepProcessList,
              })(
                <Checkbox.Group>
                  {dictionary.stepProcess.list.map(({ value, name }) => (
                    <Checkbox style={checkboxItemStyle} key={value} value={value}>
                      {name}
                    </Checkbox>
                  ))}
                </Checkbox.Group>,
              )}
            </Form.Item>

            {/* 紧急程度 */}
            <Form.Item label={dictionary.emergencyLevel.title} {...formItemLayout}>
              {getFieldDecorator('emergencyLevelList', {
                initialValue: tableConditions.emergencyLevelList,
              })(
                <Checkbox.Group>
                  {dictionary.emergencyLevel.list.map(({ value, name }) => (
                    <Checkbox style={checkboxItemStyle} key={value} value={value}>
                      {name}
                    </Checkbox>
                  ))}
                </Checkbox.Group>,
              )}
            </Form.Item>
          </>
        )}
        <Form.Item label="服务内容：" {...formItemLayout}>
          {getFieldDecorator('serviceProductId', {
            initialValue: tableConditions.serviceProductId,
          })(
            <TreeSelect
              placeholder="请选择服务内容"
              treeDefaultExpandAll
              treeData={treeData}
              dropdownStyle={{ maxHeight: 300 }}
              treeNodeLabelProp="splicingLabel"
            />,
          )}
        </Form.Item>
        {[1, 3].includes(taskAuth) && (
          <Form.Item label="执行人" {...formItemLayout}>
            {getFieldDecorator('executorId', {
              initialValue: tableConditions.executorId,
            })(
              <SearchTreeSelect
                placeholder="请选择经办人"
                style={{ width: '100%' }}
                treeData={executorList}
                treeDefaultExpandAll
                dropdownStyle={{ maxHeight: 300 }}
              />,
            )}
          </Form.Item>
        )}
      </div>
    );
  };

  return (
    <SearchInput
      name="searchName"
      className={Style['m-taskSearch']}
      autoComplete="off"
      style={{ width: 320 }}
      placeholder={taskAuth === 2 ? '请输入任务名称' : '请输入客户名称/任务单号'}
      value={inputValue}
      getValue={getValue}
      getContent={getContent}
      getSearchData={getSearchData}
      getOperateType={getOperateType}
      onSearch={onSearch}
      defaultValue={inputValue}
    />
  );
};

export default connect(
  ({ tableConditions, executorList, productList, taskAuth, allEmployeeList }) => ({
    tableConditions,
    executorList,
    productList,
    taskAuth,
    allEmployeeList,
  }),
)(Search);
