import React, { useMemo, useState, useCallback, useEffect } from 'react';
import { Form, Checkbox, TreeSelect, Select } from 'antd';
import { connect } from 'nuomi';
import SearchTreeSelect from '@components/select/SearchTreeSelect';
import AntdSearchComplete from '@components/AntdSearchComplete';
import { getTreeNames, getSearchValue } from '@components/AntdSearchComplete/Suffix';
import globalServices from '@home/services';
import dictionary from '../../../utils';
import Style from './style.less';

const { Option } = Select;

const Search = ({
  tableConditions,
  taskAuth,
  executorList,
  productList,
  allEmployeeList,
  dispatch,
}) => {
  // input默认值
  const [inputValue, setInputValue] = useState('');
  const [autoCompleteList, setAutoCompleteList] = useState([]);
  // 输入框变化的时候
  const onChange = async (value) => {
    if (!value) {
      return false;
    }
    const data = await globalServices.searchCustomerByName({ customerName: value });
    const dataSource = data.map((item) => item.customerName);
    setAutoCompleteList(dataSource);
    return false;
  };

  // 执行人数据
  const treeData = useMemo(() => {
    return productList.map((item) => ({
      title: item.serviceName,
      value: item.serviceTypeId,
      selectable: false,
      children: item.serviceProductVOList.map((it) => ({
        title: it.serviceProductName,
        name: it.serviceProductName,
        value: it.serviceProductId,
        splicingLabel: `${item.serviceName}-${it.serviceProductName}`,
        selectable: true,
      })),
    }));
  }, [productList]);

  const onSearch = async (formValues) => {
    // 查询清空后，原来的条件没有清空
    const leftQuery = {
      current: tableConditions.current,
      pageSize: tableConditions.pageSize,
    };
    dispatch({
      type: 'updateState',
      payload: {
        tableConditions: leftQuery,
      },
    });
    await dispatch({
      type: 'updateCondition',
      payload: formValues,
    });
  };

  // 获取输入框展示数据，用于在输入框中展示前的处理
  const getSearchData = useCallback(
    (data, getNames) => {
      const searchData = [];
      Object.keys(data).forEach((i) => {
        const value = data[i];
        if (value) {
          switch (i) {
            case 'executorOperator': {
              searchData.push({
                title: '经办人执行人',
                text: []
                  .concat(value)
                  .map((ele) => allEmployeeList.find((item) => item.staffId === ele)?.realName),
              });
              break;
            }
            // 任务状态
            case 'taskStatusList':
              searchData.push({
                title: dictionary.taskStatus.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.taskStatus.list.find((item) => item.value === ele)?.name,
                  ),
              });
              break;
            // 派工状态
            case 'assignStatusList':
              searchData.push({
                title: dictionary.assignStatus.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.assignStatus.list.find((item) => item.value === ele)?.name,
                  ),
              });
              break;
            // 步骤状态
            case 'stepProcessList':
              searchData.push({
                title: dictionary.stepProcess.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) => dictionary.stepProcess.list.find((item) => item.value === ele)?.name,
                  ),
              });
              break;
            // 紧急程度
            case 'emergencyLevelList':
              searchData.push({
                title: dictionary.emergencyLevel.title,
                text: []
                  .concat(value)
                  .map(
                    (ele) =>
                      dictionary.emergencyLevel.list.find((item) => item.value === ele)?.name,
                  ),
              });
              break;
            case 'serviceProductId':
              searchData.push({
                title: '服务内容',
                text:
                  getNames &&
                  getNames({
                    treeData,
                    selectedArr: [].concat(value),
                  }),
              });
              break;
            case 'executorId':
              searchData.push({
                title: '执行人',
                text:
                  getNames &&
                  getNames({
                    treeData: executorList,
                    selectedArr: [].concat(value),
                  }),
              });
              break;
            default:
              break;
          }
        }
      });
      return searchData;
    },
    [allEmployeeList, executorList, treeData],
  );

  // 处理从部门员工跳转过来的回显
  useEffect(() => {
    setInputValue(getSearchValue(getSearchData(tableConditions, getTreeNames)));
  }, [getSearchData, tableConditions]);

  // 执行者内容
  /**
   * 管理者1-任务状态、派工状态、服务内容、执行人
   * 执行者2-任务状态、步骤状态、紧急程度、服务内容
   * 双重3--任务状态、派工状态、步骤状态、紧急程度、服务内容、执行人
   */
  const getContent = ({ getFieldDecorator }) => {
    return (
      <>
        {/* 执行人或经办人id，从停用员工跳转过来 */}
        {getFieldDecorator('executorOperator', {
          initialValue: tableConditions.executorOperator,
        })(
          <Select style={{ display: 'none' }}>
            {allEmployeeList.map(({ staffId, realName }) => (
              <Option value={staffId} key={staffId}>
                {realName}
              </Option>
            ))}
          </Select>,
        )}
        {/* 任务状态 */}
        <Form.Item label={dictionary.taskStatus.title} className="ui-checkboxGroup">
          {getFieldDecorator('taskStatusList', {
            initialValue: tableConditions.taskStatusList,
          })(
            <Checkbox.Group>
              {dictionary.taskStatus.list.map(({ value, name }) => (
                <Checkbox key={value} value={value}>
                  {name}
                </Checkbox>
              ))}
            </Checkbox.Group>,
          )}
        </Form.Item>
        {/* 派工状态 */}
        {[1, 3].includes(taskAuth) && (
          <Form.Item label={dictionary.assignStatus.title} className="ui-checkboxGroup">
            {getFieldDecorator('assignStatusList', {
              initialValue: tableConditions.assignStatusList,
            })(
              <Checkbox.Group>
                {dictionary.assignStatus.list.map(({ value, name }) => (
                  <Checkbox key={value} value={value}>
                    {name}
                  </Checkbox>
                ))}
              </Checkbox.Group>,
            )}
          </Form.Item>
        )}
        {/* 步骤状态 */}
        {[2, 3].includes(taskAuth) && (
          <>
            <Form.Item label={dictionary.stepProcess.title} className="ui-checkboxGroup">
              {getFieldDecorator('stepProcessList', {
                initialValue: tableConditions.stepProcessList,
              })(
                <Checkbox.Group>
                  {dictionary.stepProcess.list.map(({ value, name }) => (
                    <Checkbox key={value} value={value}>
                      {name}
                    </Checkbox>
                  ))}
                </Checkbox.Group>,
              )}
            </Form.Item>

            {/* 紧急程度 */}
            <Form.Item label={dictionary.emergencyLevel.title} className="ui-checkboxGroup">
              {getFieldDecorator('emergencyLevelList', {
                initialValue: tableConditions.emergencyLevelList,
              })(
                <Checkbox.Group>
                  {dictionary.emergencyLevel.list.map(({ value, name }) => (
                    <Checkbox key={value} value={value}>
                      {name}
                    </Checkbox>
                  ))}
                </Checkbox.Group>,
              )}
            </Form.Item>
          </>
        )}
        <Form.Item label="服务内容：">
          {getFieldDecorator('serviceProductId', {
            initialValue: tableConditions.serviceProductId,
          })(
            <TreeSelect
              placeholder="请选择服务内容"
              treeDefaultExpandAll
              treeData={treeData}
              dropdownStyle={{ maxHeight: 300 }}
              treeNodeLabelProp="splicingLabel"
            />,
          )}
        </Form.Item>
        {[1, 3].includes(taskAuth) && (
          <Form.Item label="执行人">
            {getFieldDecorator('executorId', {
              initialValue: tableConditions.executorId,
            })(
              <SearchTreeSelect
                placeholder="请选择经办人"
                style={{ width: '100%' }}
                treeData={executorList}
                treeDefaultExpandAll
                dropdownStyle={{ maxHeight: 300 }}
              />,
            )}
          </Form.Item>
        )}
      </>
    );
  };

  return (
    <AntdSearchComplete
      name="searchName"
      className={Style['m-taskSearch']}
      placeholder={taskAuth === 2 ? '请输入任务名称' : '请输入客户名称/任务单号'}
      getContent={getContent}
      getSearchData={getSearchData}
      defaultValue={inputValue}
      isHasAutocomplete
      autoCompleteList={autoCompleteList}
      onCommonSearch={onSearch}
      onChange={onChange}
    />
  );
};

export default connect(
  ({ tableConditions, executorList, productList, taskAuth, allEmployeeList }) => ({
    tableConditions,
    executorList,
    productList,
    taskAuth,
    allEmployeeList,
  }),
)(Search);
