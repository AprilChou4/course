// 更多按钮
import React from 'react';
import { connect } from 'nuomi';
import DropDown from '@components/DropDown';
import pubData from 'data';
import StopBtn from './StopBtn'; // 终止
import RecoverBtn from './RecoverBtn'; // 恢复
import DeleteBtn from './DeleteBtn'; // 删除
import ExportBtn from './ExportBtn'; // 导出

const userAuth = pubData.get('authority');
const More = () => {
  return (
    <DropDown>
      <StopBtn />
      <RecoverBtn />
      {userAuth[606] && <DeleteBtn />}
      {userAuth[607] && <ExportBtn />}
    </DropDown>
  );
};

export default connect()(More);
