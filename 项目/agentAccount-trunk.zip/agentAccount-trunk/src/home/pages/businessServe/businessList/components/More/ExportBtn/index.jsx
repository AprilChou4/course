/* eslint-disable no-param-reassign */
/**
 * 新增
 */
import React from 'react';
import ExportText from '@components/ExportText';
import { connect } from 'nuomi';

const ExportBtn = ({ tableConditions }) => {
  // 点击导出
  const { current, pageSize, ...query } = tableConditions;
  return (
    <>
      <ExportText
        url={`${basePath}instead/v2/customer/task/business/export.do`}
        method="post"
        data={query}
      >
        导出
      </ExportText>
    </>
  );
};

export default connect(({ tableConditions }) => ({
  tableConditions,
}))(ExportBtn);
