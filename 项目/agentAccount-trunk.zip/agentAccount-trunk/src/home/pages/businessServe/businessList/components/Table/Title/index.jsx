import React from 'react';
import { connect } from 'nuomi';
import Iconfont from '@components/Iconfont';
import LinkButton from '@components/buttons/LinkButton';
import { isNil } from 'lodash';
import './style.less';

const Title = ({ dispatch, taskAuth, notStartCount, goingCount, waitingExecutionCount }) => {
  const handleClick = (type) => {
    setTimeout(() => {
      // 错误 #176686
      if (type === 5) {
        dispatch({
          type: 'updateCondition',
          payload: {
            waitingExecution: true,
            taskStatusList: [],
          },
        });
      } else {
        dispatch({
          type: 'updateCondition',
          payload: {
            taskStatusList: isNil(type) ? [] : [type],
            waitingExecution: false,
          },
        });
      }
    });
  };

  // 任务状态 （-1无状态，0未开始，1进行中/2已完成/3已终止/4移交中/5待处理)
  const getButton = (type, number) => (
    <LinkButton underline style={{ color: 'inherit' }} onClick={() => handleClick(type)}>
      <span> {number}</span>
    </LinkButton>
  );

  return (
    <>
      <Iconfont code="&#xea3d;" />
      {
        [
          <span>
            当前存在未开始任务 {getButton(0, notStartCount)}
            个、进行中任务 {getButton(1, goingCount)}个
          </span>,
          <span>您有 {getButton(5, waitingExecutionCount)} 个待执行的工商任务，请及时处理！</span>,
          <span>
            当前存在未开始任务 {getButton(0, notStartCount)} 个，进行中任务
            {getButton(1, goingCount)} 个，待执行任务 {getButton(5, waitingExecutionCount)}
            个，请及时处理！
          </span>,
        ][taskAuth - 1]
      }
      <span styleName="dangerBtn" onClick={() => handleClick(null)}>
        查看全部
      </span>
    </>
  );
};
export default connect(({ taskAuth, notStartCount, goingCount, waitingExecutionCount }) => ({
  taskAuth,
  notStartCount,
  goingCount,
  waitingExecutionCount,
}))(Title);
