/**
 * 终止按钮
 */
import React from 'react';
import { message } from 'antd';
import ShowConfirm from '@components/ShowConfirm';
import CollapseItem from '@components/CollapseItem';
import { connect } from 'nuomi';

const StopBtn = ({ dispatch, selectedRowKeys, selectedRows }) => {
  // 终止收缩框
  const getCollapseItem = (cannotEditList, completeList, stopList) => (
    <CollapseItem
      getContent={() => (
        <div>
          {!!cannotEditList.length && (
            <div>
              {cannotEditList.map((item) => (
                <span key={item.taskNumber}>“{item.taskNumber}”，</span>
              ))}
              等任务无权限终止
            </div>
          )}
          {!!completeList.length && (
            <div>
              {completeList.map((item) => (
                <span key={item.taskNumber}>“{item.taskNumber}”，</span>
              ))}
              等任务已完成，不支持终止
            </div>
          )}
          {!!stopList.length && (
            <div>
              {stopList.map((item) => (
                <span key={item.taskNumber}>“{item.taskNumber}”，</span>
              ))}
              等任务已终止，不支持终止
            </div>
          )}
        </div>
      )}
      header="详细原因"
    />
  );

  // 点击终止：可对未开始，进行中的任务进行终止，已完成的任务不支持终止
  const stop = () => {
    if (!selectedRowKeys.length) {
      message.warning('请选择要终止的任务');
      return false;
    }
    // 不能编辑的行
    const cannotEditList = selectedRows.filter((item) => !item.edit);
    if (cannotEditList.length === selectedRows.length) {
      message.warning('您无权限终止所选任务');
      return false;
    }
    // 已经完成的行
    const completeList = selectedRows.filter((item) => item.taskStatus === 2);
    if (completeList.length === selectedRows.length) {
      message.warning('所选任务已完成，无法终止');
      return false;
    }

    // 已经终止的行
    const stopList = selectedRows.filter((item) => item.taskStatus === 3);
    if (stopList.length === selectedRows.length) {
      message.warning('所选任务已终止');
      return false;
    }

    // 完成和没有编辑的
    const noCompleteAndNoEditAndStop = selectedRows.filter(
      (item) => item.taskStatus === 2 || item.taskStatus === 3 || !item.edit,
    );
    ShowConfirm({
      title: '你确定要终止所选任务信息吗？',
      onOk: () => {
        if (cannotEditList.length === 0 && completeList.length === 0) {
          dispatch({
            type: '$stopBusiness',
            payload: {
              taskIdList: selectedRowKeys,
            },
          });
        } else {
          ShowConfirm({
            title: `“${noCompleteAndNoEditAndStop[0].taskNumber}”
            ${noCompleteAndNoEditAndStop.length > 1 ? '等' : ''}
            ${noCompleteAndNoEditAndStop.length}个任务不支持终止`,
            type: 'warning',
            width: 420,
            content: getCollapseItem(cannotEditList, completeList, stopList),
          });
        }
      },
    });
    // eslint
    return true;
  };
  return (
    <>
      <div onClick={stop}>终止</div>
    </>
  );
};

export default connect(({ selectedRowKeys, selectedRows }) => ({
  selectedRowKeys,
  selectedRows,
}))(StopBtn);
