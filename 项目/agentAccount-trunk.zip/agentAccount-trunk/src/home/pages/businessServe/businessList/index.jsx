// 工商任务列表
import React from 'react';
import pubData from 'data';
import NoAuthPage from '@components/NoAuthPage';
import Layout from './components/Layout';
import effects from './effects';

const userAuth = pubData.get('authority');
export default {
  id: 'businessServe_businessList',
  state: {
    // query: {},

    // 员工列表 制单人/业务员/收款人
    staffList: [],
    // 所有员工列表
    allEmployeeList: [],
    // 部门树
    deptList: [],
    // 服务项目列表
    chargeItemList: [],
    // 删除失败弹窗
    delFailVisible: false,
    // 删除失败返回数据
    delFailData: {},

    // =================================================
    // ==========列表相关==============
    // 列表权限，1管理者权限，2执行者权限，3管理者-执行者权限
    taskAuth: 1,
    pageSizeOptions: ['50', '100', '200', '300'],
    // 表格选中数据
    selectedRowKeys: [],
    selectedRows: [],
    // 表格数据请求条件
    tableConditions: {
      current: 1,
      pageSize: 50,
    },
    // 表格的list
    tableList: [],
    // 总数
    total: 0,
    // 未开始数量
    notStartCount: 0,
    // 进行中数量
    goingCount: 0,
    // 待执行数量
    waitingExecutionCount: 0,
    // 自定义列
    columnSource: [],
    // 工商服务表格自定义列弹窗是否显示
    businessCustomColVisible: false,
    // 服务内容产品列表
    productList: [],
    // =========派工相关==============
    // 工商任务派工弹窗是否显示
    taskAssignVisible: false,
    // 单个派工详情
    taskAssignData: {},
    // 是否单个派工
    isSingleAssign: false,
    // 执行人列表 处理成树结构
    executorList: [],
  },
  effects,
  render() {
    return <>{userAuth[601] ? <Layout /> : <NoAuthPage />}</>;
  },
  onChange: {
    query() {
      if (userAuth[601]) {
        this.store.dispatch({
          type: 'initData',
        });
      }
    },
  },
  onInit() {},
};
