// 工商任务列表
import React from 'react';
import { connect } from 'nuomi';
import { useSize } from '@umijs/hooks';
import Title from './Title';
import MyTable from './MyTable';
import CustomColModal from './CustomColModal';
import './style.less';

const BusinessTable = ({ tableList }) => {
  const [titleSize, titleRef] = useSize();
  return (
    <>
      {!!tableList.length && (
        <div styleName="title" ref={titleRef}>
          <Title />
        </div>
      )}
      <div style={{ height: `calc(100% - 5px - ${titleSize.height || 38}px)` }}>
        <MyTable />
      </div>
      <CustomColModal />
    </>
  );
};

export default connect(({ tableList }) => ({ tableList }))(BusinessTable);
