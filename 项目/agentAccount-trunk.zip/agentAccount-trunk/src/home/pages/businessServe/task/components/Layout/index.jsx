import React from 'react';
import ContentWrapper from '@components/ContentWrapper';
import Layout from '@components/Layout';
import { connect } from 'nuomi';
import { Badge } from 'antd';
import Content from '../Content';
import Operate from '../Operate';
import Footer from '../Footer';

import './style.less';

const BusinessServe = ({ formValues }) => {
  // 左侧任务单状态JSX
  const Left = () => {
    if (formValues.taskStatus === 2) {
      return <div styleName="task-complete-symbol" />;
    }
    if (formValues.taskStatus === 3) {
      return (
        <div styleName="task-stop-symbol">
          <Badge color="#FF0000" />
          <span>任务已终止</span>
        </div>
      );
    }
    return null;
  };

  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title="任务单"
        header={{
          left: <Left />,
          right: <Operate />,
        }}
        content={<Content />}
        footer={<Footer />}
      />
    </Layout.PageWrapper>
  );
};

export default connect(({ formValues }) => ({
  formValues,
}))(BusinessServe);
