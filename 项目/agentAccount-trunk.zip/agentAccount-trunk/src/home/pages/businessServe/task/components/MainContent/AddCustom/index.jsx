// 新增客户弹窗
import React, { useEffect, useReducer, useState, createContext } from 'react';
import { Modal, Spin, Input, message, Form, Row, Col, Select } from 'antd';
import { InputLimit } from '@components/InputLimit';
import Title from '@components/Title';
import Iconfont from '@components/Iconfont';
import { dictionary } from '@pages/custom/utils';
import globalServices from '@home/services';
import MultiTreeSelect from '@components/MultiTreeSelect';
import ServiceType from '@components/ServiceType';
import CustomerNameInput from './CustomerNameInput';
import { reducer, defaultState } from './reducer';
import './style.less';

const FormItem = Form.Item;
const { Option } = Select;
const formItemLayout = {
  labelCol: {
    sm: { span: 8 },
  },
  wrapperCol: {
    sm: { span: 16 },
  },
};

const layout = {
  labelCol: {
    sm: { span: 4 },
  },
  wrapperCol: {
    sm: { span: 19 },
  },
};

const Context = createContext(null);

const AddCustomModal = ({ formRef, form, visible, customerName, onSuccess, onCancelCallback }) => {
  const [state, dispatch] = useReducer(reducer, defaultState);
  const {
    addCustomerCode,
    customVisible,
    serviceTypeList,
    bookeepers,
    drawerList,
    loading,
  } = state;
  const { getFieldValue, getFieldDecorator, validateFields, setFieldsValue } = form;

  // 更新弹窗状态、客户名称
  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        customVisible: visible,
      },
    });
  }, [visible]);

  // 初始化数据
  useEffect(() => {
    async function addCustomInit() {
      // 客户编码、服务类型,记账会计
      const [customerCode, serviceList, bookeepersList] = await Promise.all([
        globalServices.getCustomerCode(),
        globalServices.getServiceType(),
        globalServices.getBookkeep(),
      ]);

      const data = await globalServices.getRoletypeList();
      // 开票员
      let drawerArr = [];
      data.forEach((item) => {
        switch (item.roleType) {
          case 3:
            drawerArr = item.treeList;
            break;
          default:
            break;
        }
      });
      dispatch({
        type: 'updateState',
        payload: {
          addCustomerCode: customerCode,
          serviceTypeList: serviceList || [],
          bookeepers: bookeepersList || [],
          drawerList: drawerArr || [],
        },
      });
    }
    addCustomInit();
  }, []);

  // 服务类型选中值
  const [servivceValue, setServivceValue] = useState([]);

  // 选中服务类型
  const onCheckBox = (checkedValue, checkedObj) => {
    setFieldsValue({ customerServiceRelationList: checkedObj });
    setServivceValue(checkedValue);
  };

  // 取消
  const onCancel = async () => {
    /** 新增客户-回收客户编码
     * @param {*string} customerCode 客户编码
     */
    await globalServices.deleteCode({
      customerCode: getFieldValue('customerCode'),
    });
    dispatch({
      type: 'updateState',
      payload: {
        customVisible: false,
      },
    });
    onCancelCallback();
    formRef.resetFields('customerName');
  };

  // 保存客户
  const save = () => {
    dispatch({
      type: 'updateState',
      payload: {
        loading: true,
      },
    });
    validateFields(async (err, values) => {
      if (!err) {
        const subData = { ...values };
        delete subData.serviceType;
        await globalServices.addCustomer(subData);
        message.success('客户新增成功');
        dispatch({
          type: 'updateState',
          payload: {
            loading: false,
            customVisible: false,
          },
        });
        onSuccess();
      }
      // eslint
      return true;
    });
  };
  return (
    <Context.Provider value={{ state, dispatch }}>
      <Spin spinning={loading}>
        <Modal
          title="新增客户"
          visible={customVisible}
          width={800}
          styleName="m-addClient"
          onCancel={onCancel}
          onOk={save}
          okButtonProps={
            {
              // loading: !!loadings.$addCustomer,
            }
          }
          destroyOnClose
          maskClosable={false}
          getContainer={false}
          centered
        >
          {/* <Spin spinning={!!loadings.$deleteCode || !!loadings.$addCustomInit}> */}
          <div styleName="m-hint">
            <Iconfont code="&#xeaa1;" />
            温馨提示：您输入的客户未在系统中存档，如需新增请填写下方信息
          </div>
          <Form {...formItemLayout}>
            <Title title="客户基础信息" />
            <Row gutter={12}>
              <Col span={12}>
                <FormItem label="客户编码">
                  {getFieldDecorator('customerCode', {
                    initialValue: addCustomerCode,
                    validateTrigger: ['onBlur'],
                    rules: [
                      {
                        validator: async (rule, value, callback) => {
                          const data = await globalServices.checkCustomerCode({
                            customerCode: value,
                          });
                          if (data) {
                            callback('客户编码不可重复');
                          } else {
                            callback();
                          }
                        },
                      },
                    ],
                  })(<InputLimit placeholder="请输入客户编码" maxLength={30} autoComplete="off" />)}
                </FormItem>
              </Col>
              <Col span={12}>
                <CustomerNameInput
                  form={form}
                  getPopupContainer={(triggerNode) => triggerNode.parentNode}
                  defaultValue={customerName}
                />
              </Col>
            </Row>
            <Row gutter={12}>
              <Col span={12}>
                <FormItem label="统一社会信用代码">
                  {getFieldDecorator('unifiedSocialCreditCode', {
                    initialValue: '',
                    rules: [
                      {
                        pattern: /^[a-zA-Z0-9]{15,20}$/,
                        message: '格式有误，须为15~20位数字、字母',
                      },
                    ],
                  })(
                    <InputLimit
                      placeholder="请输入统一社会信用代码"
                      maxLength={30}
                      autoComplete="off"
                    />,
                  )}
                </FormItem>
              </Col>
              <Col span={12}>
                <FormItem label="纳税性质">
                  {getFieldDecorator('vatType', {
                    initialValue: undefined,
                  })(
                    <Select placeholder="请选择纳税性质">
                      {dictionary.taxType.list.map((item) => (
                        <Option value={item.value} key={item.value}>
                          {item.name}
                        </Option>
                      ))}
                    </Select>,
                  )}
                </FormItem>
              </Col>
            </Row>
            <Title title="服务信息" />
            <Row>
              <Col>
                {/* 服务类型组合 */}
                {getFieldDecorator('customerServiceRelationList', {
                  initialValue: [],
                })(<Input type="hidden" />)}
                <FormItem label="服务类型" className="form-item form-service" {...layout}>
                  {getFieldDecorator('serviceType', {
                    initialValue: [],
                    rules: [
                      {
                        required: true,
                        message: '服务类型不能为空',
                      },
                    ],
                  })(<ServiceType serviceTypeList={serviceTypeList} onCheckBox={onCheckBox} />)}
                </FormItem>
              </Col>
            </Row>
            {(servivceValue.includes(1) || servivceValue.includes(2)) && (
              <div>
                <Title title="派工信息" />
                <Row gutter={12}>
                  {servivceValue.includes(1) && (
                    <Col span={12}>
                      <Form.Item label="记账会计">
                        {getFieldDecorator('bookkeepingAccounting', {
                          initialValue: undefined,
                        })(
                          <Select
                            placeholder="请选择记账会计"
                            showArrow
                            showSearch
                            filterOption={(input, option) =>
                              option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                            // getPopupContainer={(triggerNode) => triggerNode.parentNode}
                          >
                            {bookeepers.map(({ staffId, realName }) => (
                              <Select.Option key={staffId} value={staffId}>
                                {realName}
                              </Select.Option>
                            ))}
                          </Select>,
                        )}
                      </Form.Item>
                    </Col>
                  )}
                  {servivceValue.includes(2) && (
                    <Col span={12}>
                      <FormItem label="开票员">
                        {getFieldDecorator('drawer', {
                          initialValue: [],
                        })(
                          <MultiTreeSelect
                            treeData={drawerList}
                            searchPlaceholder="请选择开票员"
                          />,
                        )}
                      </FormItem>
                    </Col>
                  )}
                </Row>
              </div>
            )}
          </Form>
        </Modal>
      </Spin>
    </Context.Provider>
  );
};
AddCustomModal.defaultProps = {
  // 弹窗是否显示
  visible: false,
  // 默认客户名称
  customerName: '',
  // 新增成功回调
  onSuccess() {},
};
export default Form.create()(AddCustomModal);
// export default connect(({ loadings, customVisible }) => ({
//   loadings,
//   customVisible,
// }))(Form.create()(AddCustomModal));
