import React, { useMemo, useCallback, useEffect } from 'react';
import { Form, Row, Col, Input, Select, TreeSelect, DatePicker } from 'antd';
import { connect } from 'nuomi';
import GenFormItem from '@components/form/GenFormItem';
import SuperSelect from '@components/select/SuperSelect';
// VirtualSelect是SuperSelect的最新版，怕直接替换有bug
import VirtualSelect from '@components/select/VirtualSelect';
import DeptTreeSelect from '@components/select/DeptTreeSelect';
import LimitInput from '@components/input/LimitInput';
import AreaCascader from '@components/AreaCascader';
import moment from 'moment';
import pubData from 'data';
import ShowConfirm from '@components/ShowConfirm';
import { formatSourceType, STATUS_ENUM, getContainerId } from '../../utils';
import AddCustomModal from './AddCustom';
import './style.less';

const { Option } = Select;
const userAuth = pubData.get('authority');
const MainContent = ({
  status,
  form,
  formValues,
  customerList,
  customerDataSource,
  staffList,
  productList,
  processList,
  spareProcessList,
  allProcessList,
  areaCodeMap,
  productMap,
  processMap,
  stepForm,
  stepValues,
  // hasOperator,
  dispatch,
  customerVisible,
  noMatchedCustomerName,
}) => {
  // 更新form
  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        form,
      },
    });
  }, [dispatch, form]);

  const treeData = useMemo(() => {
    return productList.map((item) => ({
      title: item.serviceName,
      value: item.serviceTypeId,
      selectable: false,
      disabled: !item.serviceProductVOList.length,
      children: item.serviceProductVOList.map((it) => ({
        title: it.serviceProductName,
        value: it.serviceProductId,
        key: it.serviceProductId,
        splicingLabel: `${item.serviceName}-${it.serviceProductName}`,
        selectable: true,
      })),
    }));
  }, [productList]);

  const setFieldAndGetProcess = useCallback(
    ({ serviceProcessId }, isGetProcessDetail) => {
      const oldProcessId = form.getFieldValue('serviceProcessId');
      form.setFieldsValue({
        serviceProcessId,
      });
      // isGetProcessDetail 为false代表没匹配成功，任务流程列表置空
      if (!isGetProcessDetail) {
        dispatch({
          type: 'updateState',
          payload: {
            stepValues: [],
          },
        });
      }
      // 如果使用流程还是同一个，不需要重置任务流程
      if (oldProcessId !== serviceProcessId && isGetProcessDetail) {
        dispatch({
          type: '$getProcessDetail',
          payload: {
            serviceProcessId,
            staffId: form.getFieldValue('executorId'),
          },
        });
      }
    },
    [dispatch, form],
  );

  const getProcessList = useCallback(
    (areaCode, productId) => {
      // 清空使用流程
      // form.setFieldsValue({
      //   serviceProcessId: undefined,
      // });
      // dispatch({
      //   type: 'updateState',
      //   payload: {
      //     stepValues: [],
      //   },
      // });
      stepForm.resetFields();
      // 1.无地区时，无服务内容
      if (!areaCode && !productId) return allProcessList;

      // 2.有服务内容
      if (productId) {
        let list = productMap[productId];
        //---------------------------------------------------
        // ③ 若没有全国，则u该项显示为“-”
        //---------------------------------------------------
        if (!list || !list.length) {
          setFieldAndGetProcess({
            serviceProcessName: '-',
            serviceProcessId: '-',
          });
          return [];
        }
        //---------------------------------------------------
        // ① 填写了所在地，若严格匹配上，则带出
        //---------------------------------------------------
        if (areaCode) {
          list = list.filter((it) => it.areaCode === areaCode);
        }
        if (list.length) {
          if (areaCode) {
            setFieldAndGetProcess(list[0], true);
          }
          return list;
        }
        //---------------------------------------------------
        // ② 若没有严格匹配上，则尝试使用全国模板
        //---------------------------------------------------
        const originList = productMap[productId];
        const spareList = originList.filter((it) => it.areaCode === '100000');
        if (spareList.length) {
          setFieldAndGetProcess(spareList[0], true);
        } else {
          //---------------------------------------------------
          // ③ 若没有全国，则该项显示为“-”
          //---------------------------------------------------
          setFieldAndGetProcess({
            serviceProcessName: '-',
            serviceProcessId: '-',
          });
        }
        return spareList;
      }
      // 3. 无服务内容、有地区
      const areaMatchList = areaCodeMap[areaCode] || [];
      const list = [...areaMatchList, ...spareProcessList];
      //---------------------------------------------------
      // ① 填写了所在地，若严格匹配上，则带出
      //---------------------------------------------------
      const strictMatchItem = list.find((it) => it.areaCode === areaCode);
      if (list.length === 1 && strictMatchItem) {
        const product = processMap[strictMatchItem.serviceProcessId];
        setFieldAndGetProcess(strictMatchItem, true);
        form.setFieldsValue({
          serviceProductId: product.serviceProductId,
        });
      }
      return list;
    },
    [
      allProcessList,
      areaCodeMap,
      form,
      processMap,
      productMap,
      setFieldAndGetProcess,
      spareProcessList,
      stepForm,
    ],
  );

  // 地区改变，需要+服务产品匹配适合的服务流程
  const handleAreaChange = useCallback(
    (area) => {
      const serviceProductId = form.getFieldValue('serviceProductId');
      dispatch({
        type: 'updateState',
        payload: {
          processList: getProcessList(area.areaCode, serviceProductId),
        },
      });
    },
    [dispatch, form, getProcessList],
  );

  // 服务产品改变，需要+地区匹配适合的服务流程
  const handleProductChange = useCallback(
    (value) => {
      const area = form.getFieldValue('area');
      dispatch({
        type: 'updateState',
        payload: {
          processList: getProcessList(area.areaCode, value),
        },
      });
    },
    [dispatch, form, getProcessList],
  );

  // 部门发生改变，业务员下拉列表要重新请求
  const handleDeptChange = useCallback(
    (value) => {
      form.setFieldsValue({
        executorId: undefined,
      });
      dispatch({
        type: '$getStaffList',
        payload: value,
      });
    },
    [dispatch, form],
  );

  // 员工发生改变，自动带出部门
  const handleStaffChange = useCallback(
    async (value) => {
      if (!value) return;
      // // 1. 需要带出业务部门
      await dispatch({
        type: '$getDeptListByStaffId',
        payload: value,
      });
      // 2. 如果存在流程，需要带出经办人
      stepValues.forEach((item) => {
        // const operator = stepForm.getFieldValue(index, 'operator');
        if (item.stepStatus > 1) {
          return;
        }
        stepForm.setFieldsValue({
          [`${item.serviceProcessStepId}.operator`]: value,
        });
      });
    },
    [dispatch, stepForm, stepValues],
  );

  // 服务流程改变，
  const handleProcessChange = useCallback(
    (value) => {
      // 流程删掉，下面任务流程也要清空
      if (!value) {
        dispatch({
          type: 'updateState',
          payload: {
            stepValues: [],
          },
        });
        stepForm.resetFields();
        return;
      }
      // 1.带出服务产品
      const product = processMap[value];
      form.setFieldsValue({
        serviceProductId: product.serviceProductId,
      });
      // 2.任务流程表单初始值改变。
      dispatch({
        type: '$getProcessDetail',
        payload: {
          serviceProcessId: value,
          staffId: form.getFieldValue('executorId'),
        },
      });
      // 3/4 步在effects处理
      // 3.如果存在经办人，流程需要带出经办人
      // 4.如果存在预计耗时，需要推算出完成时间
    },
    [dispatch, form, processMap, stepForm],
  );

  // 是否存在经办人, 存在的话，执行人不能为空
  const checkHasOperator = (rule, value, callback) => {
    // 因为initialValue是name值，可能是空字符串
    if (value || formValues.executorId) {
      callback(undefined);
      return;
    }
    const list = stepForm.getFieldsValue();
    const flag = list.some((it) => it.operator);
    callback(flag ? '请选择执行人' : undefined);
  };

  // 签约时间不能大于当前日期
  const disabledStartDate = (startValue) => {
    const currentDate = new Date();
    if (!startValue) {
      return false;
    }
    return startValue.valueOf() > currentDate.valueOf();
  };

  // 完成时间不能小于签约时间
  const disabledEndDate = (endValue) => {
    const appointmentTime = form.getFieldValue('appointmentTime');
    if (!endValue || !appointmentTime) {
      return false;
    }
    return endValue.valueOf() <= appointmentTime.valueOf();
  };

  // #162497 输入筛选
  const handleCustomerSearch = (value) => {
    const list = customerList.filter((item) => item.customerName.indexOf(value) > -1);
    dispatch({
      type: 'updateState',
      payload: {
        customerDataSource: list,
      },
    });
  };

  // #162497 选择下拉的一条客户
  const handleCustomerSelect = () => {
    // const current = customerList.find((item) => item.customerName === );
    //
  };

  // 查看状态下、无权限、更新时不能修改的 需要禁用
  const isEditable =
    status !== STATUS_ENUM.RETRIEVE && formValues.edit && formValues.taskStatus < 2;
  // 任务进行中了不可以更新
  const hasStepEnd = stepValues.some((it) => it.stepStatus === 2);
  const notUpdate = status === STATUS_ENUM.UPDATE && hasStepEnd;

  const getPopupContainer = () => {
    try {
      return document.querySelector(`#${getContainerId()}`) || document.body;
    } catch (error) {
      return document.body;
    }
  };

  // 使用流程初始值
  const initialProcess = useMemo(() => {
    const idx = processList.findIndex((it) => it.serviceProcessId === formValues.serviceProcessId);
    return idx > -1 ? formValues.serviceProcessId : formValues.serviceProcessName;
  }, [formValues.serviceProcessId, formValues.serviceProcessName, processList]);

  // 服务内容初始值
  const initialService = useMemo(() => {
    const idx = treeData.findIndex((node) => {
      const i = node.children.findIndex((child) => child.key === formValues.serviceProductId);
      return i > -1;
    });
    return idx > -1 ? formValues.serviceProductId : formValues.serviceProductName;
  }, [formValues.serviceProductId, formValues.serviceProductName, treeData]);

  // 任务 #173851
  const handleCustomerBlur = () => {
    const blurCustomerName = form.getFieldValue('customerName');
    // 尝试找到
    const currentCustomer = customerList.find((item) => item.customerName === blurCustomerName);
    if (!currentCustomer && blurCustomerName) {
      if (!userAuth[4]) {
        ShowConfirm({
          title: '您暂无权限新增客户，联系公司管理员！',
          width: 312,
          type: 'warning',
          okText: '知道了',
          onOk: () => {
            form.resetFields('customerName');
          },
        });
      } else {
        dispatch({
          type: 'updateState',
          payload: {
            customerVisible: true,
            noMatchedCustomerName: blurCustomerName,
          },
        });
      }
    }
  };

  // 新增成功回调
  const onAddCustomerSuccess = () => {
    // 重新获取客户列表
    dispatch({
      type: '$getCustomerList',
    });
    dispatch({
      type: 'updateState',
      payload: {
        customerVisible: false,
      },
    });
  };

  const onCancelCallback = () => {
    dispatch({
      type: 'updateState',
      payload: {
        customerVisible: false,
      },
    });
  };
  return (
    <>
      {customerVisible && (
        <AddCustomModal
          formRef={form}
          visible={customerVisible}
          customerName={noMatchedCustomerName}
          onSuccess={onAddCustomerSuccess}
          onCancelCallback={onCancelCallback}
        />
      )}
      <Form styleName="form">
        <div styleName="main-form">
          <Row gutter={35}>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="任务单号"
                name="taskNumber"
                rules={[{ required: true, message: '请填写单据编号' }]}
                initialValue={formValues.taskNumber}
              >
                <Input placeholder="请输入任务单号" autoComplete="off" disabled />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="源单类型"
                name="sourceType"
                initialValue={formatSourceType(formValues.sourceType)}
              >
                <Input autoComplete="off" disabled />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="源单据号"
                name="sourceNumber"
                initialValue={formValues.sourceNumber || '-'}
              >
                <Input autoComplete="off" disabled />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="紧急程度"
                name="emergencyLevel"
                initialValue={formValues.emergencyLevel}
              >
                <Select disabled={!isEditable} getPopupContainer={getPopupContainer}>
                  <Option value={0}>一般</Option>
                  <Option value={1}>加急</Option>
                </Select>
              </GenFormItem>
            </Col>
          </Row>
          <Row gutter={35}>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="客户名称"
                name="customerName"
                initialValue={formValues.customerName}
                rules={[{ required: true, message: '请选择客户名称' }]}
              >
                <VirtualSelect
                  // 此选项可以实现select框填写内容，没必要选择
                  mode={Select.SECRET_COMBOBOX_MODE_DO_NOT_USE}
                  dataSource={customerDataSource}
                  placeholder="请选择客户名称"
                  onSearch={handleCustomerSearch}
                  onSelect={handleCustomerSelect}
                  disabled={!isEditable || status === STATUS_ENUM.UPDATE}
                  onBlur={handleCustomerBlur}
                >
                  {customerDataSource.map((item) => (
                    <Option value={item.customerName} key={item.customerName}>
                      {item.customerName}
                    </Option>
                  ))}
                </VirtualSelect>
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="所在地区"
                name="area"
                initialValue={{
                  areaCode: formValues.area.areaCode,
                  areaName: formValues.area.areaName,
                }}
              >
                <AreaCascader
                  placement="bottom"
                  placeholder="请选择地区"
                  secondLevel
                  disabled={!isEditable || notUpdate}
                  overlayStyle={{ width: 400 }}
                  onChange={handleAreaChange}
                  allowClear
                  getPopupContainer={getPopupContainer}
                />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="服务内容"
                name="serviceProductId"
                initialValue={initialService}
                rules={[{ required: true, message: '请选择服务内容' }]}
              >
                <TreeSelect
                  disabled={!isEditable || status === STATUS_ENUM.UPDATE}
                  placeholder="请选择服务内容"
                  treeData={treeData}
                  onChange={handleProductChange}
                  dropdownStyle={{ maxHeight: 300 }}
                  getPopupContainer={getPopupContainer}
                  treeNodeLabelProp="splicingLabel"
                />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="使用流程"
                name="serviceProcessId"
                initialValue={initialProcess}
              >
                <Select
                  placeholder="请选择使用流程"
                  onChange={handleProcessChange}
                  disabled={!isEditable || notUpdate}
                  allowClear
                  getPopupContainer={getPopupContainer}
                  optionLabelProp="label"
                >
                  {processList.map((item) => (
                    <Option
                      value={item.serviceProcessId}
                      key={item.serviceProcessId}
                      title={`${item.serviceProcessName}-${item.serviceProductName}`}
                      label={item.serviceProcessName}
                    >
                      {`${item.serviceProcessName}-${item.serviceProductName}`}
                    </Option>
                  ))}
                </Select>
              </GenFormItem>
            </Col>
          </Row>
          <Row gutter={35}>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="签约时间"
                name="appointmentTime"
                initialValue={
                  formValues.appointmentTime ? moment(formValues.appointmentTime) : null
                }
              >
                <DatePicker
                  disabledDate={disabledStartDate}
                  disabled={!isEditable}
                  allowClear={false}
                  placeholder="请选择签约时间"
                  style={{ width: '100%' }}
                />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="完成时间"
                name="completeTime"
                initialValue={formValues.completeTime ? moment(formValues.completeTime) : null}
              >
                <DatePicker
                  disabledDate={disabledEndDate}
                  disabled={!isEditable}
                  allowClear={false}
                  placeholder="请选择签约时间"
                  style={{ width: '100%' }}
                />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="部门"
                name="executorDeptId"
                onChange={handleDeptChange}
                initialValue={formValues.executorDeptName || undefined}
              >
                <DeptTreeSelect
                  placeholder="请选择部门"
                  type="all"
                  allowClear
                  disabled={!isEditable}
                  getPopupContainer={getPopupContainer}
                />
              </GenFormItem>
            </Col>
            <Col span={6}>
              <GenFormItem
                form={form}
                label="执行人"
                name="executorId"
                initialValue={formValues.executorName}
                rules={[
                  // { required: hasOperator, message: '请选择执行人' },
                  { validator: checkHasOperator },
                ]}
              >
                <SuperSelect
                  placeholder="请选择执行人"
                  defaultActiveFirstOption={false}
                  allowClear
                  onChange={handleStaffChange}
                  disabled={!isEditable}
                  getPopupContainer={getPopupContainer}
                >
                  {staffList.map((item) => (
                    <Option value={item.staffId} key={item.staffId}>
                      {item.realName}
                    </Option>
                  ))}
                </SuperSelect>
              </GenFormItem>
            </Col>
          </Row>
          <GenFormItem
            form={form}
            label="任务说明"
            name="taskRemark"
            initialValue={formValues.taskRemark}
          >
            <LimitInput maxLength={200} disabled={!isEditable} />
          </GenFormItem>
        </div>
      </Form>
    </>
  );
};

export default connect(
  ({
    formValues,
    customerList,
    customerDataSource,
    staffList,
    productList,
    spareProcessList,
    allProcessList,
    processList,
    areaCodeMap,
    productMap,
    processMap,
    stepValues,
    stepForm,
    status,
    hasOperator,
    customerVisible,
    noMatchedCustomerName,
  }) => ({
    formValues,
    customerList,
    customerDataSource,
    spareProcessList,
    allProcessList,
    staffList,
    productList,
    processList,
    areaCodeMap,
    productMap,
    processMap,
    stepValues,
    stepForm,
    status,
    hasOperator,
    customerVisible,
    noMatchedCustomerName,
  }),
)(
  Form.create({
    onValuesChange(props) {
      props.dispatch({
        type: 'updateState',
        payload: {
          isEdited: true,
        },
      });
    },
  })(MainContent),
);
