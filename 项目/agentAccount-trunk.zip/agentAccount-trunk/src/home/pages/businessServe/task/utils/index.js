import pubData from 'data';
import { get } from '@utils';
import { router } from 'nuomi';

/**
 * 页面状态 1.创建 2.创建成功3.更新 4.查看
 */
export const STATUS_ENUM = {
  CREATE: 1,
  CREATED: 2,
  UPDATE: 3,
  RETRIEVE: 4,
};

const TYPE_MAP = {};
TYPE_MAP[(TYPE_MAP['-'] = 0)] = '-';
TYPE_MAP[(TYPE_MAP['合同生成'] = 1)] = '合同生成';
TYPE_MAP[(TYPE_MAP['应收单生成'] = 2)] = '应收单生成';

/**
 * @param {String/Number} key 后端传来的源单类型数字或表单取值的字符串
 */
export function formatSourceType(key) {
  return TYPE_MAP[key];
}

/**
 * 获取容器id，查看任务单、任务单同用一个页面，id要取不同，否则getPopupContainer会出问题
 */
export function getContainerId() {
  const { pathname } = router.location();
  const isViewPage = pathname === '/businessServe/viewTask';
  return !isViewPage ? 'business-task-container' : 'business-view-task-container';
}

/**
 * 初始的表单值
 */
export const initialForm = {
  taskNumber: '',
  sourceType: 0,
  sourceNumber: '-',
  emergencyLevel: 0,
  customerId: '',
  customerName: '',
  area: {},
  serviceProductId: undefined,
  serviceProductName: undefined,
  serviceProcessName: undefined,
  serviceProcessId: undefined,
  appointmentTime: Date.now(),
  completeTime: undefined,
  executorDeptId: undefined,
  executorDeptName: undefined,
  executorId: '',
  executorName: '',
  taskRemark: '',
  addTime: Date.now(),
  addUserName: get(pubData.get('userInfo'), 'realName'),
  updateTime: '',
  updateUserName: '',
  // 派工经办人权限
  assign: true,
  // 是否有编辑权限
  edit: true,
  // 是否可执行
  execute: true,
  // 任务状态
  taskStatus: -1,
};

// 生成stepForm需要的stepValues
export const genStepValues = (list, canAssign, defaultOperator) => {
  return list.map((item) => ({
    ...item,
    taskStepId: item.taskStepId,
    serviceProcessStepId: item.serviceProcessStepId,
    // stepOrder: item.stepOrder,
    stepName: item.stepName,
    stepStatus: item.stepStatus,
    operator: item.operator || defaultOperator,
    noAssign: !canAssign,
  }));
};

/**
 * 获取使用流程下拉列表
 * 参考 src/home/pages/businessServe/task/components/MainContent/index.jsx
 * 省去form赋值
 */
export const getProcessList = (
  areaCode,
  productId,
  allProcessList,
  spareProcessList,
  productMap,
  areaCodeMap,
) => {
  // 1.无地区时，无服务内容
  if (!areaCode && !productId) return allProcessList;
  // 2.有服务内容
  if (productId) {
    let list = productMap[productId] || [];
    if (!list.length) return []; // 一个都没有匹配上直接返回
    // 有地区时，试图找到匹配的
    if (areaCode) {
      list = list.filter((it) => it.areaCode === areaCode);
    }
    // 找到匹配啦
    if (list.length) {
      return list;
    }
    // 未找到，试图找全国的。
    const originList = productMap[productId];
    const spareList = originList.filter((it) => it.areaCode === '100000');
    return spareList;
  }
  // 3. 无服务内容
  const areaMatchList = areaCodeMap[areaCode] || [];
  return [...areaMatchList, ...spareProcessList];
};

export default {};
