export const defaultState = {
  // 新增客户弹窗
  customVisible: false,
  // 新增客户编码
  addCustomerCode: '',
  // 服务类型列表
  serviceTypeList: [],
  // 记账会计
  bookeepers: [],
  // 助理
  drawerList: [],
  // 页面加载
  loading: false,
};

// export const Context = createContext(null);
export function reducer(state, action) {
  const { type, payload } = action;
  switch (type) {
    case 'updateState':
      return { ...state, ...payload };
    default:
      throw new Error();
  }
}
