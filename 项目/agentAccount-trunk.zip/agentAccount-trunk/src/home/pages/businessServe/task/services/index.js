import { createServices } from '@utils';

export default createServices({
  add: 'instead/v2/customer/task/business/add.do::postJSON', // 新增
  update: 'instead/v2/customer/task/business/update.do::postJSON', // 更新
  getDetail: 'instead/v2/customer/task/business/get.do::post', // 查看
  getTaskNumber: 'instead/v2/customer/task/business/getTaskNumber::get', // 获取任务单编号
  getCompanyArea: 'instead/v2/customer/task/business/getCompanyArea::get', // 获取公司默认所在地区
  getCustomerList: 'instead/v2/customer/receipt/shouldReceiveBill/listCustomerBillNO::get', // 获取客户列表
  getProductList: 'instead/v2/user/basicSetting/service/process/listAll.do::post', // 获取服务产品/流程列表接口
  getProcessDetail: 'instead/v2/user/basicSetting/service/process/get.do::post', // 根据流程id获取流程步骤详细
  getOperateRecord: 'instead/v2/customer/task/business/operationLogList.do::post', // 任务操作日志
  recovery: 'instead/v2/customer/task/business/renew.do::postJSON', // 恢复任务
});
