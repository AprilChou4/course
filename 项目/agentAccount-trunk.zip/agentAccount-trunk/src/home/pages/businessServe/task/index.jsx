// 工商任务单

import React from 'react';
import NoAuthPage from '@components/NoAuthPage';
import pubData from 'data';
import { router } from 'nuomi';
import Layout from './components/Layout';
import effects from './effects';
import { STATUS_ENUM, initialForm } from './utils';

const userAuth = pubData.get('authority');
const getHasAuth = () => {
  const { pathname } = router.location();
  const isViewPage = pathname === '/businessServe/viewTask';
  // 有新增权限 或者 列表查看权限
  const hasAuth = isViewPage ? userAuth['601'] : userAuth['602'];
  return hasAuth;
};

export default {
  id: 'businesst-task',
  state: {
    // 页面状态
    status: STATUS_ENUM.CREATE,
    // 主体表单
    form: {},
    // 流程步骤表单
    stepForm: {},
    // 是否表单被编辑，
    isEdited: false,
    // 任务流程是否存在经办人，用于限制执行人是否必填
    hasOperator: false,
    // 主体表单值
    formValues: initialForm,
    // 任务流程表单值
    stepValues: [],
    // 任务流程表格值
    dataSource: [],
    // 操作记录数据
    operateHistory: [],
    // 服务产品列表
    productList: [],
    // 下拉服务流程列表
    processList: [],
    // 所有的流程列表
    allProcessList: [],
    // 全国备用的流程列表
    spareProcessList: [],
    // 执行人列表
    staffList: [],
    // 经办人列表
    operatorList: [],
    // 用户总的列表
    customerList: [],
    // 筛选后用于autocomplete的数据
    customerDataSource: [],
    // 可以通过服务产品id找到对应流程列表
    productMap: {},
    // 可以通过服务产品id找到名字 , 其实可以跟productMap公用一个，找机会改掉
    productItemMap: {},
    // 可以通过流程id找到名字, 其实可以跟processMap公用一个，找机会改掉
    processItemMap: {},
    // 可以通过流程id找到对应父级服务产品
    processMap: {},
    // 可以通过地区code找到所适合的服务流程
    areaCodeMap: {},
    // 工商任务派工弹窗是否显示
    taskAssignVisible: false,
    // 单个派工详情
    taskAssignData: {},
    // 是否单个派工
    isSingleAssign: false,
    // 兼容列表的派工
    selectedRowKeys: [],
    selectedRows: [],
    // 操作记录
    operateRecordList: [],
    // 新增客户弹窗是否显示
    customerVisible: false,
    // 用于没有匹配到客户名称的客户新增客户
    noMatchedCustomerName: '',
  },
  effects,
  render() {
    return getHasAuth() ? <Layout /> : <NoAuthPage />;
  },
  onChange() {
    if (!getHasAuth()) return;
    // userAuth[601] userAuth[602]
    // 路由切换更新所有列表数据
    this.store.dispatch({
      type: '$initList',
    });
  },
  onInit() {
    if (!getHasAuth()) return;
    this.store.dispatch({
      type: '$initData',
    });
  },
};
