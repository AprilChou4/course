import React from 'react';
import { connect } from 'nuomi';
import TaskAssignModal from '@pages/businessServe/businessList/components/TaskAssign/TaskAssignModal';
import MainContent from '../MainContent';
import StepForm from '../StepForm';
import StepTable from '../StepTable';
import OperateRecord from '../OperateRecord';
import { STATUS_ENUM, getContainerId } from '../../utils';

const Content = ({ status, operatorList, taskAssignVisible }) => {
  const helper = (list) => {
    return list.map((item) => {
      if (item.isParent) {
        return {
          title: item.name,
          value: item.value,
          key: item.value,
          code: item.code,
          selectable: false,
          disabled: !item.children.length,
          children: helper(item.children),
        };
      }
      return {
        title: item.name,
        value: item.value,
        key: item.value,
        code: item.code,
        selectable: true,
      };
    });
  };
  return (
    <div style={{ height: '100%', overflow: 'auto' }} id={getContainerId()}>
      <div>
        <MainContent />
        <div style={{ paddingBottom: 1, overflow: 'hidden' }}>
          <div className="title-mark" style={{ display: 'inline-block', float: 'left' }}>
            任务流程
          </div>
          <OperateRecord />
        </div>
      </div>
      <div>{status !== STATUS_ENUM.RETRIEVE ? <StepForm /> : <StepTable />}</div>
      {taskAssignVisible && <TaskAssignModal executorList={helper(operatorList)} type={2} />}
    </div>
  );
};

export default connect(({ status, operatorList, taskAssignVisible }) => ({
  status,
  operatorList,
  taskAssignVisible,
}))(Content);
