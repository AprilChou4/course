/**
 * 查看/编辑任务单
 */
import { nuomi } from 'nuomi';
import task from '../task';

export default nuomi.extend(task, {
  id: 'service_viewTask',
  state: {},
});
