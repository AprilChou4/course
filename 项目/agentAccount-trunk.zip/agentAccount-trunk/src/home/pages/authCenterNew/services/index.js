import { createServices } from '@utils';

export default createServices({
  queryAuthority: 'instead/v2/user/authority/query::post', // 权限中心-权限树查询
  transferManage: 'instead/v2/user/staff/transferManage::post', // 移交超级管理员
  getAllAuth: 'instead/v2/user/authority/list', //  获取所有权限值
});
