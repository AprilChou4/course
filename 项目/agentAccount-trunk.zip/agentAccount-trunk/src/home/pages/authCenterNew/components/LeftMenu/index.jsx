// 左侧公共菜单
import React, { useEffect, useState } from 'react';
import { Menu } from 'antd';
import './style.less';

const LeftMenu = ({
  menuList,
  value,
  name,
  defaultName,
  selectedKey,
  onClickMenuItem,
  onClickEdit,
  editAuth,
  onClickDelete,
  deleteAuth,
}) => {
  // 菜单第一个id
  const [firstSelectedKeys, setFirstSelectedKeys] = useState('');
  useEffect(() => {
    menuList[0] && setFirstSelectedKeys(menuList[0][value]);
  }, [menuList, value]);

  // 点击 MenuItem
  const clickMenuItem = (data) => {
    onClickMenuItem(data);
  };

  // 点击 编辑
  const clickEdit = (e, item) => {
    e.stopPropagation();
    onClickEdit(item);
  };

  // 点击 删除
  const clickDelete = (e, item) => {
    e.stopPropagation();
    onClickDelete(item);
  };

  return (
    <Menu
      style={{ width: 138 }}
      selectedKeys={selectedKey === '' ? [] : [String(selectedKey || firstSelectedKeys)]}
      inlineIndent={16}
      styleName="m-menu"
      mode="inline"
      theme="light"
      onClick={clickMenuItem}
    >
      {menuList.map((item) => (
        <Menu.Item key={item[value]} menudata={item}>
          <span className="f-ellipsis" styleName="m-name">
            {/* {item.authorities} */}
            {item[name]}
          </span>
          {!item[defaultName] && (
            <span styleName="m-btn">
              {editAuth && (
                <i className="iconfont" onClick={(e) => clickEdit(e, item)}>
                  &#xea0a;
                </i>
              )}
              {deleteAuth && (
                <i className="iconfont" onClick={(e) => clickDelete(e, item)}>
                  &#xec49;
                </i>
              )}
            </span>
          )}
        </Menu.Item>
      ))}
    </Menu>
  );
};

LeftMenu.defaultProps = {
  // 菜单列表
  menuList: [],
  // 角色id字段
  value: '',
  // 角色名称字段
  name: '',
  // 是否默认字段名称
  defaultName: '',
  // 选中菜单key值
  selectedKey: '',
  // 点击菜单回调
  onClickMenuItem() {},
  // 点击编辑回调
  onClickEdit() {},
  // 编辑权限
  editAuth: true,
  // 点击删除回调
  onClickDelete() {},
  // 删除权限
  deleteAuth: true,
};

export default LeftMenu;
