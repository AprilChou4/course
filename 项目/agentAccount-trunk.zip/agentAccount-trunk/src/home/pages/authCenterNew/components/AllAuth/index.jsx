// 权限表格组件
import React from 'react';
import { Spin } from 'antd';
import Title from '@components/Title';
import AuthTable from '../AuthTable';
import AuthMenu from '../AuthMenu';
import './style.less';

const AllAuth = ({ allAuthList, defaultCheckedData, loading, nuomiName, authValue }) => {
  return (
    <>
      <Spin spinning={loading}>
        <div styleName="m-authWrap">
          {allAuthList &&
            allAuthList.map(({ typeName, parentMenuList, authorityType }) => {
              return (
                <div key={authorityType}>
                  <Title title={typeName} id={`${nuomiName}${authorityType}`} />
                  {parentMenuList &&
                    parentMenuList.map((val, key) => {
                      return (
                        <AuthTable
                          /* eslint-disable-next-line */
                          key={key}
                          nuomiName={nuomiName}
                          authValue={authValue}
                          type={`${authorityType}${key}`}
                          authData={val}
                          defaultCheckedList={defaultCheckedData[`${authorityType}${key}`]}
                        />
                      );
                    })}
                </div>
              );
            })}
        </div>
        <div styleName="m-rightMenu">
          <AuthMenu
            menuList={allAuthList}
            name="typeName"
            keyName="authorityType"
            nuomiName={nuomiName}
          />
        </div>
      </Spin>
    </>
  );
};
AllAuth.defaultProps = {
  // 权限树列表
  allAuthList: [],
  // 默认选中的权限值列表
  defaultCheckedData: {},
  // 加载
  loading: false,
  // nuomi名称
  nuomiName: '',
  // 编辑权限值
  authValue: true,
};
export default AllAuth;
