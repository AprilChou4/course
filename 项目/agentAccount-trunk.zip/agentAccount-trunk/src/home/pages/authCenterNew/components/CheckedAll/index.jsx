// 权限右侧公共导航菜单
import React, { useEffect, useState, useMemo } from 'react';
import { Checkbox } from 'antd';
import { connect } from 'nuomi';

import './style.less';

const CheckedAll = ({
  dispatch,
  nuomiName,
  style,
  allAuthValueData,
  noAuthValueData,
  allAuthValueList,
  defaultSelecedAuthData,
  ...rest
}) => {
  // 获取选中的权限列表
  const checkedAuthList = useMemo(() => {
    let arr = [];
    Object.keys(defaultSelecedAuthData).forEach((key) => {
      arr = [...arr, ...defaultSelecedAuthData[key]];
    });
    return arr;
  }, [defaultSelecedAuthData]);

  // 全选效果，只负责样式控制
  const [indeterminate, setIndeterminate] = useState(false);
  const [isChecked, setChecked] = useState(false);

  // 设置全选复选框状态
  useEffect(() => {
    if (checkedAuthList.length === allAuthValueList.length) {
      setChecked(true);
      setIndeterminate(false);
    } else {
      setChecked(false);
      setIndeterminate(
        !!checkedAuthList.length && checkedAuthList.length < allAuthValueList.length,
      );
    }
  }, [checkedAuthList, allAuthValueList]);

  // 操作
  const changeBox = (e) => {
    const { checked } = e.target;
    setChecked(checked);
    setIndeterminate(checked);
    dispatch({
      type: 'authCenterNew/$checkAllAuth',
      payload: {
        checked,
        allAuthValueData,
        noAuthValueData,
        nuomiName,
        allAuthValueList,
      },
    });
  };
  return (
    <Checkbox
      styleName="m-checkAll"
      onChange={changeBox}
      style={style}
      {...rest}
      indeterminate={indeterminate}
      checked={isChecked}
    >
      全选所有功能
    </Checkbox>
  );
};

CheckedAll.defaultProps = {
  // // 所有权限值
  // allAuthList: [],
  // 所有权限值的列表,用于全选
  allAuthValueList: [],
  // 由列表处理后的对象，用于全选
  allAuthValueData: {},
  noAuthValueData: {},
  // nuomi组件名称
  nuomiName: '',
  defaultSelecedAuthData: {},
};

export default connect()(CheckedAll);
