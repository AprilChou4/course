// 布局-管理者
import React, { useMemo, useCallback } from 'react';
import AntdTabs from '@components/AntdTabs';
import { connect, Nuomi } from 'nuomi';
import pubData from 'data';
import postMessageRouter from '@utils/postMessage';
import TransferAdmin from '../TransferAdmin';
import functionRole from '../../modules/functionRole';
import jobRole from '../../modules/jobRole';
import staffAuth from '../../modules/staffAuth';

import './style.less';

const userAuth = pubData.get('authority');

const Main = ({ dispatch, mainTabActiveKey }) => {
  // tabPane配置
  const tabPanes = useMemo(
    () =>
      [
        {
          key: '1',
          name: '岗位角色',
          hidden: !userAuth[48],
          content: <Nuomi {...jobRole} />,
        },
        {
          key: '2',
          name: '职能角色',
          hidden: !userAuth[48],
          content: <Nuomi {...functionRole} />,
        },
        {
          key: '3',
          name: '职员权限',
          hidden: !userAuth[48],
          content: <Nuomi {...staffAuth} />,
        },
      ].filter(({ hidden }) => !hidden),
    [],
  );

  // 切换tab
  const changeTabs = useCallback(
    (activeKey) => {
      // const url = ['jobRoleNuomiNew', 'functionRoleNuomi', 'staffAuthNuomiNew'][
      //   Number(mainTabActiveKey) - 1
      // ];
      dispatch({
        type: 'updateState',
        payload: {
          mainTabActiveKey: activeKey,
        },
      });
      // dispatch({
      //   type: `${url}/initData`,
      // });

      postMessageRouter({
        type: 'agentAccount/routerLocation',
        payload: {
          url: `/authCenterNew`,
          query: {
            tab: activeKey,
          },
        },
      });
    },
    [dispatch, mainTabActiveKey],
  );
  return (
    <AntdTabs
      tabPanes={tabPanes}
      activeKey={mainTabActiveKey}
      onChange={changeTabs}
      tabBarExtraContent={<TransferAdmin />}
    />
  );
};

export default connect(({ mainTabActiveKey }) => ({
  mainTabActiveKey,
}))(Main);
