/**
 * 将权限'1#2#3' 转化为 data:{ 1:['1','2'],2:['3']}
 * @param {*} authorities 权限值 '1#2#3'
 * @param {*} allAuthList 权限树
 */
const getAuthData = (authorities, allAuthList) => {
  // 全选值
  const allAuthData = {};
  // 全未选值
  const noAuthData = {};
  const allCheckList = authorities ? authorities.split('#') : [];
  allAuthList &&
    allAuthList.forEach(({ parentMenuList, authorityType }) => {
      parentMenuList.forEach((val, key) => {
        let currCheckedList = [];
        let currTableAuthList = [];
        val.authorityList.forEach((item) => {
          currTableAuthList = [...currTableAuthList, String(item.authorityId)];
        });
        val.childrenMenuList.forEach((item) => {
          currTableAuthList = [
            ...currTableAuthList,
            ...item.authorityList.map((v) => String(v.authorityId)),
          ];
        });
        currTableAuthList.forEach((item) => {
          if (allCheckList.includes(item)) {
            currCheckedList = [...currCheckedList, item];
            allAuthData[`${authorityType}${key}`] = currCheckedList;
            noAuthData[`${authorityType}${key}`] = [];
          }
        });
      });
    });
  return {
    allAuthData,
    noAuthData,
  };
};
export default getAuthData;
