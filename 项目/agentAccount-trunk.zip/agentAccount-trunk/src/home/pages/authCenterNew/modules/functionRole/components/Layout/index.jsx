import React from 'react';
import { AuthMain } from '@pages/authCenterNew/components';
import SiderMenu from '../SideMenu';
import TopContent from '../TopContent'; // 头部
import AddFuncRoleBtn from '../AddFuncRoleBtn';
import FunctionAuth from '../FunctionAuth';
import BottomBtn from '../BottomBtn';
import './style.less';

const Main = () => {
  return (
    <AuthMain
      leftSider={
        <div styleName="m-leftSider">
          <AddFuncRoleBtn />
          <SiderMenu />
        </div>
      }
      rightSider={{
        topContent: <TopContent />,
        mainContent: <FunctionAuth />,
        bottomContent: <BottomBtn />,
      }}
    />
  );
};
export default Main;
