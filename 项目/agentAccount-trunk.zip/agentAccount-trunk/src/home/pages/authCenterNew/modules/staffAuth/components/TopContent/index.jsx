// 头部
import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import { Form, Select } from 'antd';
import GenFormItem from '@components/form/GenFormItem';
import { CheckedAll } from '@pages/authCenterNew/components';
import './style.less';

const { Option } = Select;
const TopContent = ({
  dispatch,
  staffAuthorityType,
  defaultSelecedAuthData,
  allAuthValueData,
  noAuthValueData,
  allAuthValueList,
  form,
}) => {
  const { setFieldsValue } = form;
  // 重置数据权限
  useEffect(() => {
    setFieldsValue({ dataAuthorityType: staffAuthorityType });
  }, [staffAuthorityType, setFieldsValue]);

  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        form,
      },
    });
  }, [dispatch, form]);

  return (
    <div styleName="m-staffTop">
      <Form layout="inline">
        <GenFormItem
          form={form}
          label="数据权限"
          name="dataAuthorityType"
          initialValue={staffAuthorityType || 3}
          rules={[
            {
              required: true,
              message: '职能名称不能为空',
            },
          ]}
        >
          <Select style={{ width: 300 }}>
            <Option value={3}>本人</Option>
            <Option value={2}>部门</Option>
            <Option value={1}>全公司</Option>
          </Select>
        </GenFormItem>
        <CheckedAll
          allAuthValueData={allAuthValueData}
          noAuthValueData={noAuthValueData}
          allAuthValueList={allAuthValueList}
          nuomiName="staffAuthNuomiNew"
          defaultSelecedAuthData={defaultSelecedAuthData}
          style={{ lineHeight: '32px', marginLeft: 20 }}
        />
      </Form>
    </div>
  );
};
const TopContentForm = Form.create()(TopContent);
export default connect(
  ({
    allAuthValueList,
    allAuthValueData,
    noAuthValueData,
    staffAuthorityType,
    defaultSelecedAuthData,
  }) => ({
    staffAuthorityType,
    defaultSelecedAuthData,
    allAuthValueList,
    allAuthValueData,
    noAuthValueData,
  }),
)(TopContentForm);
