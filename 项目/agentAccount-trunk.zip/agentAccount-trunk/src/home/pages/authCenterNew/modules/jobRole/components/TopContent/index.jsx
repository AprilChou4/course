// 头部
import React, { useState, useEffect } from 'react';
import { connect } from 'nuomi';
import { Form, Input, Select, Popover, Button } from 'antd';
import GenFormItem from '@components/form/GenFormItem';
import { CheckedAll } from '@pages/authCenterNew/components';
import getAuthData from '@pages/authCenterNew/utils';
import { useDebouncedCallback } from 'use-debounce';
import services from '../../services';
import Style from './style.less';

const { Option } = Select;
const optionStyle = {
  width: 300,
};
const TopContent = ({
  dispatch,
  allAuthList,
  allAuthValueList,
  allAuthValueData,
  noAuthValueData,
  editStatus,
  selectedMenu,
  roleList,
  defaultSelecedAuthData,
  form,
}) => {
  const { roleName, authorities } = selectedMenu || {};
  // 关闭弹窗是否显示
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        form,
      },
    });
  }, [dispatch, editStatus, form]);

  // 改变复制下拉框
  const changeCopy = (value, option) => {
    const checkedAuth = value === -1 ? authorities : option.props?.auth;
    const { allAuthData } = getAuthData(checkedAuth, allAuthList);
    dispatch({
      type: 'updateState',
      payload: {
        defaultSelecedAuthData: allAuthData || {},
      },
    });
  };
  // 关闭帮助弹窗
  const closeHelp = () => {
    setVisible(false);
  };

  const handleVisibleChange = (visibles) => {
    setVisible(visibles);
  };

  // 加防抖
  const [checkSameNameValidator] = useDebouncedCallback(async (rule, value, callback) => {
    await services.checkRoleSameName(
      {
        roleName: value,
      },
      {
        status: {
          300: (res) => {
            callback(res.message);
          },
        },
      },
    );
    callback();
  });

  return (
    <div styleName="m-jobRoleTop">
      {editStatus === 0 && (
        <div styleName="m-showTitle">
          <h3>{roleName}权限明细</h3>
          <CheckedAll
            allAuthValueData={allAuthValueData}
            noAuthValueData={noAuthValueData}
            allAuthValueList={allAuthValueList}
            nuomiName="jobRoleNuomiNew"
            defaultSelecedAuthData={defaultSelecedAuthData}
          />
        </div>
      )}

      {editStatus === 1 && (
        <Form layout="inline" styleName="m-form">
          <GenFormItem
            form={form}
            label="岗位名称"
            name="roleName"
            initialValue={roleName || ''}
            rules={[
              {
                required: true,
                message: '名称不能为空',
              },
              {
                validator: checkSameNameValidator,
              },
            ]}
          >
            <Input
              placeholder="最多20个字，不能为空"
              autoComplete="off"
              style={optionStyle}
              maxLength={20}
            />
          </GenFormItem>
          <GenFormItem form={form} label="复制权限" name="copyAuth" initialValue={-1}>
            <Select style={optionStyle} onChange={changeCopy}>
              <Option value={-1} key={1}>
                不复制
              </Option>
              {roleList &&
                roleList.map((item, index) => (
                  <Option value={index} auth={item.authorities} key={item.roleId}>
                    {item.roleName}
                  </Option>
                ))}
            </Select>
          </GenFormItem>

          <Popover
            overlayClassName={Style['m-help']}
            content={
              <div styleName="m-helpcont">
                <h3>复制权限指：复制已有岗位的权限。</h3>
                <div>操作说明：</div>
                <div>
                  默认“不复制”，即权限为空，您可手动勾选权限；
                  当您选择某一个岗位，则系统自动将该岗位的权 限勾选上。
                </div>
                <div styleName="m-btn">
                  <Button type="primary" onClick={closeHelp}>
                    关闭
                  </Button>
                </div>
              </div>
            }
            title="复制权限说明"
            trigger="click"
            placement="bottomRight"
            visible={visible}
            onVisibleChange={handleVisibleChange}
          >
            <a className="iconfont">&#xeb10;</a>
          </Popover>
          <CheckedAll
            allAuthValueData={allAuthValueData}
            noAuthValueData={noAuthValueData}
            allAuthValueList={allAuthValueList}
            nuomiName="jobRoleNuomiNew"
            defaultSelecedAuthData={defaultSelecedAuthData}
            style={{ lineHeight: '32px', marginLeft: 20 }}
          />
        </Form>
      )}
    </div>
  );
};
const TopContentForm = Form.create()(TopContent);
export default connect(
  ({
    allAuthList,
    allAuthValueList,
    allAuthValueData,
    noAuthValueData,
    selectedMenu,
    editStatus,
    roleList,
    defaultSelecedAuthData,
  }) => ({
    allAuthList,
    allAuthValueList,
    allAuthValueData,
    noAuthValueData,
    selectedMenu,
    editStatus,
    roleList,
    defaultSelecedAuthData,
  }),
)(TopContentForm);
