// 职员权限>员工树
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { Tree } from 'antd';
import './style.less';

const { TreeNode } = Tree;

const StaffTree = ({ expandedKeys, dispatch, staffTree, selectedKey }) => {
  // 选择树
  const onSelect = (keys, e) => {
    const { props } = e.node || {};
    const { eventKey } = props || {};
    dispatch({
      type: '$getStaffAuthority',
      payload: {
        staffId: eventKey,
      },
    });
  };
  const onExpand = (expandedKey) => {
    dispatch({
      type: 'updateState',
      payload: {
        expandedKeys: expandedKey,
      },
    });
  };

  // 遍历树状结构
  const loop = useCallback(
    (data) =>
      data.map((item) => {
        if (item.children && item.children.length) {
          return (
            <TreeNode
              key={item.value}
              name={item.title}
              title={<span title={item.title}>{item.title}</span>}
              selectable={item.selectable}
              disabled={item.disabled}
            >
              {loop(item.children)}
            </TreeNode>
          );
        }
        return (
          <TreeNode
            key={item.value}
            name={item.title}
            selectable={item.selectable}
            disabled={item.disabled}
            title={<span title={item.title}>{item.title}</span>}
          />
        );
      }),
    [],
  );

  return (
    <Tree
      expandedKeys={expandedKeys}
      onExpand={onExpand}
      selectedKeys={selectedKey}
      treeNodeLabelProp="value"
      onSelect={onSelect}
      styleName="m-tree"
    >
      {loop(staffTree)}
    </Tree>
  );
};

export default connect(({ staffTree, selectedKey, expandedKeys, allAuthList }) => ({
  staffTree,
  selectedKey,
  expandedKeys,
  allAuthList,
}))(StaffTree);
