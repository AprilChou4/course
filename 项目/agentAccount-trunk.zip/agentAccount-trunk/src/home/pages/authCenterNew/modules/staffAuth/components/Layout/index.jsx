import React from 'react';
import { connect } from 'nuomi';
import { AuthMain, AllAuth } from '@pages/authCenterNew/components';
import pubData from 'data';
import StaffTree from '../StaffTree';
import TopContent from '../TopContent';
import BottomBtn from '../BottomBtn';

const Main = ({ selectedKey, allAuthList, defaultSelecedAuthData }) => {
  const userAuth = pubData.get('authority');
  // 超级管理员不能修改职员权限 有权限且不是超级管理员
  const userInfoStaffId = pubData.get('userInfo_staffId'); // 当前用户员工ID
  const isCurrManage = userInfoStaffId === selectedKey?.[0];
  return (
    <AuthMain
      leftSider={<StaffTree />}
      rightSider={{
        topContent: <TopContent />,
        mainContent: (
          <AllAuth
            allAuthList={allAuthList}
            defaultCheckedData={defaultSelecedAuthData}
            nuomiName="staffAuthNuomiNew"
            authValue={!!userAuth[490] && !isCurrManage}
          />
        ),
        bottomContent: <BottomBtn />,
      }}
    />
  );
};

// authCenter为上层存储state
export default connect(
  ({ selectedKey, defaultSelecedAuthData, allAuthList }, { authCenterNew }) => ({
    selectedKey,
    staffTree: authCenterNew.staffTree,
    allAuthList,
    defaultSelecedAuthData,
  }),
)(Main);
