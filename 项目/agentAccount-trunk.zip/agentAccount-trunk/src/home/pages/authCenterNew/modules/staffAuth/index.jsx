/**
 * 权限中心-员工权限
 */
import React from 'react';
import Main from './components/Layout';
import effects from './effects';

export default {
  id: 'staffAuthNuomiNew',
  state: {
    // 选中的树节点
    selectedKey: [],
    // 展开的树节点
    expandedKeys: [],
    // 默认选中权限值object={[key:authorityType+key]:['1','2']}
    defaultSelecedAuthData: {},
    // 默认员工数据权限 员工职能数据权限类型（1全公司，2部门，3本人）
    staffAuthorityType: 3,
    // 员工树
    staffTree: [],
    // 所有权限值的列表,用于全选
    allAuthValueList: [],
    // 由列表处理后的对象，用于全选
    allAuthValueData: {},
    // 权限列表
    allAuthList: [],
  },
  effects,
  render() {
    return <Main />;
  },
  onInit() {
    // this.store.dispatch({
    //   type: 'initData',
    // });
  },
};
