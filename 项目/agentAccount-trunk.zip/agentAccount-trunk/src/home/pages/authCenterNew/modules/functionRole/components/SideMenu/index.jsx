// 职能角色侧边菜单
import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import ShowConfirm from '@components/ShowConfirm';
import { LeftMenu } from '@/home/pages/authCenterNew/components';
import { message } from 'antd';
import pubData from 'data';

const SideMenu = ({ dispatch, functionRoleList, selectedMenu }) => {
  const userAuth = pubData.get('authority');
  // 点击菜单回调
  const clickItem = ({ item }) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedMenu: item.props?.menudata,
      },
    });
  };
  // 点击编辑回调
  const clickEdit = (item) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedMenu: item,
        editStatus: 1,
      },
    });
  };

  // 点击删除回调
  const clickDelete = async (item) => {
    const { empFunctionId, isSystem, empFunctionName } = item;
    if (isSystem) {
      message.warning('系统内置职能角色不可删除');
      return false;
    }
    const data = await dispatch({
      type: 'checkFunctionUsed',
      payload: {
        empFunctionId,
      },
    });
    // 已被使用，提示：
    if (data) {
      ShowConfirm({
        width: 340,
        title: '该职能已被已使用，删除后拥有该职能的员工将调整为普通员工，确定删除？',
        onOk: () => {
          dispatch({
            type: 'deleteFunction',
            payload: {
              empFunctionId,
            },
          });
        },
      });
      return false;
    }

    // 未被使用，则提示：
    ShowConfirm({
      width: 248,
      title: `确定要删除“${empFunctionName}”吗？`,
      onOk: () => {
        dispatch({
          type: 'deleteFunction',
          payload: {
            empFunctionId,
          },
        });
      },
    });
    // eslint
    return true;
  };

  // 获取首次选中的menuItem
  useEffect(() => {
    let selectedItem = functionRoleList[0] || {};
    if (selectedMenu.empFunctionId) {
      [selectedItem] = functionRoleList.filter(
        (item) => item.empFunctionId === selectedMenu.empFunctionId,
      );
    }
    dispatch({
      type: 'updateState',
      payload: {
        selectedMenu: {
          ...selectedItem,
        },
      },
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, functionRoleList]);

  return (
    <LeftMenu
      menuList={functionRoleList}
      value="empFunctionId"
      name="empFunctionName"
      defaultName="isSystem"
      defaultAuthName="dataAuthorityType"
      selectedKey={selectedMenu.empFunctionId}
      onClickMenuItem={clickItem}
      onClickEdit={clickEdit}
      editAuth={!!userAuth[50]}
      onClickDelete={clickDelete}
      deleteAuth={!!userAuth[50]}
    />
  );
};
export default connect(({ functionRoleList, selectedMenu }) => ({
  functionRoleList,
  selectedMenu,
}))(SideMenu);
