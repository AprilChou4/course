import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import pubData from 'data';

const BottomBtn = ({ dispatch, form, selectedKey, defaultSelecedAuthData, dataAuthorityType }) => {
  const userAuth = pubData.get('authority');
  // const [staffId] = selectedKey;
  const staffId = selectedKey?.[0];
  // 超级管理员不能修改职员权限 有权限且不是超级管理员
  const userInfoStaffId = pubData.get('userInfo_staffId'); // 当前用户员工ID
  const isCurrManage = userInfoStaffId === staffId;

  // 取消
  const onCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 0,
      },
    });
  };
  // 保存
  const save = () => {
    form.validateFields((err, values) => {
      if (err) {
        return false;
      }
      let authList = [];
      Object.keys(defaultSelecedAuthData).forEach((key) => {
        authList = [...authList, ...defaultSelecedAuthData[key]];
      });
      dispatch({
        type: '$updateStaffAuthority',
        payload: {
          staffId,
          dataAuthorityType,
          authorities: authList.join('#'),
          ...values,
        },
      });
      // eslint
      return true;
    });
  };

  return (
    !!userAuth[490] &&
    !isCurrManage && (
      <>
        <Button style={{ marginRight: 12 }} onClick={onCancel}>
          取消
        </Button>
        <Button type="primary" onClick={save}>
          保存
        </Button>
      </>
    )
  );
};

export default connect(
  ({ form, editStatus, selectedKey, defaultSelecedAuthData, dataAuthorityType }) => ({
    form,
    editStatus,
    selectedKey,
    defaultSelecedAuthData,
    dataAuthorityType,
  }),
)(BottomBtn);
