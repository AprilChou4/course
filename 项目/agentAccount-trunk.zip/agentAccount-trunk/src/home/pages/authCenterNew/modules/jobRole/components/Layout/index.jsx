import React from 'react';
import { connect } from 'nuomi';
import { AuthMain, AllAuth } from '@pages/authCenterNew/components';
import pubData from 'data';
import AddJobRoleBtn from '../AddJobRoleBtn';
import TopContent from '../TopContent';
import SiderMenu from '../SideMenu';
import BottomBtn from '../BottomBtn';
import './style.less';

const Main = ({ allAuthList, defaultSelecedAuthData }) => {
  const userAuth = pubData.get('authority');
  return (
    <AuthMain
      leftSider={
        <div styleName="m-leftSider">
          <AddJobRoleBtn />
          <SiderMenu />
        </div>
      }
      rightSider={{
        topContent: <TopContent />,
        mainContent: (
          <AllAuth
            allAuthList={allAuthList}
            defaultCheckedData={defaultSelecedAuthData}
            nuomiName="jobRoleNuomiNew"
            authValue={!!userAuth[49]}
          />
        ),
        bottomContent: <BottomBtn />,
      }}
    />
  );
};

export default connect(
  ({ editStatus, defaultSelecedAuthData, allAuthList }, { authCenterNew }) => ({
    editStatus,
    allAuthList,
    defaultSelecedAuthData,
  }),
)(Main);
