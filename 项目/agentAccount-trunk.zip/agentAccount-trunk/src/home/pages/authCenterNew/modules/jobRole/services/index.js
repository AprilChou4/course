import { createServices } from '@utils';

export default createServices({
  queryDefaultAuthority: 'instead/v2/user/authority/defaultAuthority::post', // 查询公司角色默认权限
  queryAuthority: 'instead/v2/user/authority/query::post', // 权限中心-权限树查询
  getRolesAuthorityList: 'instead/v2/user/authority/role/query.do::post', // 查询公司角色列表及角色对应的权限
  addRole: 'instead/v2/user/authority/role/add::postJSON', // 新增角色
  updateRole: 'instead/v2/user/authority/role/update::postJSON', // 修改角色
  deleteRole: 'instead/v2/user/authority/role/delete.do::post', // 删除角色
  checkRoleUsed: 'instead/v2/user/authority/role/checkUsed::post', // 角色权限-检验该角色被引用
  checkRoleSameName: 'instead/v2/user/authority/role/checkSameName::postJSON', // 角色权限-检验该角色是否重名
});
