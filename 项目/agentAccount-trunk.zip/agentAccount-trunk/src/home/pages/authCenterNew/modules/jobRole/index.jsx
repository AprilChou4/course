/**
 * 权限中心-职能角色
 */
import React from 'react';
import { store } from 'nuomi';
import Layout from './components/Layout';
import effects from './effects';

export default {
  id: 'jobRoleNuomiNew',
  state: {
    //
    form: null,
    // 0=默认 1=新增
    editStatus: 0,
    // 公司角色列表
    roleList: [],
    // 选中菜单 { "authorities": "1#2", "isDefault": true, "roleId": "1", "roleName": "周小熊"}
    selectedMenu: {},
    // 默认选中权限值object={[key:authorityType+key]:['1','2']}
    defaultSelecedAuthData: {},
    // 所有权限值的列表,用于全选
    allAuthValueList: [],
    // 由列表处理后的对象，用于全选
    allAuthValueData: {},
    noAuthValueData: {},
    // 权限列表
    allAuthList: [],
  },
  effects,
  render() {
    return <Layout />;
  },
  onInit() {
    // this.store.dispatch({
    //   type: 'initData',
    // });
  },
};
