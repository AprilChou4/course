import { message } from 'antd';
import getAuthData from '@pages/authCenterNew/utils';
import ShowConfirm from '@components/ShowConfirm';
import services from '../services';

export default {
  /**
   *   权限中心-权限树查询
   */
  async $queryAuthority(payload = {}) {
    const { allAuthorityList, authorityTypeList } =
      (await services.queryAuthority(payload, {
        loading: '正在加载...',
      })) || {};
    this.updateState({
      allAuthList: authorityTypeList || [],
      allAuthValueList: allAuthorityList || [],
    });
  },
  /**
   *   查询公司角色默认权限===恢复默认
   * @param {*} roleId 角色id
   * @param {*} allAuthList 所有权限树
   *
   */
  async $queryDefaultAuthority(payload = {}) {
    const { allAuthList } = this.getState();
    const { selectedMenu } = payload;
    const { roleId } = selectedMenu;
    const { authorities } =
      (await services.queryDefaultAuthority(
        { roleId },
        {
          loading: '正在加载...',
        },
      )) || {};
    const { allAuthData } = getAuthData(authorities, allAuthList);

    this.updateState({
      editStatus: 0,
      defaultSelecedAuthData: allAuthData,
      selectedMenu,
    });
  },
  /**
   *   查询公司角色列表及角色对应的权限
   */
  async $getRolesAuthorityList(payload = {}) {
    const { selectedMenu } = this.getState();
    const { roleId } = selectedMenu;

    const data =
      (await services.getRolesAuthorityList(
        {},
        {
          loading: '正在加载...',
        },
      )) || [];
    // payload.roleId 用于删除选中的角色
    this.$queryDefaultAuthority({
      selectedMenu: roleId && roleId !== payload.roleId ? selectedMenu : data[0],
    });
    this.updateState({
      roleList: data,
    });
  },

  /**
   *   新增角色
   * @param {*} authorities 角色权限id集合
   * @param {*} roleId 角色id
   * @param {*} roleName 角色名称
   */
  async $addRole(payload = {}) {
    const { copyAuth, ...rest } = payload;
    const add = async () => {
      await services.addRole(rest, {
        loading: '正在保存...',
      });
      message.success('角色新增成功!');
      this.updateState({
        editStatus: 0,
      });
      this.$getRolesAuthorityList();
    };
    if (rest.authorities === '') {
      ShowConfirm({
        title: '此岗位权限为空，确定保存？',
        onOk: async () => {
          add();
        },
      });
      return false;
    }
    add();
    return true;
  },

  /**
   *   修改角色
   * @param {*} authorities 角色权限id集合
   * @param {*} roleId 角色id
   * @param {*} roleName 角色名称
   */
  async $updateRole(payload = {}) {
    const update = async () => {
      await services.updateRole(payload, {
        loading: '正在修改...',
      });
      message.success('角色修改成功!');
      this.updateState({
        editStatus: 0,
      });
      this.$getRolesAuthorityList();
    };
    if (payload.authorities === '') {
      ShowConfirm({
        title: '此岗位权限为空，确定保存？',
        onOk: async () => {
          update();
        },
      });
      return false;
    }
    update();
    return true;
  },

  /**
   *   删除角色
   * @param {*} roleId 角色id
   */
  async $deleteRole(payload = {}) {
    await services.deleteRole(payload, {
      loading: '正在删除...',
    });
    message.success('角色删除成功!');
    this.$getRolesAuthorityList(payload);
  },
  /**
   * 角色权限-检验该角色被引用
   * @param {*} roleId 角色id
   */
  async checkRoleUsed(payload) {
    const data = await services.checkRoleUsed(payload);
    return data;
  },

  async initData() {
    await this.dispatch({
      type: 'authCenterNew/$queryAuthority',
      payload: {
        nuomiName: 'jobRoleNuomiNew',
      },
    });
    this.$getRolesAuthorityList();
    this.updateState({
      editStatus: 0,
    });
  },
};
