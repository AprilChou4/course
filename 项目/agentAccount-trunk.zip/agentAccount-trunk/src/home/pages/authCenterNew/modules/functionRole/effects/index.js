import { message } from 'antd';
import globalServices from '@home/services';
import services from '../services';

export default {
  /**
   *   查询公司职能
   */
  async $queryFunction(payload = {}) {
    const data = await globalServices.queryFunction(payload, {
      loading: '正在加载...',
    });
    this.updateState({
      functionRoleList: data || [],
    });
  },

  /**
   *   新增职能
   * @param {*} dataAuthorityType 员工职能数据权限类型（1全公司，2部门，3本人）
   * @param {*} empFunctionId 员工职能id
   * @param {*} empFunctionName 员工职能名称
   * @param {*} isSystem 是否系统
   */
  async $addFunction(payload = {}) {
    await services.addFunction(payload, {
      loading: '正在保存...',
    });
    message.success('职能角色新增成功');
    this.updateState({
      editStatus: 0,
    });
    this.$queryFunction();
  },

  /**
   *   修改职能
   * @param {*} dataAuthorityType 员工职能数据权限类型（1全公司，2部门，3本人）
   * @param {*} empFunctionId 员工职能id
   * @param {*} empFunctionName 员工职能名称
   * @param {*} isSystem 是否系统
   */
  async $updateFunction(payload = {}) {
    await services.updateFunction(payload, {
      loading: '正在修改...',
    });
    message.success('职能角色修改成功');
    this.updateState({
      editStatus: 0,
    });
    this.$queryFunction();
  },

  /**
   *   删除职能
   * @param {*} empFunctionId 职能id
   */
  async deleteFunction(payload = {}) {
    await services.deleteFunction(payload, {
      loading: '正在删除...',
    });
    message.success('职能角色删除成功');
    this.$queryFunction();
  },

  /**
   *   检验该职能被引用
   * @param {*} empFunctionId 职能id
   */
  async checkFunctionUsed(payload = {}) {
    const data = await services.checkFunctionUsed(payload);
    return data;
  },
  async initData() {
    await this.$queryFunction();
    this.updateState({
      editStatus: 0,
    });
  },
};
