// 请设置该职能的数据权限
import React from 'react';
import { connect } from 'nuomi';
import { Radio } from 'antd';
import './style.less';

const FunctionAuth = ({ dispatch, selectedMenu }) => {
  const onChange = (e) => {
    console.log('radio checked', e.target.value);
    // setValue(e.target.value);
    dispatch({
      type: 'updateState',
      payload: {
        selectedMenu: {
          ...selectedMenu,
          dataAuthorityType: e.target.value,
        },
      },
    });
  };
  return (
    <div styleName="m-funtionAuth">
      <h3>请设置该职能的数据权限</h3>
      <Radio.Group onChange={onChange} value={selectedMenu.dataAuthorityType}>
        <Radio value={3}>本人</Radio>
        <Radio value={2}>部门</Radio>
        <Radio value={1}>全公司</Radio>
      </Radio.Group>
    </div>
  );
};
export default connect(({ selectedMenu }) => ({ selectedMenu }))(FunctionAuth);
