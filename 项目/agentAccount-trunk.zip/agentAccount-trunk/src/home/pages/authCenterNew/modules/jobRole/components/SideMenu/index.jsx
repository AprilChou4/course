// 职能角色侧边菜单
import React, { useEffect } from 'react';
import { connect } from 'nuomi';
import { LeftMenu } from '@/home/pages/authCenterNew/components';
import ShowConfirm from '@components/ShowConfirm';
import pubData from 'data';

const SideMenu = ({ dispatch, roleList, selectedMenu, allAuthList }) => {
  const userAuth = pubData.get('authority');
  // 点击菜单回调
  const clickItem = ({ item }) => {
    const menuData = item.props?.menudata || {};
    dispatch({
      type: '$queryDefaultAuthority',
      payload: {
        selectedMenu: menuData,
      },
    });
  };
  // 点击编辑回调
  const clickEdit = (item) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedMenu: item,
        editStatus: 1,
      },
    });
  };

  // 点击删除回调
  const clickDelete = async (item) => {
    const { roleId, roleName } = item;

    const data = await dispatch({
      type: 'checkRoleUsed',
      payload: {
        roleId,
      },
    });
    // 已被使用，提示：
    if (data) {
      ShowConfirm({
        width: 340,
        title: '该岗位已被已使用，删除后拥有该岗位的员工将不再有该岗位对应权限，确定删除？',
        onOk: () => {
          dispatch({
            type: '$deleteRole',
            payload: {
              roleId,
            },
          });
        },
      });
      return false;
    }

    // 未被使用，则提示：
    ShowConfirm({
      width: 248,
      title: `确定要删除“${roleName}”吗？`,
      onOk: () => {
        dispatch({
          type: '$deleteRole',
          payload: {
            roleId,
          },
        });
      },
    });
    // eslint
    return true;
  };

  return (
    <LeftMenu
      menuList={roleList}
      value="roleId"
      name="roleName"
      defaultName="isDefault"
      selectedKey={selectedMenu.roleId}
      onClickMenuItem={clickItem}
      onClickEdit={clickEdit}
      editAuth={!!userAuth[49]}
      onClickDelete={clickDelete}
      deleteAuth={!!userAuth[49]}
    />
  );
};
export default connect(({ roleList, selectedMenu }, { authCenterNew }) => ({
  allAuthList: authCenterNew.allAuthList,
  roleList,
  selectedMenu,
}))(SideMenu);
