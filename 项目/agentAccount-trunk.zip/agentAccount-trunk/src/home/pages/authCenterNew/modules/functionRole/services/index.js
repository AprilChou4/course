import { createServices } from '@utils';

export default createServices({
  addFunction: 'instead/v2/user/authority/function/add::postJSON', // 新增职能
  updateFunction: 'instead/v2/user/authority/function/update::postJSON', // 修改职能
  deleteFunction: 'instead/v2/user/authority/function/delete::post', // 删除职能
  checkFunctionUsed: 'instead/v2/user/authority/function/checkUsed::post', // 检验该职能被引用
  checkFunctionSameName: 'instead/v2/user/authority/function/checkSameName::postJSON', // 检验该职能是否重名
});
