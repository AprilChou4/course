import React from 'react';
import moment from 'moment';
import LinkButton from '@components/buttons/LinkButton';
import { moneyFormat, validateArrayLength } from '@utils';
import dictionary from '../../utils';

const dateFormat = 'YYYY-MM-DD';

export default ({ columnSource, currentPage, pageSize, handleBillNoClick }) => {
  const columnsMap = {
    index: {
      title: '序号',
      align: 'center',
      width: 50,
      render: (text, record, index) => index + 1 + (currentPage - 1) * pageSize,
    },
    reviewBillNo: {
      title: '单据编号',
      align: 'center',
      width: 165,
      ellipsis: true,
      render: (text, record) => (
        <LinkButton
          plain
          ellipsis
          underline
          style={{ maxWidth: '100%' }}
          onClick={() => handleBillNoClick(record)}
        >
          {text}
        </LinkButton>
      ),
    },
    customerName: {
      title: '客户名称',
      className: 'th-center',
      width: 298,
      ellipsis: true,
    },
    reviewMoney: {
      title: '核销金额',
      width: 158,
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    reviewDate: {
      title: '核销日期',
      align: 'center',
      width: 122,
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
    reviewStaffName: {
      title: '核销人',
      align: 'center',
      width: 118,
      ellipsis: true,
    },
    matchType: {
      title: '核销条件',
      align: 'center',
      width: 200,
      render: (value) => dictionary.matchType.map[value],
    },
    reviewType: {
      title: '核销类型',
      align: 'center',
      width: 122,
      render: (value) => [0, 1].includes(value) && ['手动核销', '自动核销'][value],
    },
  };

  // 根据columnSource生成columns
  const columns = [];
  if (validateArrayLength(columnSource)) {
    columns.push(columnsMap.index);
    const basicColSetting = { width: 100, align: 'center', ellipsis: true };
    columnSource.forEach((item) => {
      const col = columnsMap[item?.fieldKey];
      if (!item?.selected) return;
      columns.push({
        ...(col || basicColSetting),
        ...(col ? {} : { title: item?.fieldName }),
        dataIndex: item?.fieldKey,
      });
    });
  }

  return columns;
};
