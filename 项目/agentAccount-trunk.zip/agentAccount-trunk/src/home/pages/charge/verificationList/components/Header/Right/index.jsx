import React, { useCallback } from 'react';
import { connect, store } from 'nuomi';
import pubData from 'data';
import { Button } from 'antd';
import If from '@components/If';
import ExportText from '@components/ExportText';
import ShowConfirm from '@components/ShowConfirm';
import { get, postMessageRouter, validateArrayLength } from '@utils';
import QuickReview from './QuickReview';

const userAuth = pubData.get('authority');

const HeaderRight = ({
  selectedRowKeys,
  customerName,
  createBillDateMax,
  createBillDateMin,
  dispatch,
}) => {
  const linkToAdd = useCallback((isNew) => {
    // 由于新项目经过路由跳转时只能把参数附在url上，url长度有限制，所以有的查询参数就放到了pubData
    isNew && pubData.set('verification-new', true);
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/verification',
      },
    });
  }, []);

  const handleAdd = useCallback(() => {
    const stores = store.getState();
    if (get(stores, 'verification.status') === 0) {
      // 已有一张核销单打开着且未确认核销的情况下，在核销单列表上面点击新增，触发弹层提示，选择是，则打开核销单清空原始数据并新增；选择否，则直接打开核销单老数据；
      ShowConfirm({
        title: (
          <>
            您有正在编辑中的核销单，
            <br />
            是否直接清空？
          </>
        ),
        cancelText: '否',
        okText: '是',
        onCancel() {
          linkToAdd();
        },
        onOk() {
          linkToAdd(true);
        },
      });
    } else {
      // 无打开着的核销单页面时，正常跳转;
      // 已有一张核销单打开着且已核销完毕情况下，在核销单列表上面新点击新增，则直接打开新增一张空的核销单；
      linkToAdd(true);
    }
  }, [linkToAdd]);

  const handleDelete = useCallback(() => {
    dispatch({
      type: 'deleteVerification',
    });
  }, [dispatch]);

  return (
    <>
      <QuickReview />
      <If condition={userAuth[589]}>
        <Button type="primary" onClick={handleAdd}>
          新增
        </Button>
      </If>

      <If condition={userAuth[592]}>
        <Button onClick={handleDelete}>删除</Button>
      </If>
      <If condition={userAuth[593]}>
        <ExportText
          className="f-dib"
          method="post"
          url={`${basePath}instead/v2/customer/receipt/reviewBill/list/export.do`}
          data={{
            customerName,
            createBillDateMax,
            createBillDateMin,
            ...(validateArrayLength(selectedRowKeys) ? { reviewBillIds: selectedRowKeys } : {}),
          }}
        >
          <Button>导出</Button>
        </ExportText>
      </If>
    </>
  );
};

export default connect(
  ({
    verificationTable: { selectedRowKeys },
    query: { customerName, createBillDateMax, createBillDateMin },
  }) => ({
    selectedRowKeys,
    customerName,
    createBillDateMax,
    createBillDateMin,
  }),
)(HeaderRight);
