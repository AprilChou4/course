import React, { useEffect, useState } from 'react';
import { Form, Checkbox } from 'antd';
import { connect } from 'nuomi';
import AntdSearchComplete from '@components/AntdSearchComplete';
import globalServices from '@home/services';
import dictionary from '@pages/charge/utils';
import './style.less';

const formItemLayout = {
  labelCol: {
    sm: { span: 6 },
  },
  wrapperCol: {
    sm: { span: 18 },
  },
};

const Search = ({ moreQuery, dispatch }) => {
  const [autoCompleteList, setAutoCompleteList] = useState([]);
  // 输入框变化的时候
  const onChange = async (value) => {
    if (!value) {
      return false;
    }
    const data = await globalServices.searchCustomerByName({ customerName: value });
    const dataSource = data.map((item) => item.customerName);
    setAutoCompleteList(dataSource);
    return false;
  };

  const onSearch = async (formValues) => {
    dispatch({
      type: 'updateStateAndQuery',
      payload: {
        init: true,
        moreQuery: formValues,
      },
    });
  };

  const getSearchData = (data) => {
    const searchData = [];
    Object.keys(data).forEach((i) => {
      const value = data[i];
      if (value) {
        switch (i) {
          case 'reviewType':
            searchData.push({
              title: dictionary.reviewType.title,
              text: []
                .concat(value)
                .map((ele) => dictionary.reviewType.list.find((item) => item.value === ele)?.name),
            });
            break;
          default:
            break;
        }
      }
    });
    return searchData;
  };

  const getContent = ({ getFieldDecorator }) => {
    return (
      <>
        {/* 核销类型 */}
        <Form.Item
          label={dictionary.reviewType.title}
          style={{ marginBottom: 12 }}
          className="ui-checkboxGroup"
        >
          {getFieldDecorator('reviewType', {
            initialValue: moreQuery.reviewType,
          })(
            <Checkbox.Group>
              {dictionary.reviewType.list.map(({ value, name }) => (
                <Checkbox key={value} value={value}>
                  {name}
                </Checkbox>
              ))}
            </Checkbox.Group>,
          )}
        </Form.Item>
      </>
    );
  };

  useEffect(() => {
    dispatch({
      type: 'getSearchOptions',
    });
  }, [dispatch]);

  return (
    <AntdSearchComplete
      name="customerName"
      placeholder="请输入客户名称"
      className="e-ml12"
      styleName="m-verificationSearch"
      getContent={getContent}
      getSearchData={getSearchData}
      isHasAutocomplete
      autoCompleteList={autoCompleteList}
      onCommonSearch={onSearch}
      onChange={onChange}
      formItemLayout={formItemLayout}
      popoverProps={{
        overlayStyle: { width: 320 },
      }}
    />
  );
};

export default connect(({ moreQuery }) => ({
  moreQuery,
}))(Search);
