import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { DatePicker } from 'antd';
import AntdSearch from '@components/input/AntdSearch';
import Search from './Search';

const { RangePicker } = DatePicker;

const Left = ({ createBillDate, dispatch }) => {
  const handleSearch = useCallback(
    (field, value) => {
      dispatch({
        type: 'updateStateAndQuery',
        payload: {
          init: true,
          [field]: value,
        },
      });
    },
    [dispatch],
  );

  return (
    <>
      <span style={{ marginRight: 8 }}>核销日期:</span>
      <RangePicker
        style={{ width: 249 }}
        value={createBillDate}
        onChange={(value) => handleSearch('createBillDate', value)}
      />
      <Search />
    </>
  );
};

export default connect(({ createBillDate }) => ({
  createBillDate,
}))(Left);
