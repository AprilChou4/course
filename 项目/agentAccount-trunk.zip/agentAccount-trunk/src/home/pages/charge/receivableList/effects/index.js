import { store } from 'nuomi';
import { message } from 'antd';
import { get, postMessageRouter } from '@utils';
import services from '../services';

export default {
  // 查询应收单自定义列
  async $getReceivableCustomizeColumn() {
    const data = await services.getReceivableCustomizeColumn();
    this.updateState({
      columnSource: data,
    });
    return data;
  },

  /**
   * 更新应收单自定义列
   * @param {*array}  customizeColumns 表头列表
   */
  async $updateReceivableCustomizeColumn(payload = {}) {
    const { customizeColumns } = payload;
    await services.updateReceivableCustomizeColumn(payload);
    message.success('自定义列表已保存');
    this.updateState({
      columnSource: customizeColumns,
    });
    this.$getShouldReceiveBillList();
    // this.dispatch({
    //   type: '$serviceCustomerList',
    // });
    // return data;
  },

  // 获取应收单列表
  async $getShouldReceiveBillList() {
    const { tableConditions } = this.getState();
    const data =
      (await services.getShouldReceiveBillList(tableConditions, {
        loading: '正在获取应收单列表...',
      })) || {};
    this.updateState({
      tableList: data.list || [],
      total: data.count || 0,
      totalMoney: data.totalMoney || {},
    });
  },

  // 修改筛选条件
  async updateCondition(payload = {}) {
    const { tableConditions } = this.getState();
    const lastConditions = {
      ...tableConditions,
      current: 1,
      ...payload,
    };
    this.updateState({
      tableConditions: lastConditions,
      selectedRowKeys: [],
      selectedRows: [],
    });
    await this.$getShouldReceiveBillList();
  },

  // 根据部门id查询员工集合
  async $getStaffList() {
    const aList = await services.getStaffList();
    return aList || [];
  },

  // 查询部门树
  async $getDeptList() {
    const aList = await services.getDeptList();
    return aList || [];
  },
  // 获取服务项目
  async $getChargingItem() {
    const data = await services.getChargingItem();
    let aList = [];
    data.forEach(({ serviceProductVOList }) => {
      aList = [...aList, ...serviceProductVOList];
    });
    return aList || [];
  },

  // 列表初始化查询：服务类型、部门、
  async $getTreeData() {
    const [deptList, staffList, chargeItemList] = await Promise.all([
      this.$getDeptList(),
      this.$getStaffList(),
      this.$getChargingItem(),
    ]);

    this.updateState({
      deptList,
      staffList,
      chargeItemList,
    });
  },
  /**
   * 删除应收单
   * @param {*} shouldReceiveBillIds 应收单单id
   */
  async $deleteShouldReceiveBill(payload) {
    const result = await services
      .deleteShouldReceiveBill(payload, {
        returnAll: true,
        status: {
          400: (res) => {
            this.updateState({
              delFailData: res.data,
              delFailVisible: true,
            });
          },
        },
      })
      .catch((err) => err);

    const requestSuccess = result.status === 200;
    if (requestSuccess) {
      message.success('应收单已删除');
      this.updateCondition();
    }

    const failedSrbNos = get(result, 'data.failedSrbNos', []);
    const failSrbNos = failedSrbNos && Array.isArray(failedSrbNos) ? failedSrbNos : [];
    // 如果删除的删除的应收单已经在应收单新增页面打开了，清空应收单页面
    const receivableStore = store.getStore('receivable');
    const shouldReceiveId = get(
      receivableStore && receivableStore.getState(),
      'formInitialValues.shouldReceiveId',
    );
    const srbNo = get(receivableStore && receivableStore.getState(), 'formInitialValues.srbNo');
    if (
      shouldReceiveId &&
      get(payload, 'shouldReceiveIds', []).includes(shouldReceiveId) &&
      (requestSuccess || !failSrbNos.includes(srbNo))
    ) {
      receivableStore.dispatch({
        type: 'handleNewReceivable',
      });
    }

    // 如果删除的收款单已经在应收单查看页面打开了，关闭标签页
    const viewReceivableStore = store.getStore('viewReceivable');
    const viewShouldReceiveId = get(
      viewReceivableStore && viewReceivableStore.getState(),
      'formInitialValues.shouldReceiveId',
    );
    const viewSrbNo = get(
      viewReceivableStore && viewReceivableStore.getState(),
      'formInitialValues.srbNo',
    );
    if (
      viewShouldReceiveId &&
      get(payload, 'shouldReceiveIds', []).includes(viewShouldReceiveId) &&
      (requestSuccess || !failSrbNos.includes(viewSrbNo))
    ) {
      postMessageRouter({
        type: 'agentAccount/closeTab',
        payload: {
          path: '/charge/viewReceivable',
        },
      });
    }
  },

  async initData() {
    this.$getReceivableCustomizeColumn();
    this.$getShouldReceiveBillList();
    this.$getTreeData();
  },
};
