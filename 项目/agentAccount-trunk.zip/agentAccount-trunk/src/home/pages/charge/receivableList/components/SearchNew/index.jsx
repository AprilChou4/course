import React, { useEffect, useState } from 'react';
import { Form, Checkbox, Select, Input, Row, Col } from 'antd';
import { connect } from 'nuomi';
import MultiTreeSelect from '@components/MultiTreeSelect';
import ServiceItem from '@components/ServiceItem';
import NumberInput from '@components/input/NumberInput';
import AntdSearchComplete from '@components/AntdSearchComplete';
import globalServices from '@home/services';
import dictionary from '../../../utils';
import './style.less';

// 人民币符号样式
const moneySignStyle = {
  color: '#323232',
};

const Search = ({ tableConditions, deptList, staffList, chargeItemList, dispatch }) => {
  const filterOption = (inputValue, { props: { children } }) => {
    const value = inputValue.trim();
    if (children.indexOf(value) !== -1) {
      return true;
    }
    // eslint
    return false;
  };

  const [autoCompleteList, setAutoCompleteList] = useState([]);
  // 输入框变化的时候
  const onChange = async (value) => {
    if (!value) {
      return false;
    }
    const data = await globalServices.searchCustomerByName({ customerName: value });
    const dataSource = data.map((item) => item.customerName);
    console.log(dataSource, '---dataSource');
    setAutoCompleteList(dataSource);
  };

  // 更多条件查询
  const onSearch = async (formValues, searchList, value) => {
    const newData = { ...formValues };
    // if (formValues.customerName === '') {
    if (value === '') {
      newData.reviewStatus = tableConditions.reviewStatus;
    }
    // 查询清空后，原来的条件没有清空
    const leftQuery = {
      current: tableConditions.current,
      pageSize: tableConditions.pageSize,
    };
    const { createBillDateMin, createBillDateMax } = tableConditions;
    if (createBillDateMin) {
      leftQuery.createBillDateMin = createBillDateMin;
    }
    if (createBillDateMax) {
      leftQuery.createBillDateMax = createBillDateMax;
    }
    dispatch({
      type: 'updateState',
      payload: {
        tableConditions: leftQuery,
      },
    });
    await dispatch({
      type: 'updateCondition',
      payload: newData,
    });
  };

  // 获取输入框展示数据，用于在输入框中展示前的处理
  const getSearchData = (data, getNames) => {
    const searchData = [];
    Object.keys(data).forEach((i) => {
      const value = data[i];
      if (value) {
        switch (i) {
          case 'reviewStatus':
            searchData.push({
              title: dictionary.reviewStatus.title,
              text: []
                .concat(value)
                .map(
                  (ele) => dictionary.reviewStatus.list.find((item) => item.value === ele)?.name,
                ),
            });
            break;
          case 'sourceBillTypes':
            searchData.push({
              title: dictionary.sourceBillType.title,
              text: []
                .concat(value)
                .map(
                  (ele) => dictionary.sourceBillType.list.find((item) => item.value === ele)?.name,
                ),
            });
            break;
          case 'serviceItemIds':
            searchData.push({
              title: '服务项目',
              text: [].concat(value).map((ele) => {
                return chargeItemList.find((item) => item.serviceProductId === ele)
                  ?.serviceProductName;
              }),
            });
            break;
          case 'customerName':
            searchData.push({
              title: '客户名称',
              text: value,
            });
            break;
          case 'receiveMoneyMax':
            searchData.push({
              title: '应收金额',
              text: value,
            });
            break;
          case 'receiveMoneyMin':
            searchData.push({
              title: '应收金额',
              text: value,
            });
            break;

          case 'deptId':
            searchData.push({
              title: '部门',
              text: getNames(deptList, [].concat(value)),
            });
            break;
          case 'businessStaffId':
            searchData.push({
              title: '业务员',
              text: []
                .concat(value)
                .map((ele) => staffList.find((item) => item.staffId === ele)?.realName),
            });
            break;
          case 'createBillStaffId':
            searchData.push({
              title: '制单人',
              text: []
                .concat(value)
                .map((ele) => staffList.find((item) => item.staffId === ele)?.realName),
            });
            break;
          case 'srbNo':
            searchData.push({
              title: '单据编号',
              text: value,
            });
            break;
          default:
            break;
        }
      }
    });
    return searchData;
  };

  // 获取更多条件内容
  const getContent = ({ getFieldDecorator }) => {
    return (
      <>
        {/* 核销状态 */}
        <Form.Item
          label={dictionary.reviewStatus.title}
          // style={formItemStyle}
          className="ui-checkboxGroup"
        >
          {getFieldDecorator('reviewStatus', {
            initialValue: tableConditions.reviewStatus,
          })(
            <Checkbox.Group>
              {dictionary.reviewStatus.list.map(({ value, name }) => (
                <Checkbox key={value} value={value}>
                  {name}
                </Checkbox>
              ))}
            </Checkbox.Group>,
          )}
        </Form.Item>
        {/* 源单类型 */}
        <Form.Item
          label={dictionary.receiveSourceBillType.title}
          style={{ marginBottom: 8 }}
          className="ui-checkboxGroup"
        >
          {getFieldDecorator('sourceBillTypes', {
            initialValue: tableConditions.sourceBillTypes,
          })(
            <Checkbox.Group>
              {dictionary.receiveSourceBillType.list.map(({ value, name }) => (
                <Checkbox key={value} value={value}>
                  {name}
                </Checkbox>
              ))}
            </Checkbox.Group>,
          )}
        </Form.Item>
        <Form.Item label="服务项目">
          {getFieldDecorator('serviceItemIds', {
            initialValue: tableConditions.serviceItemIds,
          })(<ServiceItem allowClear />)}
        </Form.Item>
        <Form.Item label="客户名称">
          {getFieldDecorator('customerName', {
            initialValue: tableConditions.customerName,
          })(<Input placeholder="请输入客户名称" autoComplete="off" allowClear />)}
        </Form.Item>
        <Form.Item label="应收金额">
          <Row>
            <Col span={11}>
              <Form.Item styleName="m-innerItem">
                {getFieldDecorator('receiveMoneyMin', {
                  initialValue: tableConditions.receiveMoneyMin,
                })(
                  <NumberInput
                    prefix={<span style={moneySignStyle}>￥</span>}
                    placeholder="0.00"
                    allowClear
                  />,
                )}
              </Form.Item>
            </Col>
            <Col span={2} style={{ textAlign: 'center' }}>
              —
            </Col>
            <Col span={11}>
              <Form.Item styleName="m-innerItem">
                {getFieldDecorator('receiveMoneyMax', {
                  initialValue: tableConditions.receiveMoneyMax,
                })(
                  <NumberInput
                    prefix={<span style={moneySignStyle}>￥</span>}
                    placeholder="0.00"
                    allowClear
                  />,
                )}
              </Form.Item>
            </Col>
          </Row>
        </Form.Item>
        <Form.Item label="部门">
          {getFieldDecorator('deptId', {
            initialValue: tableConditions.deptId,
          })(
            <MultiTreeSelect
              treeData={deptList}
              val="deptId"
              showMode={false}
              placeholder="请选择部门"
              multiple={false}
              treeCheckable={false}
              showSearch
              getPopupContainer={() => document.body}
            />,
          )}
        </Form.Item>
        <Form.Item label="业务员">
          {getFieldDecorator('businessStaffId', {
            initialValue: tableConditions.businessStaffId,
          })(
            <Select placeholder="请选择业务员" filterOption={filterOption} showSearch allowClear>
              {staffList.map((ele) => (
                <Select.Option key={ele.staffId} value={ele.staffId}>
                  {ele.realName}
                </Select.Option>
              ))}
            </Select>,
          )}
        </Form.Item>
        <Form.Item label="制单人">
          {getFieldDecorator('createBillStaffId', {
            initialValue: tableConditions.createBillStaffId,
          })(
            <Select placeholder="请选择制单人" filterOption={filterOption} showSearch allowClear>
              {staffList.map((ele) => (
                <Select.Option key={ele.staffId} value={ele.staffId}>
                  {ele.realName}
                </Select.Option>
              ))}
            </Select>,
          )}
        </Form.Item>
        <Form.Item label="单据编号">
          {getFieldDecorator('srbNo', {
            initialValue: tableConditions.srbNo,
          })(<Input placeholder="请输入单据编号" autoComplete="off" allowClear />)}
        </Form.Item>
      </>
    );
  };

  useEffect(() => {
    dispatch({
      type: 'getSearchOptions',
    });
  }, [dispatch]);

  return (
    <AntdSearchComplete
      name="customerName"
      placeholder="请输入客户名称"
      className="e-ml12"
      styleName="m-collectSearch"
      autoCompleteProps={{
        style: { width: 320 },
      }}
      getContent={getContent}
      getSearchData={getSearchData}
      isHasAutocomplete
      autoCompleteList={autoCompleteList}
      onCommonSearch={onSearch}
      onChange={onChange}
    />
  );
};

export default connect(({ tableConditions, staffList, deptList, chargeItemList }) => ({
  tableConditions,
  staffList,
  deptList,
  chargeItemList,
}))(Search);
