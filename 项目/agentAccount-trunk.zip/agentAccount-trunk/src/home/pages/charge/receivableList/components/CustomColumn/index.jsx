// 客户管理 > 更多 > 自定义列
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import CustomColModal from '@components/CustomColModal';

const ReceivaleCustomizeColum = ({
  receivaleCustomizeColumVisible,
  columnSource = [],
  loadings,
  dispatch,
}) => {
  // 取消/关闭自定义列弹窗
  const cancel = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        receivaleCustomizeColumVisible: false,
      },
    });
  }, [dispatch]);

  // 保存自定义顺序列
  const setColOption = useCallback(
    (columnSourceArr) => {
      dispatch({
        type: '$updateReceivableCustomizeColumn',
        payload: {
          customizeColumns: columnSourceArr,
        },
      }).then(() => {
        cancel();
      });
    },
    [cancel, dispatch],
  );

  return (
    receivaleCustomizeColumVisible && (
      <CustomColModal
        columnSource={columnSource}
        onCancel={cancel}
        visible={receivaleCustomizeColumVisible}
        isLoading={loadings.$updateReceivableCustomizeColumn}
        setColOption={setColOption}
        resetUrl="instead/v2/customer/receipt/shouldReceiveBill/customizeColumn/get"
        disabledColumn={['customerName', 'srbNo']}
      />
    )
  );
};

export default connect(({ receivaleCustomizeColumVisible, columnSource, loadings }) => ({
  receivaleCustomizeColumVisible,
  columnSource,
  loadings,
}))(ReceivaleCustomizeColum);
