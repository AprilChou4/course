/**
 * @func 数据字典
 */

const getData = (data) => {
  const datas = data;
  datas.map = {};
  datas.list.forEach((ele) => {
    datas.map[ele.value] = ele.name;
  });
  return datas;
};

// 收款单-源单类型
const sourceBillType = {
  title: '源单类型',
  list: [
    {
      name: '应收单',
      value: 1,
    },
    {
      name: '无',
      value: 0,
    },
  ],
};

// 收款单-复核状态  -1  不需要复核  0-为复核 1-已复核
const checkStatus = {
  title: '复核状态',
  list: [
    {
      name: '未复核',
      value: 0,
    },
    {
      name: '已复核',
      value: 1,
    },
  ],
};
// 核销类型 0-手动核销 1-自动核销
const reviewType = {
  title: '核销类型',
  list: [
    {
      name: '手动核销',
      value: 0,
    },
    {
      name: '自动核销',
      value: 1,
    },
  ],
};

// 应收单-源单类型
const receiveSourceBillType = {
  title: '源单类型',
  list: [
    {
      name: '合同',
      value: 1,
    },
    {
      name: '无',
      value: 0,
    },
  ],
};
// 核销状态 0-未核销 1-核销完成 2-部分核销
const reviewStatus = {
  title: '核销状态',
  list: [
    {
      name: '未核销',
      value: 0,
    },
    {
      name: '核销完成',
      value: 1,
    },
    {
      name: '部分核销',
      value: 2,
    },
  ],
};

export default {
  sourceBillType: getData(sourceBillType),
  receiveSourceBillType: getData(receiveSourceBillType),
  reviewStatus: getData(reviewStatus),
  checkStatus: getData(checkStatus),
  reviewType: getData(reviewType),
};
