import { createServices } from '@utils';

export default createServices({
  getCollectCustomizeColumn: 'instead/v2/customer/receipt/receiveBill/customizeColumn/get', // 查询应收单自定义列
  updateCollectCustomizeColumn:
    'instead/v2/customer/receipt/receiveBill/customizeColumn/update::postJSON', // 更新应收单自定义列
  getReceiveBillList: 'instead/v2/customer/receipt/receiveBill/list::postJSON', // 获取收款单列表
  deleteReceiveBill: 'instead/v2/customer/receipt/receiveBill/delete::postJSON', // 删除收款单
  getStaffList: 'instead/v2/user/staff/listServiceStaff', // 根据部门id查询员工集合 制单人/业务员/收款人
  getDeptList: 'instead/v2/user/dept/list', // 查询部门树
  getChargingItem: 'instead/v2/user/basicSetting/service/product/query::post', // 获取服务项目
});
