/**
 * 复核
 */
import React from 'react';
import { Button, message } from 'antd';
import { connect } from 'nuomi';
import pubData from 'data';
import { postMessageRouter } from '@utils';

const ReviewBtn = ({ selectedRowKeys, selectedRows }) => {
  // (750, '复核'), (751, '反复核'), (752, '快速核销');
  const userAuth = pubData.get('authority');
  const review = () => {
    // checkStatus 复核状态 -1  不需要复核  0-未复核 1-已复核
    if (!selectedRowKeys.length) {
      message.warning('请先勾选收款单');
      return false;
    }

    // 未复核列表
    const noReviewList = selectedRows.filter((item) => item.checkStatus === 0);
    if (!noReviewList.length) {
      message.warning('所选收款单已复核/无需复核，无需再复核');
      return false;
    }
    const noReviewIds = noReviewList.map((item) => item.receiveBillId);
    // 由于新项目经过路由跳转时只能把参数附在url上，url长度有限制，所以有的查询参数就放到了pubData
    pubData.set('reviewCollection-query', { receiveBillIds: noReviewIds });
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/reviewCollection',
        query: {
          type: 1,
        },
      },
    });
  };
  return userAuth[750] ? (
    <Button type="primary" onClick={review}>
      复核
    </Button>
  ) : null;
};

export default connect(({ selectedRowKeys, selectedRows }) => ({
  selectedRowKeys,
  selectedRows,
}))(ReviewBtn);
