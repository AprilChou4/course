import React, { useState } from 'react';
import { Form, Checkbox, Select, DatePicker, Input, Row, Col } from 'antd';
import { connect } from 'nuomi';
import moment from 'moment';
import GenFormItem from '@components/form/GenFormItem';
import MultiTreeSelect from '@components/MultiTreeSelect';
import NumberInput from '@components/input/NumberInput';
import ServiceItem from '@components/ServiceItem';
import { util } from '@utils';
import AntdSearchComplete from '@components/AntdSearchComplete';
import globalServices from '@home/services';
import dictionary from '../../../utils';
import './style.less';

// 人民币符号样式
const moneySignStyle = {
  color: '#323232',
};
const Search = ({ tableConditions, deptList, staffList, chargeItemList, dispatch }) => {
  // 下拉筛选
  const filterOption = (inputValue, { props: { children } }) => {
    const value = inputValue.trim();
    if (children.indexOf(value) !== -1) {
      return true;
    }
    // eslint
    return true;
  };

  const [autoCompleteList, setAutoCompleteList] = useState([]);
  // 输入框变化的时候
  const onChange = async (value) => {
    if (!value) {
      return false;
    }
    const data = await globalServices.searchCustomerByName({ customerName: value });
    const dataSource = data.map((item) => item.customerName);
    setAutoCompleteList(dataSource);
    return false;
  };

  // 更多条件查询
  const onSearch = async (formValues) => {
    const { beginReceiptDate, endReceiptDate, ...rest } = formValues;
    const params = rest;
    // 处理更多条件收款日期
    if (beginReceiptDate) {
      params.beginReceiptDate = util.formatTime(beginReceiptDate, 'startOf', 'X');
    }
    if (endReceiptDate) {
      params.endReceiptDate = util.formatTime(endReceiptDate, 'endOf', 'X');
    }

    // 查询清空后，原来的条件没有清空
    const leftQuery = {
      current: tableConditions.current,
      pageSize: tableConditions.pageSize,
    };
    const { beginCreateBillDate, endCreateBillDate } = tableConditions;
    if (beginCreateBillDate) {
      leftQuery.beginCreateBillDate = beginCreateBillDate;
    }
    if (endCreateBillDate) {
      leftQuery.endCreateBillDate = endCreateBillDate;
    }
    dispatch({
      type: 'updateState',
      payload: {
        tableConditions: leftQuery,
      },
    });
    await dispatch({
      type: 'updateCondition',
      payload: params,
    });
  };

  // 获取输入框展示数据，用于在输入框中展示前的处理
  const getSearchData = (data, getNames) => {
    const searchData = [];
    Object.keys(data).forEach((i) => {
      const value = data[i];
      if (value) {
        switch (i) {
          case 'sourceBillTypes':
            searchData.push({
              title: dictionary.sourceBillType.title,
              text: []
                .concat(value)
                .map(
                  (ele) => dictionary.sourceBillType.list.find((item) => item.value === ele)?.name,
                ),
            });
            break;
          case 'serviceItemIds':
            searchData.push({
              title: '服务项目',
              text: []
                .concat(value)
                .map(
                  (ele) =>
                    chargeItemList.find((item) => item.serviceProductId === ele)
                      ?.serviceProductName,
                ),
            });
            break;
          case 'customerName':
            searchData.push({
              title: '客户名称',
              text: value,
            });
            break;
          case 'receiveMoneyMax':
            searchData.push({
              title: '实收金额',
              text: value,
            });
            break;
          case 'receiveMoneyMin':
            searchData.push({
              title: '实收金额',
              text: value,
            });
            break;
          case 'beginReceiptDate':
            searchData.push({
              title: '收款开始日期',
              text: moment(value).format('YYYY-MM-DD'),
            });
            break;
          case 'endReceiptDate':
            searchData.push({
              title: '收款结束日期',
              text: moment(value).format('YYYY-MM-DD'),
            });
            break;
          case 'createBillStaffId':
            searchData.push({
              title: '制单人',
              text: []
                .concat(value)
                .map((ele) => staffList.find((item) => item.staffId === ele)?.realName),
            });
            break;
          case 'deptId':
            searchData.push({
              title: '部门',
              text: getNames(deptList, [].concat(value)),
            });
            break;
          case 'businessStaffId':
            searchData.push({
              title: '业务员',
              text: []
                .concat(value)
                .map((ele) => staffList.find((item) => item.staffId === ele)?.realName),
            });
            break;
          case 'receiptStaffId':
            searchData.push({
              title: '收款人',
              text: []
                .concat(value)
                .map((ele) => staffList.find((item) => item.staffId === ele)?.realName),
            });
            break;
          case 'receiptNo':
            searchData.push({
              title: '单据编号',
              text: value,
            });
            break;
          default:
            break;
        }
      }
    });
    return searchData;
  };

  // 获取更多条件内容
  const getContent = (form) => {
    return (
      <>
        <GenFormItem
          label={dictionary.sourceBillType.title}
          form={form}
          name="sourceBillTypes"
          initialValue={tableConditions.sourceBillTypes}
          className="ui-checkboxGroup"
        >
          <Checkbox.Group>
            {dictionary.sourceBillType.list.map(({ value, name }) => (
              <Checkbox key={value} value={value}>
                {name}
              </Checkbox>
            ))}
          </Checkbox.Group>
        </GenFormItem>
        <GenFormItem
          label="服务项目"
          form={form}
          name="serviceItemIds"
          initialValue={tableConditions.serviceItemIds}
        >
          <ServiceItem allowClear />
        </GenFormItem>
        <GenFormItem
          label="客户名称"
          form={form}
          name="customerName"
          initialValue={tableConditions.customerName}
        >
          <Input placeholder="请输入客户名称" autoComplete="off" allowClear />
        </GenFormItem>
        <Form.Item label="实收金额">
          <Row>
            <Col span={11}>
              <GenFormItem
                styleName="m-innerItem"
                form={form}
                name="receiveMoneyMin"
                initialValue={tableConditions.receiveMoneyMin}
              >
                <NumberInput
                  prefix={<span style={moneySignStyle}>￥</span>}
                  placeholder="0.00"
                  allowClear
                />
              </GenFormItem>
            </Col>
            <Col span={2} style={{ textAlign: 'center' }}>
              —
            </Col>
            <Col span={11}>
              <GenFormItem
                styleName="m-innerItem"
                form={form}
                name="receiveMoneyMax"
                initialValue={tableConditions.receiveMoneyMax}
              >
                <NumberInput
                  prefix={<span style={moneySignStyle}>￥</span>}
                  placeholder="0.00"
                  allowClear
                />
              </GenFormItem>
            </Col>
          </Row>
        </Form.Item>
        <Form.Item label="收款日期">
          <Row>
            <Col span={11}>
              <GenFormItem
                styleName="m-innerItem"
                form={form}
                name="beginReceiptDate"
                initialValue={tableConditions.beginReceiptDate}
              >
                <DatePicker placeholder="开始日期" autoComplete="off" allowClear />
              </GenFormItem>
            </Col>
            <Col span={2} style={{ textAlign: 'center' }}>
              —
            </Col>
            <Col span={11}>
              <GenFormItem
                styleName="m-innerItem"
                form={form}
                name="endReceiptDate"
                initialValue={tableConditions.endReceiptDate}
              >
                <DatePicker placeholder="结束日期" autoComplete="off" allowClear />
              </GenFormItem>
            </Col>
          </Row>
        </Form.Item>
        <GenFormItem
          label="制单人"
          form={form}
          name="createBillStaffId"
          initialValue={tableConditions.createBillStaffId}
        >
          <Select placeholder="请选择制单人" filterOption={filterOption} showSearch allowClear>
            {staffList.map((ele) => (
              <Select.Option key={ele.staffId} value={ele.staffId}>
                {ele.realName}
              </Select.Option>
            ))}
          </Select>
        </GenFormItem>
        <GenFormItem label="部门" form={form} name="deptId" initialValue={tableConditions.deptId}>
          <MultiTreeSelect
            treeData={deptList}
            val="deptId"
            showMode={false}
            placeholder="请选择部门"
            multiple={false}
            treeCheckable={false}
            getPopupContainer={() => document.body}
          />
        </GenFormItem>
        <GenFormItem
          label="业务员"
          form={form}
          name="businessStaffId"
          initialValue={tableConditions.businessStaffId}
        >
          <Select placeholder="请选择业务员" filterOption={filterOption} showSearch allowClear>
            {staffList.map((ele) => (
              <Select.Option key={ele.staffId} value={ele.staffId}>
                {ele.realName}
              </Select.Option>
            ))}
          </Select>
        </GenFormItem>
        <GenFormItem
          label="收款人"
          form={form}
          name="receiptStaffId"
          initialValue={tableConditions.receiptStaffId}
        >
          <Select placeholder="请选择收款人" filterOption={filterOption} showSearch allowClear>
            {staffList.map((ele) => (
              <Select.Option key={ele.staffId} value={ele.staffId}>
                {ele.realName}
              </Select.Option>
            ))}
          </Select>
        </GenFormItem>
        <GenFormItem
          label="单据编号"
          form={form}
          name="receiptNo"
          initialValue={tableConditions.receiptNo}
        >
          <Input placeholder="请输入单据编号" autoComplete="off" allowClear />
        </GenFormItem>
      </>
    );
  };

  return (
    <AntdSearchComplete
      name="customerName"
      placeholder="请输入客户名称"
      className="e-ml12"
      styleName="m-collectSearch"
      getContent={getContent}
      getSearchData={getSearchData}
      isHasAutocomplete
      autoCompleteList={autoCompleteList}
      onCommonSearch={onSearch}
      onChange={onChange}
    />
  );
};

export default connect(({ tableConditions, staffList, deptList, chargeItemList }) => ({
  tableConditions,
  staffList,
  deptList,
  chargeItemList,
}))(Search);
