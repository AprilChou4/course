import { message } from 'antd';
import { store } from 'nuomi';
import { get } from '@utils';
import postMessage from '@utils/postMessage';
import services from '../services';

export default {
  // 查询应收单自定义列
  async $getCollectCustomizeColumn() {
    const data = await services.getCollectCustomizeColumn();
    this.updateState({
      columnSource: data,
    });
    return data;
  },

  /**
   * 更新应收单自定义列
   * @param {*array}  customizeColumns 表头列表
   */
  async $updateCollectCustomizeColumn(payload = {}) {
    const { customizeColumns } = payload;
    await services.updateCollectCustomizeColumn(payload);
    message.success('自定义列表已保存');
    this.updateState({
      columnSource: customizeColumns,
    });
    this.$getReceiveBillList();
  },

  // 请求收款单列表
  async $getReceiveBillList() {
    const { tableConditions } = this.getState();
    const data =
      (await services.getReceiveBillList(tableConditions, {
        loading: '正在获取收款单列表...',
      })) || {};
    this.updateState({
      tableList: data.list || [],
      total: data.count || 0,
      totalMoney: data.totalMoney || {},
    });
  },

  // 修改筛选条件
  async updateCondition(payload = {}) {
    const { tableConditions } = this.getState();
    const lastConditions = {
      ...tableConditions,
      current: 1,
      ...payload,
    };
    this.updateState({
      tableConditions: lastConditions,
      selectedRowKeys: [],
      selectedRows: [],
    });
    await this.$getReceiveBillList();
  },

  // 根据部门id查询员工集合
  async $getStaffList() {
    const aList = await services.getStaffList();
    return aList || [];
  },

  // 查询部门树
  async $getDeptList() {
    const aList = await services.getDeptList();
    return aList || [];
  },

  // 获取服务项目
  async $getChargingItem() {
    const data = await services.getChargingItem();
    let aList = [];
    data.forEach(({ serviceProductVOList }) => {
      aList = [...aList, ...serviceProductVOList];
    });
    return aList || [];
  },

  // 列表初始化查询：服务类型、部门、
  async $getTreeData() {
    const [deptList, staffList, chargeItemList] = await Promise.all([
      this.$getDeptList(),
      this.$getStaffList(),
      this.$getChargingItem(),
    ]);

    this.updateState({
      deptList,
      staffList,
      chargeItemList,
    });
  },
  /**
   * 删除收款单
   * @param {*} receiveBillIds 收款单id
   */
  async $deleteReceiveBill(payload) {
    await services.deleteReceiveBill(payload, {
      status: {
        300: (res) => {
          message.warning(res.message);
          this.updateCondition();
          // if (payload.receiveBillIds.length === 1) {
          //   message.warning('该收款单对应的应收单已完成收款，无法删除');
          //   this.updateCondition();
          // } else {
          //   this.updateState({
          //     delFailData: res.data,
          //     delFailVisible: true,
          //   });
          // }
        },
      },
    });
    message.success('收款单已删除');
    this.updateCondition();

    /* 处理列表中删除可能牵扯到新增收款单页面、查看收款单页面 */
    const receiveBillIds = get(payload, 'receiveBillIds', []);

    // 如果删除的收款单已经在收款单新增页面打开了，清空收款单页面
    const collectionStore = store.getStore('charge_collection');
    const collectionId = get(collectionStore && collectionStore.getState(), 'receiveBillId');
    if (collectionId && receiveBillIds.includes(collectionId)) {
      // console.log('---------新增');
      collectionStore.dispatch({
        type: '$initForm',
        payload: true,
      });
    }
    // 如果删除的收款单已经在收款单查看页面打开了，关闭标签页
    const viewCollectionStore = store.getStore('charge_viewCollection');
    const viewCollectionId = get(
      viewCollectionStore && viewCollectionStore.getState(),
      'receiveBillId',
    );
    if (viewCollectionId && receiveBillIds.includes(+viewCollectionId)) {
      // console.log('---------查看');
      postMessage({
        type: 'agentAccount/closeTab',
        payload: {
          path: '/charge/viewCollection',
        },
      });
    }
  },

  async initData() {
    this.$getCollectCustomizeColumn();
    this.$getReceiveBillList();
    this.$getTreeData();
  },
};
