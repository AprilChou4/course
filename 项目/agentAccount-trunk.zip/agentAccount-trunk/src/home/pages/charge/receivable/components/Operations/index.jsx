/**
 * 操作按钮
 */
import React from 'react';
import { connect } from 'nuomi';
import { ConfigProvider } from 'antd';
import Authority from '@components/Authority';
import Save from './Save';
import Add from './Add';
import SaveAdd from './SaveAdd';
import Delete from './Delete';
import CollectionPlan from './CollectionPlan';
import ToReceivaleList from './ToReceivaleList';

const Operations = ({ status }) => {
  return (
    <ConfigProvider autoInsertSpaceInButton={false}>
      <Authority code={[0, 1].includes(status) ? 572 : 576}>
        <Save />
      </Authority>
      <Authority code={572}>
        <Add />
      </Authority>
      <Authority code={[576, 572]}>
        <SaveAdd />
      </Authority>
      <Authority code={577}>
        <Delete />
      </Authority>
      <Authority code={579}>
        <CollectionPlan />
      </Authority>
      <Authority code={[573, 574]}>
        <ToReceivaleList />
      </Authority>
    </ConfigProvider>
  );
};

export default connect(({ status }) => ({ status }))(Operations);
