/**
 * 应收单列表按钮
 */
import React, { useCallback } from 'react';
import { Button } from 'antd';
import { postMessageRouter } from '@utils';

const ToReceivaleList = () => {
  const handleClick = useCallback(() => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/receivableList',
      },
    });
  }, []);

  return <Button onClick={handleClick}>应收单列表</Button>;
};

export default ToReceivaleList;
