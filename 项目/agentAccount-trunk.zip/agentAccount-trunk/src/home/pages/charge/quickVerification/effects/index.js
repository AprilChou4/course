import { message } from 'antd';
import globalServices from '@home/services';
import services from '../services';

export default {
  // 初始化
  async initData() {
    const { form } = this.getState();
    this.getCustomerList();
    form && form.resetFields();
  },

  /**
   * 查询需要快速核销数据
   * @param {*} customerId 客户id
   */
  async $queryQuickReviewData(payload) {
    const { formInitialValues = {} } = this.getState();
    const data =
      (await services.queryQuickReviewData(payload, {
        loading: '正在加载核销数据...',
      })) || [];
    const quickReviewList =
      data &&
      data.map((item) => {
        const newItem = {
          ...item,
          checked: true,
        };
        return newItem;
      });
    this.updateState({
      quickReviewList: quickReviewList || [],
      formInitialValues: {
        ...formInitialValues,
        customerId: payload.customerId,
      },
    });
  },

  // 获取客户列表
  async getCustomerList() {
    const data = await globalServices.getCustomerBillNO({
      isShouldReceiveBill: 0,
    });
    this.updateState({
      customerList: data || [],
    });
  },

  // 更新头部form
  updateForm(payload = {}) {
    const { form } = payload;
    this.updateState({
      form,
    });
  },

  // 确定核销
  async $quickReview() {
    const { form, quickReviewList } = this.getState();
    form &&
      form.validateFields(async (err, values) => {
        if (err) {
          message.warning('请先填充信息！');
          return;
        }
        // 需要核销的list
        const checkedList = quickReviewList.filter((item) => item.checked);
        if (!checkedList.length) {
          message.warning('请先勾选需要核销的单据');
          return;
        }
        const { customerId } = values;
        const reviewObjects = [];
        checkedList.forEach((item) => {
          const { srb, reviewNo, rb } = item;
          reviewObjects.push({
            srbId: srb.srbId,
            reviewNo,
            rbId: rb.rbId,
          });
        });
        /**
         *
         * @param {*string} customerId 客户id
         * @param {*array} reviewObjects {rbId=收款单id,srbId=应收单id reviewNo=核销单号}
         */
        await services.quickReview(
          {
            customerId,
            reviewObjects,
          },
          { loading: '正在快速核销...' },
        );
        message.success('核销完成');
        this.updateState({
          quickReviewList: checkedList,
          status: 1,
        });
      });
  },
};
