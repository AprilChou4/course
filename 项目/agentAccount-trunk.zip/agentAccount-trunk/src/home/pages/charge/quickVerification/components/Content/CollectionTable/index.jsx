/**
 * 核销单-收款表格
 */
import React from 'react';
import { AntdTable } from '@components';
import getColumns from './columns';
import styles from '../style.less';

const CollectionTable = ({ dataSource }) => {
  const columns = getColumns();
  return (
    <AntdTable
      bordered
      emptyType="default"
      locale={{
        emptyText: <div className={styles['table-placeholder']}>请设置过滤项添加收款数据</div>,
      }}
      pagination={false}
      rowKey="rbId"
      columns={columns}
      dataSource={dataSource}
    />
  );
};

export default CollectionTable;
