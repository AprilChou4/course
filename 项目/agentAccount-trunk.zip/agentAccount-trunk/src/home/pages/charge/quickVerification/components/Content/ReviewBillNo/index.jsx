// 核销单号
import React from 'react';
import AntdInput from '@components/input/AntdInput';

const formItemStyle = { width: 190 };
const ReviewBillNo = ({ value }) => {
  return (
    <>
      <span style={{ marginRight: 8 }}>核销单号:</span>
      <AntdInput disabled placeholder="-" style={formItemStyle} value={value} />
    </>
  );
};
export default ReviewBillNo;
