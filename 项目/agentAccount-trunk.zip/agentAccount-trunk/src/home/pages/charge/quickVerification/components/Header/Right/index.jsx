import React, { useCallback } from 'react';
import { connect, withNuomi } from 'nuomi';
import pubData from 'data';
import { Button } from 'antd';
import { If } from '@components';
import { postMessageRouter } from '@utils';

const userAuth = pubData.get('authority');

const HeaderRight = ({ form, status, formInitialValues, dispatch }) => {
  // const isViewPage = useMemo(() => get(nuomiProps, 'id') === 'viewVerification', [nuomiProps]);
  const isView = status === 1;

  // 确定核销
  const handleSave = useCallback(() => {
    dispatch({
      type: '$quickReview',
    });
  }, [dispatch]);

  // 快速核销
  const quickReview = () => {
    dispatch({
      type: 'updateState',
      payload: {
        quickReviewList: [],
        status: 0,
        formInitialValues: {
          ...formInitialValues,
          customerId: '',
        },
      },
    });
    // 重置form
    form && form.resetFields();
  };

  // 新增核销单
  const handleNew = () => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/verification',
      },
    });
  };

  return (
    <If condition={userAuth[589]}>
      <If condition={!isView}>
        <Button type="primary" onClick={handleSave}>
          确认核销
        </Button>
      </If>
      <If condition={!!isView}>
        <Button type="primary" onClick={quickReview}>
          快速核销
        </Button>
        <Button type="primary" onClick={handleNew}>
          新增核销单
        </Button>
      </If>
    </If>
  );
};

export default connect(({ form, status, formInitialValues }) => ({
  form,
  status,
  formInitialValues,
}))(withNuomi(HeaderRight));
