import React, { forwardRef } from 'react';
import monment from 'moment';
import { connect } from 'nuomi';
import { Descriptions } from 'antd';
import styles from './style.less';

const { Item: DescriptionsItem } = Descriptions;
const dateFormat = 'YYYY-MM-DD';

const Footer = forwardRef(({ formInitialValues }, ref) => (
  <Descriptions column={6} ref={ref} className={styles.descriptions}>
    <DescriptionsItem label="核销人">{formInitialValues.reviewStaffName || ''}</DescriptionsItem>
    <DescriptionsItem label="核销日期" span={5}>
      {formInitialValues.reviewDate
        ? monment(formInitialValues.reviewDate, 'X').format(dateFormat)
        : ''}
    </DescriptionsItem>
  </Descriptions>
));

export default connect(({ formInitialValues }) => ({ formInitialValues }))(Footer);
