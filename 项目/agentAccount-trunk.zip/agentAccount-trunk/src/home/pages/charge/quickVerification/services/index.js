import { createServices } from '@utils';

export default createServices({
  quickReview: 'instead/v2/customer/receipt/reviewBill/quickReview::postJSON', // 快速核销
  queryQuickReviewData: 'instead/v2/customer/receipt/reviewBill/quickReview/queryData::postJSON', // 查询需要快速核销数据
});
