import React from 'react';
import { connect } from 'nuomi';
import PropType from 'prop-types';
import { Checkbox } from 'antd';
import classnames from 'classnames';
import If from '@components/If';
import ReceivableTable from '../ReceivableTable';
import CollectionTable from '../CollectionTable';
import ReviewBillNo from '../ReviewBillNo';
import Style from './style.less';

const TableGroup = ({ dispatch, quickReviewList, status, tableGroupData }) => {
  // srb object 应收单数据
  // reviewNo	string 核销单号
  // rb	object 收款单
  const { checked, reviewNo, srb, rb } = tableGroupData || {};
  // 改变复选框
  const onChange = (e) => {
    const list = quickReviewList.map((item) => {
      const newItem = { ...item };
      if (newItem.reviewNo === reviewNo) {
        newItem.checked = !newItem.checked;
      }
      return newItem;
    });
    dispatch({
      type: 'updateState',
      payload: {
        quickReviewList: list,
      },
    });
  };
  return (
    <div className={Style.tableGroup}>
      <If condition={status === 1}>
        <span className={Style.reviewMark} />
      </If>
      <div>
        <div>
          <div className={classnames('title-mark', Style.mark)}>应收</div>
          <ReviewBillNo value={reviewNo} />
          <If condition={status === 0}>
            <Checkbox
              onChange={onChange}
              checked={checked}
              style={{
                float: 'right',
                lineHeight: '36px',
              }}
            >
              核销
            </Checkbox>
          </If>
        </div>
        <ReceivableTable dataSource={[srb]} />
      </div>
      <div>
        <div className={Style.header}>
          <div className={classnames('title-mark', Style.mark)}>收款</div>
        </div>
        <CollectionTable dataSource={[rb]} />
      </div>
    </div>
  );
};
TableGroup.propType = {
  TableGroup: PropType.objectOf(PropType.any),
};
export default connect(({ status, quickReviewList }) => ({ status, quickReviewList }))(TableGroup);
