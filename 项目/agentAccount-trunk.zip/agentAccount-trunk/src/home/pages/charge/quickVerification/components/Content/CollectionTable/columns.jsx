import React from 'react';
import moment from 'moment';
import { moneyFormat } from '@utils';

const dateFormat = 'YYYY-MM-DD';

export default () => {
  return [
    {
      title: '收款单单据编号',
      dataIndex: 'rbNo',
      align: 'center',
      width: 200,
    },
    {
      title: '制单日期',
      dataIndex: 'createBillDate',
      align: 'center',
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
    {
      title: '本次核销金额',
      dataIndex: 'currentReviewedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '收款金额',
      dataIndex: 'receivedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '已核销金额',
      dataIndex: 'reviewedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '未核销金额',
      dataIndex: 'unReviewMoney',
      align: 'center',
      render: (value) => <span className="f-fr">{moneyFormat(value)}</span>,
    },
  ];
};
