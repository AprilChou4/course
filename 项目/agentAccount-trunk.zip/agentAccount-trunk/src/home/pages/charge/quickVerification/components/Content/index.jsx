import React from 'react';
import { connect } from 'nuomi';
import TableGroup from './TableGroup';
import styles from './style.less';
import Footer from '../Footer';

const Content = ({ formInitialValues, quickReviewList }) => {
  return (
    <div className={styles.container}>
      {quickReviewList && quickReviewList.length ? (
        <>
          {quickReviewList.map((item) => (
            <TableGroup key={item.reviewNo} tableGroupData={item} />
          ))}
          <Footer />
        </>
      ) : (
        <div className={styles.noData}>
          {formInitialValues.customerId ? '该客户无核销数据' : '请选择客户后进行核销'}
        </div>
      )}
    </div>
  );
};

export default connect(({ formInitialValues, quickReviewList }) => ({
  formInitialValues,
  quickReviewList,
}))(Content);
