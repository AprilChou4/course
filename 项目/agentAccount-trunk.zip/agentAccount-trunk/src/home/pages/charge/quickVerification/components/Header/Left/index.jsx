import React, { useEffect, useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { Form } from 'antd';
import { GenFormItem, SuperSelect } from '@components';
import { getSelectOptions } from '@utils';

const formItemStyle = { width: 300 };

const Left = ({ form, formInitialValues, customerList, dispatch }) => {
  const customerOptions = useMemo(
    () =>
      getSelectOptions(customerList, (item) => ({
        value: item.customerId,
        name: item.customerName,
      })),
    [customerList],
  );

  // 客户名称改变
  const handleCustomerIdChange = useCallback(
    (value) => {
      dispatch({
        type: '$queryQuickReviewData',
        payload: {
          customerId: value,
        },
      });
    },
    [dispatch],
  );

  // 更新form
  useEffect(() => {
    dispatch({
      type: 'updateForm',
      payload: { form },
    });
  }, [dispatch, form]);
  return (
    <Form layout="inline" className="form-hide-explain">
      <GenFormItem
        required
        form={form}
        label="客户名称"
        name="customerId"
        initialValue={formInitialValues.customerId}
        rules={[{ required: true, message: '请选择客户名称' }]}
      >
        <SuperSelect
          placeholder="请选择客户名称"
          defaultActiveFirstOption={false}
          style={formItemStyle}
          // disabled={isView}
          onChange={handleCustomerIdChange}
        >
          {customerOptions}
        </SuperSelect>
      </GenFormItem>
    </Form>
  );
};

export default connect(({ formInitialValues, customerList }) => ({
  formInitialValues,
  customerList,
}))(Form.create()(Left));
