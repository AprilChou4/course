/**
 * 核销单-应收表格
 */
import React, { useMemo } from 'react';
import { AntdTable } from '@components';
import getColumns from './columns';
import styles from '../style.less';

const ReceivableTable = ({ dataSource }) => {
  const columns = useMemo(() => getColumns(), []);

  return (
    <AntdTable
      bordered
      emptyType="default"
      locale={{
        emptyText: <div className={styles['table-placeholder']}>请设置过滤项添加应收数据</div>,
      }}
      pagination={false}
      rowKey="srbId"
      columns={columns}
      dataSource={dataSource}
    />
  );
};

export default ReceivableTable;
