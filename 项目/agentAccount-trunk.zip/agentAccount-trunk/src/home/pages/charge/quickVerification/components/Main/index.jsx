import React, { useRef } from 'react';
import { connect } from 'nuomi';
import classnames from 'classnames';
import { Layout, ContentWrapper } from '@components';
import HeaderLeft from '../Header/Left';
import HeaderRight from '../Header/Right';
import Content from '../Content';
import styles from './styles.less';

const Main = ({ title }) => {
  const wrapperRef = useRef(null);

  return (
    <div className={classnames('hide-disabled', styles.container)} ref={wrapperRef}>
      <Layout.PageWrapper>
        <ContentWrapper
          title={title}
          header={{
            left: <HeaderLeft />,
            right: <HeaderRight />,
          }}
          headerStyle={{ boxShadow: '0px 5px 3px -2px rgba(0,0,0,0.08)' }}
          content={<Content wrapperRef={wrapperRef} />}
        />
      </Layout.PageWrapper>
    </div>
  );
};

export default connect(({ title }) => ({ title }))(Main);
