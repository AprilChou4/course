import React from 'react';
import moment from 'moment';
import { moneyFormat } from '@utils';

const dateFormat = 'YYYY-MM-DD';

export default () => {
  return [
    {
      title: '应收单单据编号',
      dataIndex: 'srbNo',
      align: 'center',
      width: 200,
      render: (value) => <span>{value}</span>,
    },
    {
      title: '制单日期',
      dataIndex: 'createBillDate',
      align: 'center',
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
    {
      title: '本次核销金额',
      dataIndex: 'currentReviewedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '应收金额',
      dataIndex: 'shouldReceiveMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '已核销金额',
      dataIndex: 'reviewedMoney',
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    {
      title: '未核销金额',
      dataIndex: 'unReviewMoney',
      align: 'center',
      render: (value) => <span className="f-fr">{moneyFormat(value)}</span>,
    },
  ];
};
