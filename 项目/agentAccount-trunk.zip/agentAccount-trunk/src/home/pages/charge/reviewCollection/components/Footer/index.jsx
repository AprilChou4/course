import React from 'react';
import { Descriptions } from 'antd';
import moment from 'moment';
import { connect } from 'nuomi';
import styles from './style.less';

const { Item: DescriptionsItem } = Descriptions;

const Footer = ({ formValues }) => {
  const { checkStatus, createBillStaffName, createBillDate, reviewStaffName, reviewDate } =
    formValues || {};
  return (
    <Descriptions column={6} className={styles.descriptions}>
      <DescriptionsItem label="制单人">{createBillStaffName || ''}</DescriptionsItem>
      <DescriptionsItem label="制单日期" span={2}>
        {createBillDate ? moment(createBillDate, 'X').format('YYYY-MM-DD') : ''}
      </DescriptionsItem>
      {checkStatus === 1 && (
        <>
          <DescriptionsItem label="复核人">{reviewStaffName || ''}</DescriptionsItem>
          <DescriptionsItem label="复核日期">
            {reviewDate ? moment(reviewDate, 'X').format('YYYY-MM-DD') : ''}
          </DescriptionsItem>
        </>
      )}
    </Descriptions>
  );
};

export default connect(({ formValues }) => ({ formValues }))(Footer);
