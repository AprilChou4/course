import React from 'react';
import MainContent from '../MainContent';
import ServiceForm from '../ServiceForm';

const Content = ({ form }) => {
  return (
    <div style={{ height: '100%', overflow: 'auto' }}>
      <div>
        <MainContent form={form} />
        <div style={{ paddingBottom: 1 }}>
          <div className="title-mark">服务项目</div>
        </div>
      </div>
      <div>
        <ServiceForm />
      </div>
    </div>
  );
};

export default Content;
