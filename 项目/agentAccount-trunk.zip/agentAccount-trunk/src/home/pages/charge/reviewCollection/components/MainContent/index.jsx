import React, { useMemo } from 'react';
import { Form, Input, Row, Col, Select, DatePicker, message, Divider } from 'antd';
import { LimitInput, DeptTreeSelect, SuperSelect, NumberInput, GenFormItem } from '@components';

import { connect } from 'nuomi';
import { getSelectOptions } from '@utils';
import moment from 'moment';

import './style.less';

const { Option } = Select;

const MainContent = ({
  form,
  formValues,
  receiptTypeList,
  receiptAccountList,
  receiptStaffList,
  businessStaffList,
  customerList,
  maxPreMoney,
}) => {
  // 客户名称下拉框列表
  const customerOptions = useMemo(
    () =>
      getSelectOptions(customerList, (item) => ({
        value: item.customerId,
        name: item.customerName,
      })),
    [customerList],
  );

  // 空白只做展示的表单组件
  const Blank = React.forwardRef(({ value }, ref) => {
    return <span ref={ref}>{value}</span>;
  });

  return (
    <Form styleName="form">
      <div styleName="main-form">
        <Row gutter={35}>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="客户名称"
              name="customerId"
              initialValue={formValues.customerName}
              rules={[{ required: true, message: '请选择客户名称' }]}
            >
              <SuperSelect defaultActiveFirstOption={false} placeholder="请选择客户名称" disabled>
                {customerOptions}
              </SuperSelect>
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="单据编号"
              name="receiptNo"
              rules={[{ required: true, message: '请填写单据编号' }]}
              initialValue={formValues.receiptNo}
            >
              <Input placeholder="请输入单据编号" autoComplete="off" disabled />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="源单类型"
              name="sourceBillType"
              initialValue={formValues.sourceBillType}
            >
              <Select placeholder="源单类型" disabled>
                <Option value={0}>-</Option>
                <Option value={1}>应收单</Option>
              </Select>
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="源单据号"
              name="sourceBillNo"
              initialValue={formValues.sourceBillNo}
            >
              <Input disabled placeholder="-" />
            </GenFormItem>
          </Col>
        </Row>
        <Row gutter={35}>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="收款金额"
              name="totalReceiptMoney"
              rules={[{ required: true, message: '请输入收款金额' }]}
              initialValue={formValues.totalReceiptMoney}
            >
              <NumberInput placeholder="请输入收款金额" disabled />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="收款日期"
              name="receiptDate"
              rules={[{ required: true, message: '请选择收款日期' }]}
              initialValue={
                formValues.receiptDate ? moment(formValues.receiptDate, 'X') : undefined
              }
            >
              <DatePicker
                allowClear={false}
                placeholder="请选择收款日期"
                style={{ width: '100%' }}
                disabled
              />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="收款方式"
              name="receiptType"
              initialValue={formValues.receiptType || undefined}
            >
              <Select
                placeholder="请选择收款方式"
                allowClear
                dropdownStyle={{ maxWidth: 230 }}
                dropdownMatchSelectWidth={false}
                disabled
                dropdownRender={(menu) => (
                  <div>
                    {menu}
                    <Divider style={{ margin: 0 }} />
                  </div>
                )}
              >
                {receiptTypeList.map((item) => (
                  <Option value={item.receiptTypeId} key={item.receiptTypeId}>
                    {item.receiptTypeName}
                  </Option>
                ))}
              </Select>
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="收款账号"
              name="receiptTypeAccountId"
              initialValue={
                formValues.receiptTypeAccountId
                  ? Number(formValues.receiptTypeAccountId)
                  : undefined
              }
            >
              <Select placeholder="收款账号" allowClear disabled>
                {receiptAccountList.map((item) => (
                  <Option value={item.receiptTypeAccountId} key={item.receiptTypeAccountId}>
                    {item.receiptTypeAccount}
                  </Option>
                ))}
              </Select>
            </GenFormItem>
          </Col>
        </Row>
        <Row gutter={35}>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="收款人"
              name="receiptStaffId"
              initialValue={formValues.receiptStaffName || undefined}
            >
              <SuperSelect
                placeholder="请选择收款人"
                allowClear
                disabled
                defaultActiveFirstOption={false}
              >
                {receiptStaffList.map((item) => (
                  <Option value={item.staffId} key={item.staffId}>
                    {item.realName}
                  </Option>
                ))}
              </SuperSelect>
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="部门"
              name="deptId"
              initialValue={formValues.deptName || undefined}
            >
              <DeptTreeSelect type="all" disabled allowClear />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="业务员"
              name="businessStaffId"
              initialValue={formValues.businessStaffName || undefined}
            >
              <SuperSelect
                placeholder="请选择业务员"
                disabled
                defaultActiveFirstOption={false}
                allowClear
              >
                {businessStaffList.map((item) => (
                  <Option value={item.staffId} key={item.staffId}>
                    {item.realName}
                  </Option>
                ))}
              </SuperSelect>
            </GenFormItem>
          </Col>
        </Row>
        <Row gutter={35}>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="应收总额"
              name="shouldTotalMoney"
              initialValue={formValues.shouldTotalMoney}
            >
              <NumberInput placeholder="请输入应收总额" disabled />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="优惠金额"
              name="freeMoney"
              initialValue={formValues.freeMoney}
            >
              <NumberInput placeholder="请输入优惠金额" disabled />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="本次预收"
              name="preReceiptMoney"
              initialValue={formValues.preReceiptMoney}
            >
              <Blank />
            </GenFormItem>
          </Col>
          <Col span={6}>
            <GenFormItem
              form={form}
              label="使用预收"
              name="userPreReceiptMoney"
              initialValue={formValues.userPreReceiptMoney}
            >
              <NumberInput
                disabled
                placeholder={maxPreMoney > 0 ? `最大可使用预收${maxPreMoney}元` : '无可使用预收'}
                max={parseFloat(maxPreMoney)}
              />
            </GenFormItem>
          </Col>
        </Row>
        <GenFormItem form={form} label="摘要" name="remark" initialValue={formValues.remark}>
          <LimitInput maxLength={200} disabled />
        </GenFormItem>
      </div>
    </Form>
  );
};

export default connect(
  ({
    formValues,
    receiptTypeList,
    receiptAccountList,
    receiptStaffList,
    businessStaffList,
    customerList,
    isReference,
    maxPreMoney,
  }) => ({
    formValues,
    receiptTypeList,
    receiptAccountList,
    receiptStaffList,
    businessStaffList,
    customerList,
    isReference,
    maxPreMoney,
  }),
)(MainContent);
