import React, { useEffect } from 'react';
import { Layout, ContentWrapper } from '@components';
import { Form } from 'antd';
import { connect } from 'nuomi';
import Operations from '../Operations';
import Content from '../Content';
import Footer from '../Footer';

import './style.less';

const ChargeCollection = ({ dispatch, form }) => {
  // 更新form
  useEffect(() => {
    dispatch({
      type: 'updateForm',
      payload: form,
    });
  }, [dispatch, form]);

  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title="复核收款单"
        header={{
          right: <Operations form={form} />,
        }}
        content={<Content form={form} />}
        footer={<Footer />}
      />
    </Layout.PageWrapper>
  );
};
const ChargeCollectionForm = Form.create()(ChargeCollection);
export default connect()(ChargeCollectionForm);
