import globalServices from '@home/services';
import pubData from 'data';
import { message } from 'antd';
import { get, validateArrayLength } from '@utils';
import services from '../services';
import { genInitDataSource, calcTotalMoney } from '../../collection/utils';

export default {
  // 查看收款单
  async $getDetail(payload) {
    const { receiveBillId } = payload;
    if (!receiveBillId) {
      message.warning('请选择要复核的收款单！');
      return;
    }

    const data = await services.getDetail(
      { receiveBillId },
      {
        loading: '正在获取收款单信息...',
      },
    );
    const { receiveBillItems, customerId } = data;
    const maxPreMoney = await services.getMaxMoney({ customerId });
    // 有明细计算合计
    const totalMoney = calcTotalMoney(receiveBillItems);
    const receiptRes = await services.getReceiptType();
    const receiptTypeList = get(receiptRes, 'receiptList', []);
    // 查找收款账号对应的收款方式
    let receiptType = '';
    let receiptAccountList = [];
    if (data.receiptTypeAccountId) {
      for (let i = 0; i < receiptTypeList.length; i++) {
        // 收款方式对应的收款账号列表
        const receiptTypeAccounts = get(receiptTypeList[i], 'receiptTypeAccounts', []);
        for (let j = 0; j < receiptTypeAccounts.length; j++) {
          const account = receiptTypeAccounts[j];
          if (account.receiptTypeAccountId === Number(data.receiptTypeAccountId)) {
            receiptType = account.receiptTypeId;
            receiptAccountList = receiptTypeAccounts;
            // 匹配成功break
            break;
          }
        }
        if (receiptType) break;
      }
    }
    console.log({ ...data, receiptType }, '--{ ...data, receiptType }');
    this.updateState({
      formValues: { ...data, receiptType },
      dataSource: genInitDataSource(receiveBillItems),
      maxPreMoney,
      // 合计
      totalMoney,
      // 收款方式、账号
      receiptTypeList,
      receiptAccountList,
      receiveBillId,
    });
    // hack!
    setTimeout(() => {
      const { form } = this.getState();
      form.resetFields && form.resetFields();
    });
  },

  // 获取最大使用预收
  async $getMaxMoney(customerId) {
    const { dataSource } = this.getState();
    const data = await services.getMaxMoney({ customerId });
    this.dispatch({
      type: 'updateState',
      payload: {
        maxPreMoney: data,
        // 最大预收改变后，置空添加过使用的预收
        dataSource: dataSource.map((it) => ({ ...it, userPreReceiptMoney: undefined })),
      },
    });
  },

  /**
   * 收款单复核
   * @param {*} receiveId
   */
  async reviewReceiveBill(payload) {
    const { receiveBillId } = this.getState();
    const { receiveId } = payload;
    await services.reviewReceiveBill(
      { receiveId },
      {
        loading: '正在复核收款单...',
      },
    );
    message.success('复核成功');
    this.$getDetail({ receiveBillId });
  },
  /**
   * 收款单反复核
   * @param {*} receiveId
   */
  async reverseReviewReceiveBill(payload) {
    const { receiveBillId } = this.getState();
    const { receiveId } = payload;
    await services.reverseReviewReceiveBill(
      { receiveId },
      {
        loading: '正在反复核收款单...',
      },
    );
    message.success('反复核成功');
    this.$getDetail({ receiveBillId });
  },
  async initList() {
    const { formValues } = this.getState();
    if (formValues.customerId) {
      this.$getMaxMoney(formValues.customerId);
    }
    // 获取收款人列表
    this.$getStaffList();
    // 获取客户列表
    this.$getCustomerList();
    // 获取服务项目列表
    this.$getChargingList();
    // 获取收款方式列表
    this.$getReceiptTypeList();
  },

  async initData() {
    const { receiveBillIds } = pubData.get('reviewCollection-query') || {};
    pubData.set('taskExecution-query', undefined);
    const receiveBillId = validateArrayLength(receiveBillIds) ? receiveBillIds[0] : '';
    this.$getDetail({ receiveBillId });
    this.updateState({
      receiveBillId,
      ...(validateArrayLength(receiveBillIds) ? { receiveBillIds } : {}),
    });
    // }
  },

  // 获取收款人列表
  async $getStaffList() {
    const data = await globalServices.getStaffList();
    this.updateState({
      receiptStaffList: data || [],
      businessStaffList: data || [],
    });
  },

  // 获取客户列表
  async $getCustomerList() {
    const data = await services.getCustomerBillList({ isShouldReceiveBill: 0 });
    this.updateState({
      customerList: data || [],
    });
  },

  // 获取服务项目列表
  async $getChargingList() {
    const data = await services.getCharging();
    const list = data.reduce((a, c) => [...a, ...c.chargingItemList], []);
    const serviceItemMap = list.reduce((a, c) => ({ ...a, [c.chargingItemId]: c.serviceName }), {});
    this.updateState({
      serviceList: list || [],
      serviceItemMap,
    });
  },

  // 获取收款方式列表
  async $getReceiptTypeList() {
    const data = await services.getReceiptType();
    const receiptTypeList = get(data, 'receiptList', []);
    this.updateState({
      receiptTypeList,
    });
  },
};
