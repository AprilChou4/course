import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import { NumberInput, FormTable } from '@components';
import ServiceItems from '../../../components/ServiceItems';
import FormTableFooter from './Footer';

import './style.less';

const ServiceForm = ({
  serviceList,
  isReference,
  dataSource,
  totalMoney,
  maxPreMoney,
  tableForm,
  dispatch,
}) => {
  const selectedMap = useMemo(() => {
    return dataSource.reduce((a, c) => ({ ...a, [c.serviceItemId]: true }), {});
  }, [dataSource]);

  // 是否有服务项目明细
  const hasServiceItems = isReference || dataSource.some((it) => it.serviceItemId);

  // 获取表格列, 1. 服务项目+服务类型 2.摘要
  const columns = [
    {
      title: '服务项目',
      dataIndex: 'serviceItemId',
      key: 'serviceItemId',
      align: 'center',
      className: 'form-table-service-item-td',
      total: '合计',
      render() {
        return (
          <ServiceItems
            showArrow={false}
            disabled
            dataSource={serviceList}
            getSelectNodeProps={(item) => ({
              value: Number(item.chargingItemId),
              name: item.itemName,
              disabled: selectedMap[item.chargingItemId],
            })}
            style={{ width: '100%' }}
          />
        );
      },
    },
    {
      title: '服务类型',
      dataIndex: 'serviceTypeName',
      key: 'serviceTypeName',
      align: 'center',
    },
    {
      title: '应收金额（元）',
      dataIndex: 'shouldMoney',
      key: 'shouldMoney',
      align: 'center',
      className: 'collection-disabled-td',
      total: totalMoney.shouldTotalMoney,
      render(text, record) {
        if (!record.serviceItemId && !record.remark) {
          return null;
        }
        return <NumberInput style={{ textAlign: 'right' }} placeholder="0.00" disabled />;
      },
    },
    {
      title: '实收金额（元）',
      dataIndex: 'receiptMoney',
      key: 'receiptMoney',
      align: 'center',
      fieldDecorator: {
        rules: [{ required: true, message: '' }],
      },
      asterisk: hasServiceItems,
      total: totalMoney.totalReceiptMoney,
      render(text, record) {
        if (!record.serviceItemId && !record.remark) {
          return null;
        }
        return <NumberInput style={{ textAlign: 'right' }} disabled placeholder="0.00" />;
      },
    },
    {
      title: '优惠金额（元）',
      dataIndex: 'freeMoney',
      key: 'freeMoney',
      align: 'center',
      total: totalMoney.freeMoney,
      render(text, record) {
        if (!record.serviceItemId && !record.remark) {
          return null;
        }
        return <NumberInput style={{ textAlign: 'right' }} placeholder="0.00" disabled />;
      },
    },
    {
      title: '本次预收',
      dataIndex: 'preReceiptMoney',
      key: 'preReceiptMoney',
      total: totalMoney.preReceiptMoney,
      align: 'center',
      className: 'form-table-pre-receipt-td',
    },
    {
      title: '使用预收',
      dataIndex: 'userPreReceiptMoney',
      key: 'userPreReceiptMoney',
      align: 'center',
      className: 'collection-disabled-td',
      total: totalMoney.userPreReceiptMoney,
      render(text, record, index) {
        const userPreReceiptMoney = tableForm.getFieldValue(index, 'userPreReceiptMoney');
        if (!record.serviceItemId && !record.remark) {
          return null;
        }
        const max = maxPreMoney - (totalMoney.userPreReceiptMoney - (userPreReceiptMoney || 0));
        return <NumberInput style={{ textAlign: 'right' }} disabled max={max} placeholder="0.00" />;
      },
    },
  ];
  // 应收单只填表头, 未填明细
  const isPlanList = isReference && dataSource.some((it) => it.remark);
  if (isReference && isPlanList) {
    columns.splice(0, 2, {
      title: '摘要',
      dataIndex: 'remark',
      key: 'remark',
      align: 'center',
    });
  }

  return (
    <FormTable
      rowKey="id"
      dataSource={dataSource}
      columns={columns}
      getForm={(f) => {
        dispatch({
          type: 'updateState',
          payload: {
            tableForm: f,
          },
        });
      }}
      onAddIcon={() => ({
        className: 'collection-refrence-disable',
      })}
      onDelIcon={() => ({
        className: 'collection-refrence-disable',
      })}
      className="collection-form-table"
      footer={() => <FormTableFooter columns={columns} />}
    />
  );
};

export default connect(
  ({ tableForm, serviceList, totalMoney, isReference, dataSource, maxPreMoney }) => ({
    tableForm,
    serviceList,
    dataSource,
    totalMoney,
    maxPreMoney,
    isReference,
  }),
)(ServiceForm);
