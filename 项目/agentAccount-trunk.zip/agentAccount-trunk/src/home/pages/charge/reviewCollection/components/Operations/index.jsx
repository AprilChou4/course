import React, { useMemo, useCallback } from 'react';
import { Button, ConfigProvider } from 'antd';
import { connect } from 'nuomi';
import { first, last } from 'lodash';
import { postMessageRouter } from '@utils';
import pubData from 'data';
import Iconfont from '@components/Iconfont';

import './style.less';

const Operations = ({ dispatch, receiveBillId, receiveBillIds, formValues }) => {
  // (750, '复核'), (751, '反复核'), (752, '快速核销');
  const userAuth = pubData.get('authority');
  const { checkStatus } = formValues;
  // 上一个是否禁用
  const prevDisabled = useMemo(() => {
    const firstId = first(receiveBillIds);
    return !receiveBillId || !firstId || firstId === receiveBillId;
  }, [receiveBillId, receiveBillIds]);

  // 下一个是否禁用
  const nextDisabled = useMemo(() => {
    const lastId = last(receiveBillIds);
    return !receiveBillId || !lastId || lastId === receiveBillId;
  }, [receiveBillId, receiveBillIds]);

  // 切换收款单 0=上一个； 1=下一个
  const switchReview = (status) => {
    const currentIndex = receiveBillIds.findIndex((val) => val === receiveBillId);
    const nextIndex = status === 1 ? currentIndex + 1 : currentIndex - 1;
    const nextReceiveBillId = receiveBillIds[nextIndex];
    dispatch({
      type: '$getDetail',
      payload: {
        receiveBillId: nextReceiveBillId,
      },
    });
  };

  // 复核
  const review = () => {
    dispatch({
      type: 'reviewReceiveBill',
      payload: {
        receiveId: receiveBillId,
      },
    });
  };
  // 反复核
  const reverseReview = () => {
    dispatch({
      type: 'reverseReviewReceiveBill',
      payload: {
        receiveId: receiveBillId,
      },
    });
  };

  // 跳转收款单列表
  const toList = useCallback(() => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/collectionList',
      },
    });
  }, []);
  return (
    <div styleName="charge-collection-operation">
      <ConfigProvider autoInsertSpaceInButton={false}>
        {userAuth[750] && checkStatus === 0 && (
          <Button type="primary" onClick={() => review(false)}>
            复核
          </Button>
        )}
        {userAuth[751] && checkStatus === 1 && (
          <Button type="primary" onClick={() => reverseReview(false)}>
            反复核
          </Button>
        )}
        <Button onClick={toList}>收款单列表</Button>
        {receiveBillIds && receiveBillIds.length > 1 && (
          <>
            <Button className="arrow-btn" disabled={prevDisabled} onClick={() => switchReview(0)}>
              <Iconfont code="&#xe6d9;" />
            </Button>
            <Button className="arrow-btn" disabled={nextDisabled} onClick={() => switchReview(1)}>
              <Iconfont code="&#xe611;" />
            </Button>
          </>
        )}
      </ConfigProvider>
    </div>
  );
};

export default connect(({ formValues, receiveBillId, receiveBillIds }) => ({
  formValues,
  receiveBillId,
  receiveBillIds,
}))(Operations);
