import { createServices } from '@utils';

export default createServices({
  getDetail: 'instead/v2/customer/receipt/receiveBill/get::get', // 查看收款单
  getReceiptType: 'instead/v2/user/basicSetting/receipt/type/query::get', // 获取收款方式列表
  getCustomer: 'instead/receipt/getCustomerList::get', // 获取客户
  getCharging: 'instead/contract/getChargingItem::get', // 获取服务项目
  getCustomerBillList: 'instead/v2/customer/receipt/shouldReceiveBill/listCustomerBillNO::get', // 获取客户对应的应收单
  getMaxMoney: 'instead/v2/customer/receipt/receiveBill/getPreReceiveMoney::get',
  reviewReceiveBill: 'instead/v2/customer/receipt/receiveBill/review::postJSON', // 收款单复核
  reverseReviewReceiveBill: 'instead/v2/customer/receipt/receiveBill/reverseReview::postJSON', // 收款单反复核
});
