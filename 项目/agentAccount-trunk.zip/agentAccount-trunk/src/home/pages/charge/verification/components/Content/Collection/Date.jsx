/**
 * 收款单制单日期
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { DatePicker } from 'antd';

const { RangePicker } = DatePicker;

const ReceivableDate = ({ status, collectionBillDate, dispatch }) => {
  const isView = status === 1;

  const handleChange = useCallback(
    (dates) => {
      dispatch({
        type: 'updateBillDate',
        payload: {
          collectionBillDate: dates,
        },
      });
    },
    [dispatch],
  );

  return (
    <>
      <span style={{ marginRight: 8 }}>制单日期:</span>
      <RangePicker
        style={{ width: 240 }}
        disabled={isView}
        value={collectionBillDate}
        onChange={handleChange}
      />
    </>
  );
};

export default connect(({ status, collectionBillDate }) => ({ status, collectionBillDate }))(
  ReceivableDate,
);
