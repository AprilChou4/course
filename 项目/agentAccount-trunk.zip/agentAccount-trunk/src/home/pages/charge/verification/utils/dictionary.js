/**
 * @object 数据字典
 */

const getData = (params) => {
  const map = {};
  params.list.forEach(({ value, name, label, data }) => {
    map[value] = data || name || label;
  });
  return { ...params, map };
};

// 核销条件
const matchType = {
  title: '核销条件',
  list: [
    {
      value: 0,
      name: '按单据',
    },
    {
      value: 1,
      name: '按服务类型',
    },
    {
      value: 2,
      name: '按服务项目',
    },
  ],
};

export default {
  matchType: getData(matchType),
};
