import React, { useEffect, useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { Form, Tooltip } from 'antd';
import GenFormItem from '@components/form/GenFormItem';
import AntdInput from '@components/input/AntdInput';
import AntdSelect from '@components/select/AntdSelect';
import SuperSelect from '@components/select/SuperSelect';
import LinkButton from '@components/buttons/LinkButton';
import Iconfont from '@components/Iconfont';

import { getSelectOptions, postMessageRouter } from '@utils';
import dictionary from '@pages/charge/verification/utils';
import styles from './styles.less';

// eslint-disable-next-line no-underscore-dangle
LinkButton.__ANT_BUTTON = true; // 解决Antd.Tooltip在Button是disabled时不消失的bug

const formItemStyle = { width: 190 };

const Left = ({ form, formInitialValues, customerList, status, dispatch }) => {
  form.getFieldDecorator('reviewBillId', {
    initialValue: formInitialValues.reviewBillId,
  });
  form.getFieldDecorator('srbIds', {
    initialValue: formInitialValues.srbIds,
  });

  const isView = status === 1; // 是否是查看状态

  const customerOptions = useMemo(
    () =>
      getSelectOptions(customerList, (item) => ({
        value: item.customerId,
        name: item.customerName,
      })),
    [customerList],
  );

  // 客户名称改变
  const handleCustomerIdChange = useCallback(
    (value) => {
      dispatch({
        type: '$query',
        payload: {
          customerId: value,
        },
      });
    },
    [dispatch],
  );

  const handleSetMatchOrder = useCallback(() => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/setting/business',
      },
    });
  }, []);

  // 更新form
  useEffect(() => {
    dispatch({
      type: 'updateForm',
      payload: { form },
    });
  }, [dispatch, form]);

  return (
    <Form layout="inline" className="form-hide-explain">
      <GenFormItem
        required
        form={form}
        label="客户名称"
        name="customerId"
        initialValue={formInitialValues.customerId}
        rules={[{ required: true, message: '请选择客户名称' }]}
      >
        <SuperSelect
          placeholder="请选择客户名称"
          defaultActiveFirstOption={false}
          style={formItemStyle}
          disabled={isView}
          onChange={handleCustomerIdChange}
        >
          {customerOptions}
        </SuperSelect>
      </GenFormItem>
      <GenFormItem
        form={form}
        label="核销条件"
        name="matchType"
        initialValue={formInitialValues.matchType}
      >
        <AntdSelect
          placeholder="请选择核销条件"
          disabled={isView}
          style={formItemStyle}
          dataSource={dictionary.matchType.list}
        />
      </GenFormItem>
      <GenFormItem
        form={form}
        label="核销单号"
        name="reviewBillNo"
        initialValue={formInitialValues.reviewBillNo}
      >
        <AntdInput disabled placeholder="-" style={formItemStyle} />
      </GenFormItem>
      <div className={styles.setting}>
        <Tooltip title="设置匹配顺序">
          <LinkButton disabled={isView} onClick={handleSetMatchOrder}>
            <Iconfont code="&#xee7e;" />
          </LinkButton>
        </Tooltip>
      </div>
    </Form>
  );
};

export default connect(({ status, formInitialValues, customerList }) => ({
  status,
  formInitialValues,
  customerList,
}))(Form.create()(Left));
