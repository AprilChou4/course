/**
 * 应收单制单日期
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { DatePicker } from 'antd';

const { RangePicker } = DatePicker;

const ReceivableDate = ({ status, receivableBillDate, dispatch }) => {
  const isView = status === 1;

  const handleChange = useCallback(
    (dates) => {
      dispatch({
        type: 'updateBillDate',
        payload: {
          receivableBillDate: dates,
        },
      });
    },
    [dispatch],
  );

  return (
    <>
      <span style={{ marginRight: 8 }}>制单日期:</span>
      <RangePicker
        style={{ width: 240 }}
        disabled={isView}
        value={receivableBillDate}
        onChange={handleChange}
      />
    </>
  );
};

export default connect(({ status, receivableBillDate }) => ({ status, receivableBillDate }))(
  ReceivableDate,
);
