/**
 * content为Table的Popover
 */
import React, { useState, useCallback, useMemo } from 'react';
import { Popover } from 'antd';
import AntdTable from '@components/table/AntdTable';
import Iconfont from '@components/Iconfont';

import styles from './style.less';

const PopoverTable = ({ tableProps, children, ...restProps }) => {
  const [visible, setVisible] = useState(false);

  const handleCancel = useCallback(() => {
    setVisible(false);
  }, []);

  const title = useMemo(
    () => (
      <div className="f-tar">
        <Iconfont code="&#xec95;" className={styles['btn-close']} onClick={handleCancel} />
      </div>
    ),
    [handleCancel],
  );

  const content = useMemo(
    () => (
      <AntdTable
        bordered
        emptyType="default"
        columnAutoMinWidth={100}
        pagination={false}
        scroll={{ y: 36 * 6 }}
        {...tableProps}
      />
    ),
    [tableProps],
  );

  const handleVisibleChange = useCallback((status) => {
    setVisible(status);
  }, []);

  return (
    <Popover
      arrowPointAtCenter
      trigger="click"
      overlayClassName={styles.overlay}
      title={title}
      content={content}
      visible={visible}
      onVisibleChange={handleVisibleChange}
      {...restProps}
    >
      {children}
    </Popover>
  );
};

export default PopoverTable;
