import React from 'react';

const Header = () => {
  return <div />;
};

export default Header;
