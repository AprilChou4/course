import React from 'react';

const Side = () => {
  return <div />;
};

export default Side;
