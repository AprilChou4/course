/**
 * 上传附件
 */
import React, { forwardRef, useCallback, useMemo } from 'react';
import { Upload, Button, Icon, message, Typography } from 'antd';
import cls from 'classnames';
import { Iconfont, ShowConfirm } from '@components';
import { get, validateArrayLength } from '@utils';
import styles from './style.less';

const { Text } = Typography;
const AccFileType = ['doc', 'docx', 'pdf', 'jpg', 'png', 'jpeg'];
const handleFileName = (name = '') => {
  let dotIndex = name.lastIndexOf('.');
  dotIndex = dotIndex > 0 ? dotIndex : name.length;
  return (
    <>
      <Text ellipsis title={name}>
        {name.slice(0, dotIndex)}
      </Text>
      {name.slice(dotIndex)}
    </>
  );
};

const UploadAttachment = forwardRef(({ value = [], onChange }, ref) => {
  // 上传前验证
  const handleBeforeUpload = useCallback(
    ({ name, size }, fileList) => {
      // 文件最多支持上传10个
      if (Number(validateArrayLength(value) + Number(validateArrayLength(fileList))) > 10) {
        message.warn('文件最多支持上传10个');
        return false;
      }
      // 验证文件格式
      const reg = new RegExp(`^.+.(${AccFileType.join('|')})$`);
      const isValidFormat = reg.test(name);
      if (!isValidFormat) {
        ShowConfirm({
          type: 'warning',
          title: '上传文件格式错误',
          content: `仅支持文档(doc 、docx、pdf)、图片(jpg、png、jpeg)`,
        });
        return false;
      }
      // 单个文件最大支持10M
      const isValidSize = size / 1024 / 1024 < 10;
      if (!isValidSize) {
        message.warn('单个文件最大支持10M');
        return false;
      }
      return true;
    },
    [value],
  );

  // 合并数据
  const mergeUploadList = useCallback(
    (data) => {
      onChange(value.concat(data));
    },
    [onChange, value],
  );

  const handleChange = useCallback(
    ({ file }) => {
      if (['done', 'error'].includes(file.status)) {
        const response = get(file, 'response', {});
        const hasError = response.status !== 200;
        if (hasError) {
          message.error(response.message || '上传失败!');
        }
        mergeUploadList({
          ...(response.data || {}),
          hasError,
        });
      }
    },
    [mergeUploadList],
  );

  // 移除文件
  const handleRemoveFile = useCallback(
    (file) => {
      onChange(value.filter((item) => item.filePath !== file.filePath));
    },
    [onChange, value],
  );

  const uploadResultContent = useMemo(
    () =>
      validateArrayLength(value) ? (
        <div className={styles.files}>
          {value.map((item) => {
            const { hasError } = item;
            return (
              <div
                key={item.filePath}
                className={cls(styles.file, {
                  [styles['file-success']]: !hasError,
                  [styles['file-error']]: hasError,
                })}
              >
                <Iconfont type="iconfujian" className={styles['icon-file']} />
                {handleFileName(item.fileName)}
                <Iconfont
                  type={hasError ? 'iconjingshi' : 'iconchenggong'}
                  className={styles['icon-result']}
                />
                <Iconfont
                  type="iconshanchu6"
                  className={styles['icon-remove']}
                  onClick={() => handleRemoveFile(item)}
                />
              </div>
            );
          })}
        </div>
      ) : null,
    [handleRemoveFile, value],
  );

  return (
    <>
      <Upload
        multiple
        name="file"
        accept={`.${AccFileType.join(',.')}`}
        showUploadList={false}
        beforeUpload={handleBeforeUpload}
        onChange={handleChange}
        action={`${basePath}instead/v2/customer/contract/uploadFile.do`}
      >
        <Button>
          <Icon type="upload" />
          上传附件
        </Button>
      </Upload>
      {uploadResultContent}
    </>
  );
});

export default UploadAttachment;
