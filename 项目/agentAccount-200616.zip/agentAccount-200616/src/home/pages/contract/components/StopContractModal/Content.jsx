import React, { forwardRef, useEffect, useImperativeHandle } from 'react';
import { useEffectOnce } from 'react-use';
import moment from 'moment';
import { Row, Form, DatePicker, Checkbox } from 'antd';
import { GenFormItem, Iconfont, LimitTextArea } from '@components';
import styles from './style.less';

const formItemLayout = {
  labelCol: {
    span: 5,
  },
  wrapperCol: {
    span: 19,
  },
};
const formItemStyle = {
  width: '100%',
};

const Content = forwardRef(({ form, form: { getFieldValue, setFieldsValue } }, ref) => {
  const terminateType = getFieldValue('terminateType');

  useEffectOnce(() => {
    // 设置初始值
    setFieldsValue({
      terminateDate: moment(),
    });
  });

  // 选中立即终止时，时间设置为当天
  useEffect(() => {
    terminateType &&
      setFieldsValue({
        terminateDate: moment(),
      });
  }, [setFieldsValue, terminateType]);

  // 传给父组件
  useImperativeHandle(ref, () => ({ form }), [form]);

  return (
    <>
      <div className={styles.title}>
        <Iconfont code="&#xeaa1;" />
        温馨提示：终止合同时会同步终止应收和收款业务！
      </div>
      <Form className={styles.form}>
        <Row>
          <GenFormItem
            form={form}
            required={false}
            label="终止服务至"
            name="terminateDate"
            rules={[
              {
                required: true,
                message: '请选择终止日期',
              },
            ]}
            className={styles.left}
          >
            <DatePicker
              placeholder="请选择终止日期"
              allowClear={false}
              style={formItemStyle}
              disabled={terminateType}
            />
          </GenFormItem>
          <GenFormItem
            form={form}
            name="terminateType"
            valuePropName="checked"
            className={styles.right}
          >
            <Checkbox>立即终止</Checkbox>
          </GenFormItem>
        </Row>
        <Row>
          <GenFormItem
            form={form}
            label="备注原因"
            name="terminateReason"
            rules={[{ max: 200, message: '最多200个字' }]}
            {...formItemLayout}
          >
            <LimitTextArea placeholder="请输入备注原因" rows={5} maxLength={200} />
          </GenFormItem>
        </Row>
      </Form>
    </>
  );
});

export default Form.create()(Content);
