import React, { forwardRef, useState, useEffect, useCallback, useImperativeHandle } from 'react';
import moment from 'moment';
import { Form, Radio } from 'antd';
import { GenFormItem } from '@components';
import { get } from '@utils';
import commonServices from '../../services';
import TimeSelect from './TimeSelect';
import styles from './style.less';

const { Group: RadioGroup } = Radio;
const dateFormat = 'YYYY-MM-DD';

const Content = forwardRef(
  ({ data: { contractId }, form, form: { getFieldValue, validateFields } }, ref) => {
    // 注册隐藏域
    form.getFieldDecorator('contractId', {
      initialValue: contractId,
    });

    const [contractInfo, setContractInfo] = useState({});

    const handleRadioChange = useCallback(() => {
      // 强制验证
      setTimeout(() => {
        validateFields(['extendMonth'], { force: true });
      });
    }, [validateFields]);

    const timeValidator = useCallback(
      (rule, value, callback) => {
        const renewType = getFieldValue('renewType');
        if (renewType === 0 && (!value || (!get(value, 'year') && !get(value, 'month')))) {
          callback('请选择时间');
        } else {
          callback();
        }
      },
      [getFieldValue],
    );

    const getContractInfo = useCallback(async () => {
      const info = await commonServices.getContractInfo({ contractId });
      setContractInfo(info || {});
    }, [contractId]);

    useEffect(() => {
      getContractInfo();
    }, [getContractInfo]);

    // 传给父组件
    useImperativeHandle(ref, () => ({ form }), [form]);

    return (
      <Form>
        <GenFormItem
          form={form}
          name="renewType"
          initialValue={0}
          rules={[
            {
              required: true,
              message: '请选择续签方式',
            },
          ]}
          className={styles.radioGroup}
        >
          <RadioGroup onChange={handleRadioChange}>
            <Radio value={0}>根据当前合同自动延长时间进行续签</Radio>
            <div className={styles.details}>
              <GenFormItem form={form} name="extendMonth" rules={[{ validator: timeValidator }]}>
                <TimeSelect data={{ contractInfo }} />
              </GenFormItem>
              <div>
                所有非周期性服务均按
                <span className={styles.date}>
                  {moment(contractInfo.endDate, 'X')
                    .add({ months: 1 })
                    .startOf('month')
                    .format(dateFormat)}
                </span>
                执行
              </div>
            </div>
            <Radio value={1}>基于当前合同信息手动有调整的进行续签</Radio>
          </RadioGroup>
        </GenFormItem>
      </Form>
    );
  },
);

export default Form.create()(Content);
