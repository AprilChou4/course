/**
 * 选择时间
 */
import React, { forwardRef, useCallback } from 'react';
import moment from 'moment';
import { AntdSelect } from '@components';
import styles from './style.less';

const dateFormat = 'YYYY-MM-DD';
const yearList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const monthList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

const TimeSelect = forwardRef(
  (
    {
      value = {},
      onChange,
      data: {
        contractInfo: { endDate },
      },
    },
    ref,
  ) => {
    const triggerChange = useCallback(
      (changedValue) => {
        onChange &&
          onChange({
            ...value,
            ...changedValue,
          });
      },
      [onChange, value],
    );

    const handleYearChange = useCallback(
      (val) => {
        triggerChange({ year: val });
      },
      [triggerChange],
    );

    const handleMonthChange = useCallback(
      (val) => {
        triggerChange({ month: val });
      },
      [triggerChange],
    );

    return (
      <div ref={ref} className={styles['time-select']}>
        所有周期性服务均延长
        <AntdSelect
          allowClear
          placeholder="0"
          className={styles.plain}
          dataSource={yearList}
          value={value.year}
          onChange={handleYearChange}
        />
        年
        <AntdSelect
          allowClear
          placeholder="0"
          dataSource={monthList}
          value={value.month}
          onChange={handleMonthChange}
        />
        月 至
        <span className={styles.date}>
          {moment(endDate || undefined, 'X')
            .add({ years: Number(value.year) || 0, months: Number(value.month) || 0 })
            .endOf('month')
            .format(dateFormat)}
        </span>
        日止
      </div>
    );
  },
);

export default TimeSelect;
