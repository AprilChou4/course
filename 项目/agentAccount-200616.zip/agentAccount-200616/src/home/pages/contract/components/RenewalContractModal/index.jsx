/**
 * 续签合同
 */
import React, { useCallback, useRef } from 'react';
import cls from 'classnames';
import { AntdModal } from '@components';
import Content from './Content';
import styles from './style.less';

const RenewalContractModal = ({ visible, onCancel, onOk, data, ...restProps }) => {
  const contentRef = useRef(null);

  const handleOk = useCallback(() => {
    onOk(contentRef.current);
  }, [onOk]);

  return (
    <AntdModal
      title="续签合同"
      width={580}
      getContainer={false}
      visible={visible}
      onCancel={onCancel}
      onOk={handleOk}
      {...restProps}
      className={cls('withForm', styles.modal)}
    >
      <Content wrappedComponentRef={contentRef} data={data} />
    </AntdModal>
  );
};

export default RenewalContractModal;
