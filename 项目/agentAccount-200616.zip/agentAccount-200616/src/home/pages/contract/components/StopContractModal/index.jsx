/**
 * 终止合同
 */
import React, { useCallback, useRef } from 'react';
import cls from 'classnames';
import { AntdModal } from '@components';
import Content from './Content';
import styles from './style.less';

const StopContractModal = ({ visible, onCancel, onOk, data, ...restProps }) => {
  const contentRef = useRef(null);

  const handleOk = useCallback(() => {
    onOk(contentRef.current);
  }, [onOk]);

  return (
    <AntdModal
      title="终止合同"
      width={440}
      getContainer={false}
      visible={visible}
      onCancel={onCancel}
      onOk={handleOk}
      {...restProps}
      className={cls('withForm', styles.modal)}
    >
      <Content wrappedComponentRef={contentRef} data={data} />
    </AntdModal>
  );
};

export default StopContractModal;
