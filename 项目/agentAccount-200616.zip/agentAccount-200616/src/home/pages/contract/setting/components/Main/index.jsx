import React from 'react';
import { Layout, ContentWrapper } from '@components';
import Title from '../Title';
import Content from '../Content';
import ContractClauseSetting from '../ContractClauseSetting';

const Main = () => {
  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title={<Title />}
        content={<Content />}
        contentStyle={{ padding: '6px 20px 0' }}
      />
      <ContractClauseSetting />
    </Layout.PageWrapper>
  );
};

export default Main;
