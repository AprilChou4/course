import React from 'react';
import { connect } from 'nuomi';
import { Checkbox, InputNumber } from 'antd';
import pubData from 'data';
import { If, LinkButton } from '@components';
import { isNil, postMessageRouter } from '@utils';
import Layouts from '../../Layouts';
import styles from '../style.less';

const userAuth = pubData.get('authority');
const operateAuth = !!userAuth[660];

const BasicSetting = ({
  enclosureUpload,
  electronicContract,
  contractClause,
  contractExpireRemind,
  expireDay,
  defaultExpireDay,
  dispatch,
}) => {
  const handleChange = (key, value) => {
    dispatch({
      type: 'handleContractSettingChange',
      payload: {
        [key]: value,
      },
    });
  };

  const handleETCContractClick = () => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/contractModel',
      },
    });
  };

  const handleContractClauseClick = () => {
    dispatch({
      type: 'updateContractClauseSetting',
      payload: {
        visible: true,
      },
    });
  };

  const handleExpireDayChange = (value) => {
    dispatch({
      type: 'updateSettingsState',
      payload: {
        expireDay: value,
      },
    });
  };

  const handleExpireDayBlur = (e) => {
    const { value } = e.target;
    if (Number(value) !== Number(defaultExpireDay)) {
      handleChange('expireDay', value);
    }
  };

  return (
    <Layouts
      title="基本设置"
      content={
        <>
          <div className={styles.item}>
            <Checkbox
              checked={!!enclosureUpload}
              onChange={(e) => handleChange('enclosureUpload', e.target.checked)}
              disabled={!operateAuth}
            >
              上传附件
            </Checkbox>
            <span className={styles.subTitle}>
              勾选上传附件，在新增合同时可上传附件；取消勾选则新增时无法上传附件
            </span>
          </div>
          <div className={styles.item}>
            <Checkbox
              checked={!!electronicContract}
              onChange={(e) => handleChange('electronicContract', e.target.checked)}
              disabled={!operateAuth}
            >
              电子合同模板
            </Checkbox>
            <span className={styles.subTitle}>
              设置电子合同模版，可以在创建合同时引用，生成电子合同，方便打印、归档等
            </span>
            <LinkButton
              onClick={handleETCContractClick}
              disabled={!(userAuth[661] && userAuth[662])}
            >{`合同模板设置>>`}</LinkButton>
          </div>
          <div className={styles.item}>
            <Checkbox
              checked={!!contractClause}
              onChange={(e) => handleChange('contractClause', e.target.checked)}
              disabled={!operateAuth}
            >
              合同条款
            </Checkbox>
            <LinkButton
              onClick={handleContractClauseClick}
              disabled={!operateAuth}
            >{`合同条款配置>>`}</LinkButton>
          </div>
          <div className={styles.item}>
            <Checkbox
              checked={!!contractExpireRemind}
              onChange={(e) => handleChange('contractExpireRemind', e.target.checked)}
              disabled={!operateAuth}
            >
              合同到期前提醒
            </Checkbox>
            <span className={styles.subTitle}>设置到期前提醒，可以在合同到期前收到提示</span>
          </div>
          <If condition={contractExpireRemind}>
            <div className={styles.subItem}>
              到期前：
              <InputNumber
                placeholder="0"
                min={0}
                style={{ width: 80 }}
                value={isNil(expireDay) ? undefined : expireDay}
                onChange={handleExpireDayChange}
                onBlur={handleExpireDayBlur}
                disabled={!operateAuth}
              />
              天提醒
            </div>
          </If>
        </>
      }
    />
  );
};

export default connect(
  ({
    settings: {
      enclosureUpload,
      electronicContract,
      contractClause,
      contractExpireRemind,
      expireDay,
    },
    defaultSettings: { expireDay: defaultExpireDay },
  }) => ({
    enclosureUpload,
    electronicContract,
    contractClause,
    contractExpireRemind,
    expireDay,
    defaultExpireDay,
  }),
)(BasicSetting);
