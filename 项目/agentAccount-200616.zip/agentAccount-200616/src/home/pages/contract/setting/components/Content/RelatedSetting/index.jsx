/* eslint-disable no-nested-ternary */
import React from 'react';
import { connect } from 'nuomi';
import { Checkbox } from 'antd';
import pubData from 'data';
import Layouts from '../../Layouts';
import styles from '../style.less';

const userAuth = pubData.get('authority');
const operateAuth = !!userAuth[660];

const RelatedSetting = ({ contractCreateSrbBill, dispatch }) => {
  const handleChange = (key, value) => {
    dispatch({
      type: 'handleContractSettingChange',
      payload: {
        [key]: value,
      },
    });
  };

  return (
    <Layouts
      title="关联设置"
      content={
        <>
          <div className={styles.item}>
            <Checkbox
              checked={!!contractCreateSrbBill}
              onChange={(e) => handleChange('contractCreateSrbBill', e.target.checked)}
              disabled={!operateAuth}
            >
              生成应收单
            </Checkbox>
            <span className={styles.subTitle}>
              勾选生成应收单，将在新增合同时自动生成应收单；取消勾选则不自动生成
            </span>
          </div>
          {/* <div className={styles.item}>
            <Checkbox
              checked={!!contractCreateTaskBill}
              onChange={(e) => handleChange('contractCreateTaskBill', e.target.checked)}
              disabled={!operateAuth}
            >
              生成任务单
            </Checkbox>
            <span className={styles.subTitle}>
              勾选生成任务单，将在新增合同时自动生成任务单；取消勾选则不自动生成
            </span>
          </div> */}
        </>
      }
    />
  );
};

export default connect(({ settings: { contractCreateSrbBill } }) => ({
  contractCreateSrbBill,
}))(RelatedSetting);
