import React from 'react';
import { connect } from 'nuomi';
import styles from './style.less';

const Header = ({ title }) => {
  return (
    <div className={styles.box}>
      {title}
      <span className={styles.subTitle}>（设置后立即生效）</span>
    </div>
  );
};

export default connect(({ title }) => ({ title }))(Header);
