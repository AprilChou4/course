/**
 * 合同条款配置
 */
import React, { useCallback, useRef } from 'react';
import { connect } from 'nuomi';
import cls from 'classnames';
import { AntdModal } from '@components';
import Content from './Content';
import styles from './style.less';

const ContractClauseSetting = ({ visible, status, dispatch }) => {
  const contentRef = useRef(null);

  const handleCancel = () => {
    dispatch({
      type: 'hideContractClauseSetting',
    });
  };

  const handleOk = useCallback(() => {
    const { form } = contentRef.current;
    form.validateFields((err, { contractClauseId, title, content }) => {
      if (err) return;
      if (status === 0) {
        // 新增
        dispatch({
          type: 'addContractClause',
          payload: {
            title,
            content,
          },
        });
      } else {
        // 编辑
        dispatch({
          type: 'updateContractClause',
          payload: {
            contractClauseId,
            content,
          },
        });
      }
    });
  }, [dispatch, status]);

  return (
    <AntdModal
      title="合同条款配置"
      width={700}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      onOk={handleOk}
      className={cls('withForm', styles.modal)}
    >
      <Content wrappedComponentRef={contentRef} />
    </AntdModal>
  );
};

export default connect(({ contractClauseSetting: { visible, data: { status } } }) => ({
  visible,
  status,
}))(ContractClauseSetting);
