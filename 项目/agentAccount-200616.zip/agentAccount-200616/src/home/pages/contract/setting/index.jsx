/**
 * 合同管理-业务设置
 */
import React from 'react';
import pubData from 'data';
import { NoAuthPage } from '@components';
import Main from './components/Main';
import effects from './effects';

const userAuth = pubData.get('authority');
const initContractClauseSettingData = {
  status: 1, // 状态：0：新增，1：查看
  contractClauseList: [], // 合同条款列表
  form: {},
};

export default {
  id: 'contractSetting',
  state: {
    title: '业务设置',
    // 所有设置
    settings: {
      // 附件是否要上传
      enclosureUpload: false,
      // 是否需要电子合同
      electronicContract: false,
      // 是否添加合同条款
      contractClause: false,
      // 是否合同到期前提醒
      contractExpireRemind: false,
      // 合同到期前提醒的天数
      expireDay: undefined,
      // 合同创建是否生成应收单
      contractCreateSrbBill: false,
      // 合同创建是否生成任务单
      // contractCreateTaskBill: false,
    },
    // 页面源数据备份
    defaultSettings: {},
    // 合同条款配置弹窗
    contractClauseSetting: {
      visible: false,
      clausekey: 'contractClauseId', // 合同条款列表的key
      initData: initContractClauseSettingData, // 弹窗内部初始状态
      data: initContractClauseSettingData, // 弹窗内部状态
    },
  },
  effects,
  render() {
    // 控制查看权限
    return userAuth[659] ? <Main /> : <NoAuthPage />;
  },
  onChange() {
    // 控制查看权限
    if (!userAuth[659]) return;

    this.store.dispatch({
      type: 'query',
    });
  },
};
