import React, { forwardRef, useEffect, useCallback, useMemo, useImperativeHandle } from 'react';
import { connect } from 'nuomi';
import { Form, Row } from 'antd';
import {
  If,
  GenFormItem,
  SuperSelect,
  LinkButton,
  ShowConfirm,
  LimitInput,
  LimitTextArea,
} from '@components';
import { get, getSelectOptions } from '@utils';
import styles from './style.less';

const formItemStyle = { width: '100%' };

const formItemLayout = {
  labelCol: {
    span: 3,
  },
  wrapperCol: {
    span: 21,
  },
};

const Content = forwardRef(
  (
    {
      form,
      form: { getFieldValue, setFieldsValue },
      clausekey,
      status,
      contractClauseList,
      dispatch,
    },
    ref,
  ) => {
    // 完成人下拉框列表
    const contractClauseOptions = useMemo(
      () =>
        getSelectOptions(contractClauseList, (item) => ({
          value: item[clausekey],
          name: item.title,
        })),
      [clausekey, contractClauseList],
    );
    const contractClauseId = getFieldValue('contractClauseId');

    // 当前选中的合同条款
    const curSelectedNode = useMemo(
      () => contractClauseList.find((item) => item[clausekey] === contractClauseId) || {},
      [clausekey, contractClauseList, contractClauseId],
    );

    // 删除条款
    const handleDelete = () => {
      dispatch({
        type: 'deleteContractClause',
        payload: {
          contractClauseId: getFieldValue('contractClauseId'),
        },
      });
    };

    // 添加条款
    const handleAdd = () => {
      dispatch({
        type: 'updateContractClauseSettingData',
        payload: {
          status: 0,
        },
      });
      setFieldsValue({
        content: undefined,
      });
    };

    // 切换合同条款
    const handleContractClauseChange = useCallback(
      (value, option) => {
        const lastContractClauseId = getFieldValue('contractClauseId'); // 之前的选项

        // 切换条款后的变化
        const afterChange = () => {
          const dataref = get(option, 'props.dataref', {});
          setFieldsValue({
            content: dataref.content,
          });
          dispatch({
            type: 'updateContractClauseSettingData',
            payload: {
              status: 1,
            },
          });
        };

        // 如果当前正在新增，要提示确认
        if (status === 0) {
          ShowConfirm({
            title: '当前条款未保存，确定进行其他操作？',
            onCancel() {
              // 重置上个选项
              setFieldsValue({
                contractClauseId: lastContractClauseId,
              });
            },
            onOk() {
              afterChange();
            },
          });
        } else {
          afterChange();
        }
      },
      [dispatch, getFieldValue, setFieldsValue, status],
    );

    // 传给父组件
    useImperativeHandle(ref, () => ({ form }), [form]);

    useEffect(() => {
      setTimeout(() => {
        dispatch({
          type: 'getContractClauseList',
          payload: {
            init: true,
          },
        });
      });
    }, [dispatch]);

    useEffect(() => {
      dispatch({
        type: 'updateContractClauseSettingData',
        payload: {
          form,
        },
      });
    });

    return (
      <Form>
        <Row>
          <GenFormItem form={form} label="条款名称" name="contractClauseId" className={styles.name}>
            <SuperSelect
              placeholder="请选择条款名称"
              style={formItemStyle}
              onChange={handleContractClauseChange}
            >
              {contractClauseOptions}
            </SuperSelect>
          </GenFormItem>
          <div className={styles.operations}>
            {status === 0 ? (
              <GenFormItem
                form={form}
                name="title"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: '条款名称不能为空',
                  },
                  { max: 15, message: '最多15个字' },
                ]}
              >
                <LimitInput
                  allowClear
                  placeholder="请输入条款名称"
                  style={formItemStyle}
                  maxLength={15}
                />
              </GenFormItem>
            ) : (
              <>
                <If condition={curSelectedNode.isSys === 0}>
                  <LinkButton onClick={handleDelete}>x 删除条款</LinkButton>
                </If>
                <LinkButton onClick={handleAdd}>+ 添加条款</LinkButton>
              </>
            )}
          </div>
        </Row>
        <Row>
          <GenFormItem
            form={form}
            label="条款内容"
            name="content"
            rules={[
              {
                required: true,
                whitespace: true,
                message: '条款内容不能为空',
              },
              { max: 3000, message: '最多3000个字' },
            ]}
            {...formItemLayout}
          >
            <LimitTextArea placeholder="请输入条款内容" rows={16} maxLength={3000} />
          </GenFormItem>
        </Row>
      </Form>
    );
  },
);

export default connect(
  ({
    contractClauseSetting: {
      clausekey,
      data: { status, contractClauseList },
    },
  }) => ({
    clausekey,
    status,
    contractClauseList,
  }),
)(Form.create()(Content));
