import React from 'react';
import BasicSetting from './BasicSetting';
import RelatedSetting from './RelatedSetting';

const Content = () => {
  return (
    <>
      <BasicSetting />
      <RelatedSetting />
    </>
  );
};

export default Content;
