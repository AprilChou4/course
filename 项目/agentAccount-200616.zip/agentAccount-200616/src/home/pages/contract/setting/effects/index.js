/* eslint-disable no-nested-ternary */
import { validateArrayLength } from '@utils';
import globalServices from '@home/services';
import services from '../services';

export default {
  // 合同业务设置查询
  async query() {
    const data = await globalServices.getContractSetting();
    this.updateState({
      settings: data || {},
      defaultSettings: data || {},
    });
  },

  // 更新前端状态
  updateSettingsState(payload = {}) {
    const { settings } = this.getState();
    this.updateState({
      settings: {
        ...settings,
        ...payload,
      },
    });
  },

  // 设置改变的回调
  handleContractSettingChange(payload = {}) {
    const data = {};
    for (const [key, value] of Object.entries(payload)) {
      data[key] = key === 'expireDay' ? value || 0 : value ? 1 : 0;
    }
    this.updateContractSetting(data);
  },

  // 合同业务设置更新
  async updateContractSetting(payload = {}) {
    const { settings } = this.getState();
    const params = { ...settings, ...payload };
    await services.updateContractSetting(params, { successMsg: '保存成功' });
    this.query();
  },

  // 查询合同条款数据
  async getContractClauseList(payload = {}) {
    const {
      contractClauseSetting: {
        clausekey,
        data: { form },
      },
    } = this.getState();
    const { init, ...rest } = payload;
    const list = await globalServices.getContractClauseList();
    this.updateContractClauseSettingData({
      status: 1,
      contractClauseList: list,
      ...rest,
    });
    if (init && validateArrayLength(list)) {
      form.setFieldsValue({
        contractClauseId: list[0][clausekey],
        content: list[0].content,
      });
    }
  },
  // 更新合同条款配置
  updateContractClauseSetting(payload = {}) {
    const { contractClauseSetting } = this.getState();
    this.updateState({
      contractClauseSetting: {
        ...contractClauseSetting,
        ...payload,
      },
    });
  },
  // 更新合同条款配置状态
  updateContractClauseSettingData(payload = {}) {
    const { contractClauseSetting } = this.getState();
    this.updateState({
      contractClauseSetting: {
        ...contractClauseSetting,
        data: {
          ...contractClauseSetting.data,
          ...payload,
        },
      },
    });
  },
  // 隐藏合同条款配置弹窗
  hideContractClauseSetting() {
    const {
      contractClauseSetting: { initData },
    } = this.getState();
    this.updateContractClauseSetting({
      visible: false,
      data: initData,
    });
  },

  // 添加合同条款
  async addContractClause(payload = {}) {
    const {
      contractClauseSetting: {
        data: { form },
      },
    } = this.getState();
    const data = await services.addContractClause(payload, { successMsg: '添加成功' });
    await this.getContractClauseList();
    form.setFieldsValue({
      contractClauseId: data,
    });
  },

  // 编辑合同条款
  async updateContractClause(payload = {}) {
    await services.updateContractClause(payload, { successMsg: '保存成功' });
    this.getContractClauseList();
  },

  // 删除合同条款
  async deleteContractClause(payload = {}) {
    await services.deleteContractClause(payload, { successMsg: '删除成功' });
    // 删除后要查询条款列表并选中第一条
    this.getContractClauseList({ init: true });
  },
};
