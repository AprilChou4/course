import React from 'react';
import cls from 'classnames';
import { Layout } from '@components';
import styles from './style.less';

const { Left, BFCContent } = Layout;

const Layouts = ({ title, content }) => {
  return (
    <div className={styles.container}>
      <Left className={cls('t-bold', styles.sider)}>{title}</Left>
      <BFCContent className={styles.content}>{content}</BFCContent>
    </div>
  );
};

export default Layouts;
