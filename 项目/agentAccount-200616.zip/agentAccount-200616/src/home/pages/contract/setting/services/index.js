// import mock from './mock';
import { createServices } from '@utils';

export default createServices({
  // ...mock,
  updateContractSetting: 'instead/v2/customer/contractSet/update::postJSON', // 合同业务设置更新
  addContractClause: 'instead/v2/customer/contractSet/addContractClause::postJSON', // 添加合同条款
  updateContractClause: 'instead/v2/customer/contractSet/updateContractClause::postJSON', // 更新合同条款
  deleteContractClause: 'instead/v2/customer/contractSet/deleteContractClause::postJSON', // 删除合同条款
});
