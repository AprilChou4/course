import React from 'react';

const HeaderLeft = () => {
  return null;
};

export default HeaderLeft;
