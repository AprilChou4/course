import React from 'react';
import { Layout, ContentWrapper } from '@components';
import Title from '../Title';
import HeaderRight from '../Header/Right';
import Content from '../Content';
import Footer from '../Footer';
import StopContract from '../StopContract';
import RenewalContract from '../RenewalContract';
import PreviewFileModal from '../PreviewFileModal';

const Main = () => {
  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title={<Title />}
        header={{
          right: <HeaderRight />,
        }}
        content={<Content />}
        footer={<Footer />}
      />
      <StopContract />
      <RenewalContract />
      <PreviewFileModal />
    </Layout.PageWrapper>
  );
};

export default Main;
