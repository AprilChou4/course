/**
 * 新增合同
 */
import React from 'react';
import { router } from 'nuomi';
import moment from 'moment';
import pubData from 'data';
import { NoAuthPage } from '@components';
import Main from './components/Main';
import effects from './effects';

const userName = pubData.get('userInfo_realName');
const staffId = pubData.get('userInfo_staffId');
const userAuth = pubData.get('authority');

const getAuth = () => {
  // 要实时获取，拿到最新的pathname
  const { pathname } = router.location();
  const authMap = {
    '/contract/add': 14,
    '/contract/edit': 493,
    '/contract/renewal': 15,
    '/contract/view': true,
  };
  return authMap[pathname] === true ? true : userAuth[authMap[pathname]];
};
const defaultFormInitialValues = {
  signUserStaffId: staffId, // 签单人：当前登录用户
  payType: 0, // 收款方式：预收
  settlementMethod: 1, // 结算方式：月结
  signDate: moment().startOf('day'), // 签订时间：当前日期
  startDate: moment().startOf('day'), // 开始日期：当前日期
  createStaffName: userName, // 创建人：当前登录用户
  createDate: moment().format('X'), // 创建日期：当前日期
};

export default {
  id: 'contractAdd',
  state: {
    title: '云代账合同',
    // 页面状态(0：新增，1：变更，2：续签，3：查看)
    status: 0,
    // 主页面的form
    form: undefined,
    // form初始值
    defaultFormInitialValues,
    formInitialValues: defaultFormInitialValues,
    // 当前合同详情
    contractInfo: {},
    // 客户列表
    customerList: [],
    // 业务员列表
    businessStaffList: [],
    // 电子合同模板列表
    ETCContractTemplateList: [],
    // 合同条款列表
    contractClauseList: [],
    // 合同操作记录
    contractOperateLog: [],
    // 服务类型
    serviceItemsList: [],
    // 是否允许上传附件
    enclosureUpload: false,
    // 是否生成电子合同
    isElectronicContract: false,
    // 是否添加合同条款
    isContractClause: false,
    // 是否自动生成应收单
    isCreateSrbBill: false,
    // 是否自动生成工商任务单
    isCreateTaskBill: false,
    // 表格行的key
    tableRowKey: 'itemOrder',
    // 表格行key叠加器
    tableRowKeyCounter: 2,
    // 服务项目表格
    tableData: [{ itemOrder: 0 }, { itemOrder: 1 }, { itemOrder: 2 }],
    // 表格金额合计
    tableSumMoney: 0,
    // 服务项目表格验证
    tableValidate: false,
    // 终止合同弹窗
    stopModal: {
      visible: false,
      data: {},
    },
    // 续签合同弹窗
    renewalModal: {
      visible: false,
      data: {},
    },
    // 合同附件预览弹窗
    previewFileModal: {
      visible: false,
    },
  },
  effects,
  render() {
    // 控制查看权限
    return getAuth() ? <Main /> : <NoAuthPage />;
  },
  onChange: {
    // 这里加上$让它在初始化的时候不执行，initData里再手动的去执行 query，否则 initData中无法拿到 query中请求得到的数据
    $query() {
      // 控制查看权限
      if (!getAuth()) return;

      this.store.dispatch({
        type: 'initData',
      });
    },
  },
  onInit() {
    // 控制查看权限
    if (!getAuth()) return;

    this.store.dispatch({
      type: 'initData',
      payload: true,
    });
  },
};
