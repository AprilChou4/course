/* eslint-disable no-nested-ternary */
/* eslint-disable no-param-reassign */
import { router } from 'nuomi';
import moment from 'moment';
import produce from 'immer';
import { message } from 'antd';
import pubData from 'data';
import { ShowConfirm } from '@components';
import {
  get,
  util,
  flatMap,
  filter,
  map,
  repeat,
  isNil,
  omit,
  omitBy,
  validateArrayLength,
  handleRouterChange,
  postMessageRouter,
} from '@utils';
import globalServices from '@home/services';
import commonServices from '../../services';
import { dictionary, cycleRequiredFields, noCycleRequiredFields } from '../../utils';

const userAuth = pubData.get('authority');
const dateFormat = 'YYYY-MM-DD';
const monthFormat = 'YYYY-MM';
const unitList = ['次', '月', '季', '半年', '年', '张'];
const payCycleList = ['次付', '月付', '季付', '半年', '年付', '张付'];
// 付款方式
const payType = [
  {
    value: 0,
    name: '预付',
  },
  {
    value: 1,
    name: '后付',
  },
];

export default {
  async initData(init) {
    const {
      status,
      formInitialValues: { contractId, contractNo },
    } = this.getState();
    const { id } = router.location().query || {};
    // 临时数据不适合放到url上，放到pubData上取完后销毁
    const isAddNew = pubData.get('contractAdd-new');
    const isEditNew = pubData.get('contractEdit-new');
    const isRenewalNew = pubData.get('contractRenewal-new');
    pubData.set('contractAdd-new', undefined);
    pubData.set('contractEdit-new', undefined);
    pubData.set('contractRenewal-new', undefined);
    // 是否是初始状态
    const isInit = init || isAddNew || isEditNew || isRenewalNew || status === 3;

    if (status === 0) {
      // 新增
      if (isInit) {
        this.initAddContract({ contractNo });
      }
    } else {
      // 查看/变更/续签
      // FIXME: 是否可以放到query中
      // 这里先拿到id放到formInitialValues中，后面无论是新增还是查看统一从formInitialValues中取，因为新增页面也可能是查看状态但是url中没有id
      this.updateFormInitialValues({ contractId: (id ? Number(id) : '') || contractId });

      if (status === 1) {
        // 变更
      } else if (status === 2) {
        // 续签
        if (isEditNew) {
          this.setFormInitialValues({
            contractNo: undefined,
          });
        }
      } else if (status === 3) {
        // 查看
        if (isAddNew) {
          // 代表是“新增合同”页面，但是已经新增完了，是查看状态
          this.updateState({ status: 0 });
          this.initAddContract();
        }
      }
    }
    // 等待form的value重置
    setTimeout(() => {
      this.query(isInit);
    });
  },

  // 查询
  async query(init) {
    const {
      status,
      formInitialValues: { contractId, contractNo },
    } = this.getState();

    // 获取客户列表
    this.getCustomerList();
    // 获取业务员列表
    this.getBusinessStaffList();
    // 获取服务项目列表
    this.getServiceItems();
    // 合同设置查询
    this.getContractSetting();
    // 获取电子合同模板列表
    this.getETCContractTemplateList();
    // 获取合同条款列表
    this.getContractClauseList();

    if (status !== 0) {
      await this.getContractInfo({ id: contractId, init });
      // 续签页面首次进来时重新获取合同编号
      if (status === 2) {
        this.setFormInitialValues({
          contractNo: init ? undefined : contractNo,
        });
      }
    }
  },

  // 新增合同初始化
  async initAddContract(payload = {}) {
    const { tableRowKey, defaultFormInitialValues } = this.getState();
    // 重置redux
    this.updateState({
      tableRowKeyCounter: 2,
      tableData: [{ [tableRowKey]: 0 }, { [tableRowKey]: 1 }, { [tableRowKey]: 2 }],
      tableSumMoney: 0,
      tableValidate: false,
    });
    // form重新设置初始值
    this.setFormInitialValues({ ...defaultFormInitialValues, init: true, ...payload });
  },

  // 查看合同初始化
  async initViewContractInfo(payload = {}) {
    const { id } = payload;
    // const { formInitialValues } = this.getState();
    // 代表是查看收款单
    await this.getContractInfo({ id, init: true });
  },

  // form重新设置初始值
  async setFormInitialValues(payload = {}) {
    this.updateFormInitialValues(payload);
    if (!payload.contractNo) {
      await this.getContractNo();
    }
  },

  // 更新form初始值
  updateFormInitialValues(payload = {}) {
    const that = this;
    const { init, ...rest } = payload;
    const { form, formInitialValues = {} } = this.getState();
    that.updateState({
      formInitialValues: {
        ...(init ? {} : formInitialValues),
        ...rest,
      },
    });
    init && form && form.resetFields();
  },

  // 点新增时重置应收单
  handleNewContract() {
    this.initAddContract();
    this.updateState({
      status: 0,
    });
  },

  // 获取单据编号
  async getContractNo() {
    const data = await commonServices.getContractNo();
    this.updateFormInitialValues({
      contractNo: data,
    });
  },

  // -------------------
  // 保存应收单
  async handleSaveContract(payload = {}) {
    const that = this;
    const { toNew } = payload;
    const { form, tableData, tableRowKey, tableSumMoney } = this.getState();

    form &&
      form.validateFields(async (err, values) => {
        this.updateState({
          tableValidate: true,
        });
        if (err) return;

        // 清除空值和无用值
        const formValues = omitBy(values, (val) => isNil(val, ''));

        let tableDataValidate = 1; // table的验证状态

        const realTableData = tableData.filter((item) => {
          const requiredFields = item.isCycle ? cycleRequiredFields : noCycleRequiredFields; // 必填值的数量

          const realData = omit(item, [
            tableRowKey,
            'serviceTypeId',
            'freePeriodNum',
            'isCycle',
            'serviceItemDates',
          ]);

          if (
            realData.serviceItemId &&
            requiredFields.some((val) => {
              const result = isNil(realData[val], '');
              if (result) {
                console.log('缺少必填字段:', val);
              }
              return result;
            })
          ) {
            tableDataValidate = 0;
          }

          return !!item.serviceItemId;
        });

        if (!tableDataValidate) {
          message.warning('服务项目不完整');
          return;
        }

        // 提交前验证金额合计
        if (
          tableSumMoney &&
          Number(tableSumMoney).toFixed(2) !== Number(formValues.contractMoney || 0).toFixed(2)
        ) {
          ShowConfirm({
            title: '总金额与服务项目合计金额不相等',
            content: '是否把总金额改为与合计金额相等？',
            cancelText: '否',
            okText: '是',
            onOk() {
              that.saveContract({
                formValues: {
                  ...formValues,
                  contractMoney: tableSumMoney,
                },
                realTableData,
                toNew,
              });
            },
          });
          return;
        }

        this.saveContract({
          formValues,
          realTableData,
          toNew,
        });
      });
  },

  async saveContract(payload = {}) {
    const { status, formInitialValues, isElectronicContract } = this.getState();
    const { formValues, realTableData, toNew } = payload;
    const formSettlementMethodCycle = formValues.settlementMethod !== 0;

    // 每个页面状态对应的保存接口
    const serviceType = { 0: 'addContract', 1: 'updateContract', 2: 'renewalContract' };
    let earliestStartDate = formValues.startDate
      ? formValues.startDate.startOf('month')
      : undefined; // 最早的开始日期
    let lastEndDate = formValues.endDate
      ? formSettlementMethodCycle
        ? formValues.endDate.endOf('month')
        : formValues.endDate.endOf('day')
      : undefined; // 最晚的结束日期

    // 保存后的页面状态
    let nextStatus = {
      0: toNew ? 0 : 3,
      1: 1,
      2: 2,
      3: 3,
    }[status];
    nextStatus = isNil(nextStatus) ? status : nextStatus;

    // 如果table有数据，上方的开始时间取table中的最小值，结束时间取table中的最大值
    const contractServiceItems =
      realTableData && realTableData.length
        ? realTableData.map(({ itemOrder, serviceTypeId, startDate, endDate, ...rest }, index) => {
            const servicePeriodNum = rest.isCycle ? rest.servicePeriodNum : 0;
            const freePeriodNum = rest.isCycle ? rest.freePeriodNum : 0;
            const eDate = rest.isCycle ? (endDate ? endDate.endOf('month') : undefined) : endDate;
            const sDate = rest.isCycle
              ? startDate
                ? startDate.startOf('month')
                : undefined
              : eDate;
            if (sDate) {
              earliestStartDate = index === 0 ? sDate : moment.min(earliestStartDate, sDate);
            }
            if (eDate) {
              lastEndDate = index === 0 ? eDate : moment.max(lastEndDate, eDate);
            }
            return omitBy(
              {
                ...rest,
                startDate: sDate ? sDate.format('X') : undefined,
                endDate: eDate ? eDate.format('X') : undefined,
                servicePeriodNum,
                freePeriodNum,
              },
              (val, key) => isNil(val, '') || ['isCycle', 'serviceItemDates'].includes(key),
            );
          })
        : undefined;

    const endDate = lastEndDate;
    const startDate = earliestStartDate || endDate;
    // const startDate =
    //   formSettlementMethodCycle || validateArrayLength(contractServiceItems)
    //     ? earliestStartDate
    //     : endDate;

    // 组装附件数据
    const contractFiles = validateArrayLength(formValues.contractFiles)
      ? formValues.contractFiles.filter((item) => !item.hasError)
      : undefined;

    const param = {
      ...formValues,
      // customerId:
      //   formValues.customerId === formInitialValues.customerName
      //     ? formInitialValues.initCustomerId
      //     : formValues.customerId,
      // signUserStaffId:
      //   formValues.signUserStaffId === formInitialValues.signUserName
      //     ? formInitialValues.initSignUserStaffId
      //     : formValues.signUserStaffId,
      signDate: formValues.signDate ? formValues.signDate.format('X') : undefined,
      startDate: startDate ? startDate.format('X') : undefined,
      endDate: endDate ? endDate.format('X') : undefined,
      validPeriodNum: formSettlementMethodCycle ? endDate.diff(startDate, 'month') + 1 : 1,
      contractFiles,
      contractServiceItems,
      // 是否生成应收单
      isCreateSrbBill: formValues.isCreateSrbBill ? 1 : 0,
      // 是否生成任务单
      isCreateTaskBill: formValues.isCreateTaskBill ? 1 : 0,
      // 续签类型
      renewType: status === 2 ? 1 : undefined,
    };

    let { electronicContract } = formInitialValues;
    if (!electronicContract && isElectronicContract) {
      electronicContract = await this.createElectronicContract({ contractData: param });
    }
    electronicContract = electronicContract
      ? {
          ...electronicContract,
          content: util.utf8_to_b64(
            util.createBraftEditorContentPage({
              content: electronicContract.content,
            }),
          ),
        }
      : undefined;

    const params = { ...param, electronicContract };

    // console.log('form.startDate传参', startDate ? startDate.format('YYYY-MM-DD') : undefined);
    // console.log('form.endDate传参', endDate ? endDate.format('YYYY-MM-DD') : undefined);
    // const isEdit = !!formValues.contractId;
    const successMsg = {
      0: '新增成功',
      1: `变更成功${!isNil(formInitialValues.srbId) ? '，并已同步变更相对应的应收单' : ''}`,
      2: '续签成功',
    };

    const resData = await commonServices[serviceType[status]](params, {
      loading: '正在保存...',
      successMsg: successMsg[status],
    });
    this.updateState({
      status: nextStatus,
      tableValidate: false,
    });
    if (toNew) {
      // 保存并新增
      this.handleNewContract();
    } else {
      const nextContractId = resData || params.contractId;
      if ([1, 2].includes(status)) {
        // 变更/续签成功后 跳转掉查看页面
        userAuth[13] &&
          postMessageRouter({
            type: 'agentAccount/routerLocation',
            payload: {
              url: '/contract/view',
              query: { id: nextContractId },
            },
          });
      }
      await this.initViewContractInfo({
        id: nextContractId,
      });
      // 续签成功后获取新的合同编号
      if (status === 2) {
        this.setFormInitialValues({
          contractNo: undefined,
        });
      }
    }
  },

  // tableData改变时组装数据
  async handleTableData(contractServiceItems) {
    const { status, tableRowKey, tableRowKeyCounter, serviceItemsList } = this.getState();
    const isRenewal = status === 2; // 是否是续签页面
    let newCount = tableRowKeyCounter;

    const sourceTableData = validateArrayLength(contractServiceItems) ? contractServiceItems : [];

    // 获取客户对应服务项目已经添加过的服务期间
    let serviceItemSamePeriod = [];
    if (sourceTableData.length) {
      const period = await this.getServiceItemSamePeriod({
        serviceItemIds: sourceTableData.map((item) => item.serviceItemId),
      }).catch(() => {});
      serviceItemSamePeriod = validateArrayLength(period) ? period : [];
    }

    // 组装、处理数据
    const calcTableData = sourceTableData.map((item) => {
      const sil = serviceItemsList.find((it) => `${it.chargingItemId}` === `${item.serviceItemId}`);
      // 是否是周期性服务
      const isCycle = get(sil, 'isCycle', 1) !== 0;
      // 续签时开始时间为父合同的结束时间的后一月，结束时间置空
      const startDate = isRenewal
        ? isCycle
          ? item.endDate
            ? moment(item.endDate, 'X')
                .add({
                  months: 1,
                })
                .startOf('month')
            : undefined
          : undefined
        : isCycle
        ? item.startDate
          ? moment(item.startDate, 'X')
          : undefined
        : undefined; // 非周期性服务开始日期为空
      const endDate = isRenewal ? undefined : item.endDate ? moment(item.endDate, 'X') : undefined;
      const servicePeriodNum = isCycle ? item.servicePeriodNum : undefined; // 非周期性服务服务期数为空

      newCount += 1;
      return {
        ...item,
        [tableRowKey]: newCount,
        servicePeriodNum,
        startDate,
        endDate,
        // 客户对应服务项目已经添加过的服务期间
        serviceItemDates: get(
          serviceItemSamePeriod.find((it) => `${it.serviceItemId}` === `${item.serviceItemId}`),
          'serviceItemDates',
          [],
        ),
        isCycle,
      };
    });

    const restLength = 3 - calcTableData.length;
    for (let i = 1; restLength > 0 && i <= restLength; i++) {
      newCount += 1;
      calcTableData.push({
        [tableRowKey]: newCount,
      });
    }
    this.updateState({
      tableData: calcTableData,
      tableRowKeyCounter: newCount,
    });
  },

  // 查看合同信息
  async getContractInfo(payload = {}) {
    const { status } = this.getState();
    const { id, init, ...restPayload } = payload;

    const data = await commonServices.getContractInfo(
      { contractId: id },
      {
        loading: '正在查询合同信息',
      },
    );

    const { contractServiceItems = {}, ...rest } = data || {};

    const isRenewal = status === 2; // 是否是续签页面
    const isCycle = rest.settlementMethod !== 0; // 是否是周期性
    // 续签时开始时间为父合同的结束时间的后一月，结束时间置空
    const startDate = isRenewal
      ? rest.endDate && isCycle
        ? moment(rest.endDate, 'X')
            .add({ months: 1 })
            .startOf('month')
        : undefined
      : rest.startDate
      ? moment(rest.startDate, 'X')
      : undefined;
    const endDate = isRenewal ? undefined : rest.endDate ? moment(rest.endDate, 'X') : undefined;
    const signDate = isRenewal ? startDate : rest.signDate ? moment(rest.signDate, 'X') : undefined;

    this.updateFormInitialValues({
      ...rest,
      init,
      signDate,
      startDate,
      endDate,
      // 客户、签单人赋初始值的时候直接用name，解决列表匹配不到id的情况，最后提交表单的时候再对比id与初始的name即可
      // initCustomerId: rest.customerId,
      // customerId: rest.customerName,
      // initSignUserStaffId: rest.signUserStaffId,
      // signUserStaffId: rest.signUserName,
      ...restPayload,
    });
    this.updateState({
      contractInfo: data || {},
    });

    // 如果需要重置页面时才会重新计算表格，其他时候不动（比如正常切换页签）
    init && this.handleTableData(contractServiceItems);
  },

  // 表格新增行
  addEmptyTr(payload = {}) {
    const { record } = payload;
    const { tableRowKeyCounter, tableRowKey, tableData } = this.getState();
    const newCount = tableRowKeyCounter + 1;
    const index = this.getRowIndex(record);
    tableData.splice(index + 1, 0, { [tableRowKey]: newCount });
    this.updateState({
      tableData: [...tableData],
      tableRowKeyCounter: newCount,
    });
  },

  // 表格删除行
  deleteTr(payload = {}) {
    const { record } = payload;
    const { tableRowKey, tableData } = this.getState();

    // 保持最少3行，低于3行时只删除数据不删除行
    const newTableData = filter(
      map(tableData, (item) => {
        if (item[tableRowKey] === record[tableRowKey]) {
          if (tableData.length > 3) {
            return undefined;
          }
          return { [tableRowKey]: item[tableRowKey] };
        }
        return item;
      }),
      Boolean,
    );
    this.updateState({
      tableData: newTableData,
    });
    // this.formValidateFields({
    //   fields: ['validPeriodNum', 'startDate', 'endDate'],
    // });
  },

  // 更新tableData
  updateTableData(payload = {}) {
    const { record, changes } = payload;
    const { tableData, tableRowKey } = this.getState();

    const newTableData = tableData.map((item) =>
      item[tableRowKey] === record[tableRowKey] ? { ...item, ...changes } : item,
    );
    this.updateState({
      tableData: newTableData,
    });
  },

  // form强制验证
  formValidateFields(payload = {}) {
    const { fields } = payload;
    const { form } = this.getState();
    // 要加定时器 和 {force: true}
    setTimeout(() => {
      form && form.validateFields(...[fields, { force: true }].filter(Boolean));
    });
  },

  // 表格数据改变的时候计算数据
  onTableDataChange() {
    const { tableData } = this.getState();
    // 计算表格footer里的金额合计
    const tableSumMoney = tableData.reduce(
      (preValue, curValue) => preValue + (Number(curValue.money) || 0),
      0,
    );
    this.updateState({
      tableSumMoney,
    });
  },

  // 获取客户对应服务项目已经添加过的服务期间
  async getServiceItemSamePeriod(payload = {}) {
    const { serviceItemIds } = payload;
    const { form } = this.getState();
    const { customerId, contractId } = form ? form.getFieldsValue() : {};
    // const customerId =
    //   formCustomerId === formInitialValues.customerName
    //     ? formInitialValues.initCustomerId
    //     : formCustomerId;
    if (!(serviceItemIds && customerId)) {
      return null;
    }
    const data = await commonServices.getServiceItemSamePeriod({
      customerId,
      serviceItemIds,
      contractId: contractId || undefined,
    });
    return data;
  },

  // 获取客户列表
  async getCustomerList() {
    const data = await globalServices.getCustomerBillNO({
      isShouldReceiveBill: 0,
    });
    this.updateState({
      customerList: data || [],
    });
  },
  // 获取业务员列表
  async getBusinessStaffList(payload = {}) {
    const data = await globalServices.getStaffList(payload);
    this.updateState({
      businessStaffList: data || [],
    });
  },
  // 获取服务项目列表
  async getServiceItems() {
    const data = await globalServices.getServiceItems();
    this.updateState({
      serviceItemsList: flatMap(data || [], (item) => get(item, 'chargingItemList', [])),
    });
  },
  // 合同设置查询
  async getContractSetting() {
    const data = await globalServices.getContractSetting();
    const {
      enclosureUpload,
      contractCreateSrbBill,
      contractCreateTaskBill,
      electronicContract,
      contractClause,
    } = data || {};
    this.updateState({
      enclosureUpload: enclosureUpload === 1, // 是否允许上传附件
      isCreateSrbBill: contractCreateSrbBill === 1, // 是否生成应收单
      isCreateTaskBill: contractCreateTaskBill === 1, // 是否生成任务单
      isElectronicContract: electronicContract === 1, // 是否生成电子合同
      isContractClause: contractClause === 1, // 是否添加合同条款
    });
  },
  // 获取电子合同模板列表
  async getETCContractTemplateList() {
    const data = await globalServices.getETCContractTemplateList();
    this.updateState({
      ETCContractTemplateList: data || [],
    });
  },
  // 获取合同条款列表
  async getContractClauseList() {
    const data = await globalServices.getContractClauseList();
    this.updateState({
      contractClauseList: data || [],
    });
  },

  // 获取index
  getRowIndex(record) {
    const { tableRowKey, tableData } = this.getState();
    return tableData.findIndex((item) => item[tableRowKey] === record[tableRowKey]);
  },

  // 处理变更逻辑
  handleEditContract() {
    const {
      formInitialValues: { contractStatus, contractId },
    } = this.getState();
    const contractStatusDate = dictionary.contractStatus.map[contractStatus] || {};
    if (contractStatusDate.edit) {
      handleRouterChange.handleToContractEdit({ contractId });
    } else {
      message.warning(`${contractStatusDate.name}的合同不支持变更`);
    }
  },

  // 处理终止逻辑
  handleStopContract() {
    const {
      formInitialValues: { contractStatus, contractId },
    } = this.getState();
    const contractStatusDate = dictionary.contractStatus.map[contractStatus] || {};
    if (contractStatusDate.stop) {
      this.updateStopModal({
        visible: true,
        data: {
          contractId,
        },
      });
    } else {
      message.warning(`${contractStatusDate.name}的合同不支持终止`);
    }
  },
  // 隐藏终止合同弹窗
  hideStopModal() {
    this.updateState({
      stopModal: { visible: false },
    });
  },
  // 更新终止合同弹窗
  updateStopModal(payload = {}) {
    const { stopModal } = this.getState();
    this.updateState({
      stopModal: { ...stopModal, ...payload },
    });
  },
  // 终止合同
  async stopContract(payload = {}) {
    await commonServices.stopContract(payload, {
      loading: '正在终止中...',
      successMsg: '终止成功',
    });
    this.hideStopModal();
    this.query();
  },

  // 处理续签逻辑
  handleRenewalContract() {
    const {
      formInitialValues: { contractStatus, contractId },
    } = this.getState();
    const contractStatusDate = dictionary.contractStatus.map[contractStatus] || {};
    if (contractStatusDate.renewal) {
      this.updateRenewalModal({
        visible: true,
        data: {
          contractId,
        },
      });
    } else {
      message.warning(`${contractStatusDate.name}的合同不支持续签`);
    }
  },
  // 隐藏续签合同弹窗
  hideRenewalModal() {
    this.updateState({
      renewalModal: { visible: false },
    });
  },
  // 更新续签合同弹窗
  updateRenewalModal(payload = {}) {
    const { renewalModal } = this.getState();
    this.updateState({
      renewalModal: { ...renewalModal, ...payload },
    });
  },
  // 续签合同
  async renewalContract(payload = {}) {
    await commonServices.renewalContract(payload, {
      loading: '正在续签中...',
      successMsg: '续签成功',
    });
    this.hideRenewalModal();
    this.query();
  },

  // 查询合同操作记录
  async getContractOperateLog() {
    const {
      formInitialValues: { contractId },
    } = this.getState();
    const data = await commonServices.getContractOperateLog({ contractId });
    return data;
  },

  // 查询客户信息
  async getCustomerInfo(payload = {}) {
    const data = await globalServices.getCustomerInfo(payload);
    return data;
  },

  // 查询表格数据
  getTableData() {
    const { tableData } = this.getState();
    return tableData;
  },

  // 生成应收单
  async handleCreateReceivable() {
    const {
      formInitialValues: { contractId },
    } = this.getState();
    const data = await commonServices.pushCreateSrb(
      { contractId },
      {
        successMsg: '生成成功',
        status: {
          300() {
            ShowConfirm({
              title: '对应应收单已存在，请手动关联。',
              type: 'warning',
              okText: '知道了',
            });
          },
        },
      },
    );
    this.updateFormInitialValues(data);
  },

  // 生成应收单
  async handleRelatedReceivable(payload = {}) {
    const {
      formInitialValues: { contractId },
    } = this.getState();
    const data = await commonServices.contractRelSrbBill(
      { contractId, ...payload },
      { successMsg: '关联成功' },
    );
    this.updateFormInitialValues(data);
    return data;
  },

  // 生成电子合同
  async createElectronicContract(payload = {}) {
    const { ETCContractTemplateList } = this.getState();
    const { contractData } = payload;
    const { customerId, signUserStaffId, ETCContractTemplate } = contractData;

    let etcContractData;
    if (ETCContractTemplate) {
      const contractModelData =
        ETCContractTemplateList.find((item) => item.templateId === ETCContractTemplate) || {};
      let clientData = {};
      if (customerId) {
        // 如果选择了客户，请求客户信息
        const customerInfo = await this.getCustomerInfo({
          customerId,
          signUserStaffId,
        });
        if (customerInfo) {
          clientData = customerInfo || {};
        }
      }
      etcContractData = await this.getEtcContractData(contractModelData, contractData, clientData);
    }

    return etcContractData && etcContractData.title ? etcContractData : undefined;
    // // 电子合同源数据储存在pubData中用于编辑电子合同
    // pubData.set('electronicContract', etcContractData);
  },

  async getEtcContractData(contractModelData = {}, contractData = {}, clientData = {}) {
    const { form, contractClauseList } = this.getState();
    const modelHTML = contractModelData.content;
    const { contractMoney } = form ? form.getFieldsValue() : {};
    const tableData = await this.getTableData();

    // 把table中的数据与模板字段对应
    const dataGride = produce(
      tableData.filter((item) => !isNil(item.serviceItemId, '')),
      (draft) => {
        draft.forEach((item) => {
          const { isCycle } = item;
          item.itemName = item.serviceTypeName; // 服务项目名称
          item.serviceName = item.serviceTypeName; // 服务类型名称
          item.unitPrice = `${(Number(item.unitPriceContainTax) || 0).toFixed(2)}/${
            item.priceUnit || item.priceUnit === 0 ? unitList[item.priceUnit] : ''
          }`; // 含税单价
          item.startTime = item.startDate
            ? moment(item.startDate).format(isCycle ? monthFormat : dateFormat)
            : ''; // 开始时间
          item.endTime = item.endDate
            ? moment(item.endDate).format(isCycle ? monthFormat : dateFormat)
            : ''; // 结束时间
          item.servicePeriod = isCycle
            ? `${item.servicePeriodNum || 0}月+${item.freePeriodNum || 0}月`
            : ''; // 服务期数
          item.payCycle =
            item.settlementMethod || item.settlementMethod === 0
              ? payCycleList[item.settlementMethod]
              : ''; // 结算周期
          item.summoney = (Number(item.money) || 0).toFixed(2); // 费用金额
        });
      },
    );

    const isCycle = contractData.settlementMethod !== 0;

    const modelData = {
      ...contractData,
      ...clientData,
      // 合同相关信息
      contractNumber: contractData.contractNo, // 合同编号
      paymentType: (payType.find((item) => item.value === contractData.payType) || {}).name, // 付款方式
      signingTime: contractData.signDate
        ? moment(contractData.signDate, 'X').format(dateFormat)
        : '', // 签订时间
      startDate:
        contractData.startDate &&
        moment(contractData.startDate, 'X').format(isCycle ? monthFormat : dateFormat),
      endDate:
        contractData.endDate &&
        moment(contractData.endDate, 'X').format(isCycle ? monthFormat : dateFormat),
      signer: clientData.signUserStaffName, // 签单人
      remark: contractData.remark, // 备注
      contractTotal: contractMoney, // 总金额
      contractClause: (
        contractClauseList.find(
          (item) => item.contractClauseId === contractData.contractClauseId,
        ) || {}
      ).content, // 合同条款
      // 客户相关信息
      clientName: clientData.customerName, // 客户名称
      clientNumber: clientData.customerCode, // 客户编码
      taxNumer: clientData.texnum, // 统一社会信用代码
      taxType: clientData.vatType, // 纳税性质
      serviceType: clientData.serviceType, // 服务类型
      industryType: clientData.industryType, // 行业类型
      declarationType: clientData.taxType, // 申报类型
      taxUnit: clientData.gsDeptName, // 主管税务机关
      accounter: clientData.chiefAccountant, // 记账会计
      customerContractName: clientData.customerContractName, // 常用联系人名称
      customerContractNamePhone: clientData.customerContractNamePhone, // 常用联系人手机号
      companyName: clientData.companyName, // 企业名称
      companyUnitNumber: clientData.companyUnitNumber, // 企业统一社会信用代码
      signUserStaffPhone: clientData.signUserStaffPhone, // 签单人手机号
    };
    const spaces = repeat('&nbsp;', 20);
    // 下面把模板中的字段解析成对应的数据（jQuery牛逼！！！）
    // 付款信息 两张表格列不固定，而且还要根据数据生成行
    const newDiv = document.createElement('div');
    newDiv.innerHTML = modelHTML;
    // 周期性表格生成dom，渲染数据
    const cycleListBaseHTML =
      $(newDiv)
        .find('.model-table-cycleList')
        .next('table')
        .find('tr')
        .eq(1)
        .prop('outerHTML') || '';
    // 根据数据条数生成表格行DOM
    dataGride.some((item, index) => {
      if (index === dataGride.length - 1) {
        return true;
      }
      $(newDiv)
        .find('.model-table-cycleList')
        .next('table')
        .append(cycleListBaseHTML);
    });
    $(newDiv)
      .find('.model-table-cycleList')
      .each((index, item) => {
        // 处理多个"付款信息"表格
        $(item)
          .next('table')
          .find('tr:not(:first)')
          .each((index1, item1) => {
            $(item1)
              .find('span.modelFields-item')
              .each((index2, item2) => {
                const { key } = $(item2).data();
                const list = dataGride[index1] || [];
                const value = list[key] || '&nbsp;';
                // 标记是"付款信息"字段
                $(item2)
                  .addClass('paymentInfo')
                  .html(value);
              });
          });
      });

    // 处理除了上面两个表格之外的其他所有字段
    $(newDiv)
      .find('span.modelFields-item:not(.paymentInfo)')
      .each((index, item) => {
        const key = $(item).data('key');
        $(item).html(modelData[key] || spaces);
      });
    const resultHTML = $(newDiv).html() || '';
    const { clientName = '' } = modelData;
    return {
      title: `${contractModelData.title || ''}${clientName ? `（${clientName}）` : ''}`, // 电子合同的名称：合同模板名称+客户名称
      content: resultHTML,
    };
  },

  // 更新查看图片合同弹窗
  updatePreviewFileModal(payload = {}) {
    const { previewFileModal } = this.getState();
    this.updateState({
      previewFileModal: { ...previewFileModal, ...payload },
    });
  },
};
