import React, { useMemo } from 'react';
import cls from 'classnames';
import Qs from 'qs';
import { connect } from 'nuomi';
import { Icon, message } from 'antd';
import { util } from 'nuijs';
import { Carousel } from '@components';
import styles from './style.less';

const downloadFile = ({ name, path }) =>
  util.location(
    `${basePath}instead/v2/customer/enclosure/downloadFile.do?${Qs.stringify({
      enclosureName: name,
      enclosurePath: path,
    })}`,
  );

const Content = ({ currentFile = {}, fileList = [], dispatch }) => {
  // 当前图片位置
  const imgIndex = useMemo(
    () => fileList.findIndex((item) => item.filePath === currentFile.filePath) ?? -1,
    [currentFile.filePath, fileList],
  );

  // 切换图片
  const switchImg = (type) => {
    const dataMap = {
      '-1': {
        message: '已经到头了！',
      },
      1: {
        message: '已经是最后一张了！',
      },
    };
    const newIndex = imgIndex + type;
    const newItem = fileList[newIndex];
    if (newIndex >= 0 && newIndex < fileList.length) {
      dispatch({
        type: 'updatePreviewFileModal',
        payload: { currentFile: newItem },
      });
    } else {
      message.warn(dataMap[type]?.message);
    }
  };

  return (
    <div className={cls('f-no-select', styles['m-imgWrap'])}>
      <h3>
        合同附件（{imgIndex + 1}/{fileList.length}）
      </h3>
      <Carousel
        imageUrl={currentFile.filePath}
        getContent={({ zoom, rotate, curScale }) => (
          <i
            onClick={() =>
              downloadFile({ name: currentFile?.fileName, path: currentFile?.filePath })
            }
            className="iconfont"
            title="下载"
          >
            &#xea34;
          </i>
        )}
      />
      <Icon type="left-circle" onClick={() => switchImg(-1)} />
      <Icon type="right-circle" onClick={() => switchImg(1)} />
    </div>
  );
};

export default connect(({ previewFileModal: { currentFile, fileList } }) => ({
  currentFile,
  fileList,
}))(Content);
