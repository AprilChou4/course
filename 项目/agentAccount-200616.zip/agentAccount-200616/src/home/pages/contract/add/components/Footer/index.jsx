import React, { forwardRef } from 'react';
import { connect } from 'nuomi';
import monment from 'moment';
import { Descriptions } from 'antd';
import styles from './style.less';

const { Item: DescriptionsItem } = Descriptions;
const dateFormat = 'YYYY-MM-DD';

const Footer = forwardRef(({ createStaffName, createDate, updateStaffName, updateDate }, ref) => {
  return (
    <Descriptions column={6} ref={ref} className={styles.descriptions}>
      <DescriptionsItem label="创建人">{createStaffName}</DescriptionsItem>
      <DescriptionsItem label="创建日期" span={2}>
        {createDate ? monment(createDate, 'X').format(dateFormat) : ''}
      </DescriptionsItem>
      <DescriptionsItem label="修改人">{updateStaffName}</DescriptionsItem>
      <DescriptionsItem label="修改日期">
        {updateDate ? monment(updateDate, 'X').format(dateFormat) : ''}
      </DescriptionsItem>
    </Descriptions>
  );
});

export default connect(
  ({ formInitialValues: { createStaffName, createDate, updateStaffName, updateDate } }) => ({
    createStaffName,
    createDate,
    updateStaffName,
    updateDate,
  }),
)(Footer);
