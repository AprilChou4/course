/* eslint-disable no-nested-ternary */
/**
 * 应收单相关
 */
import React, { useState, useEffect } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import { GenFormItem, LinkButton, AntdInput } from '@components';
import { isNil, postMessageRouter } from '@utils';
import styles from './style.less';

const Receivable = ({ status, contractId, srbNo, srbId, dispatch }) => {
  const [related, setRelated] = useState(false);
  const [input, setInput] = useState();

  const handleClickSrbNo = () => {
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/viewReceivable',
        query: { id: srbId },
      },
    });
  };

  const handleCreateReceivable = () => {
    dispatch({
      type: 'handleCreateReceivable',
    });
  };

  const handleRelatedReceivable = () => {
    setRelated(true);
  };

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const handleClick = async () => {
    const data = await dispatch({
      type: 'handleRelatedReceivable',
      payload: {
        srbNo: input,
      },
    });
    data !== undefined && setRelated(false);
  };

  useEffect(() => {
    !related && setInput('');
  }, [related]);

  // 切换合同后关闭输入框
  useEffect(() => {
    setRelated(false);
  }, [contractId]);

  // 只有变更、查看页面展示
  return isNil(srbNo, '') ? (
    status === 3 && (
      <GenFormItem label="合同生单" className={styles.receivable}>
        <Button type="highlight" onClick={handleCreateReceivable}>
          生成应收单
        </Button>
        {related ? (
          <>
            <AntdInput
              placeholder="请输入要关联的应收单编号"
              value={input}
              className={styles.input}
              onChange={handleInputChange}
            />
            <Button type="primary" onClick={handleClick}>
              确定
            </Button>
          </>
        ) : (
          <Button type="highlight" onClick={handleRelatedReceivable}>
            关联应收单
          </Button>
        )}
      </GenFormItem>
    )
  ) : (
    <GenFormItem label="合同生单" className={styles.receivable}>
      <LinkButton underline onClick={handleClickSrbNo}>
        {srbNo}
      </LinkButton>
    </GenFormItem>
  );
};

export default connect(({ status, formInitialValues: { contractId, srbNo, srbId } }) => ({
  status,
  contractId,
  srbNo,
  srbId,
}))(Receivable);
