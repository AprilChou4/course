/**
 * 终止合同
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import moment from 'moment';
import StopContractModal from '../../../components/StopContractModal';

const StopContract = ({ visible, data, dispatch }) => {
  const handleCancel = useCallback(() => {
    dispatch({
      type: 'hideStopModal',
    });
  }, [dispatch]);

  const handleOk = useCallback(
    ({ form }) => {
      form.validateFields((err, { terminateType, terminateDate, terminateReason }) => {
        if (err) return;

        const { contractId } = data;
        dispatch({
          type: 'stopContract',
          payload: {
            contractId,
            terminateType: terminateType ? 0 : 1,
            terminateDate: terminateType
              ? undefined
              : moment(terminateDate)
                  .endOf('day')
                  .format('X'),
            terminateReason,
          },
        });
      });
    },
    [data, dispatch],
  );

  return (
    <StopContractModal visible={visible} data={data} onCancel={handleCancel} onOk={handleOk} />
  );
};

export default connect(({ stopModal: { visible, data } }) => ({
  visible,
  data,
}))(StopContract);
