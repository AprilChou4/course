/**
 * 标题
 */
import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import { Badge } from 'antd';
import { If } from '@components';
import { dictionary } from '../../../utils';
import ContractOperateLog from '../ContractOperateLog';

const Title = ({ title, status, contractStatus }) => {
  const contractDictionary = useMemo(() => dictionary.contractStatus.map[contractStatus], [
    contractStatus,
  ]);

  return (
    <div>
      {status === 3 && !!contractDictionary && (
        <Badge className="f-fl" color={contractDictionary.color} text={contractDictionary.name} />
      )}
      {title}
      <If condition={status === 3}>
        <ContractOperateLog />
      </If>
    </div>
  );
};

export default connect(({ title, status, formInitialValues: { contractStatus } }) => ({
  title,
  status,
  contractStatus,
}))(Title);
