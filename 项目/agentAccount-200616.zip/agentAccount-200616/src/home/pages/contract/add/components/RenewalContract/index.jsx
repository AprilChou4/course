import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { get, handleRouterChange } from '@utils';
import RenewalContractModal from '../../../components/RenewalContractModal';

const RenewalContract = ({ visible, data, dispatch }) => {
  const handleCancel = useCallback(() => {
    dispatch({
      type: 'hideRenewalModal',
    });
  }, [dispatch]);

  const handleOk = useCallback(
    ({ form }) => {
      form.validateFields((err, { extendMonth, renewType, contractId }) => {
        if (err) return;

        if (renewType === 0) {
          dispatch({
            type: 'renewalContract',
            payload: {
              contractId,
              renewType,
              extendMonth:
                Number(get(extendMonth, 'year', 0)) * 12 + Number(get(extendMonth, 'month', 0)),
            },
          });
        } else if (renewType === 1) {
          dispatch({
            type: 'hideRenewalModal',
          });
          handleRouterChange.handleToContractRenewal({ contractId });
        }
      });
    },
    [dispatch],
  );

  return (
    <RenewalContractModal visible={visible} data={data} onCancel={handleCancel} onOk={handleOk} />
  );
};

export default connect(({ renewalModal: { visible, data } }) => ({
  visible,
  data,
}))(RenewalContract);
