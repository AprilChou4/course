import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import { If, Authority } from '@components';
import { dictionary } from '../../../../utils';

const HeaderRight = ({ status, contractStatus, dispatch }) => {
  const contractDictionary = useMemo(() => dictionary.contractStatus.map[contractStatus] || {}, [
    contractStatus,
  ]);

  const handleSave = (toNew) => {
    dispatch({
      type: 'handleSaveContract',
      payload: {
        toNew,
      },
    });
  };

  const handleEdit = () => {
    dispatch({
      type: 'handleEditContract',
    });
  };

  const handleStop = () => {
    // 逻辑同合同列表页面点击终止
    dispatch({
      type: 'handleStopContract',
    });
  };

  const handleRenewal = () => {
    // 逻辑同合同列表页面点击续签
    dispatch({
      type: 'handleRenewalContract',
    });
  };

  return (
    <>
      <If condition={[0, 1, 2].includes(status)}>
        <Button type="primary" onClick={() => handleSave()}>
          保存
        </Button>
        <If condition={status === 0}>
          <Button onClick={() => handleSave(true)}>保存并新增</Button>
        </If>
      </If>
      <If condition={status === 3}>
        <If condition={contractDictionary.edit}>
          <Authority code="493">
            <Button type="primary" onClick={handleEdit}>
              变更
            </Button>
          </Authority>
        </If>
        <If condition={contractDictionary.stop}>
          <Authority code="16">
            <Button onClick={handleStop}>终止</Button>
          </Authority>
        </If>
        <If condition={contractDictionary.renewal}>
          <Authority code="15">
            <Button onClick={handleRenewal}>续签</Button>
          </Authority>
        </If>
      </If>
    </>
  );
};

export default connect(({ status, formInitialValues: { contractStatus } }) => ({
  status,
  contractStatus,
}))(HeaderRight);
