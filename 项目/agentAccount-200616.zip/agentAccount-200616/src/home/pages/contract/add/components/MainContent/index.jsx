/* eslint-disable no-param-reassign */
/* eslint-disable no-nested-ternary */
import React, { useEffect, useCallback, useMemo, useRef } from 'react';
import { connect } from 'nuomi';
import { util } from 'nuijs';
import moment from 'moment';
import Qs from 'qs';
import cls from 'classnames';
import { Form, Row, Col, DatePicker, Radio, InputNumber, Typography } from 'antd';
import pubData from 'data';
import {
  GenFormItem,
  LimitInput,
  NumberInput,
  AntdSelect,
  SuperSelect,
  LinkButton,
  Iconfont,
} from '@components';
import {
  get,
  isNil,
  trim,
  getSelectOptions,
  validateArrayLength,
  handleFileName,
  postMessageRouter,
  regex as regexs,
} from '@utils';
import { useFormFix } from '@hooks';
import UploadAttachment from '../../../components/UploadAttachment';
import { dictionary } from '../../../utils';
import styles from './style.less';

const { Group: RadioGroup } = Radio;
const { MonthPicker } = DatePicker;
const { Text } = Typography;
const formItemStyle = { width: '100%' };
const pictureTypes = ['jpg', 'png', 'jpeg'];
const splitFileName = (name = '') => {
  let dotIndex = name.lastIndexOf('.');
  dotIndex = dotIndex > 0 ? dotIndex : name.length;
  return (
    <>
      <Text ellipsis title={name}>
        {name.slice(0, dotIndex)}
      </Text>
      <span>{name.slice(dotIndex)}</span>
    </>
  );
};
const downloadFile = ({ name, path }) =>
  util.location(
    `${basePath}instead/v2/customer/enclosure/downloadFile.do?${Qs.stringify({
      enclosureName: name,
      enclosurePath: path,
    })}`,
  );

const MainContent = ({
  status,
  form,
  form: { setFieldsValue, getFieldValue },
  contractInfo = {},
  formInitialValues = {},
  customerList,
  businessStaffList,
  ETCContractTemplateList,
  contractClauseList,
  enclosureUpload,
  isElectronicContract,
  isContractClause,
  dispatch,
}) => {
  const inputing = useRef(); // 是否正在输入中文

  useFormFix();
  form.getFieldDecorator('contractId', {
    initialValue: formInitialValues.contractId,
  });

  const { settlementMethod } = form.getFieldsValue();
  const isViewPage = status === 3; // 是否是查看状态
  const isRenewal = status === 2; // 是否是续签状态
  const isCycle = settlementMethod !== 0; // 是否是周期性

  const disabledStartDate = useCallback(
    (current) => {
      const endDate = form.getFieldValue('endDate');
      const cValue = current.valueOf() - (current.valueOf() % 1000); // 后端保存的是秒级时间戳，valueOf()得到的是毫秒级时间戳
      // 续签时还要禁用上个合同结束日期前的日期
      return (
        current &&
        ((!!(isRenewal && contractInfo.endDate) &&
          cValue <=
            moment(contractInfo.endDate, 'X')
              .endOf('day')
              .valueOf()) ||
          (!!endDate && cValue > endDate.valueOf()))
      );
    },
    [contractInfo.endDate, form, isRenewal],
  );

  const disabledEndDate = useCallback(
    (current) => {
      const startDate = form.getFieldValue('startDate');
      const cValue = current.valueOf() - (current.valueOf() % 1000); // 后端保存的是秒级时间戳，valueOf()得到的是毫秒级时间戳
      // 续签时还要禁用上个合同结束日期前的日期
      return (
        current &&
        ((!!(isRenewal && contractInfo.endDate) &&
          cValue <= moment(contractInfo.endDate, 'X').valueOf()) ||
          (!!startDate && cValue < startDate.valueOf()))
      );
    },
    [contractInfo.endDate, form, isRenewal],
  );

  const customerOptions = useMemo(
    () =>
      getSelectOptions(customerList, (item) => ({
        value: item.customerId,
        name: item.customerName,
      })),
    [customerList],
  );
  const businessStaffOptions = useMemo(
    () =>
      getSelectOptions(businessStaffList, (item) => ({
        value: item.staffId,
        name: item.realName,
      })),
    [businessStaffList],
  );
  const ETCContractTemplateListOptions = useMemo(
    () =>
      getSelectOptions(ETCContractTemplateList, (item) => ({
        value: item.templateId,
        name: item.title,
      })),
    [ETCContractTemplateList],
  );
  const contractClauseListOptions = useMemo(
    () =>
      getSelectOptions(contractClauseList, (item) => ({
        value: item.contractClauseId,
        name: item.title,
      })),
    [contractClauseList],
  );

  // 客户名称改变（重置整个页面数据到初始状态）
  const handleCustomerIdChange = useCallback(
    (value) => {
      // FIXME: form.getFieldValue应该可以改成getFieldValue
      dispatch({
        type: 'initAddContract',
        payload: {
          customerId: value,
          contractNo: form.getFieldValue('contractNo'),
        },
      });
    },
    [dispatch, form],
  );

  // 选择系统预置的电子合同模板后，自动带出预置的合同条款
  const handleETCContractTemplateChange = useCallback(
    (value, option) => {
      const dataref = get(option, 'props.dataref', {});
      if (dataref.isSys === 1) {
        const syscontractClause = contractClauseList.find((item) => item.isSys === 1);
        syscontractClause &&
          setFieldsValue({
            contractClauseId: syscontractClause.contractClauseId,
          });
      }
    },
    [contractClauseList, setFieldsValue],
  );

  // 结算方式改变
  const handleSettlementMethodChange = useCallback(
    (value) => {
      if (value === 0) {
        // 如果选择非周期性，开始时间和有效期数字段 失效，结束日期变成当天
        setFieldsValue({
          startDate: undefined,
          validPeriodNum: undefined,
          endDate: moment(),
        });
      } else if (!getFieldValue('startDate')) {
        // 如果选择周期性，开始时间没有值时填充值同签订时间
        setFieldsValue({
          startDate: getFieldValue('signDate'),
          // validPeriodNum: undefined,
        });
      }
    },
    [setFieldsValue, getFieldValue],
  );

  // 结束日期-开始日期+1=有效期数
  // 有效期数改变后（计算结束日期）
  const handleValidPeriodNumChange = useCallback(
    (value) => {
      const startDate = getFieldValue('startDate');
      // add前要使用moment包裹一下，否则会改变原始值
      setFieldsValue({
        endDate: value && startDate ? moment(startDate).add(Number(value) - 1, 'month') : undefined,
      });
    },
    [getFieldValue, setFieldsValue],
  );

  // 开始日期改变后（计算有效期数）
  const handleStartDateChange = useCallback(
    (date) => {
      const endDate = getFieldValue('endDate');
      // 有效时间 = 结束日期 - 开始日期 + 1
      setFieldsValue({
        validPeriodNum: date && endDate ? endDate.diff(date, 'month') + 1 : undefined,
      });
    },
    [getFieldValue, setFieldsValue],
  );

  // 开始日期改变后（计算有效期数）
  const handleEndDateChange = useCallback(
    (date) => {
      const startDate = getFieldValue('startDate');
      // 有效时间 = 结束日期 - 开始日期 + 1
      setFieldsValue({
        validPeriodNum: date && startDate ? date.diff(startDate, 'month') + 1 : undefined,
      });
    },
    [getFieldValue, setFieldsValue],
  );

  // 查看电子合同
  const hendleEtcContractView = () => {
    pubData.set('etcContractViewData', formInitialValues.electronicContract);
    setTimeout(() => {
      postMessageRouter({
        type: 'agentAccount/routerLocation',
        payload: {
          url: '/EtcContract/view',
        },
      });
    });
  };

  // （变更时）删除电子合同
  const handleEtcContractDelete = () => {
    dispatch({
      type: 'updateFormInitialValues',
      payload: { electronicContract: undefined },
    });
  };

  const handleContractFilesClick = useCallback(
    (file, contractFiles) => {
      // 点击图片会查看大图，其他格式直接下载
      const { suffix } = handleFileName(file.fileName);
      if (pictureTypes.includes(suffix)) {
        const pictureFiles = contractFiles.filter((item) =>
          pictureTypes.includes(handleFileName(item?.fileName).suffix),
        );
        dispatch({
          type: 'updatePreviewFileModal',
          payload: {
            visible: true,
            currentFile: file,
            fileList: pictureFiles,
          },
        });
        // 打开图片弹窗
      } else {
        downloadFile({ name: file.fileName, path: file.filePath });
      }
    },
    [dispatch],
  );

  const contractFilesContent = useMemo(
    () =>
      status === 3
        ? !!validateArrayLength(formInitialValues.contractFiles) && (
            <Row>
              <Col>
                <GenFormItem label="附件">
                  {formInitialValues.contractFiles.map((item) => (
                    <LinkButton
                      plain
                      key={item.filePath}
                      className={styles.file}
                      onClick={() =>
                        handleContractFilesClick(item, formInitialValues.contractFiles)
                      }
                    >
                      <Iconfont type="iconfujian" className={styles['icon-file']} />
                      {splitFileName(item.fileName)}
                    </LinkButton>
                  ))}
                </GenFormItem>
              </Col>
            </Row>
          )
        : !!enclosureUpload &&
          !isViewPage && (
            <Row>
              <Col>
                <GenFormItem
                  form={form}
                  label="附件"
                  name="contractFiles"
                  initialValue={formInitialValues.contractFiles}
                  className={styles.upload}
                >
                  <UploadAttachment disabled={isViewPage} />
                </GenFormItem>
              </Col>
            </Row>
          ),
    [
      enclosureUpload,
      form,
      formInitialValues.contractFiles,
      handleContractFilesClick,
      isViewPage,
      status,
    ],
  );

  const totalMoneyValidator = useCallback((rule, value, callback) => {
    if (!trim(value)) {
      callback('总金额不能为空');
    } else if (!(Number(value) > 0)) {
      callback('总金额需大于0');
    } else {
      callback();
    }
  }, []);

  const contractNoValidator = useCallback((rule, value, callback) => {
    // 由于事件执行顺序问题，使用setTimeout才能拿到inputing的最新值
    setTimeout(() => {
      if (inputing.current) {
        return;
      }
      if (!trim(value)) {
        callback('请输入合同编号');
      } else if (!regexs.code.test(value)) {
        callback('合同编号格式错误');
      } else {
        callback();
      }
    });
  }, []);

  const handleInputCompositionStart = useCallback(() => {
    inputing.current = true;
  }, []);
  const handleInputCompositionEnd = useCallback(() => {
    inputing.current = false;
  }, []);

  // 单据日期改变后，同步开始日期
  // useEffect(() => {
  //   dispatch({
  //     type: 'updateFormInitialValues',
  //     payload: {
  //       startDate: signDate,
  //     },
  //   });
  // }, [signDate, dispatch]);

  // 更新form
  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: { form },
    });
  }, [dispatch, form]);

  const Picker = isCycle ? MonthPicker : DatePicker;

  return (
    <Form className={cls('hide-disabled', styles.form)}>
      <Row>
        <Col span={6}>
          <GenFormItem
            form={form}
            label="客户名称"
            name="customerId"
            initialValue={formInitialValues.customerId}
            rules={[{ required: true, message: '请选择客户名称' }]}
          >
            <SuperSelect
              placeholder="请选择客户名称"
              defaultActiveFirstOption={false}
              disabled={isViewPage || !!form.getFieldValue('contractId')}
              onChange={handleCustomerIdChange}
            >
              {customerOptions}
            </SuperSelect>
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            required={false}
            form={form}
            label="合同编号"
            name="contractNo"
            initialValue={formInitialValues.contractNo}
            rules={[{ validator: contractNoValidator }]}
          >
            <LimitInput
              placeholder="请输入合同编号"
              maxLength={30}
              disabled={isViewPage}
              onCompositionStart={handleInputCompositionStart}
              onCompositionEnd={handleInputCompositionEnd}
            />
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            form={form}
            label="签单人"
            name="signUserStaffId"
            initialValue={formInitialValues.signUserStaffId}
          >
            <SuperSelect
              placeholder="请选择签单人"
              disabled={isViewPage}
              defaultActiveFirstOption={false}
            >
              {businessStaffOptions}
            </SuperSelect>
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            form={form}
            required={false}
            label="签订时间"
            name="signDate"
            initialValue={formInitialValues.signDate}
            rules={[{ required: true, message: '请选择签订时间' }]}
          >
            <DatePicker
              placeholder="请选择签订时间"
              allowClear={false}
              style={formItemStyle}
              disabled={isViewPage}
            />
          </GenFormItem>
        </Col>
      </Row>
      <Row>
        <Col span={6}>
          <GenFormItem
            form={form}
            label="开始日期"
            name="startDate"
            className="label-required-hide"
            initialValue={formInitialValues.startDate}
            rules={[{ required: isCycle, message: '请选择服务开始日期' }]}
          >
            <Picker
              placeholder={isCycle ? '请选择服务开始日期' : '-'}
              allowClear={false}
              style={formItemStyle}
              disabledDate={disabledStartDate}
              onChange={handleStartDateChange}
              disabled={isViewPage || !isCycle}
            />
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            form={form}
            required={false}
            label="结束日期"
            name="endDate"
            initialValue={formInitialValues.endDate}
            rules={[{ required: true, message: '请选择服务结束日期' }]}
          >
            <Picker
              placeholder="请选择服务结束日期"
              allowClear={false}
              style={formItemStyle}
              disabledDate={disabledEndDate}
              onChange={handleEndDateChange}
              disabled={isViewPage}
            />
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            form={form}
            label="总金额"
            required
            name="contractMoney"
            initialValue={formInitialValues.contractMoney}
            rules={[
              {
                validator: totalMoneyValidator,
              },
            ]}
          >
            <NumberInput placeholder="请输入总金额" disabled={isViewPage} />
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            form={form}
            required={false}
            label="收款方式"
            name="payType"
            initialValue={formInitialValues.payType}
            rules={[{ required: true, message: '请选择收款方式' }]}
          >
            <RadioGroup options={dictionary.payType.list} disabled={isViewPage} />
          </GenFormItem>
        </Col>
      </Row>
      <Row>
        <Col span={6}>
          <GenFormItem
            form={form}
            required={false}
            label="结算方式"
            name="settlementMethod"
            initialValue={formInitialValues.settlementMethod}
            rules={[{ required: true, message: '请选择结算方式' }]}
          >
            <AntdSelect
              showSearch={false}
              placeholder="请选择结算方式"
              dataSource={dictionary.settlementMethod.list}
              onChange={handleSettlementMethodChange}
              disabled={isViewPage}
            />
          </GenFormItem>
        </Col>
        <Col span={6}>
          <GenFormItem
            form={form}
            label="有效期数"
            name="validPeriodNum"
            initialValue={formInitialValues.validPeriodNum}
            // rules={[{ required: isDateRequired && isCycle, message: '请选择有效期数' }]}
            // trigger="onBlur"
            // valuePropName="defaultValue"
          >
            <InputNumber
              placeholder={isCycle ? '请输入有效期数' : '-'}
              min={1}
              max={600}
              style={formItemStyle}
              onChange={handleValidPeriodNumChange}
              disabled={isViewPage || !isCycle}
            />
          </GenFormItem>
        </Col>
        {(isElectronicContract ||
          (formInitialValues.electronicContract && [1, 3].includes(status))) && (
          <Col span={6}>
            {status === 0 || !formInitialValues.electronicContract ? (
              <GenFormItem
                form={form}
                label="电子合同模板"
                name="ETCContractTemplate"
                initialValue={formInitialValues.ETCContractTemplate}
              >
                <SuperSelect
                  allowClear
                  placeholder="请选择电子合同模板"
                  defaultActiveFirstOption={false}
                  disabled={isViewPage}
                  onChange={handleETCContractTemplateChange}
                >
                  {ETCContractTemplateListOptions}
                </SuperSelect>
              </GenFormItem>
            ) : (
              <GenFormItem label="电子合同">
                <div
                  className={cls(styles.etcContract, {
                    [styles['etcContract-view']]: isViewPage,
                  })}
                >
                  <LinkButton plain onClick={hendleEtcContractView}>
                    {splitFileName(formInitialValues.electronicContract.title)}
                  </LinkButton>
                  {!isViewPage && (
                    <Iconfont
                      type="iconshanchu6"
                      className="icon-clear"
                      onClick={handleEtcContractDelete}
                    />
                  )}
                </div>
              </GenFormItem>
            )}
          </Col>
        )}
        {(isContractClause ||
          (formInitialValues.contractClauseId &&
            form.getFieldValue('contractClauseId') &&
            [1, 3].includes(status))) && (
          <Col span={6}>
            <GenFormItem
              form={form}
              label="合同条款"
              name="contractClauseId"
              initialValue={formInitialValues.contractClauseId}
            >
              <SuperSelect
                allowClear
                placeholder="请选择合同条款"
                defaultActiveFirstOption={false}
                disabled={isViewPage}
              >
                {contractClauseListOptions}
              </SuperSelect>
            </GenFormItem>
          </Col>
        )}
      </Row>
      {contractFilesContent}
      <Row>
        <Col>
          <GenFormItem
            form={form}
            label="备注"
            name="remark"
            initialValue={formInitialValues.remark}
            rules={[{ max: 200, message: '最大长度200' }]}
          >
            <LimitInput allowClear placeholder="请输入备注" maxLength={200} disabled={isViewPage} />
          </GenFormItem>
        </Col>
      </Row>
    </Form>
  );
};

export default connect(
  ({
    status,
    contractInfo,
    formInitialValues,
    customerList,
    businessStaffList,
    ETCContractTemplateList,
    contractClauseList,
    enclosureUpload,
    isElectronicContract,
    isContractClause,
  }) => ({
    status,
    contractInfo,
    formInitialValues,
    customerList,
    businessStaffList,
    ETCContractTemplateList,
    contractClauseList,
    enclosureUpload,
    isElectronicContract,
    isContractClause,
  }),
)(Form.create()(MainContent));
