import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import { Checkbox } from 'antd';
import { If, GenFormItem } from '@components';
import Receivable from './Receivable';
import styles from './style.less';

const TableHeader = ({ status, form, tableData, isCreateSrbBill, isCreateTaskBill }) => {
  // 页面是新增/续签 且 表格中有服务类型属于“工商服务”时，上方显示“生成工商任务单”
  const isShowCreateTask = useMemo(
    () => [0, 2].includes(status) && tableData.some((item) => item.serviceClassId === '2'),
    [status, tableData],
  );

  return (
    <div className={styles.content}>
      {[0, 2].includes(status) && (
        <GenFormItem label="合同生单">
          <GenFormItem
            form={form}
            name="isCreateSrbBill"
            valuePropName="checked"
            initialValue={isCreateSrbBill}
            className={styles.checkbox}
          >
            <Checkbox>生成应收单</Checkbox>
          </GenFormItem>
          <If condition={isShowCreateTask}>
            <GenFormItem
              form={form}
              name="isCreateTaskBill"
              valuePropName="checked"
              initialValue={isCreateTaskBill}
              className={styles.checkbox}
            >
              <Checkbox>生成工商任务单</Checkbox>
            </GenFormItem>
          </If>
        </GenFormItem>
      )}
      {[1, 3].includes(status) && <Receivable />}
    </div>
  );
};

export default connect(({ status, form, tableData, isCreateSrbBill, isCreateTaskBill }) => ({
  status,
  form,
  tableData,
  isCreateSrbBill,
  isCreateTaskBill,
}))(TableHeader);
