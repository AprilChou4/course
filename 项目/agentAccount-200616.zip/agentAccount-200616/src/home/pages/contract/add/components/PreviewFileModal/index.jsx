// 图片预览弹窗
import React from 'react';
import { connect } from 'nuomi';
import { AntdModal } from '@components';
import Content from './Content';
import styles from './style.less';

const ViewFileModal = ({ visible, dispatch }) => {
  const cancel = () => {
    dispatch({
      type: 'updatePreviewFileModal',
      payload: { visible: false },
    });
  };

  return (
    <AntdModal
      title={null}
      footer={null}
      width={800}
      height={500}
      visible={visible}
      onCancel={cancel}
      wrapClassName={styles['attach-viewimg-modal']}
    >
      <Content />
    </AntdModal>
  );
};

export default connect(({ previewFileModal: { visible } }) => ({
  visible,
}))(ViewFileModal);
