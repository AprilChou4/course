/**
 * 查看电子合同
 */
import React from 'react';
import Main from './components/Main';
import effects from './effects';

export default {
  state: {
    iframeKey: new Date().getTime(),
    etcContractData: {},
  },
  effects,
  render() {
    return <Main />;
  },
  onChange() {
    this.store.dispatch({
      type: 'getEtcContractViewData',
    });
  },
};
