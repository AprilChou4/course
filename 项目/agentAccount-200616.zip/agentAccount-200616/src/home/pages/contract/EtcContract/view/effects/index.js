import pubData from 'data';
import { message } from 'antd';

export default {
  getEtcContractViewData() {
    const etcContractData = pubData.get('etcContractViewData');
    if (!etcContractData) {
      message.warning('请选择要查看的电子合同！');
    }
    this.updateState({
      iframeKey: new Date().getTime(),
      etcContractData: etcContractData || {},
    });
  },
};
