/* eslint-disable react/no-danger */
import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import Frame from 'react-frame-component';
import cls from 'classnames';
import Qs from 'qs';
import { Authority } from '@components';
import { util } from '@utils';
import styles from './style.less';

const Main = ({ iframeKey, etcContractData = {} }) => {
  // 下载电子合同
  const handleDownload = () => {
    util.location(
      `${basePath}instead/v2/customer/enclosure/downloadFile.do?${Qs.stringify({
        enclosureName: `${etcContractData.title}.doc`,
        enclosurePath: etcContractData.filePath,
      })}`,
    );
  };

  // 打印电子合同
  const handlePrint = () => {
    window.document
      .querySelector('.etcContract-view-iframe-container iframe')
      .contentWindow.print();
  };

  return (
    <div className={styles.container}>
      <div className={styles.opterations}>
        <Authority code="523">
          <Button type="highlight" onClick={handleDownload}>
            下载
          </Button>
        </Authority>
        <Authority code="522">
          <Button type="highlight" onClick={handlePrint}>
            打印
          </Button>
        </Authority>
      </div>
      <div className={cls('etcContract-view-iframe-container', styles.content)}>
        <Frame
          key={iframeKey}
          initialContent={etcContractData.content}
          // mountTarget='#mountHere'
        />
      </div>
    </div>
  );
};

export default connect(({ iframeKey, etcContractData }) => ({ iframeKey, etcContractData }))(Main);
