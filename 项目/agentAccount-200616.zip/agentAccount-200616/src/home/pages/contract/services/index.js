import { createServices } from '@utils';

export default createServices({
  getContractList: 'instead/v2/customer/contract/list::postJSON', // 合同列表
  addContract: 'instead/v2/customer/contract/add::postJSON', // 新增合同
  updateContract: 'instead/v2/customer/contract/update::postJSON', // 变更合同
  deleteContract: 'instead/v2/customer/contract/delete::postJSON', // 删除合同
  renewalContract: 'instead/v2/customer/contract/renew::postJSON', // 续签合同
  stopContract: 'instead/v2/customer/contract/terminate::postJSON', // 终止合同
  importContract: 'instead/v2/customer/contract/batchImport::post', // 批量导入合同
  getImportProcess: 'instead/v2/customer/contract/importProcess/query', // 合同导入进度查询
  getContractNo: 'instead/v2/customer/contract/getContractNo', // 生成合同编号
  getContractInfo: 'instead/v2/customer/contract/get::postJSON', // 查询合同详情
  getContractOperateLog: 'instead/v2/customer/contract/operateLog', // 查询合同操作记录
  getServiceItemSamePeriod: 'instead/v2/customer/contract/queryCustomerServicePeriod::postJSON', // 获取客户对应服务项目已经添加过的服务期间
  pushCreateSrb: '/instead/v2/customer/contract/pushCreateSrb::postJSON', // 推适生成应收单
  contractRelSrbBill: '/instead/v2/customer/contract/contractRelSrbBill::postJSON', // 手动关联应收单
});
