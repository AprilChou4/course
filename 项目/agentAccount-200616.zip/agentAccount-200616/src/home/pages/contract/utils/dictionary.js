/**
 * @object 数据字典
 */

const getData = (params) => {
  const map = {};
  params.list.forEach(({ value, name, label, data }) => {
    map[value] = data || name || label;
  });
  return { ...params, map };
};

// 合同状态
const contractStatus = {
  title: '合同状态',
  list: [
    {
      value: 0,
      data: {
        name: '未开始',
        color: '#BFBFBF',
        edit: 1, // 是否可 变更
        stop: 1, // 是否可 终止
        renewal: 1, // 是否可 续签
      },
    },
    {
      value: 1,
      data: {
        name: '服务中',
        color: '#008CFF',
        edit: 1,
        stop: 1,
        renewal: 1,
      },
    },
    {
      value: 2,
      data: {
        name: '停止中',
        color: '#FF6400 ',
        edit: 0,
        stop: 0,
        renewal: 0,
      },
    },
    {
      value: 3,
      data: {
        name: '已停止',
        color: '#FF0000',
        edit: 0,
        stop: 0,
        renewal: 0,
      },
    },
    {
      value: 4,
      data: {
        name: '已完成',
        color: '#27DD72',
        edit: 0,
        stop: 0,
        renewal: 1,
      },
    },
  ],
};

const isArrears = {
  title: '是否欠费',
  list: [
    {
      value: 0,
      name: '正常',
    },
    {
      value: 1,
      name: '欠费',
    },
  ],
};

// 收款方式
const payType = {
  title: '收款方式',
  list: [
    {
      value: 0,
      label: '预收',
    },
    {
      value: 1,
      label: '后收',
    },
  ],
};

// 结算方式
const settlementMethod = {
  title: '结算方式',
  list: [
    {
      value: 1,
      name: '月结',
    },
    {
      value: 2,
      name: '季结',
    },
    {
      value: 3,
      name: '半年结',
    },
    {
      value: 4,
      name: '年结',
    },
    {
      value: 0,
      name: '按次',
    },
  ],
};

// 源单类型
const sourceBillType = {
  title: '源单类型',
  list: [
    {
      value: 0,
      name: '-',
    },
    {
      value: 1,
      name: '合同',
    },
  ],
};

// 含税单价的单位 0-一次 1-月 2-季 4-年结
const TaxPriceUnit = {
  title: '含税单价',
  list: [
    {
      value: 1,
      name: '月',
    },
    {
      value: 2,
      name: '季',
    },
    {
      value: 4,
      name: '年',
    },
    {
      value: 0,
      name: '次',
    },
  ],
};

export default {
  contractStatus: getData(contractStatus),
  isArrears: getData(isArrears),
  payType: getData(payType),
  settlementMethod: getData(settlementMethod),
  sourceBillType: getData(sourceBillType),
  TaxPriceUnit: getData(TaxPriceUnit),
};
