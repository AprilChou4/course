import dictionary from './dictionary';

// 周期性服务的必填字段
const cycleRequiredFields = [
  'serviceItemId',
  'serviceTypeName',
  'unitPriceContainTax',
  'priceUnit',
  'startDate',
  'endDate',
  'servicePeriodNum',
  'settlementMethod',
  'money',
];
// 非周期性服务的必填字段
const noCycleRequiredFields = [
  'serviceItemId',
  'serviceTypeName',
  'unitPriceContainTax',
  'priceUnit',
  'endDate',
  'settlementMethod',
  'money',
];

export { dictionary, cycleRequiredFields, noCycleRequiredFields };
