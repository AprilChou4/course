/**
 * 查看合同
 */
import { nuomi } from 'nuomi';
import add from '../add';

export default nuomi.extend(add, {
  id: 'contractView',
  state: {
    status: 3,
  },
});
