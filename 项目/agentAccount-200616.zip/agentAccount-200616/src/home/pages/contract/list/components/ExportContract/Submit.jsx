import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import { ExportText } from '@components';
import { validateArrayLength } from '@utils';

const Export = ({ contentRef, selectedRowKeys, dispatch }) => {
  const handleSubmit = useCallback(async () => {
    const query = await dispatch({
      type: 'getQueryParams',
      payload: {
        current: undefined,
        pageSize: undefined,
      },
    });
    let params;
    contentRef.current.form.validateFields((err, values) => {
      if (err) return;
      params = values;
    });
    return { ...(query || {}), ...(params || {}) };
  }, [contentRef, dispatch]);

  return (
    <ExportText
      className="f-dib"
      method="post"
      url={`${basePath}instead/v2/customer/contract/export.do`}
      data={{
        ...(validateArrayLength(selectedRowKeys) ? { contractIds: selectedRowKeys } : {}),
      }}
      onSubmit={handleSubmit}
    >
      <Button type="primary">确定下载</Button>
    </ExportText>
  );
};

export default connect(({ contractTable: { selectedRowKeys } }) => ({
  selectedRowKeys,
}))(Export);
