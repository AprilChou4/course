/**
 * 批量导入合同
 */
import React from 'react';
import { connect } from 'nuomi';
import { AntdModal } from '@components';
import Content from './Content';
import styles from './style.less';

const ImportContract = ({ visible, dispatch }) => {
  const handleCancel = () => {
    dispatch({
      type: 'hideImportModal',
    });
  };

  return (
    <AntdModal
      title="批量导入合同"
      width={640}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      className={styles.modal}
      footer={null}
    >
      <Content />
    </AntdModal>
  );
};

export default connect(({ importModal: { visible } }) => ({
  visible,
}))(ImportContract);
