/**
 * 导出合同
 */
import React from 'react';
import { connect } from 'nuomi';

const Export = ({ dispatch }) => {
  const handleClick = () => {
    dispatch({
      type: 'handleExportContract',
    });
  };

  return <div onClick={handleClick}>导出</div>;
};

export default connect()(Export);
