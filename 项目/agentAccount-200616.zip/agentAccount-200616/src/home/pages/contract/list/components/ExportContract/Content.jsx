import React, { forwardRef, useImperativeHandle } from 'react';
import { Form, Radio } from 'antd';
import { GenFormItem } from '@components';
import styles from './style.less';

const { Group: RadioGroup } = Radio;

const Content = forwardRef(({ form }, ref) => {
  // 传给父组件
  useImperativeHandle(ref, () => ({ form }), [form]);

  return (
    <Form>
      <GenFormItem
        form={form}
        name="exportType"
        initialValue={0}
        rules={[
          {
            required: true,
            message: '请选择导出类型',
          },
        ]}
        className={styles.exportType}
      >
        <RadioGroup>
          <Radio value={0}>导出合同列表（简表）</Radio>
          <div className={styles.subTitle}>适用综合汇总数据分析</div>
          <Radio value={1}>导出合同列表（明细表）</Radio>
          <div className={styles.subTitle}>适用于单项服务数据分析</div>
        </RadioGroup>
      </GenFormItem>
    </Form>
  );
});

export default Form.create()(Content);
