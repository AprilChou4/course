/**
 * 新增合同
 */
import React from 'react';
import { Button } from 'antd';
import { handleRouterChange } from '@utils';

const Add = () => {
  const handleAdd = () => {
    handleRouterChange.handleToContractAdd();
  };

  return (
    <Button type="primary" onClick={handleAdd}>
      新增合同
    </Button>
  );
};

export default Add;
