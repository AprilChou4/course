import React from 'react';
import ContractList from '../ContractList';

const Content = () => {
  return <ContractList />;
};

export default Content;
