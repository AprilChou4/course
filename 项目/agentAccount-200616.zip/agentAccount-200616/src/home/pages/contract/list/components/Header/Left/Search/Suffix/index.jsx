import React, { useState, useCallback } from 'react';
import { connect } from 'nuomi';
import { Popover } from 'antd';
import { LinkButton } from '@components';
import Content from './Content';
import styles from './style.less';

const Suffix = ({ dispatch }) => {
  const [visible, setVisible] = useState(false);

  const handleVisibleChange = useCallback(
    (vsb) => {
      setVisible(vsb);
      if (!vsb) {
        // 重置form的值
        dispatch({
          type: 'resetSearchFormValues',
        });
      }
    },
    [dispatch],
  );

  return (
    <Popover
      placement="bottom"
      trigger="click"
      overlayClassName={styles.overlay}
      overlayStyle={{ width: 420 }}
      visible={visible}
      getPopupContainer={() => document.querySelector('.layout-left')} // container不要放在Antd.Input内部，Input会影响Popover内输入框的部分样式
      // getPopupContainer={(trigger) => trigger.parentNode.parentNode.parentNode}
      onVisibleChange={handleVisibleChange}
      content={<Content visible={visible} setVisible={setVisible} />}
    >
      <LinkButton>更多条件</LinkButton>
    </Popover>
  );
};

export default connect()(Suffix);
