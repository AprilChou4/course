/**
 * 合同列表
 */
import React, { useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { AntdTable } from '@components';
import { isNil, postMessageRouter } from '@utils';
import getColumns from './columns';

const scroll = { x: '100%', y: true };

const Receivable = ({
  tableLoading,
  rowKey,
  dataSource,
  columnSource,
  selectedRowKeys,
  pagination,
  queryCustomerNameNo,
  contractExpireDateType,
  dispatch,
}) => {
  const handleNumberClick = useCallback(
    (record) => {
      postMessageRouter({
        type: 'agentAccount/routerLocation',
        payload: {
          url: '/contract/view',
          query: { id: record[rowKey] },
        },
      });
    },
    [rowKey],
  );

  // 头部纳税性质、记账状态等下拉筛选
  const handleTableFilter = useCallback(
    ({ key }, field) => {
      dispatch({
        type: 'initQuery',
        payload: {
          init: true,
          [field]: key,
        },
      });
    },
    [dispatch],
  );

  const currentPage = pagination.current;
  const columns = useMemo(
    () =>
      getColumns({
        columnSource,
        currentPage,
        pageSize: pagination.pageSize,
        contractExpireDateType,
        handleNumberClick,
        handleTableFilter,
      }),

    [
      columnSource,
      contractExpireDateType,
      currentPage,
      handleNumberClick,
      handleTableFilter,
      pagination.pageSize,
    ],
  );

  const rowSelection = useMemo(
    () => ({
      columnWidth: 36,
      selectedRowKeys,
      onChange(sRowKeys, sRows) {
        dispatch({
          type: 'updateContractTable',
          payload: {
            selectedRowKeys: sRowKeys,
            selectedRows: sRows,
          },
        });
      },
    }),
    [dispatch, selectedRowKeys],
  );

  const handleTableChange = useCallback(
    ({ current, pageSize }) => {
      dispatch({
        type: 'initQuery',
        payload: {
          current,
          pageSize,
        },
      });
    },
    [dispatch],
  );

  const handleSettingClick = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        customColModal: { visible: true },
      },
    });
  }, [dispatch]);

  const locale = useMemo(
    () => ({
      emptyText: isNil(queryCustomerNameNo, '')
        ? `暂无合同`
        : `未找到与 “${queryCustomerNameNo}” 相关的合同`,
    }),
    [queryCustomerNameNo],
  );

  return (
    <AntdTable
      bordered
      showSettingIcon
      rowKey={rowKey}
      locale={locale}
      scroll={scroll}
      loading={tableLoading}
      columns={columns}
      dataSource={dataSource}
      rowSelection={rowSelection}
      pagination={pagination}
      onChange={handleTableChange}
      onSettingClick={handleSettingClick}
    />
  );
};

export default connect(
  ({
    loadings: { $query: tableLoading },
    contractTable: { rowKey, dataSource, columnSource, selectedRowKeys, pagination },
    lastQuery: { customerNameNo: queryCustomerNameNo },
    query: { contractExpireDateType },
  }) => ({
    tableLoading,
    rowKey,
    dataSource,
    columnSource,
    selectedRowKeys,
    pagination,
    queryCustomerNameNo,
    contractExpireDateType,
  }),
)(Receivable);
