import React from 'react';
import moment from 'moment';
import cls from 'classnames';
import { Icon, Badge, Typography } from 'antd';
import { LinkButton, ServiceTypeTag, FilterDropdown } from '@components';
import { isNil, moneyFormat, validateArrayLength, postMessageRouter } from '@utils';
import { dictionary } from '../../../utils';
import styles from './styles.less';

const { Paragraph } = Typography;
const dateFormat = 'YYYY.MM.DD';
const monthFormat = 'YYYY.MM';
const getPaddingRight = (record) => {
  let value = 0;
  if (record.isArrears) {
    value += 20;
  }
  if (record.isRenew === 1) {
    value += 20;
  }
  return value;
};
const routerLink = (payload = {}) =>
  postMessageRouter({
    type: 'agentAccount/routerLocation',
    payload,
  });

export default ({
  columnSource,
  currentPage,
  pageSize,
  contractExpireDateType,
  handleNumberClick,
  handleTableFilter,
}) => {
  const columnsMap = {
    index: {
      title: '序号',
      width: 50,
      ellipsis: true,
      align: 'center',
      render: (text, record, index) => index + 1 + (currentPage - 1) * pageSize,
    },
    customerName: {
      title: '客户名称',
      width: 209,
      ellipsis: true,
      className: 'th-center',
    },
    contractNo: {
      title: '合同编号',
      width: 142,
      ellipsis: true,
      className: 'th-center td-padding-half',
      render: (text, record) => (
        <div className="f-pr" style={{ paddingLeft: 4, paddingRight: getPaddingRight(record) }}>
          <LinkButton
            plain
            ellipsis
            onClick={() => handleNumberClick(record)}
            className={styles.contractNo}
          >
            {text}
          </LinkButton>
          <em className={styles.marks}>
            {!!record.isArrears && <span className={styles['tag-red']}>欠</span>}
            {record.isRenew === 1 && <span className={styles['tag-red']}>续</span>}
          </em>
        </div>
      ),
    },
    serviceName: {
      title: '服务类型',
      width: 130,
      className: 'th-center',
      render: (value) => (value ? <ServiceTypeTag list={value} /> : <div className="f-tac">-</div>),
    },
    servicePeriod: {
      title: () => (
        <FilterDropdown
          fieldName="服务期间"
          trigger={['click', 'hover']}
          list={[
            {
              value: -1,
              title: '全部',
            },
            {
              value: 0,
              title: '已过期',
            },
            {
              value: 1,
              title: '近一个月到期',
            },
            {
              value: 2,
              title: '近三个月到期',
            },
            {
              value: 3,
              title: '进半年到期',
            },
          ]}
          selectedKeys={isNil(contractExpireDateType, ['']) ? [] : [contractExpireDateType]}
          menuClick={(data) => handleTableFilter(data, 'contractExpireDateType')}
        />
      ),
      key: 'servicePeriod',
      align: 'center',
      width: 125,
      className: 'f-pr',
      filterIcon: (filtered) => (
        <Icon
          component={() => <i className={cls('iconfont', { 'c-primary': filtered })}>&#xe688;</i>}
        />
      ),
      render: (value, record) =>
        `${record.startDate ? moment(record.startDate, 'X').format(monthFormat) : ''}-${
          record.endDate ? moment(record.endDate, 'X').format(monthFormat) : ''
        }`,
    },
    contractMoney: {
      title: '合同金额',
      width: 120,
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    receivedMoney: {
      title: '已收金额',
      width: 120,
      className: 'th-center td-right',
      render: (value) => moneyFormat(value),
    },
    signDate: {
      title: '签订时间',
      width: 100,
      align: 'center',
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
    contractStatus: {
      title: '合同状态',
      align: 'center',
      width: 90,
      render(value) {
        const data = dictionary.contractStatus.map[value];
        return data ? <Badge color={data.color} text={data.name} /> : '-';
      },
    },
    signStaffName: {
      title: '签单人',
      align: 'center',
      width: 110,
      ellipsis: true,
    },
    remark: {
      title: '备注',
      width: 105,
      ellipsis: true,
      className: 'th-center',
    },
    electronicContractTitle: {
      title: '电子合同',
      align: 'center',
      width: 105,
      ellipsis: true,
      render: (value) => (
        <Paragraph ellipsis style={{ margin: 0 }}>
          {value}
        </Paragraph>
      ),
    },
    contractFiles: {
      title: '附件合同',
      align: 'center',
      width: 147,
      ellipsis: true,
      render: (value) => (
        <Paragraph ellipsis style={{ margin: 0 }}>
          {value}
        </Paragraph>
      ),
    },
    srbNo: {
      title: '合同应收单',
      align: 'center',
      width: 129,
      ellipsis: true,
      className: 'td-padding-half',
      render: (value, record) =>
        value ? (
          <LinkButton
            plain
            ellipsis
            underline
            style={{ maxWidth: '100%' }}
            onClick={() =>
              routerLink({
                url: '/charge/viewReceivable',
                query: { id: record.srbId },
              })
            }
          >
            {value}
          </LinkButton>
        ) : (
          '-'
        ),
    },
    taskNo: {
      title: '合同任务单',
      align: 'center',
      width: 148,
      className: 'td-padding-half',
      render: (value, record) =>
        validateArrayLength(record.taskList)
          ? record.taskList.map((item, index) => (
              <LinkButton
                key={item.taskId || index}
                plain
                ellipsis
                underline
                style={{ maxWidth: '100%' }}
                onClick={() =>
                  routerLink({
                    url: '/businessServe/viewTask',
                    query: { id: item.taskId },
                  })
                }
              >
                {item.taskNo}
              </LinkButton>
            ))
          : '-',
    },
    payType: {
      title: '收款方式',
      align: 'center',
      width: 78,
      render: (value) => dictionary.payType.map[value],
    },
    settlementMethod: {
      title: '结算方式',
      align: 'center',
      width: 78,
      render: (value) => dictionary.settlementMethod.map[value],
    },
    validPeriodNum: {
      title: '有效服务期',
      align: 'center',
      width: 90,
    },
    createStaffName: {
      title: '创建人',
      align: 'center',
      width: 100,
      ellipsis: true,
    },
    createDate: {
      title: '创建日期',
      width: 90,
      align: 'center',
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
    updateStaffName: {
      title: '最新修改人',
      align: 'center',
      width: 100,
      ellipsis: true,
    },
    updateDate: {
      title: '修改日期',
      width: 110,
      align: 'center',
      render: (value) => (value ? moment(value, 'X').format(dateFormat) : ''),
    },
  };

  // 根据columnSource生成columns
  const columns = [];
  if (validateArrayLength(columnSource)) {
    columns.push(columnsMap.index);
    const basicColSetting = { width: 100, align: 'center', ellipsis: true };
    columnSource.forEach((item) => {
      const col = columnsMap[item?.fieldKey];
      if (!item?.selected) return;
      columns.push({
        ...(col || basicColSetting),
        ...(col ? {} : { title: item?.fieldName }),
        dataIndex: item?.fieldKey,
      });
    });
  }

  return columns;
};
