/**
 * 终止合同
 */
import React from 'react';
import { connect } from 'nuomi';

const Stop = ({ dispatch }) => {
  const handleClick = () => {
    dispatch({
      type: 'handleStopContract',
    });
  };

  return <div onClick={handleClick}>终止</div>;
};

export default connect()(Stop);
