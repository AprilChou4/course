/**
 * 导入合同
 */
import React from 'react';
import { connect } from 'nuomi';

const Import = ({ dispatch }) => {
  const handleClick = () => {
    dispatch({
      type: 'handleImportContract',
    });
  };

  return <div onClick={handleClick}>导入</div>;
};

export default connect()(Import);
