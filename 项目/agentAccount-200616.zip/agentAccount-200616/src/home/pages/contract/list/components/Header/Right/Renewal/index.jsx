/**
 * 续签合同
 */
import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';

const Renewal = ({ dispatch }) => {
  const handleClick = () => {
    dispatch({
      type: 'handleRenewalContract',
    });
  };

  return (
    <Button type="primary" onClick={handleClick}>
      续签
    </Button>
  );
};

export default connect()(Renewal);
