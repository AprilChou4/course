import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { AntdSearch } from '@components';
import Suffix from './Suffix';
import styles from './style.less';

const Search = ({ customerNameNo, headerSearchReadOnly, dispatch }) => {
  const handleSearch = useCallback(
    (value) => {
      if (value) {
        dispatch({
          type: 'query',
          payload: {
            init: true,
          },
        });
      } else {
        dispatch({
          type: 'updateState',
          payload: {
            headerSearchReadOnly: false,
          },
        });
        dispatch({
          type: 'updateSearchData',
        });
      }
    },
    [dispatch],
  );

  const handleInputChange = useCallback(
    (e) => {
      dispatch({
        type: 'updateQuery',
        payload: {
          customerNameNo: e.target.value,
        },
      });
    },
    [dispatch],
  );

  return (
    <AntdSearch
      allowClear
      placeholder="请输入客户名称/合同编号"
      suffix={<Suffix />}
      value={customerNameNo}
      onSearch={handleSearch}
      onChange={handleInputChange}
      onMouseEnter={(e) => {
        e.target.focus();
      }}
      readOnly={headerSearchReadOnly}
      style={{ width: 320 }}
      className={styles.search}
    />
  );
};

export default connect(({ headerSearchReadOnly, query: { customerNameNo } }) => ({
  headerSearchReadOnly,
  customerNameNo,
}))(Search);
