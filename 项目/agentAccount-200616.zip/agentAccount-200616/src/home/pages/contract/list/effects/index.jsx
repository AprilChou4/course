/* eslint-disable no-nested-ternary */
/* eslint-disable consistent-return */
import React from 'react';
import { Checkbox, message } from 'antd';
import { router, store } from 'nuomi';
import moment from 'moment';
import globalServices from '@home/services';
import { AsyncShowConfirm, AsyncShowConfirms } from '@components';
import {
  get,
  isNil,
  isEmpty,
  omitBy,
  delay,
  flatMap,
  validateArrayLength,
  handleRouterChange,
  postMessageRouter,
} from '@utils';
import services from '../services';
import { dictionary } from '../../utils';
import commonServices from '../../services';

const dateFormat = 'YYYY-MM-DD';

// 把顶部搜索框的表单数据转成文本
const getSearchData = (data, { chargingItemTypeList, businessStaffList }) => {
  const searchData = [];
  for (const i in data) {
    if (i !== 'status') {
      const value = data[i];
      if (!isEmpty(value)) {
        switch (i) {
          case 'contractStatus':
            searchData.push({
              title: dictionary[i].title,
              text: value.map((ele) => dictionary[i].map[ele].name),
            });
            break;
          // case 'isArrears':
          //   searchData.push({
          //     title: dictionary[i].title,
          //     text: value.map((ele) => dictionary[i].map[ele]),
          //   });
          //   break;
          case 'customerNameNo':
            searchData.push({
              title: '客户名称',
              text: value,
            });
            break;
          case 'serviceItemIds':
            searchData.push({
              title: '服务项目',
              text: [].concat(value).map((ele) => {
                return chargingItemTypeList.find((item) => item.serviceProductId === ele)
                  .serviceProductName;
              }),
            });
            break;
          case 'contractNo':
            searchData.push({
              title: '合同编号',
              text: value,
            });
            break;
          case 'signStaffId':
            searchData.push({
              title: '签单人',
              text: []
                .concat(value)
                .map((ele) => businessStaffList.find((item) => item.staffId === ele).realName),
            });
            break;
          case 'contractExpireDate':
            searchData.push({
              title: '到期时间',
              text: `${
                value[0]
                  ? moment(value[0])
                      .startOf('day')
                      .format(dateFormat)
                  : ''
              }-${
                value[1]
                  ? moment(value[1])
                      .endOf('day')
                      .format(dateFormat)
                  : ''
              }`,
            });
            break;
          case 'signDate':
            searchData.push({
              title: '签订时间',
              text: `${
                value[0]
                  ? moment(value[0])
                      .startOf('day')
                      .format(dateFormat)
                  : ''
              }-${
                value[1]
                  ? moment(value[1])
                      .endOf('day')
                      .format(dateFormat)
                  : ''
              }`,
            });
            break;
          case 'contractMoneyMin':
            searchData.push({
              title: '合同金额最小值',
              text: value,
            });
            break;
          case 'contractMoneyMax':
            searchData.push({
              title: '合同金额最大值',
              text: value,
            });
            break;
          default:
            break;
        }
      }
    }
  }
  const values = [];
  if (searchData.length) {
    searchData.forEach((ele) => {
      const text = Array.isArray(ele.text) ? ele.text.join('、') : ele.text;
      if (text) {
        values.push(`${ele.title}：${text}`);
      }
    });
    return values.join('；');
  }
  return undefined;
};

export default {
  // 初始化
  async initData(payload) {
    const { customerid } = router.location().query || {};
    this.updateQuery({
      customerId: customerid,
    });
    await this.query(payload);
  },

  // 查询
  async query(payload) {
    // this.getCompanyBasicSetting();
    // this.getCompleteUserList();
    this.getCustomCols();
    await this.$query(payload);
  },

  async initQuery(payload = {}) {
    const { init, ...rest } = payload;
    this.updateContractTable({
      selectedRowKeys: [],
      selectedRows: [],
    });
    this.updateQuery(rest);
    await this.query({ init });
  },

  // 处理查询参数
  getQueryParams(args = {}) {
    const {
      headerSearchReadOnly,
      query: { headerSearchFormData, ...restQuery },
    } = this.getState();
    return omitBy(
      {
        ...restQuery,
        ...headerSearchFormData,
        // 处理顶部搜索框传参
        customerNameNo:
          (headerSearchReadOnly ? headerSearchFormData.customerNameNo : restQuery.customerNameNo) ||
          undefined,
        // 处理searchFormData
        // isArrears:
        //   validateArrayLength(headerSearchFormData.isArrears) === 1
        //     ? headerSearchFormData.isArrears.includes(0)
        //       ? 0
        //       : 1
        //     : undefined,
        contractExpireDate: undefined,
        contractExpireDateMin:
          headerSearchFormData.contractExpireDate && headerSearchFormData.contractExpireDate[0]
            ? moment(headerSearchFormData.contractExpireDate[0])
                .startOf('day')
                .format('X')
            : undefined,
        contractExpireDateMax:
          headerSearchFormData.contractExpireDate && headerSearchFormData.contractExpireDate[1]
            ? moment(headerSearchFormData.contractExpireDate[1])
                .endOf('day')
                .format('X')
            : undefined,
        signDate: undefined,
        signDateMin:
          headerSearchFormData.signDate && headerSearchFormData.signDate[0]
            ? moment(headerSearchFormData.signDate[0])
                .startOf('day')
                .format('X')
            : undefined,
        signDateMax:
          headerSearchFormData.signDate && headerSearchFormData.signDate[1]
            ? moment(headerSearchFormData.signDate[1])
                .endOf('day')
                .format('X')
            : undefined,
        contractExpireDateType: isNil(restQuery.contractExpireDateType, ['', '-1'])
          ? undefined
          : restQuery.contractExpireDateType,
        ...args,
      },
      isEmpty,
    );
  },

  // 查询合同列表
  async $query(args = {}) {
    const { contractTable } = this.getState();
    const { init, ...payload } = args;
    const param = this.getQueryParams();
    const params = {
      ...param,
      ...payload,
      ...(init ? { current: 1 } : {}),
    };
    const data = await commonServices.getContractList(params).catch(() => {});

    const list = get(data, 'list', []);
    const total = get(data, 'count', 0);
    this.updateContractTable({
      dataSource: list,
      pagination: {
        ...contractTable.pagination,
        total,
        current: params.current,
        pageSize: params.pageSize,
      },
    });
    this.updateState({
      lastQuery: params,
    });
  },

  // 更新query
  updateQuery(payload = {}) {
    const { query } = this.getState();
    this.updateState({
      query: {
        ...query,
        ...payload,
      },
    });
  },

  // 重置顶部form的值
  resetSearchFormValues() {
    const {
      query: { headerSearchFormData },
    } = this.getState();
    this.updateQuery({
      headerSearchFormData: { ...headerSearchFormData },
    });
  },

  // 更新头部搜索框表单数据
  async updateSearchData(payload) {
    const {
      headerSearchFormInitialValues,
      chargingItemTypeList,
      businessStaffList,
    } = this.getState();
    // 组装顶部输入框的值
    const searchDataText = getSearchData(payload || {}, {
      chargingItemTypeList,
      businessStaffList,
    });
    this.updateQuery({
      customerNameNo: searchDataText,
      headerSearchFormData: payload || headerSearchFormInitialValues,
    });
    await this.$query({ init: true });
  },

  // 查询头部搜索框依赖的列表
  querySearchDependence() {
    this.getBusinessStaffList();
    this.getChargingItems();
  },

  // 获取业务员列表
  async getBusinessStaffList(payload = {}) {
    const businessStaffList = await globalServices.getStaffList(payload);
    this.updateState({
      businessStaffList,
    });
  },
  // 获取服务项目列表
  async getChargingItems(payload = {}) {
    const chargingItemList = await globalServices.getChargingItems(payload);
    this.updateState({
      chargingItemList,
      chargingItemTypeList: flatMap(chargingItemList || [], (item) =>
        get(item, 'serviceProductVOList', []),
      ),
    });
  },

  // 更新表格相关数据
  updateContractTable(payload = {}) {
    const { contractTable } = this.getState();
    this.updateState({
      contractTable: {
        ...contractTable,
        ...payload,
      },
    });
  },

  // 处理删除合同逻辑
  async handleDeleteContract() {
    const that = this;
    const {
      contractTable: { rowKey, selectedRowKeys, dataSource },
    } = this.getState();
    const length = validateArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请选择要删除的合同');
      return;
    }

    if (length > 1) {
      // 批量删除
      const values = { isDeleteContractSrb: true };
      await AsyncShowConfirms({
        title: '你确定要删除所选合同信息吗？',
        content: (
          <Checkbox
            defaultChecked={values.isDeleteContractSrb}
            onChange={(e) => {
              values.isDeleteContractSrb = e.target.checked;
            }}
          >
            同步删除合同对应的应收单
          </Checkbox>
        ),
        async onOk() {
          await that.deleteContract({ selectedRowKeys, ...values });
        },
      });
    } else {
      // 单个删除
      // 如果该合同有应收单，需要确认；没有应收单则直接删除
      const selectedRowData = dataSource.find((item) => item[rowKey] === selectedRowKeys[0]);
      const type = selectedRowData?.srbNo
        ? await AsyncShowConfirm({
            title: '是否同步删除关联的应收单？',
            cancelText: '忽略',
            okText: '删除',
          })
        : false;
      await this.deleteContract({ selectedRowKeys, isDeleteContractSrb: type });
    }
  },

  // 删除合同
  async deleteContract(payload = {}) {
    const { selectedRowKeys, ...rest } = payload;
    const length = validateArrayLength(selectedRowKeys);

    const data = await commonServices.deleteContract(
      { contractIds: selectedRowKeys, ...rest },
      { loading: '正在删除...' },
    );
    const failedContractNos = get(data, 'failedContractNos', []);

    const deleteStatus = get(data, 'deleteStatus');
    if (deleteStatus === 1) {
      message.success('删除成功');
    } else {
      const failedReason = get(data, 'failedReason', '删除失败');
      if (length === 1) {
        message.warning(failedReason);
      } else {
        this.updateDeleteResult({
          visible: true,
          data: {
            failedReason,
            successCount: get(data, 'successCount', 0),
            failedCount: get(data, 'failedCount', 0),
            failedContractNos,
          },
        });
      }
    }
    if (deleteStatus === 1 || length > 1) {
      // 删除合同后关闭相关页签（新增、查看、变更、续签）
      this.afterDelete({ contractIds: selectedRowKeys, failedContractNos });
      await this.initQuery();
    }
  },
  // 关闭删除结果弹窗
  hideDeleteResult() {
    this.updateState({
      deleteResult: { visible: false },
    });
  },
  // 更新删除结果弹窗
  updateDeleteResult(payload = {}) {
    const { deleteResult } = this.getState();
    this.updateState({
      deleteResult: { ...deleteResult, ...payload },
    });
  },
  // 删除合同后关闭相关页签（新增、查看、变更、续签）
  afterDelete(payload = {}) {
    const { contractIds = [], failedContractNos = [] } = payload;
    const closeTab = ({ namespace, path }) => {
      const contractStore = store.getStore(namespace);
      const { contractId, contractNo } = get(
        contractStore && contractStore.getState(),
        'formInitialValues',
        {},
      );
      if (
        contractId &&
        contractIds.includes(contractId) &&
        !failedContractNos.includes(contractNo)
      ) {
        if (namespace === 'contractAdd') {
          // 如果删除的合同已经在新增合同页面打开了，重置新增合同页面
          contractStore.dispatch({
            type: 'handleNewContract',
          });
        } else {
          // 如果删除的合同已经在查看、续签、变更合同页面打开了，关闭相关标签页
          postMessageRouter({
            type: 'agentAccount/closeTab',
            payload: { path },
          });
        }
      }
    };

    [
      { namespace: 'contractAdd' },
      { namespace: 'contractEdit', path: '/contract/edit' },
      { namespace: 'contractRenewal', path: '/contract/renewal' },
      { namespace: 'contractView', path: '/contract/view' },
    ].forEach((item) => closeTab(item));
  },

  // 处理续签逻辑
  handleRenewalContract() {
    const {
      contractTable: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = validateArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请选择要续签的合同');
    } else if (length > 1) {
      message.warning('合同只支持单个续签');
    } else {
      const { contractStatus, contractId } = get(selectedRows, '[0]', {});
      const contractStatusDate = dictionary.contractStatus.map[contractStatus] || {};
      if (contractStatusDate.renewal) {
        this.updateRenewalModal({
          visible: true,
          data: {
            contractId,
          },
        });
      } else {
        message.warning(`${contractStatusDate.name}的合同不支持续签`);
      }
    }
  },
  // 隐藏续签合同弹窗
  hideRenewalModal() {
    this.updateState({
      renewalModal: { visible: false },
    });
  },
  // 更新续签合同弹窗
  updateRenewalModal(payload = {}) {
    const { renewalModal } = this.getState();
    this.updateState({
      renewalModal: { ...renewalModal, ...payload },
    });
  },
  // 续签合同
  async renewalContract(payload = {}) {
    await commonServices.renewalContract(payload, {
      loading: '正在续签中...',
      successMsg: '续签成功',
    });
    this.hideRenewalModal();
    await this.initQuery();
  },

  // 处理终止逻辑
  handleStopContract() {
    const {
      contractTable: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = validateArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请选择要终止的合同');
    } else if (length > 1) {
      message.warning('合同只支持单个终止');
    } else {
      const { contractStatus, contractId } = get(selectedRows, '[0]', {});
      const contractStatusDate = dictionary.contractStatus.map[contractStatus] || {};
      if (contractStatusDate.stop) {
        this.updateStopModal({
          visible: true,
          data: {
            contractId,
          },
        });
      } else {
        message.warning(`${contractStatusDate.name}的合同不支持终止`);
      }
    }
  },
  // 隐藏终止合同弹窗
  hideStopModal() {
    this.updateState({
      stopModal: { visible: false },
    });
  },
  // 更新终止合同弹窗
  updateStopModal(payload = {}) {
    const { stopModal } = this.getState();
    this.updateState({
      stopModal: { ...stopModal, ...payload },
    });
  },
  // 终止合同
  async stopContract(payload = {}) {
    await commonServices.stopContract(payload, {
      loading: '正在终止中...',
      successMsg: '终止成功',
    });
    this.hideStopModal();
    await this.initQuery();
  },

  // 处理导出逻辑
  handleExportContract() {
    this.updateExportModal({
      visible: true,
    });
  },
  // 隐藏导出合同弹窗
  hideExportModal() {
    this.updateState({
      exportModal: { visible: false },
    });
  },
  // 更新导出合同弹窗
  updateExportModal(payload = {}) {
    const { exportModal } = this.getState();
    this.updateState({
      exportModal: { ...exportModal, ...payload },
    });
  },
  // 导出合同
  async exportContract(payload = {}) {
    await commonServices.stopContract(payload, {
      loading: '正在终止中...',
      successMsg: '终止成功',
    });
    this.hideExportModal();
    await this.initQuery();
  },

  // 处理导入逻辑
  handleImportContract() {
    this.updateImportModal({
      visible: true,
    });
  },
  // 隐藏导入合同弹窗
  async hideImportModal() {
    const {
      importModal: {
        initData,
        data: { status },
      },
    } = this.getState();
    this.updateImportModal({
      visible: false,
      data: initData,
    });
    // 如果有导入文件，关闭弹窗后刷新列表
    status !== 0 && (await this.initQuery());
  },
  // 更新导入合同弹窗
  updateImportModal(payload = {}) {
    const { importModal } = this.getState();
    this.updateState({
      importModal: { ...importModal, ...payload },
    });
  },
  // 更新导入合同弹窗data
  updateImportModalData(payload = {}) {
    const { importModal } = this.getState();
    this.updateState({
      importModal: {
        ...importModal,
        data: {
          ...importModal.data,
          ...payload,
        },
      },
    });
  },

  // 合同导入进度查询
  async getImportProcess(payload = {}) {
    const { clearImportProcessInterval } = payload;
    const {
      importModal: {
        data: { taskId },
      },
    } = this.getState();
    if (!taskId) return;
    this.updateImportModalData({
      status: 1,
    });
    const data = await commonServices.getImportProcess({ taskId });
    const { process, fileName, filePath, successCount, failedCount } = data || {};
    if (filePath) {
      // 关闭进度请求循环
      clearImportProcessInterval();

      this.updateImportModalData({
        process,
      });
      await delay();
      // 有失败记录了
      this.updateImportModalData({
        status: 3,
        errorResult: {
          fileName,
          filePath,
          successCount,
          failedCount,
        },
      });
    } else if (!isNil(process)) {
      if (process === 100) {
        // 关闭进度请求循环
        clearImportProcessInterval();

        this.updateImportModalData({
          process,
        });
        await delay();

        // 导入成功
        this.updateImportModalData({
          status: 2,
        });
      } else {
        // 更新进度
        this.updateImportModalData({
          status: 1,
          process,
        });
      }
    }
  },

  // 处理变更逻辑
  handleEditContract() {
    const {
      contractTable: { selectedRowKeys, selectedRows },
    } = this.getState();
    const length = validateArrayLength(selectedRowKeys);
    if (!length) {
      message.warning('请选择要变更的合同');
    } else if (length > 1) {
      message.warning('合同只支持单个变更');
    } else {
      const { contractStatus, contractId } = get(selectedRows, '[0]', {});
      const contractStatusDate = dictionary.contractStatus.map[contractStatus] || {};
      if (contractStatusDate.edit) {
        handleRouterChange.handleToContractEdit({ contractId });
      } else {
        message.warning(`${contractStatusDate.name}的合同不支持变更`);
      }
    }
  },

  // 查询自定义列
  async getCustomCols(payload = {}) {
    const data = await services.getCustomCols(payload);
    !payload.isInit &&
      this.updateContractTable({
        columnSource: data || [],
      });
    return data;
  },

  // 更新自定义列
  async updateCustomCols(payload = {}) {
    const { customizeColumns } = payload;
    const {
      query: { contractExpireDateType },
    } = this.getState();
    // 如果当前筛选条件有“服务期间”，然后关闭了“服务期间”列，那么要重置服务期间筛选条件
    if (
      !isNil(contractExpireDateType, ['', '-1']) &&
      customizeColumns &&
      customizeColumns.some((item) => item.fieldKey === 'servicePeriod' && !item.selected)
    ) {
      this.updateQuery({ contractExpireDateType: '' });
    }

    await services.updateCustomCols(payload, {
      loading: '正在保存...',
      successMsg: '保存成功',
    });
    this.updateState({
      customColModal: { visible: false },
    });
    this.getCustomCols();
  },
};
