/**
 * 变更合同
 */
import React from 'react';
import { connect } from 'nuomi';

const Edit = ({ dispatch }) => {
  const handleClick = () => {
    dispatch({
      type: 'handleEditContract',
    });
  };

  return <div onClick={handleClick}>变更</div>;
};

export default connect()(Edit);
