import React from 'react';
import { Authority } from '@components';
import Search from './Search';

const Left = () => (
  <Authority code="13">
    <Search />
  </Authority>
);

export default Left;
