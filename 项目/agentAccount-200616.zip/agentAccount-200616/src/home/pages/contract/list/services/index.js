// import mock from './mock';
import { createServices } from '@utils';

export default createServices({
  getCustomCols: 'instead/v2/customer/contract/customizeColumn/get', // 查询合同自定义列数据
  updateCustomCols: 'instead/v2/customer/contract/customizeColumn/update::postJSON', // 更新合同自定义列
});
