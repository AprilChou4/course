/**
 * 合同列表
 */
import React from 'react';
import pubData from 'data';
import { NoAuthPage } from '@components';
import Main from './components/Main';
import effects from './effects';

const userAuth = pubData.get('authority');
const defaultCurrent = 1;
const defaultPageSize = 100;
const initImportModalData = {
  status: 0, // 当前导入状态（0：未导入，1：正在导入，2：导入成功，3：部分失败，4：导入失败(模板有误)）
  process: 0, // 导入进度
  taskId: '', // 查询进度的id
  file: {},
  // status为3时的导入失败结果
  errorResult: {
    fileName: '', // 失败记录文件名
    filePath: '', // 失败记录路径
    successCount: 0, // 成功的条数
    failedCount: 0, // 失败的条数
  },
};
const headerSearchFormInitialValues = {
  contractStatus: [0, 1, 2, 4],
  // isArrears: [0, 1],
  customerNameNo: undefined,
  serviceItemIds: undefined,
  contractNo: undefined,
  signStaffId: undefined,
  contractExpireDate: undefined,
  signDate: undefined,
  contractMoneyMin: undefined,
  contractMoneyMax: undefined,
};

export default {
  id: 'contractList',
  state: {
    title: '合同管理列表',
    // 顶部搜索框初始值
    headerSearchFormInitialValues,
    // 顶部搜索框是否只读状态
    headerSearchReadOnly: false,
    // 列表查询参数
    query: {
      customerId: '', // 客户id
      current: defaultCurrent,
      pageSize: defaultPageSize,
      customerNameNo: undefined, // 合同名称
      headerSearchFormData: headerSearchFormInitialValues, // 顶部搜索框form
      contractExpireDateType: '', // 时间范围,
    },
    // 记录上次的真实传参
    lastQuery: {},
    // 业务员列表
    businessStaffList: [],
    // 服务类型列表
    chargingItemList: [],
    // 服务项目列表
    chargingItemTypeList: [],
    // 合同表格相关数据
    contractTable: {
      rowKey: 'contractId',
      columnSource: [],
      dataSource: [],
      selectedRowKeys: [],
      selectedRows: [],
      pagination: {
        total: 0, // 数据总数
        current: defaultCurrent, // 当前页
        pageSize: defaultPageSize, // 每页条数
        pageSizeOptions: ['100', '200', '300'],
      },
    },
    // 合同删除结果弹窗
    deleteResult: {
      visible: false,
      data: {},
    },
    // 续签合同弹窗
    renewalModal: {
      visible: false,
      data: {},
    },
    // 终止合同弹窗
    stopModal: {
      visible: false,
      data: {},
    },
    // 导出合同弹窗
    exportModal: {
      visible: false,
      data: {},
    },
    // 导入合同弹窗
    importModal: {
      visible: false,
      data: initImportModalData,
      initData: initImportModalData,
    },
    // 自定义列弹窗
    customColModal: {
      visible: false,
    },
  },
  effects,
  render() {
    // 控制查看权限
    return userAuth[13] ? <Main /> : <NoAuthPage />;
  },
  onChange: {
    // 这里加上$让它在初始化的时候不执行，initData里再手动的去执行 query，否则 initData中无法拿到 query中请求得到的数据
    $query() {
      // 控制查看权限
      if (!userAuth[13]) return;

      this.store.dispatch({
        type: 'initData',
      });
    },
  },
  onInit() {
    // 控制查看权限
    if (!userAuth[13]) return;

    this.store.dispatch({
      type: 'initData',
      payload: { init: true },
    });
  },
};
