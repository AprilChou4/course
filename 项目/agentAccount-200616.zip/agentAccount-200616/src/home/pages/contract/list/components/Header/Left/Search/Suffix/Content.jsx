import React, { useEffect, useMemo } from 'react';
import { connect } from 'nuomi';
import { Form, Checkbox, DatePicker, Input, TreeSelect, Button } from 'antd';
import { GenFormItem, AntdInput, NumberInput, SuperSelect, AntdTreeSelect } from '@components';
import { isEmpty, getSelectOptions } from '@utils';
import { dictionary } from '../../../../../../utils';
import styles from './style.less';

const { Group: CheckboxGroup } = Checkbox;
const { RangePicker } = DatePicker;
const { SHOW_CHILD } = TreeSelect;
const dropdownStyle = { maxHeight: 260 };
const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const serviceItemIdsTreeNodeProps = (record) => ({
  childrenPropName: 'serviceProductVOList',
  value: record.serviceProductVOList
    ? `serviceTypeId-${record.serviceTypeId}`
    : record.serviceProductId,
  title: record[record.serviceProductVOList ? 'serviceName' : 'serviceProductName'],
});

const Content = ({
  visible,
  setVisible,
  form,
  form: { setFieldsValue, validateFields, resetFields },
  businessStaffList,
  chargingItemList,
  headerSearchFormData,
  dispatch,
}) => {
  const contractStatusContent = useMemo(
    () =>
      dictionary.contractStatus.list.map((item) => (
        <Checkbox key={item.value} value={item.value}>
          {item.data.name}
        </Checkbox>
      )),
    [],
  );

  // const isArrearsContent = useMemo(
  //   () =>
  //     dictionary.isArrears.list.map((item) => (
  //       <Checkbox key={item.value} value={item.value}>
  //         {item.name}
  //       </Checkbox>
  //     )),
  //   [],
  // );

  const businessStaffOptions = useMemo(
    () =>
      getSelectOptions(businessStaffList, (item) => ({
        value: item.staffId,
        name: item.realName,
      })),
    [businessStaffList],
  );

  const handleSubmit = () => {
    validateFields((err, values) => {
      if (err) return;

      const hasSearchData = Object.values(values).some((val) => !isEmpty(val));

      setVisible(false);
      dispatch({
        type: 'updateState',
        payload: {
          headerSearchReadOnly: hasSearchData,
        },
      });
      dispatch({
        type: 'updateSearchData',
        payload: values,
      });
    });
  };

  const handleReset = () => {
    resetFields();
  };

  useEffect(() => {
    setFieldsValue(headerSearchFormData);
  }, [headerSearchFormData, setFieldsValue]);

  useEffect(() => {
    visible &&
      dispatch({
        type: 'querySearchDependence',
      });
  }, [dispatch, visible]);

  return (
    <>
      <Form {...formItemLayout} className={styles.form}>
        <GenFormItem
          form={form}
          label="合同状态"
          name="contractStatus"
          className={styles.checkboxGroup}
        >
          <CheckboxGroup>{contractStatusContent}</CheckboxGroup>
        </GenFormItem>
        {/* <GenFormItem form={form} label="收费状态" name="isArrears" className={styles.checkboxGroup}>
          <CheckboxGroup>{isArrearsContent}</CheckboxGroup>
        </GenFormItem> */}
        <GenFormItem form={form} label="客户名称" name="customerNameNo">
          <Input placeholder="请输入客户名称" />
        </GenFormItem>
        <GenFormItem form={form} label="服务项目" name="serviceItemIds">
          <AntdTreeSelect
            allowClear
            treeCheckable
            dropdownMatchSelectWidth
            treeDefaultExpandAll
            placeholder="请选择服务项目"
            showCheckedStrategy={SHOW_CHILD}
            treeData={chargingItemList}
            dropdownStyle={dropdownStyle}
            getTreeNodeProps={serviceItemIdsTreeNodeProps}
          />
        </GenFormItem>
        <GenFormItem form={form} label="合同编号" name="contractNo">
          <AntdInput placeholder="请输入合同编号" />
        </GenFormItem>
        <GenFormItem form={form} label="签单人" name="signStaffId">
          <SuperSelect allowClear placeholder="请选择签单人" defaultActiveFirstOption={false}>
            {businessStaffOptions}
          </SuperSelect>
        </GenFormItem>
        <GenFormItem form={form} label="到期时间" name="contractExpireDate">
          <RangePicker />
        </GenFormItem>
        <GenFormItem form={form} label="签订时间" name="signDate">
          <RangePicker />
        </GenFormItem>
        <GenFormItem label="合同金额" className={styles.contractMoney}>
          <GenFormItem form={form} name="contractMoneyMin">
            <NumberInput placeholder="0.00" prefix="￥" />
          </GenFormItem>
          <span>—</span>
          <GenFormItem form={form} name="contractMoneyMax">
            <NumberInput placeholder="0.00" prefix="￥" />
          </GenFormItem>
        </GenFormItem>
      </Form>
      <div className={styles.footer}>
        <Button onClick={handleReset}>清空</Button>
        <Button type="primary" onClick={handleSubmit}>
          查询
        </Button>
      </div>
    </>
  );
};

export default connect(
  ({ businessStaffList, chargingItemList, query: { headerSearchFormData } }) => ({
    businessStaffList,
    chargingItemList,
    headerSearchFormData,
  }),
)(Form.create()(Content));
