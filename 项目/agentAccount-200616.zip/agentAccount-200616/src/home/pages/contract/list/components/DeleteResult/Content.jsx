import React from 'react';
import { Collapse } from 'antd';
import { If, LinkButton, Iconfont } from '@components';
import { validateArrayLength } from '@utils';
import styles from './styles.less';

const { Panel } = Collapse;

const Content = ({ data }) => {
  const { successCount, failedCount, failedContractNos, failedReason } = data || {};

  return (
    <>
      <div className="t-bold">
        {successCount ? `成功删除${successCount}个合同，` : ''}
        {failedCount}个合同删除失败。
      </div>
      <Collapse
        bordered={false}
        destroyInactivePanel
        expandIconPosition="right"
        className={styles.collapse}
        expandIcon={({ isActive }) => (
          <div>
            <LinkButton>
              <span>{isActive ? '收起' : '展开'}&nbsp;</span>
              <Iconfont
                className={isActive ? 'iconshuangjiantoushang-copy' : 'iconshuangjiantouxia'}
              />
            </LinkButton>
          </div>
        )}
      >
        <Panel header="详细原因">
          <If condition={validateArrayLength(failedContractNos)}>
            <div className={styles.panel}>
              {`${failedReason}：`}
              {failedContractNos.map((val) => (
                <div key={val}>{val}</div>
              ))}
            </div>
          </If>
        </Panel>
      </Collapse>
    </>
  );
};

export default Content;
