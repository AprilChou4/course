/**
 * 导出合同
 */
import React, { useRef } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import { AntdModal } from '@components';
import Content from './Content';
import Submit from './Submit';
import styles from './style.less';

const ExportContract = ({ visible, dispatch }) => {
  const contentRef = useRef(null);

  const handleCancel = () => {
    dispatch({
      type: 'hideExportModal',
    });
  };

  return (
    <AntdModal
      title="导出合同"
      width={400}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      className={styles.modal}
      footer={
        <>
          <Button onClick={handleCancel}>取消</Button>
          <Submit contentRef={contentRef} />
        </>
      }
    >
      <Content wrappedComponentRef={contentRef} />
    </AntdModal>
  );
};

export default connect(({ exportModal: { visible } }) => ({
  visible,
}))(ExportContract);
