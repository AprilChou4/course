import React from 'react';
import pubData from 'data';
import { DropDown, Authority, LinkButton, Iconfont } from '@components';
import Add from './Add';
import Renewal from './Renewal';
import Delete from './Delete';
import Edit from './Edit';
import Stop from './Stop';
import Import from './Import';
import Export from './Export';
import styles from './style.less';

const userAuth = pubData.get('authority');

const HeaderRight = () => (
  <>
    <LinkButton href="https://hetong.nuonuo.com">
      <Iconfont code="&#xee5e;" className={styles.icon} />
      电子合同在线签署
    </LinkButton>
    <Authority code="14">
      <Add />
    </Authority>
    <Authority code="15">
      <Renewal />
    </Authority>
    <Authority code="17">
      <Delete />
    </Authority>
    <DropDown>
      {!!userAuth[493] && <Edit />}
      {!!userAuth[16] && <Stop />}
      {!!userAuth[656] && <Import />}
      {!!userAuth[18] && <Export />}
    </DropDown>
  </>
);

export default HeaderRight;
