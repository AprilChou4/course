/**
 * 合同删除结果弹窗
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import cls from 'classnames';
import { AntdModal } from '@components';
import Content from './Content';
import styles from './styles.less';

const DeleteResult = ({ visible, resultData, dispatch }) => {
  const handleCancel = useCallback(
    () =>
      dispatch({
        type: 'hideDeleteResult',
      }),
    [dispatch],
  );

  return (
    <AntdModal
      title="删除结果"
      width={440}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      footer={
        <Button type="primary" onClick={handleCancel}>
          知道了
        </Button>
      }
      className={cls('withForm', styles.modal)}
    >
      <Content data={resultData} />
    </AntdModal>
  );
};

export default connect(({ deleteResult: { visible, data: resultData } }) => ({
  visible,
  resultData,
}))(DeleteResult);
