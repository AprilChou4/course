/* eslint-disable no-nested-ternary */
import React, { useEffect, useCallback, useRef } from 'react';
import { connect } from 'nuomi';
import { util } from 'nuijs';
import Qs from 'qs';
import { Steps, Button, Icon, Upload, Progress, Typography, message } from 'antd';
import { If, ExportText, LinkButton, Iconfont } from '@components';
import { get } from '@utils';
import styles from './style.less';

const { Paragraph } = Typography;
const { Step } = Steps;
const AccFileType = ['xls', 'xlsx'];
const downloadFile = ({ name, path }) =>
  util.location(
    `${basePath}instead/v2/customer/enclosure/downloadFile.do?${Qs.stringify({
      enclosureName: name,
      enclosurePath: path,
    })}`,
  );

const Content = ({ status, uploadFile, process, errorResult, dispatch }) => {
  const importProcessInterval = useRef();

  // 清除循环请求进度流程
  const clearImportProcessInterval = () => clearInterval(importProcessInterval.current);

  const handleDownloadFile = () => {
    downloadFile({
      name: errorResult.fileName,
      path: errorResult.filePath,
    });
  };

  // 上传前验证
  const handleBeforeUpload = useCallback(({ name }) => {
    // 验证文件格式
    const reg = new RegExp(`^.+.(${AccFileType.join('|')})$`);
    const isValidFormat = reg.test(name);
    if (!isValidFormat) {
      message.warning('请导入.xls.xlsx格式的文件');
      return false;
    }
    return true;
  }, []);

  const handleChange = useCallback(
    ({ file }) => {
      dispatch({
        type: 'updateImportModalData',
        payload: {
          file,
          process: 0,
        },
      });
      // FIXME: status为uploading时的处理
      if (['done', 'error'].includes(file.status)) {
        const response = get(file, 'response', {});
        if (response.status !== 200) {
          message.error(response.message || '上传失败!');
          return;
        }
        if (response.status === 901) {
          // 导入模板有误
          dispatch({
            type: 'updateImportModalData',
            payload: {
              status: 4,
            },
          });
        } else if (response.status === 200) {
          dispatch({
            type: 'updateImportModalData',
            payload: {
              status: 1,
              taskId: get(response, 'data.taskId'),
            },
          });
          // 上传成功后，开始循坏请求进度
          importProcessInterval.current = setInterval(async () => {
            const res = await dispatch({
              type: 'getImportProcess',
              payload: {
                clearImportProcessInterval,
              },
            });
            if (res === false) {
              clearImportProcessInterval();
            }
          }, 500);
        }
      }
    },
    [dispatch],
  );

  // 清除循环请求进度流程
  useEffect(() => clearImportProcessInterval, []);

  return (
    <Steps direction="vertical" className={styles.steps}>
      <Step
        status="process"
        title={
          <>
            请下载
            <ExportText
              method="get"
              url={`${basePath}instead/v2/customer/contract/importTemplate/download.do`}
            >
              <LinkButton className={styles.template}>
                <Iconfont code="&#xea9f;" />
                最新Excel模板
              </LinkButton>
            </ExportText>
            并将数据按照模板格式整理。
          </>
        }
        description="提示：模板请保存为XLS或XLSX格式。"
      />
      <Step
        status="process"
        title={
          <Upload
            name="file"
            showUploadList={false}
            accept={`.${AccFileType.join(',.')}`}
            beforeUpload={handleBeforeUpload}
            onChange={handleChange}
            action={`${basePath}instead/v2/customer/contract/batchImport.do`}
          >
            <Button type="highlight" disabled={status === 1}>
              <Icon type="upload" />
              导入合同
            </Button>
          </Upload>
        }
        description={
          <If condition={status === 1}>
            <Progress
              showInfo={false}
              status={process === 100 ? 'success' : 'active'}
              percent={process}
              className={styles.progress}
            />
            <div>
              目前进度为 {process}% {process < 100 ? '… 请耐心等待' : ''}
            </div>
          </If>
        }
      />

      {[2, 3, 4].includes(status) &&
        (status === 2 ? (
          <Step
            status="process"
            title="导入成功"
            description={
              <div className={styles.file}>
                <Paragraph ellipsis title={uploadFile.name}>
                  <Iconfont type="iconfujian" />
                  {uploadFile.name}
                </Paragraph>
              </div>
            }
            icon={<Iconfont type="iconchenggong-full" />}
            className={styles['step-success']}
          />
        ) : status === 3 ? (
          <Step
            status="process"
            title={`成功导入数据${errorResult.successCount ||
              0}条，失败数据${errorResult.failedCount || 0}条`}
            description={
              <LinkButton underline onClick={handleDownloadFile}>
                下载失败记录
              </LinkButton>
            }
            icon={<Iconfont type="iconjingshi-full" />}
            className={styles['step-record']}
          />
        ) : (
          <Step
            status="process"
            title="导入失败"
            description="导入模板有误，请下载最新模板"
            icon={<Iconfont type="iconshanchu6-full" />}
            className={styles['step-faild']}
          />
        ))}
    </Steps>
  );
};

export default connect(
  ({
    importModal: {
      data: { status, file: uploadFile, process, errorResult },
    },
  }) => ({
    status,
    uploadFile,
    process,
    errorResult,
  }),
)(Content);
