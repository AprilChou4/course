/**
 * 删除合同
 */
import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';

const Delete = ({ dispatch }) => {
  const handleDelete = () => {
    dispatch({
      type: 'handleDeleteContract',
    });
  };

  return <Button onClick={handleDelete}>删除</Button>;
};

export default connect()(Delete);
