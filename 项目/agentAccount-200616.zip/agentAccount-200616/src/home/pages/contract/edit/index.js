/**
 * 变更合同
 */
import { nuomi } from 'nuomi';
import add from '../add';

export default nuomi.extend(add, {
  id: 'contractEdit',
  state: {
    status: 1,
  },
});
