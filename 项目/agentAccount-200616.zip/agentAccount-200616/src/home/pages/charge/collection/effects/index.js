import { message } from 'antd';
import { router } from 'nuomi';
import { get } from '@utils';
import globalServices from '@home/services';
import services from '../services';
import { initialForm, genInitDataSource, getUid, getNextStatus, calcTotalMoney } from '../utils';

export default {
  // 新增收款单 isContinue=true代表是 保存+新增, false是保存+查看
  async $addCollection({ params, isContinue }) {
    const { formValues } = this.getState();
    const finalParams = {
      ...params,
      shouldReceiveId: formValues.shouldReceiveId,
    };
    const data = await services.addCollection(finalParams, {
      loading: '正在保存...',
    });
    message.success('保存成功');
    if (isContinue) {
      // 初始化form表单
      this.$initForm(true);
    } else {
      this.updateState({
        status: 3,
        receiveBillId: data,
        receiveBillSubjectItem: [],
        isEdit: false,
      });
      await this.$getDetail(data);
      this.$resetFields();
    }
  },

  // 删除收款单
  async $deleteCollection() {
    const { receiveBillId } = this.getState();
    await services.deleteOne({ receiveBillIds: [receiveBillId] });
    message.success('删除成功');
    this.$initForm(true);
  },

  // 更新收款单
  async $updateCollection({ params, isContinue }) {
    const { receiveBillId } = this.getState();
    await services.updateOne(
      { ...params, receiveBillId },
      {
        loading: '正在更新...',
      },
    );
    message.success('保存成功');
    if (isContinue) {
      // 初始化form表单
      this.$initForm(true);
    } else {
      const { isViewPage } = this.getState();
      this.updateState({
        status: isViewPage ? 5 : 3,
        isEdit: false,
      });
      await this.$getDetail(receiveBillId);
      this.$resetFields();
    }
  },

  // 查看收款单
  async $getDetail(receiveBillId) {
    const data = await services.getDetail(
      { receiveBillId },
      {
        loading: '正在获取收款单信息...',
      },
    );
    const { sourceBillType, receiveBillItems, customerId } = data;
    const maxPreMoney = await services.getMaxMoney({ customerId });
    // 有明细计算合计
    const totalMoney = calcTotalMoney(receiveBillItems);
    const receiptRes = await services.getReceiptType();
    const receiptTypeList = get(receiptRes, 'receiptList', []);
    // 查找收款账号对应的收款方式
    let receiptType = '';
    let receiptAccountList = [];
    if (data.receiptTypeAccountId) {
      for (let i = 0; i < receiptTypeList.length; i++) {
        // 收款方式对应的收款账号列表
        const receiptTypeAccounts = get(receiptTypeList[i], 'receiptTypeAccounts', []);
        for (let j = 0; j < receiptTypeAccounts.length; j++) {
          const account = receiptTypeAccounts[j];
          if (account.receiptTypeAccountId === Number(data.receiptTypeAccountId)) {
            receiptType = account.receiptTypeId;
            receiptAccountList = receiptTypeAccounts;
            // 匹配成功break
            break;
          }
        }
        if (receiptType) break;
      }
    }

    this.updateState({
      formValues: { ...data, receiptType },
      isReference: sourceBillType === 1,
      dataSource: genInitDataSource(receiveBillItems),
      maxPreMoney,
      // 合计
      totalMoney,
      // 收款方式、账号
      receiptTypeList,
      receiptAccountList,
    });
    // hack!
    setTimeout(() => {
      const { form } = this.getState();
      form.resetFields && form.resetFields();
    });
  },

  // 根据部门ID获取业务员列表
  async $getStaffByDeptId(deptId) {
    const data = await globalServices.getStaffList({ deptId });
    this.updateState({
      businessStaffList: data,
    });
  },

  // 获取收款单编号
  async $getReceiptNo() {
    const data = await services.getReceiptNo({
      receiveType: 1,
    });
    this.dispatch({
      type: 'updateFormValues',
      payload: {
        receiptNo: data,
      },
    });
  },

  /**
   * 初始化form表单
   * isNew==true代表新增一条新的，需要重新获取编号
   * isNew==false代表修改收款单或者参应收单不需要重新获取编号
   * @param {*} isNew
   */
  async $initForm(isNew) {
    const { formValues, receiveBillId, status } = this.getState();
    this.updateState({
      formValues: { ...initialForm, receiptNo: isNew ? undefined : formValues.receiptNo },
      status: isNew ? 0 : status, // 新增时初始化，其他情况下不变
      isEdit: false,
      dataSource: genInitDataSource([]),
      receiveBillId: isNew ? '' : receiveBillId,
      totalMoney: {
        shouldTotalMoney: 0,
        totalReceiptMoney: 0,
        freeMoney: 0,
        preReceiptMoney: 0,
        userPreReceiptMoney: 0,
      },
    });
    this.$resetFields();
    if (isNew) {
      this.$resetReferenceModal();
      await this.$getReceiptNo();
    }
  },

  // 表单清空
  $resetFields() {
    const { form, tableForm } = this.getState();
    form.resetFields && form.resetFields();
    tableForm.resetFields && tableForm.resetFields();
  },

  // 参照弹窗内容清空
  $resetReferenceModal() {
    this.updateState({
      isReference: false,
      ysdId: '',
      customerId: '',
      selectedKeys: [],
      referenceCustomerList: [],
      ysdList: [],
      skjhList: [],
    });
  },

  // 获取最大使用预收
  async $getMaxMoney(customerId) {
    const { dataSource } = this.getState();
    const data = await services.getMaxMoney({ customerId });
    this.dispatch({
      type: 'updateState',
      payload: {
        maxPreMoney: data,
        // 最大预收改变后，置空添加过使用的预收
        dataSource: dataSource.map((it) => ({ ...it, userPreReceiptMoney: undefined })),
      },
    });
  },

  // 获取收款单编号
  async $getYsdList(curtomerId) {
    const data = await services.getYsdList({ curtomerId });
    this.updateState({
      ysdList: data,
    });
  },

  // 展示参照应收单弹窗
  async $showReferenceModal() {
    this.$getCustomerBillList();
  },

  // 清空参照应收单
  async $clearReference() {
    this.$initForm();
    this.$resetReferenceModal();
  },

  // 获取客户对应的应收单
  async $getCustomerBillList() {
    const data = await services.getCustomerBillList({ isShouldReceiveBill: 1 });
    this.updateState({
      referenceCustomerList: data || [],
      isShowModal: true,
    });
  },

  // 获取收款计划明细表
  async $getplanDetailList(shouldReceiveId) {
    const data = await services.getplanDetailList({ shouldReceiveId });
    this.updateState({
      skjhList: data.list.map((item, index) => ({ ...item, index })),
    });
  },

  // 改变status、isEdit
  changeStatus() {
    const { status } = this.getState();
    this.updateState({
      isEdit: true,
      status: getNextStatus(status),
    });
  },

  // 获取收款计划明细表 ugly!
  async $refrenceYsd(params) {
    // console.log('refrenceYsd params', params);
    const data = await services.refrenceYsd(params);
    const { status, dataSource, formValues } = this.getState();
    // 客户id与参照的id不相同， 清空表单
    if (data.customerId !== formValues.customerId) {
      this.$initForm();
    }

    const {
      shouldReceiveId,
      srbNo,
      customerId,
      customerName,
      deptId,
      businessStaffId,
      businessStaffName,
      deptName,
      totalShouldReceiveMoney,
      customerPreReceiveMoney,
      itemDetails,
    } = data;
    this.dispatch({
      type: 'updateFormValues',
      payload: {
        sourceBillType: 1,
        sourceBillNo: srbNo,
        srbNo,
        customerId,
        customerName,
        deptId,
        deptName,
        businessStaffId,
        businessStaffName,
        shouldTotalMoney: totalShouldReceiveMoney,
        totalReceiptMoney: totalShouldReceiveMoney,
        shouldReceiveId,
      },
    });
    let list = dataSource;
    list = itemDetails.map((item) => ({
      ...item,
      shouldMoney: item.shouldReceiveMoney,
      receiptMoney: item.shouldReceiveMoney, // #141868
      id: getUid(), // 表格唯一id，
      shouldReceiveItemId: item.id,
    }));
    // 计算合计
    const totalMoney = calcTotalMoney(list);
    this.updateState({
      isShowModal: false,
      // skjhList: [],
      // isEdit: true,
      isReference: true,
      maxPreMoney: customerPreReceiveMoney,
      status: getNextStatus(status),
      dataSource: genInitDataSource(list),
      totalMoney,
    });

    // 请求成功
    return true;
  },

  async initList() {
    const { formValues } = this.getState();
    if (formValues.customerId) {
      this.$getMaxMoney(formValues.customerId);
    }
    // 获取收款人列表
    this.$getStaffList();
    // 获取客户列表
    this.$getCustomerList();
    // 获取服务项目列表
    this.$getChargingList();
    // 获取收款方式列表
    this.$getReceiptTypeList();
  },

  async initData() {
    const { id } = router.location().query || {};
    if (id) {
      // 代表是查看收款单
      await this.$getDetail(id);
      this.updateState({
        status: 5,
        isViewPage: true,
        receiveBillId: id,
      });
    } else {
      // 代表是新增收款单，需要获取新的单据编号
      await this.$getReceiptNo();
      // 默认生成3条表格数据源
      this.updateState({
        dataSource: genInitDataSource([]),
      });
    }
  },

  // 获取收款人列表
  async $getStaffList() {
    const data = await globalServices.getStaffList();
    this.updateState({
      receiptStaffList: data || [],
      businessStaffList: data || [],
    });
  },

  // 获取客户列表
  async $getCustomerList() {
    const data = await services.getCustomerBillList({ isShouldReceiveBill: 0 });
    this.updateState({
      customerList: data || [],
    });
  },

  // 获取服务项目列表
  async $getChargingList() {
    const data = await services.getCharging();
    const list = data.reduce((a, c) => [...a, ...c.chargingItemList], []);
    const serviceItemMap = list.reduce((a, c) => ({ ...a, [c.chargingItemId]: c.serviceName }), {});
    this.updateState({
      serviceList: list || [],
      serviceItemMap,
    });
  },

  // 获取收款方式列表
  async $getReceiptTypeList() {
    const data = await services.getReceiptType();
    const receiptTypeList = get(data, 'receiptList', []);
    this.updateState({
      receiptTypeList,
    });
  },
};
