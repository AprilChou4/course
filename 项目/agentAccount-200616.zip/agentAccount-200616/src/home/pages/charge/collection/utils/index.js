import { uniqueId } from 'lodash';
import pubData from 'data';
import { get } from '@utils';
import { ShowConfirm } from '@components';

/**
 * 收款单明细表唯一ID
 */
export const getUid = () => uniqueId('change_collection_');

/**
 * 初始化的表单字段
 */
export const initialForm = {
  customerId: '',
  receiptNo: '',
  sourceBillType: 0,
  sourceBillNo: '-',
  shouldReceiveId: '',
  totalReceiptMoney: '',
  receiptDate: parseInt(Date.now() / 1000, 10),
  receiptType: '',
  receiptTypeAccountId: '',
  receiptStaffId: '',
  deptId: '',
  shouldTotalMoney: '',
  freeMoney: '',
  preReceiptMoney: 0,
  userPreReceiptMoney: '',
  remark: '',
  srbNo: undefined,
  createBillStaffName: get(pubData.get('userInfo'), 'realName'),
  createBillDate: parseInt(Date.now() / 1000, 10), // eslint-disable-line
  receiveBillItems: [],
};

/**
 * 获取初始的表格源数据，不够3条补上空行
 * @param {Array} receiveBillItems 明细表
 */
export const genInitDataSource = (receiveBillItems = []) => {
  const remain = Math.max(0, 3 - receiveBillItems.length);
  const list = receiveBillItems.map((item) => ({ ...item, id: getUid() }));
  for (let i = 0; i < remain; i++) {
    list.push({
      id: getUid(),
    });
  }
  return list;
};

/**
 * 获取下一次按钮的状态
 * @param {Number} currentStatus 当前状态
 */
export const getNextStatus = (currentStatus) => {
  const status = currentStatus;
  const nextStatusMap = {
    0: 1,
    2: 3,
    4: 5,
  };
  return nextStatusMap[status] || status;
};

// 计算合计
export const calcTotalMoney = (list) => {
  return list.reduce(
    (a, c) => ({
      shouldTotalMoney: a.shouldTotalMoney + Number(c.shouldMoney || 0),
      totalReceiptMoney: a.totalReceiptMoney + Number(c.receiptMoney || 0),
      freeMoney: a.freeMoney + Number(c.freeMoney || 0),
      preReceiptMoney: a.preReceiptMoney + Number(c.preReceiptMoney || 0),
      userPreReceiptMoney: a.userPreReceiptMoney + Number(c.userPreReceiptMoney || 0),
    }),
    {
      shouldTotalMoney: 0,
      totalReceiptMoney: 0,
      freeMoney: 0,
      preReceiptMoney: 0,
      userPreReceiptMoney: 0,
    },
  );
};

/**
 * 弹窗确认是否同步修改客户名称
 */
export const syncMoneyConfirm = async () => {
  return new Promise((resolve) => {
    ShowConfirm({
      title: '收款金额与实收金额合计不相等，是否同步（以表体合计值为准）？',
      okText: '是',
      cancelText: '否',
      onOk() {
        resolve(true);
      },
      onCancel() {
        resolve(false);
      },
    });
  });
};

export default {};
