export default {
  addCollection() {
    return {
      status: 200,
      data: null,
    };
  },
  getDetail() {
    return {
      status: 200,
      data: [],
    };
  },
  getYsdList() {
    return {
      status: 200,
      data: [],
    };
  },
  getReceiptNo() {
    return {
      status: 200,
      data: 'sk123123123',
    };
  },
  getMaxMoney() {
    return {
      status: 200,
      data: 100,
    };
  },
};
