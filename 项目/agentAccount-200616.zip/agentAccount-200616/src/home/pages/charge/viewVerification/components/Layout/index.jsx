import React from 'react';

const Layout = () => {
  return null;
};

export default Layout;