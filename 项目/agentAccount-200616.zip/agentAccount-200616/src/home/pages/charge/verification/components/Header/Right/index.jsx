import React, { useCallback, useMemo } from 'react';
import { connect, withNuomi } from 'nuomi';
import pubData from 'data';
import { Button } from 'antd';
import { If } from '@components';
import { get } from '@utils';

const userAuth = pubData.get('authority');

const HeaderRight = ({ status, dispatch, nuomiProps }) => {
  const isViewPage = useMemo(() => get(nuomiProps, 'id') === 'viewVerification', [nuomiProps]);
  const isView = status === 1;

  const handleSave = useCallback(() => {
    dispatch({
      type: '$addVerification',
    });
  }, [dispatch]);

  const handleNew = useCallback(() => {
    dispatch({
      type: 'handleNewVerification',
    });
  }, [dispatch]);

  return (
    <If condition={!isViewPage && userAuth[589]}>
      <If condition={!isView}>
        <Button type="primary" onClick={handleSave}>
          确认核销
        </Button>
      </If>
      <If condition={!!isView}>
        <Button type="primary" onClick={handleNew}>
          新增
        </Button>
      </If>
    </If>
  );
};

export default connect(({ status }) => ({ status }))(withNuomi(HeaderRight));
