/**
 * 核销单-应收表格
 */
import React, { useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { AntdTable } from '@components';
import { moneyFormat, getRows, validateArrayLength } from '@utils';
import getColumns from './columns';
import styles from '../style.less';

const Receivable = ({ status, form, rowKey, dataSource, selectedRowKeys, dispatch }) => {
  const isView = status === 1;

  const { matchType } = useMemo(() => (form ? form.getFieldsValue() : {}), [form]);

  const columns = useMemo(() => getColumns({ isView, matchType }), [isView, matchType]);

  const rowSelection = useMemo(
    () => ({
      columnWidth: 30,
      selectedRowKeys,
      getCheckboxProps: () =>
        isView
          ? {
              disabled: true,
            }
          : {},
      onChange(sRowKeys) {
        dispatch({
          type: 'updateReceivableTable',
          payload: {
            selectedRowKeys: sRowKeys,
            dataSource: dataSource.map((item) => ({
              ...item,
              currentReviewedMoney: sRowKeys.includes(item[rowKey]) ? item.unReviewMoney : 0,
            })),
          },
        });
      },
    }),
    [dataSource, dispatch, isView, rowKey, selectedRowKeys],
  );

  const footer = useCallback(
    (currentPageData) => {
      const sum = (a, b) => Number(a || 0) + Number(b || 0);
      const { currentReviewedMoney, shouldReceiveMoney, reviewedMoney } = getRows(
        currentPageData,
        selectedRowKeys,
        rowKey,
      ).reduce(
        (acc, cur) => ({
          currentReviewedMoney: sum(acc.currentReviewedMoney, cur.currentReviewedMoney),
          shouldReceiveMoney: sum(acc.shouldReceiveMoney, cur.shouldReceiveMoney),
          reviewedMoney: sum(acc.reviewedMoney, cur.reviewedMoney),
        }),
        {},
      );
      return (
        <div className={styles['table-footer']}>
          <span className={styles['footer-title']}>本次核销合计：</span>
          {moneyFormat(currentReviewedMoney)}
          <span className={styles['footer-title']}>应收合计：</span>
          {moneyFormat(shouldReceiveMoney)}
          <span className={styles['footer-title']}>已核销合计：</span>
          {moneyFormat(reviewedMoney)}
        </div>
      );
    },
    [rowKey, selectedRowKeys],
  );

  return (
    <AntdTable
      bordered
      emptyType="default"
      locale={{
        emptyText: <div className={styles['table-placeholder']}>请设置过滤项添加应收数据</div>,
      }}
      pagination={false}
      rowKey={rowKey}
      columns={columns}
      rowSelection={rowSelection}
      dataSource={dataSource}
      footer={validateArrayLength(selectedRowKeys) ? footer : null}
    />
  );
};

export default connect(
  ({ status, form, receivableTable: { rowKey, dataSource, selectedRowKeys } }) => ({
    status,
    form,
    rowKey,
    dataSource,
    selectedRowKeys,
  }),
)(Receivable);
