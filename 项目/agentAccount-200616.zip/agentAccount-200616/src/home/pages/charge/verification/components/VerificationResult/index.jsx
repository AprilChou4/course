/**
 * 核销结果弹窗
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { AntdModal } from '@components';
import Content from './Content';

const VerificationResult = ({ visible, resultData, dispatch }) => {
  const handleCancel = useCallback(() => {
    dispatch({
      type: 'updateVerificationResult',
      payload: {
        visible: false,
      },
    });
  }, [dispatch]);

  const handleConfirm = useCallback(() => {
    handleCancel();
  }, [handleCancel]);

  return (
    <AntdModal
      title="核销结果"
      className="withForm"
      okText="知道了"
      width={470}
      getContainer={false}
      cancelButtonProps={{ style: { display: 'none' } }}
      okButtonProps={{ style: { margin: 0 } }}
      visible={visible}
      onCancel={handleCancel}
      onOk={handleConfirm}
    >
      <Content data={resultData} />
    </AntdModal>
  );
};

export default connect(({ verificationResult: { visible, data: resultData } }) => ({
  visible,
  resultData,
}))(VerificationResult);
