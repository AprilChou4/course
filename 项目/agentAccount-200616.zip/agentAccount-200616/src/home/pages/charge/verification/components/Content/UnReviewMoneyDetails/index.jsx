/**
 * 未核销金额详情
 */
import React from 'react';
import { LinkButton } from '@components';
import { moneyFormat, validateArrayLength } from '@utils';
import PopoverTable from '../../PopoverTable';

const UnReviewMoneyDetails = ({ matchType, record, tableType }) => {
  const dataSource =
    matchType === 1
      ? record[['srbServiceTypes', 'rbServiceTypes'][tableType]]
      : record[['srbItems', 'receiveItems'][tableType]];

  return matchType === 1 ? (
    <PopoverTable
      placement="topRight"
      overlayStyle={{ width: 279 }}
      tableProps={{
        rowKey: 'serviceTypeId',
        columns: [
          {
            title: '服务类型',
            dataIndex: 'serviceTypeName',
            align: 'center',
          },
          {
            title: '金额',
            dataIndex: 'unReviewMoney',
            render: (val) => moneyFormat(val),
            align: 'center',
          },
        ],
        dataSource,
      }}
    >
      <LinkButton className="f-fl" disabled={!validateArrayLength(dataSource)}>
        明细
      </LinkButton>
    </PopoverTable>
  ) : (
    <PopoverTable
      placement="topRight"
      overlayStyle={{ width: 279 }}
      tableProps={{
        rowKey: 'serviceItemId',
        columns: [
          {
            title: '服务项目',
            dataIndex: 'serviceItemName',
            align: 'center',
          },
          {
            title: '金额',
            dataIndex: 'unReviewMoney',
            align: 'center',
            render: (val) => moneyFormat(val),
          },
        ],
        dataSource,
      }}
    >
      <LinkButton className="f-fl" disabled={!validateArrayLength(dataSource)}>
        明细
      </LinkButton>
    </PopoverTable>
  );
};

export default UnReviewMoneyDetails;
