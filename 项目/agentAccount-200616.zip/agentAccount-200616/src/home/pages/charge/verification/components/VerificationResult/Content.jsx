import React from 'react';
import { Collapse } from 'antd';
import { If, LinkButton, Iconfont } from '@components';
import styles from './styles.less';

const { Panel } = Collapse;

const Content = ({ data }) => {
  const { srbSuccessCount, rbSuccessCount, failedSrbNos, failedRbNos } = data || {};

  return (
    <div>
      <p className="t-bold">
        成功核销{srbSuccessCount}张应收单和{rbSuccessCount}张收款单，{failedSrbNos.length}
        张应收单和{failedRbNos.length}张收款单核销失败。
      </p>
      <Collapse
        bordered={false}
        destroyInactivePanel
        expandIconPosition="right"
        className={styles.collapse}
        expandIcon={({ isActive }) => (
          <div>
            <LinkButton>
              {isActive ? (
                <>
                  <span>收起&nbsp;</span>
                  <Iconfont code="&#xee81;" />
                </>
              ) : (
                <>
                  <span>展开&nbsp;</span>
                  <Iconfont code="&#xe714;" />
                </>
              )}
            </LinkButton>
          </div>
        )}
      >
        <Panel header="详细原因">
          <div className={styles.panel}>
            <If condition={failedSrbNos.length}>
              <div className={styles['panel-item']}>
                以下应收单无匹配信息，核销失败：
                {failedSrbNos.map((val) => (
                  <div key={val}>{val}</div>
                ))}
              </div>
            </If>
            <If condition={failedRbNos.length}>
              <div className={styles['panel-item']}>
                以下收款单无匹配信息，核销失败：
                {failedRbNos.map((val) => (
                  <div key={val}>{val}</div>
                ))}
              </div>
            </If>
          </div>
        </Panel>
      </Collapse>
    </div>
  );
};

export default Content;
