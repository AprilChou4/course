import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import classnames from 'classnames';
import { useScroll } from 'react-use';
import useComponentSize from '@rehooks/component-size';
import { Affix, Button } from 'antd';
import { If, Iconfont } from '@components';
import Receivable from './Receivable';
import ReceivableDate from './Receivable/Date';
import Collection from './Collection';
import CollectionDate from './Collection/Date';
import VerificationResult from '../VerificationResult';
import styles from './style.less';
import Footer from '../Footer';

const Content = ({ wrapperRef }) => {
  const [scrollStatus, setScrollStatus] = useState(0);
  const containerRef = useRef(null);
  const totalContentRef = useRef(null);
  const upTableRef = useRef(null);
  const downTableHeaderRef = useRef(null);

  const { height: containerHeight = 0 } = useComponentSize(containerRef);
  const { height: totalContentHeight = 0 } = useComponentSize(totalContentRef);
  const { height: upTableHeight = 0 } = useComponentSize(upTableRef);
  const { height: downTableHeaderHeight = 0 } = useComponentSize(downTableHeaderRef);
  const { y: scrollY = 0 } = useScroll(containerRef);

  const isShowAffix = useMemo(
    () => upTableHeight + downTableHeaderHeight >= containerHeight || scrollY >= upTableHeight,
    [containerHeight, downTableHeaderHeight, scrollY, upTableHeight],
  );

  // 页面高度+scrollY = 内容总高度时，滚动到最底部

  const handleAffixClick = useCallback(() => {
    if (scrollStatus === 0) {
      containerRef.current.scrollTop = upTableHeight;
    } else {
      containerRef.current.scrollTop = 0;
    }
  }, [scrollStatus, upTableHeight]);

  useEffect(() => {
    setScrollStatus(
      scrollY === totalContentHeight - containerHeight || scrollY >= upTableHeight ? 1 : 0,
    );
  }, [containerHeight, scrollY, totalContentHeight, upTableHeight]);

  return (
    <div className={styles.container} ref={containerRef}>
      <div ref={totalContentRef}>
        <div ref={upTableRef}>
          <div className={styles.header}>
            <div className={classnames('title-mark', styles.mark)}>应收</div>
            <ReceivableDate />
          </div>
          <Receivable />
        </div>
        <div>
          <div className={styles.header} ref={downTableHeaderRef}>
            <div className={classnames('title-mark', styles.mark)}>收款</div>
            <CollectionDate />
          </div>
          <Collection />
        </div>
        <Footer />
        <If condition={isShowAffix}>
          <Affix offsetBottom={16} target={() => wrapperRef.current} className={styles.affix}>
            <Button type="link" onClick={handleAffixClick}>
              <Iconfont code="&#xee7f;" />
              <span>{scrollStatus === 0 ? '收款' : '应收'}</span>
            </Button>
          </Affix>
        </If>
        <VerificationResult />
      </div>
    </div>
  );
};

export default Content;
