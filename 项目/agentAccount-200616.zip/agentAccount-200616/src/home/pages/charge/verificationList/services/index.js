// import mock from './mock';
import { createServices } from '@utils';

export default createServices({
  // ...mock,
  getVerificationList: 'instead/v2/customer/receipt/reviewBill/list::postJSON', // 查询核销单列表
  deleteVerification: 'instead/v2/customer/receipt/reviewBill/delete::postJSON', // 删除核销单
  exportVerification: 'instead/v2/customer/receipt/reviewBill/list/export::postJSON', // 核销单列表导出
  getCustomCols: 'instead/v2/customer/receipt/reviewBill/customizeColumn/get', // 查询核销单自定义列数据
  updateCustomCols: 'instead/v2/customer/receipt/reviewBill/customizeColumn/update::postJSON', // 更新核销单自定义列
});
