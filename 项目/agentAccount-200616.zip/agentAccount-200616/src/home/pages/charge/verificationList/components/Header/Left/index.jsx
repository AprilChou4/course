import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { DatePicker } from 'antd';
import { AntdSearch } from '@components';
import styles from '../style.less';

const { RangePicker } = DatePicker;

const Left = ({ createBillDate, inputSearchValue, dispatch }) => {
  const handleSearch = useCallback(
    (field, value) => {
      dispatch({
        type: 'updateStateAndQuery',
        payload: {
          init: true,
          [field]: value,
        },
      });
    },
    [dispatch],
  );

  const handleInputChange = useCallback(
    (e) => {
      dispatch({
        type: 'updateState',
        payload: {
          inputSearchValue: e.target.value,
        },
      });
    },
    [dispatch],
  );

  return (
    <>
      <span style={{ marginRight: 8 }}>核销日期:</span>
      <RangePicker
        style={{ width: 249 }}
        value={createBillDate}
        onChange={(value) => handleSearch('createBillDate', value)}
      />
      <AntdSearch
        placeholder="请输入客户名称"
        style={{ width: 268 }}
        className={styles.item}
        value={inputSearchValue}
        onChange={handleInputChange}
        onSearch={(value) => handleSearch('inputSearchValue', value)}
      />
    </>
  );
};

export default connect(({ createBillDate, inputSearchValue }) => ({
  createBillDate,
  inputSearchValue,
}))(Left);
