import React from 'react';
import { connect } from 'nuomi';
import { Layout, ContentWrapper } from '@components';
import HeaderLeft from '../Header/Left';
import HeaderRight from '../Header/Right';
import Content from '../Content';
import CustomColModal from '../CustomColModal';

const Main = ({ title }) => (
  <Layout.PageWrapper style={{ paddingBottom: 0 }}>
    <ContentWrapper
      title={title}
      header={{
        left: <HeaderLeft />,
        right: <HeaderRight />,
      }}
      content={<Content />}
    />
    <CustomColModal />
  </Layout.PageWrapper>
);

export default connect(({ title }) => ({ title }))(Main);
