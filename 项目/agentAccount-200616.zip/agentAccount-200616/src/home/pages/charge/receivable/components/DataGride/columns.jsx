import React from 'react';
import moment from 'moment';
import classnames from 'classnames';
import { DatePicker, Icon, Tooltip } from 'antd';
import { isNil, isTrue } from '@utils';
import { LinkButton, AntdSelect, NumberInput } from '@components';
import { dictionary, cycleRequiredFields, noCycleRequiredFields } from '../../utils';
import ServiceItems from '../../../components/ServiceItems';
import TaxUnitprice from '../TaxUnitprice';
import ServicePeriods from '../ServicePeriods';
import styles from './style.less';

const { MonthPicker } = DatePicker;
const dateFormat = 'YYYY-MM-DD';
const monthFormat = 'YYYY-MM';

const getIsRequired = (record, dataIndex, tableValidate) => {
  const requiredFields = record.isCycle ? cycleRequiredFields : noCycleRequiredFields; // 必填字段
  return (
    tableValidate &&
    record.serviceItemId &&
    isNil(record[dataIndex], '') &&
    requiredFields.includes(dataIndex)
  );
};

export default function({
  tableData,
  tableValidate,
  serviceItemsList,
  handleAddRow,
  handleDeleteRow,
  handleServiceItemChange,
  handleStartDateChange,
  handleEndDateChange,
  handleSettlementChange,
  handleUnitPriceChange,
  handleServicePeriodNumChange,
  handleMoneyChange,
  tableSumMoney,
  isCustomerIdSelected,
}) {
  const style = { width: '100%' };
  // 如果服务项目没有选择，其他单元格全部为空
  const handleEmptyCell = ({ record, content }) => (record.serviceItemId ? content : '');

  return [
    {
      width: 30,
      dataIndex: 'operations',
      className: 'table-cell-pre',
      align: 'center',
      render: (value, record, index) => (
        <div className="table-cell-toggle">
          <Tooltip arrowPointAtCenter title="插入行" mouseLeaveDelay={0} placement="top">
            <LinkButton onClick={() => handleAddRow({ value, record, index })}>
              <Icon type="plus-circle" />
            </LinkButton>
          </Tooltip>
          <Tooltip arrowPointAtCenter title="删除行" mouseLeaveDelay={0} placement="bottom">
            <LinkButton onClick={() => handleDeleteRow({ value, record, index })}>
              <Icon type="close-circle" />
            </LinkButton>
          </Tooltip>
        </div>
      ),
    },
    {
      title: '服务项目',
      dataIndex: 'serviceItemId',
      className: classnames('th-required', styles.serviceItemId),
      align: 'center',
      total: '合计',
      totalStyle: { textAlign: 'left', padding: 0 },
      render: (value, record, index) => (
        <div
          className={classnames({
            'has-error': getIsRequired(record, 'serviceItemId', tableValidate),
          })}
        >
          <ServiceItems
            showArrow={false}
            disabled={!isCustomerIdSelected}
            dataSource={serviceItemsList}
            getSelectNodeProps={(item) => ({
              value: item.chargingItemId,
              name: item.itemName,
              disabled: tableData
                .map((v) => (v.serviceItemId ? `${v.serviceItemId}` : ''))
                .filter(Boolean)
                .includes(item.chargingItemId ? `${item.chargingItemId}` : ''),
            })}
            style={style}
            value={isTrue(value, 0) ? `${value}` : undefined}
            onChange={(...args) => handleServiceItemChange({ value, record, index }, ...args)}
          />
        </div>
      ),
    },
    {
      title: '服务类型',
      dataIndex: 'serviceTypeName',
      className: 'th-required',
      align: 'center',
      render: (value, record, index) => handleEmptyCell({ value, record, index, content: value }),
    },
    {
      title: '含税单价（元）',
      dataIndex: 'unitPriceContainTax',
      className: 'th-required',
      align: 'center',
      render: (value, record, index) =>
        handleEmptyCell({
          value,
          record,
          index,
          content: (
            <TaxUnitprice
              placeholder="0.00"
              disableSelect={!record.isCycle}
              style={style}
              inputClassName={classnames({
                'has-error': getIsRequired(record, 'unitPriceContainTax', tableValidate),
              })}
              selectClassName={classnames({
                'has-error': getIsRequired(record, 'unitPrice', tableValidate),
              })}
              value={{ input: record.unitPriceContainTax, select: record.unitPrice }}
              onChange={(...args) => handleUnitPriceChange({ value, record, index }, ...args)}
            />
          ),
        }),
    },
    {
      title: '开始日期',
      dataIndex: 'startDate',
      className: 'th-required',
      align: 'center',
      render: (value, record, index) => {
        const Picker = record.isCycle ? MonthPicker : DatePicker;
        const format = record.isCycle ? monthFormat : dateFormat;
        const { serviceItemDates } = record;
        const disabledDate = (startValue) => {
          // 需要排除掉同客户同个服务项目其他应收单已经选了的日期
          let result = false;
          if (!startValue) {
            return false;
          }
          const sValue = startValue.format(format).valueOf();
          if (record.endDate) {
            result = result || sValue > record.endDate.format(format).valueOf();
          }
          if (serviceItemDates && Array.isArray(serviceItemDates)) {
            serviceItemDates.forEach((item) => {
              if (item.startDate && item.endDate) {
                result =
                  result ||
                  (sValue >=
                    moment(item.startDate, 'X')
                      .format(format)
                      .valueOf() &&
                    sValue <=
                      moment(item.endDate, 'X')
                        .format(format)
                        .valueOf());
              }
            });
          }
          return result;
        };
        return handleEmptyCell({
          value,
          record,
          index,
          content: (
            <div
              className={classnames({
                'has-error': getIsRequired(record, 'startDate', tableValidate),
              })}
            >
              <Picker
                placeholder={`${record.isCycle ? '请选择' : '-'}`}
                allowClear={false}
                style={style}
                disabled={!record.isCycle}
                disabledDate={disabledDate}
                value={value ? moment(value, 'X') : undefined}
                onChange={(...args) => handleStartDateChange({ value, record, index }, ...args)}
              />
            </div>
          ),
        });
      },
    },
    {
      title: '结束日期',
      dataIndex: 'endDate',
      className: 'th-required',
      align: 'center',
      render: (value, record, index) => {
        const Picker = record.isCycle ? MonthPicker : DatePicker;
        const format = record.isCycle ? monthFormat : dateFormat;
        const { serviceItemDates } = record;
        const disabledDate = (endValue) => {
          // 需要排除掉同客户同个服务项目其他应收单已经选了的日期
          let result = false;
          if (!endValue) {
            return false;
          }
          const eValue = endValue.format(format).valueOf();
          if (record.startDate) {
            result = result || eValue < record.startDate.format(format).valueOf();
          }
          if (serviceItemDates && Array.isArray(serviceItemDates)) {
            serviceItemDates.forEach((item) => {
              if (item.startDate && item.endDate) {
                result =
                  result ||
                  (eValue >=
                    moment(item.startDate, 'X')
                      .format(format)
                      .valueOf() &&
                    eValue <=
                      moment(item.endDate, 'X')
                        .format(format)
                        .valueOf());
              }
            });
          }
          return result;
        };
        return handleEmptyCell({
          value,
          record,
          index,
          content: (
            <div
              className={classnames({
                'has-error': getIsRequired(record, 'endDate', tableValidate),
              })}
            >
              <Picker
                placeholder="请选择"
                allowClear={false}
                style={style}
                disabledDate={disabledDate}
                value={value ? moment(value, 'X') : undefined}
                onChange={(...args) => handleEndDateChange({ value, record, index }, ...args)}
              />
            </div>
          ),
        });
      },
    },
    {
      title: '服务期数（月）',
      dataIndex: 'servicePeriodNum',
      className: 'th-required',
      align: 'center',
      render: (value, record, index) =>
        handleEmptyCell({
          value,
          record,
          index,
          content: record.isCycle ? (
            <ServicePeriods
              style={style}
              firstClassName={classnames({
                'has-error': getIsRequired(record, 'servicePeriodNum', tableValidate),
              })}
              value={{ first: record.servicePeriodNum, second: record.freePeriodNum }}
              onChange={(...args) =>
                handleServicePeriodNumChange({ value, record, index }, ...args)
              }
            />
          ) : (
            <NumberInput disabled placeholder="-" />
          ),
        }),
    },
    {
      title: '结算方式',
      dataIndex: 'settlementMethod',
      className: 'th-required',
      align: 'center',
      render: (value, record, index) =>
        handleEmptyCell({
          value,
          record,
          index,
          content: (
            <div
              className={classnames({
                'has-error': getIsRequired(record, 'settlementMethod', tableValidate),
              })}
            >
              <AntdSelect
                placeholder="请选择"
                showSearch={false}
                disabled={!record.isCycle || record.unitPrice === 0}
                style={style}
                value={value}
                dataSource={dictionary.settlementMethod.list}
                onChange={(...args) => handleSettlementChange({ value, record, index }, ...args)}
              />
            </div>
          ),
        }),
    },
    {
      title: '金额（元）',
      dataIndex: 'money',
      align: 'right',
      className: classnames('th-required', styles['total-money']),
      total: tableSumMoney || '',
      totalStyle: {
        padding: '0 20px',
      },
      render: (value, record, index) =>
        handleEmptyCell({
          value,
          record,
          index,
          content: (
            <div
              className={classnames({
                'has-error': getIsRequired(record, 'money', tableValidate),
              })}
            >
              <NumberInput
                placeholder="0.00"
                style={style}
                value={value}
                onChange={(...args) => handleMoneyChange({ value, record, index }, ...args)}
              />
            </div>
          ),
        }),
    },
  ];
}
