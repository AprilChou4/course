import React from 'react';
import { connect } from 'nuomi';
import { Layout, ContentWrapper } from '@components';
import Operations from '../Operations';
import Content from '../Content';
import Footer from '../Footer';

const Main = ({ title }) => {
  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title={title}
        header={{
          right: <Operations />,
        }}
        content={<Content />}
        footer={<Footer />}
      />
    </Layout.PageWrapper>
  );
};

export default connect(({ title }) => ({ title }))(Main);
