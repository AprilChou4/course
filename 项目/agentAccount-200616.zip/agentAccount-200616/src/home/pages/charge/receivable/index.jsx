/**
 * （新增）应收单
 */
import React from 'react';
import pubData from 'data';
import { router } from 'nuomi';
import { NoAuthPage } from '@components';
import Main from './components/Main';
import effects from './effects';

const getAuth = () => {
  const userAuth = pubData.get('authority');
  const { pathname } = router.location();
  const isViewPage = pathname === '/charge/viewReceivable';
  return isViewPage ? userAuth['574'] : userAuth['572'];
};

export default {
  id: 'receivable',
  state: {
    title: '应收单',
    // 页面状态
    status: 0,
    // 主页面的form
    form: undefined,
    // form初始值
    formInitialValues: {},
    // 客户列表
    customerList: [],
    // 业务员列表
    businessStaffList: [],
    // 服务类型
    serviceItemsList: [],
    // 是否自动生成工商任务单
    shouldCreateTask: false,
    // 表格行的key
    tableRowKey: 'itemOrder',
    // 表格行key叠加器
    tableRowKeyCounter: 2,
    // 服务项目表格
    tableData: [{ itemOrder: 0 }, { itemOrder: 1 }, { itemOrder: 2 }],
    // 表格金额合计
    tableSumMoney: 0,
    // 服务项目表格验证
    tableValidate: false,
  },
  effects,
  render() {
    // 控制查看权限
    return <>{getAuth() ? <Main /> : <NoAuthPage />}</>;
  },
  onChange: {
    // 这里加上$让它在初始化的时候不执行，initData里再手动的去执行 query，否则 initData中无法拿到 query中请求得到的数据
    $query() {
      // 控制查看权限
      if (!getAuth()) {
        return;
      }
      this.store.dispatch({
        type: 'query',
      });
    },
  },
  onInit() {
    // 控制查看权限
    if (!getAuth()) {
      return;
    }
    this.store.dispatch({
      type: 'initData',
    });
  },
};
