import dictionary from './dictionary';

// 周期性服务的必填字段
const cycleRequiredFields = [
  'serviceItemId',
  'serviceTypeName',
  'unitPriceContainTax',
  'unitPrice',
  'startDate',
  'endDate',
  'servicePeriodNum',
  'settlementMethod',
  'money',
];
// 非周期性服务的必填字段
const noCycleRequiredFields = [
  'serviceItemId',
  'serviceTypeName',
  'unitPriceContainTax',
  'unitPrice',
  'endDate',
  'settlementMethod',
  'money',
];

export { dictionary, cycleRequiredFields, noCycleRequiredFields };
