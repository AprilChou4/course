/**
 * 查看/编辑收款单
 */
import { nuomi } from 'nuomi';
import collection from '../collection';

export default nuomi.extend(collection, {
  id: 'charge_viewCollection',
  state: {},
});
