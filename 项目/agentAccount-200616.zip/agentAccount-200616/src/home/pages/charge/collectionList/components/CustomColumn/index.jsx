// 客户管理 > 更多 > 自定义列
import React, { useState, useCallback } from 'react';
import { connect } from 'nuomi';
import CustomColModal from '@components/CustomColModal';

const ReceivaleCustomizeColum = ({
  collectCustomizeColumVisible,
  columnSource = [],
  loadings,
  dispatch,
}) => {
  // 取消/关闭自定义列弹窗
  const cancel = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        collectCustomizeColumVisible: false,
      },
    });
  }, [dispatch]);

  // 保存自定义顺序列
  const setColOption = useCallback(
    (columnSourceArr) => {
      dispatch({
        type: '$updateCollectCustomizeColumn',
        payload: {
          customizeColumns: columnSourceArr,
        },
      }).then(() => {
        cancel();
      });
    },
    [cancel, dispatch],
  );

  return (
    collectCustomizeColumVisible && (
      <CustomColModal
        columnSource={columnSource}
        onCancel={cancel}
        visible={collectCustomizeColumVisible}
        isLoading={loadings.$updateCollectCustomizeColumn}
        setColOption={setColOption}
        resetUrl="instead/v2/customer/receipt/receiveBill/customizeColumn/get.do"
        disabledColumn={['customerName', 'receiptNo']}
      />
    )
  );
};

export default connect(({ collectCustomizeColumVisible, columnSource, loadings }) => ({
  collectCustomizeColumVisible,
  columnSource,
  loadings,
}))(ReceivaleCustomizeColum);
