/* eslint-disable no-param-reassign */
/**
 *核销按钮
 */
import React from 'react';
import pubData from 'data';
import { connect, store } from 'nuomi';
import { Button, message } from 'antd';
import { ShowConfirm } from '@components';
import { get, postMessageRouter } from '@utils';

const WriteOffBtn = ({ selectedRowKeys, selectedRows = [], dispatch }) => {
  const linkToAdd = (args = {}) => {
    const { query, isNew } = args;
    // 由于新项目经过路由跳转时只能把参数附在url上，url长度有限制，所以有的查询参数就放到了pubData
    query && pubData.set('verification-query', query);
    isNew && pubData.set('verification-new', true);
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/charge/verification',
      },
    });
  };

  // 点击核销
  const writeOff = () => {
    if (!selectedRowKeys.length) {
      message.warning('请选择要核销的信息');
      return false;
    }

    const { customerId } = selectedRows[0];
    if (selectedRows.some((item) => item.customerId !== customerId)) {
      message.warning('请选择同一个客户的应收单去核销！');
      return false;
    }

    const stores = store.getState();
    if (get(stores, 'verification.status') === 0) {
      // 已有一张核销单打开着且未确认核销的情况下，在应收单列表上面新勾选了应收单点击核销的弹层提示，选择是，则打开核销单并数据直接替换；选择否，则隐藏弹层打开老的页面；
      ShowConfirm({
        title: (
          <>
            您有正在编辑中的核销单，
            <br />
            是否直接替换？
          </>
        ),
        cancelText: '否',
        okText: '是',
        onCancel() {
          linkToAdd();
        },
        onOk() {
          linkToAdd({
            isNew: true,
            query: {
              customerId,
              srbIds: selectedRows.map((item) => item.shouldReceiveId),
            },
          });
        },
      });
    } else {
      // 无打开着的核销单页面时，正常跳转;
      // 已有一张核销单打开着且已核销完毕情况下，在应收单列表上面新勾选了应收单点击核销，则直接将新数据带入打开核销单新增界面（清空原始核销完毕的单据）；
      linkToAdd({
        isNew: true,
        query: {
          customerId,
          srbIds: selectedRows.map((item) => item.shouldReceiveId),
        },
      });
    }
  };

  return (
    <>
      <Button type="primary" onClick={writeOff}>
        核销
      </Button>
    </>
  );
};

export default connect(({ selectedRowKeys, selectedRows }) => ({ selectedRowKeys, selectedRows }))(
  WriteOffBtn,
);
