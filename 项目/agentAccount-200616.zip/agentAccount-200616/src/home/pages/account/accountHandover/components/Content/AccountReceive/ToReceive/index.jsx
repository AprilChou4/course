// 账套接受表格
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Table } from 'antd';
import { connect } from 'nuomi';
import { If, AntdTable, LinkButton, ShowConfirm } from '@components';

const ToReceive = ({ toReceive: { pagination, ...restTableOptions }, loadings, dispatch }) => {
  //  接收账套
  const handleReceive = useCallback(
    (record) => () => {
      dispatch({
        type: 'updateAssignAccounting',
        payload: {
          record,
          visible: true,
        },
      });
    },
    [dispatch],
  );
  // 拒绝账套
  const handleRefuse = useCallback(
    ({ recordId }) => () => {
      ShowConfirm({
        title: '您确认要拒绝接收该账套吗？',
        content: '拒绝后该账套将退回给移交人',
        onOk() {
          dispatch({
            type: 'refuse',
            payload: {
              recordId,
            },
          });
        },
      });
    },
    [dispatch],
  );
  const columns = useMemo(
    () => [
      {
        title: '序号',
        dataIndex: 'index',
        align: 'center',
        width: 50,
        render: (text, record, index) => index + 1 + (pagination.current - 1) * pagination.pageSize,
      },
      {
        title: '账套名称',
        dataIndex: 'accountNames',
      },
      {
        title: '移交人',
        dataIndex: 'transferRealName',
        width: 120,
      },
      {
        title: '接收人',
        dataIndex: 'receiptRealName',
        width: 120,
      },
      {
        title: '接收状态',
        dataIndex: 'status',
        width: 90,
        render(value) {
          const datas = {
            2: <span className="t-success">接收成功</span>,
            3: (
              <span className="t-error">
                接收失败
                <br />
                接收人拒收
              </span>
            ),
            4: (
              <span className="t-error">
                接收失败
                <br />
                移交人撤回
              </span>
            ),
          };
          return datas[value] || '';
        },
      },
      {
        title: '更新时间',
        dataIndex: 'operateTime',
        align: 'center',
        width: 93,
      },
      {
        title: '操作',
        dataIndex: 'options',
        align: 'center',
        width: 100,
        render(text, record) {
          return (
            <div className="btn-operations">
              <If condition={record.status === 1}>
                <LinkButton onClick={handleReceive(record)}>接收</LinkButton>
                <LinkButton onClick={handleRefuse(record)}>拒绝</LinkButton>
              </If>
            </div>
          );
        },
      },
    ],
    [handleReceive, handleRefuse, pagination],
  );
  const onPaginationChange = useCallback(
    (page, pageSize) => {
      dispatch({
        type: '$getToReceiveList',
        payload: {
          pageSize,
          current: page,
        },
      });
    },
    [dispatch],
  );
  const tablePagination = useMemo(() => {
    return {
      ...pagination,
      onChange: onPaginationChange,
      onShowSizeChange: onPaginationChange,
    };
  }, [onPaginationChange, pagination]);

  // useEffect(() => {
  //   dispatch({
  //     type: '$getToReceiveList',
  //   });
  // }, [dispatch]);

  return (
    <AntdTable
      {...restTableOptions}
      columns={columns}
      loading={loadings.$getToReceiveList}
      pagination={tablePagination}
    />
  );
};

export default connect(({ toReceive, loadings }) => ({
  toReceive,
  loadings,
}))(ToReceive);
