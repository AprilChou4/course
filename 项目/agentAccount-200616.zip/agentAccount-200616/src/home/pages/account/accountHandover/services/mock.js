export default {
  checkUser() {
    return {
      data: [
        {
          companyId: '',
          companyname: '13657098255',
          phoneNum: '13657098255',
          realName: '13657098255',
          staffId: 'F6CFFCEB825F4C7EA5894306B468EDE4',
          unitnumber: '',
          username: 'hexin',
          versionType: '0',
        },
        {
          companyId: '',
          companyname: '13657098255',
          phoneNum: '13657098255',
          realName: '13657098255',
          staffId: 'F6CFFCEB825F4C7EA5894306B468EDE4',
          unitnumber: '',
          username: 'hexin',
          versionType: '0',
        },
      ],
      message: '',
      result: 'success',
      status: 200,
    };
  },
};
