/**
 * 批量审核设置弹窗
 */
import React, { useCallback, useRef } from 'react';
import { connect } from 'nuomi';
import { AntdModal } from '@components';
import Content from './Content';

const BatchVerifySetting = ({ visible, dispatch }) => {
  const contentRef = useRef(null);

  const handleCancel = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        batchVerifySettingModal: { visible: false },
      },
    });
  }, [dispatch]);

  const handleOk = useCallback(() => {
    contentRef.current.form?.validateFields((err, values) => {
      if (err) return;

      dispatch({
        type: 'verifySetting',
        payload: values,
      });
    });
  }, [dispatch]);

  return (
    <AntdModal
      title="批量审核设置"
      className="form-modal"
      width={343}
      getContainer={false}
      visible={visible}
      onCancel={handleCancel}
      onOk={handleOk}
    >
      <Content wrappedComponentRef={contentRef} />
    </AntdModal>
  );
};

export default connect(({ batchVerifySettingModal: { visible } }) => ({
  visible,
}))(BatchVerifySetting);
