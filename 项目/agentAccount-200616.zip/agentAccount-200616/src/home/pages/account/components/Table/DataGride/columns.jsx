/* eslint-disable no-nested-ternary */
import React from 'react';
import { LinkButton } from '@components';
import { validateArrayLength } from '@utils';
import { dictionary, openUrl, role } from '../../../utils';
import Operate from './Operate';
import styles from './style.less';

const GREEN = '#59D49E';
const RED = '#f00';
const colors = {
  '0': RED,
  '1': GREEN,
};
const colors2 = {
  '1': GREEN,
  '2': '#FF6400',
  '3': RED,
};
const getPaddingRight = (data) => {
  let value = 0;
  if (data.status === 1) {
    value += 24;
  }
  if (data.isLocking) {
    value += 24;
  }
  if (data.transfer) {
    value += 24;
  }
  return value;
};
const Cell = ({ title, children, color, open, onClick }) => {
  const style = {};
  if (color) {
    style.color = color;
  }
  return (
    <span className="table-cell" title={title} style={style}>
      {open !== undefined ? (
        <a className={open !== false ? 'table-cell-edit' : 'table-cell-normal'} onClick={onClick}>
          {children}
        </a>
      ) : (
        children
      )}
    </span>
  );
};

export default ({ columnSource, currentPage, pageSize, order, needVerify, onEdit }) => {
  const columnsMap = {
    index: {
      title: '序号',
      align: 'center',
      width: 50,
      render: (text, record, index) => index + 1 + (currentPage - 1) * pageSize,
    },
    customerCode: {
      title: '客户编码',
      align: 'center',
      width: 120,
      ellipsis: true,
      sorter: true,
      sortOrder: { customerCodeDesc: 'descend', customerCodeAsc: 'ascend' }[order] || false,
    },
    accountName: {
      title: '账套名称',
      className: 'th-center accountName',
      width: 280,
      ellipsis: true,
      render: (text, data) => (
        <>
          {!!data.isNew && <span className="newCustomer-img" />}
          <div className="f-pr" style={{ paddingRight: getPaddingRight(data) }}>
            <LinkButton
              plain
              ellipsis
              className={styles['accountName-button']}
              onClick={() => openUrl(data, 'home')}
            >
              {text}
            </LinkButton>
            <em className={styles.marks}>
              {data.status === 1 && (
                <span title="已停止" className={styles['mark-stop']}>
                  停
                </span>
              )}
              {!!data.isLocking && (
                <i title="已锁定" className="iconfont" style={{ color: '#FF0000' }}>
                  &#xee58;
                </i>
              )}
              {!!data.transfer && (
                <span title="交接中" className={styles['mark-transfer']}>
                  交
                </span>
              )}
            </em>
          </div>
        </>
      ),
    },
    vatType: {
      title: '纳税性质',
      align: 'center',
      width: 100,
      ellipsis: true,
      render: (value) => dictionary.vatType.map[value],
    },
    bookkeepingAccounting: {
      title: '记账会计',
      align: 'center',
      width: 100,
      ellipsis: true,
    },
    accountingAssistant: {
      title: '会计助理',
      align: 'center',
      width: 100,
      ellipsis: true,
    },
    schedule: {
      title: '账套进度',
      align: 'center',
      width: 73,
      ellipsis: true,
      render: (text, record) => {
        let path = '';
        // 如果返回的是"未结账(待审核)"，且未开启审核，且已有凭证，就显示“待结账”
        const realValue = text === 5 && !record.isNeedVerify && record.voucherCount > 0 ? 6 : text;
        // 待审核（已停用账套不能审核）
        if (realValue === 5 && record.isNeedVerify && !record.status) {
          path = 'voucher/list?verifyStatus=0';
        }
        // 待结账
        else if (realValue === 6 && !record.status) {
          path = 'terminal/checkout';
        }
        return (
          <Cell
            color={realValue === 7 ? GREEN : ''}
            open={path ? true : undefined}
            onClick={() => openUrl(record, path)}
          >
            {dictionary.schedules.map[realValue] || '未建账'}
          </Cell>
        );
      },
    },
    isCheckOut: {
      title: '结账状态',
      align: 'center',
      width: 73,
      ellipsis: true,
      render: (text) => (
        <Cell color={colors[text]}>{dictionary.isCheckOut.map[text] || '未开始'}</Cell>
      ),
    },
    reviewStatus: {
      title: '审核状态',
      align: 'center',
      width: 73,
      ellipsis: true,
      render: (text) => {
        return <Cell color={colors[text]}>{dictionary.reviewStatus.map[text] || '未开始'}</Cell>;
      },
    },
    createPeriod: {
      title: '建账期间',
      align: 'center',
      width: 80,
      ellipsis: true,
      sorter: true,
      sortOrder: { periodDesc: 'descend', periodAsc: 'ascend' }[order] || false,
    },
    currentPeriod: {
      title: '当前账期',
      align: 'center',
      width: 77,
      ellipsis: true,
    },
    checkStatus: {
      title: '风险检测',
      align: 'center',
      width: 73,
      ellipsis: true,
      render: (text) => (
        <Cell color={colors2[text]}>{dictionary.checkStatus.map[text] || '未开始'}</Cell>
      ),
    },
    customerName: {
      title: '客户名称',
      className: 'th-center',
      width: 267,
      ellipsis: true,
    },
    taxType: {
      title: '增值税申报类型',
      align: 'center',
      width: 118,
      ellipsis: true,
      render: (text) => dictionary.taxType.map[text] || '-',
    },
    operations: {
      title: '操作',
      fixed: 'right',
      width: role !== 3 ? 170 : 130,
      align: 'center',
      className: 'operate-cell',
      render: (text, data) => <Operate data={data} onEdit={onEdit} />,
    },
  };

  // 根据columnSource生成columns
  const columns = [];
  if (validateArrayLength(columnSource)) {
    columns.push(columnsMap.index);
    const basicColSetting = { width: 100, align: 'center', ellipsis: true };
    columnSource.forEach((item) => {
      const dataIndex = item?.fieldKey;
      const col = columnsMap[dataIndex];
      // 助理会计（role === 3）不显示 风险监测 列
      // 关闭审核时（!needVerify）不显示 审核状态 列
      if (
        !item?.selected ||
        (dataIndex === 'checkStatus' && role === 3) ||
        (dataIndex === 'reviewStatus' && !needVerify)
      ) {
        return;
      }

      columns.push({
        ...(col || basicColSetting),
        ...(col ? {} : { title: item?.fieldName }),
        dataIndex,
      });
    });
    columns[columns.length - 1].width = 'auto'; // 因为有固定列，最后一列不设置宽度
    columns.push(columnsMap.operations);
  }
  return columns;
};
