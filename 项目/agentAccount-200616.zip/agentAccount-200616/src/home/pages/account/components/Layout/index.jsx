import React from 'react';
import { connect } from 'nuomi';
import { Authority, Layout, ContentWrapper } from '@components';
import pubData from 'data';
import Search from '../Search';
import Table from '../Table';
import DateMonth from '../DateMonth';
import ReviewButton from '../ReviewBtn';
import CheckoutBtn from '../CheckoutBtn';
import BatchUpdateBtn from '../BatchUpdate';
import More from '../More';
import AccountHandover from '../AccountHandover';
import BatchVerifySetting from '../BatchVerifySetting';
import CustomColModal from '../CustomColModal';
import EditAccount from '../EditAccount';

const userAuth = pubData.get('authority');

const App = () => (
  <Layout.Container>
    <ContentWrapper
      header={{
        left: (
          <>
            <DateMonth />
            <Authority code="56">
              <Search />
            </Authority>
          </>
        ),
        right: (
          <>
            <BatchUpdateBtn />
            <ReviewButton />
            <CheckoutBtn />
            <More />
          </>
        ),
      }}
      content={<Table />}
    />
    {userAuth[57] && <AccountHandover />}
    <BatchVerifySetting />
    <CustomColModal />
    <EditAccount />
  </Layout.Container>
);

export default connect(({ key }) => ({
  key,
}))(App);
