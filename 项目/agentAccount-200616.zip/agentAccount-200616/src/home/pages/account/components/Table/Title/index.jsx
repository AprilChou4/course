import React, { forwardRef } from 'react';
import { connect } from 'nuomi';
import { If, Iconfont, LinkButton } from '@components';
import { get } from '@utils';
import { dictionary } from '../../../utils';
import styles from './style.less';

const Title = (
  {
    createdNum,
    notCheckOutNum,
    checkOutNum,
    ongoingNum,
    notStartNum,
    stopNum,
    accountListQueryType,
    searchInputRef,
    dispatch,
  },
  ref,
) => {
  const handleClick = (type) => {
    searchInputRef && searchInputRef.onReset && searchInputRef.onReset({ query: false });
    setTimeout(() => {
      dispatch({
        type: 'updateAccQueryType',
        payload: { accountListQueryType: type },
      });
    });
  };

  const getButton = (type) => (
    <LinkButton
      underline
      style={{ color: type === accountListQueryType ? '#008cff' : 'inherit' }}
      onClick={() => handleClick(type)}
    >
      {get(dictionary.accountListQueryTypeMap, `${type}.text`, '')}
    </LinkButton>
  );

  // 未开启审核时，待结账的数量要加上待审核的数量
  return (
    <>
      <Iconfont code="&#xea3d;" style={{ marginRight: 8 }} />
      本月共 {createdNum || 0} 个账套{getButton(1)}，
      {createdNum > 0 && (
        <span>
          其中：{notStartNum || 0} 个账套{getButton(2)}，{ongoingNum || 0} 个账套{getButton(3)}（
          {notCheckOutNum || 0} 个账套
          {getButton(4)}
          ），
          {checkOutNum || 0} 个账套{getButton(5)}；
        </span>
      )}
      共 {stopNum || 0} 个账套{getButton(10)}
      <If condition={accountListQueryType !== 0}>
        <span className={styles.dangerBtn} onClick={() => handleClick(0)}>
          查看全部
        </span>
      </If>
    </>
  );
};

export default connect(
  ({
    accountListQueryType,
    searchInputRef,
    totalData: { createdNum, notCheckOutNum, checkOutNum, ongoingNum, notStartNum, stopNum },
  }) => ({
    accountListQueryType,
    searchInputRef,
    createdNum,
    notCheckOutNum,
    checkOutNum,
    ongoingNum,
    notStartNum,
    stopNum,
  }),
)(forwardRef(Title));
