/* eslint-disable import/no-cycle */
import React, { createContext, useState, useCallback } from 'react';
import { DropDown, Authority } from '@components';
import AccountHandover from './AccountHandover';
import BatchVerifySetting from './BatchVerifySetting';
import RecycleBin from './RecycleBin';
import Unlock from './Unlock';
import Export from './Export';

export const VisibleContext = createContext(false);

const More = () => {
  const [visible, setVisible] = useState(false);

  const handleVisibleChange = useCallback((status) => {
    setVisible(status);
  }, []);

  return (
    <VisibleContext.Provider value={visible}>
      <DropDown onVisibleChange={handleVisibleChange}>
        <Authority code="635">
          <Export />
        </Authority>
        <Authority code="57">
          <AccountHandover />
        </Authority>
        <Authority code="57">
          <BatchVerifySetting />
        </Authority>
        <Authority code="673">
          <RecycleBin />
        </Authority>
        <Authority code="495">
          <Unlock />
        </Authority>
      </DropDown>
    </VisibleContext.Provider>
  );
};

export default More;
