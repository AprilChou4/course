import React, { useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { ShowConfirm, AntdTable } from '@components';
import { openUrl, storeForUser } from '../../../utils';
import getColumns from './columns';
import styles from './style.less';

const Table = ({
  selectedRowKeys,
  total,
  pageSize,
  current,
  order,
  columnSource,
  totalData,
  needVerify,
  dispatch,
  ...restProps
}) => {
  const onRow = useCallback(
    (data) => ({
      onDoubleClick() {
        // 判断正在迁移的话提示
        if (data.isMoving) {
          ShowConfirm({
            title: '账套升级中，请稍后访问！',
            okText: '知道了',
            cancelButtonProps: {
              style: { display: 'none' },
            },
          });
          return;
        }

        openUrl(data);
      },
    }),
    [],
  );

  // 编辑账套
  const onEdit = useCallback(
    (record) => {
      dispatch({
        type: 'updateEditAccount',
        payload: {
          visible: true,
          record,
        },
      });
    },
    [dispatch],
  );

  const columns = useMemo(
    () =>
      getColumns({
        columnSource,
        currentPage: current,
        pageSize,
        order,
        needVerify,
        onEdit,
      }),
    [columnSource, current, needVerify, onEdit, order, pageSize],
  );

  const handleTableChange = useCallback(
    (pagination, filters, sorter) => {
      storeForUser('account_table_pagesize', pagination.pageSize);
      const newOrder =
        {
          customerCode: {
            descend: 'customerCodeDesc',
            ascend: 'customerCodeAsc',
          },
          createPeriod: {
            descend: 'periodDesc',
            ascend: 'periodAsc',
          },
        }[sorter.field]?.[sorter.order] ?? '';
      // 该回调会早于表头绑定的点击事件回调先执行，因此加定时器解决该问题
      setTimeout(() => {
        dispatch({
          type: 'updateState',
          payload: {
            ...pagination,
            order: newOrder,
          },
        });
        dispatch({
          type: 'query',
        });
        // 缓存排序
        localStorage.setItem('ACCOUNT_COLUMN_SORT', newOrder);
      });
    },
    [dispatch],
  );

  const handleSettingClick = useCallback(() => {
    dispatch({
      type: 'updateState',
      payload: {
        customColModal: { visible: true },
      },
    });
  }, [dispatch]);

  return (
    <AntdTable
      bordered
      showSettingIcon
      scroll={{ y: true }}
      {...restProps}
      columns={columns}
      className={styles.table}
      rowSelection={{
        columnWidth: 35,
        selectedRowKeys,
        onChange(sRowKeys, sRows) {
          dispatch({
            type: 'updateState',
            payload: {
              selectedRowKeys: sRowKeys,
              selectedRows: sRows,
            },
          });
        },
      }}
      onRow={onRow}
      onChange={handleTableChange}
      pagination={{ current, total, pageSize }}
      onSettingClick={handleSettingClick}
    />
  );
};

export default connect(
  ({
    columnSource,
    current,
    total,
    pageSize,
    loading,
    dataSource,
    order,
    selectedRowKeys,
    needVerify,
  }) => ({
    columnSource,
    current,
    total,
    pageSize,
    loading,
    dataSource,
    order,
    selectedRowKeys,
    needVerify,
  }),
)(Table);
