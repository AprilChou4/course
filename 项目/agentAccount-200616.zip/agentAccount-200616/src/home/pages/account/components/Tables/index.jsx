import React, { useState, useContext, useEffect, useCallback, useMemo } from 'react';
import { SuperTable } from '@components';
import Operations from './Operations';

const Table = () => {
  return <SuperTable />;
};

export default Table;
