/**
 * 导出
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { ExportText } from '@components';

const Export = ({ dispatch }) => {
  const handleClick = useCallback(async () => {
    const data = await dispatch({
      type: 'getQueryParams',
    });
    return data;
  }, [dispatch]);

  return (
    <ExportText url={`${basePath}instead/v2/customer/account/export.do`} onSubmit={handleClick}>
      导出
    </ExportText>
  );
};

export default connect()(Export);
