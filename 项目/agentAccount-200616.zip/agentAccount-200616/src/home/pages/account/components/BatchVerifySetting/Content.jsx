import React, { forwardRef, useImperativeHandle } from 'react';
import { Form, Radio } from 'antd';
import { GenFormItem } from '@components';
import styles from './style.less';

const Content = forwardRef(({ form }, ref) => {
  // 传给父组件
  useImperativeHandle(ref, () => ({ form }), [form]);

  return (
    <Form>
      <GenFormItem
        form={form}
        name="isNeedVerify"
        rules={[{ required: true, message: '请选择是否开启审核' }]}
        className={styles.needVerify}
      >
        <Radio.Group>
          <Radio value={1}>开启审核</Radio>
          <Radio value={0}>关闭审核</Radio>
        </Radio.Group>
      </GenFormItem>
    </Form>
  );
});

export default Form.create()(Content);
