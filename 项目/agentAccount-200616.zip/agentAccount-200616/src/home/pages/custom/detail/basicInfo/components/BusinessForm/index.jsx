import React from 'react';
import { Form, Input, Select, DatePicker } from 'antd';
import { connect } from 'nuomi';
import { InputNumberWithUnit } from '@components';
import moment from 'moment';
import { isNil } from '@utils';
import { getMaxByUnit } from '../../utils';

import './style.less';

const { Option } = Select;
const { TextArea } = Input;

const BusinessForm = ({
  isEditing,
  form,
  formParams,
  registrationList,
  smRegistrationList,
  registerPrentMap,
  registerChildMap,
  dispatch,
}) => {
  const { getFieldDecorator } = form;

  // 登记注册类型小类改变
  function onChildChange(value) {
    if (!value) return;
    form.setFieldsValue({
      registrationType: registerChildMap[value].registrationTypeCode,
    });
  }

  // 行业类型大类改变
  function onParentChange(value) {
    form.setFieldsValue({
      registrationTypeChild: undefined,
    });
    let list = [];
    if (value) {
      list = registerPrentMap[value];
    } else {
      const keys = Object.keys(registerPrentMap);
      list = keys.reduce((a, c) => [...a, ...registerPrentMap[c]], []);
    }
    dispatch({
      type: 'updateState',
      payload: {
        smRegistrationList: list,
      },
    });
  }

  return (
    <dl className="form-block">
      <dt>工商信息</dt>
      <dd>
        <div className="form-row">
          <Form.Item label="登记注册类型" styleName="register-type-form-item">
            {getFieldDecorator('registrationType', {
              initialValue:
                !formParams.registrationType || formParams.registrationType <= 0
                  ? undefined
                  : formParams.registrationType,
            })(
              <Select
                placeholder={isEditing ? '请选择登记注册类型' : '-'}
                disabled={!isEditing}
                showSearch
                filterOption={(inputValue, option) => {
                  return option.props.children.indexOf(inputValue) > -1;
                }}
                allowClear
                onChange={onParentChange}
                getPopupContainer={(triggerNode) => triggerNode.parentNode}
              >
                {registrationList.map(({ registrationTypeCode, registrationTypeName }) => (
                  <Option value={registrationTypeCode} key={registrationTypeCode}>
                    {registrationTypeName}
                  </Option>
                ))}
              </Select>,
            )}
          </Form.Item>
          <Form.Item styleName="register-type-form-item">
            {getFieldDecorator('registrationTypeChild', {
              initialValue:
                !formParams.registrationTypeChild || formParams.registrationTypeChild <= 0
                  ? undefined
                  : formParams.registrationTypeChild,
            })(
              <Select
                placeholder={isEditing ? '请选择登记注册类型' : '-'}
                disabled={!isEditing}
                showSearch
                filterOption={(inputValue, option) => {
                  return option.props.children.indexOf(inputValue) > -1;
                }}
                onChange={onChildChange}
                allowClear
                getPopupContainer={(triggerNode) => triggerNode.parentNode}
              >
                {smRegistrationList.map(({ registrationTypeCode, registrationTypeName }) => (
                  <Option value={registrationTypeCode} key={registrationTypeCode}>
                    {registrationTypeName}
                  </Option>
                ))}
              </Select>,
            )}
          </Form.Item>
          <Form.Item label="法定代表人">
            {getFieldDecorator('representative', {
              initialValue: formParams.representative,
            })(
              <Input
                placeholder={isEditing ? '请输入法定代表人' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
        </div>
        <div className="form-row">
          <Form.Item label="注册资本">
            {getFieldDecorator('registeredCapital', {
              initialValue: {
                number: formParams.registeredCapital < 0 ? undefined : formParams.registeredCapital,
                unit: isNil(formParams.registeredCapitalUnit)
                  ? 1
                  : formParams.registeredCapitalUnit,
              },
            })(
              <InputNumberWithUnit
                max={getMaxByUnit(formParams.registeredCapitalUnit)}
                placeholder={isEditing ? '请输入注册资本' : '-'}
                autoComplete="off"
                min={0}
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
          <Form.Item label="成立日期">
            {getFieldDecorator('establishmentDate', {
              initialValue: formParams.establishmentDate
                ? moment(formParams.establishmentDate)
                : null,
            })(
              <DatePicker placeholder={isEditing ? '请选择成立日期' : '-'} disabled={!isEditing} />,
            )}
          </Form.Item>
        </div>
        <div className="form-row">
          <Form.Item label="登记机关">
            {getFieldDecorator('registrationAuthority', {
              initialValue: formParams.registrationAuthority,
            })(
              <Input
                placeholder={isEditing ? '请输入登记机关' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
          <Form.Item label="注册地址">
            {getFieldDecorator('registrationAddress', {
              initialValue: formParams.registrationAddress,
            })(
              <Input
                placeholder={isEditing ? '请输入注册地址' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
        </div>
        <div className="form-row">
          <Form.Item label="经营范围" styleName="business-scope-form-item">
            {getFieldDecorator('businessScope', {
              initialValue: formParams.businessScope,
            })(
              <TextArea
                placeholder={isEditing ? '请输入经营范围' : '-'}
                autoSize={{ minRows: 3, maxRows: 3 }}
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
        </div>
      </dd>
    </dl>
  );
};

const mapStateToProps = ({
  formParams,
  isEditing,
  registrationList,
  smRegistrationList,
  registerPrentMap,
  registerChildMap,
}) => ({
  formParams,
  isEditing,
  registrationList,
  smRegistrationList,
  registerPrentMap,
  registerChildMap,
});

export default connect(mapStateToProps)(BusinessForm);
