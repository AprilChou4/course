import { message } from 'antd';
import { router } from 'nuomi';
import ShowConfirm from '@components/ShowConfirm';
import { isNil } from '@utils';
import moment from 'moment';
import services from '../services';
import {
  syncUpdateConfirm,
  isShareholderListEqual,
  isTianYanChaInfoEqual,
  TIAN_YAN_CHA_FIELDS,
} from '../utils';

export default {
  // 获取客户基础信息详情
  async $getBasicInfo() {
    const { customerId, isEdit } = router.location().query || {};
    const data = await services.getBasicInfo(
      {
        customerId,
      },
      {
        loading: '正在获取基本信息...',
      },
    );
    const { industryPrentMap, registerPrentMap } = this.getState();
    let { smIndustryList, smRegistrationList } = this.getState();
    // 行业类型有大类，需要限制小类的列表
    if (data.industryTypeParent) {
      smIndustryList = industryPrentMap[data.industryTypeParent] || smIndustryList;
    }
    // 行业类型有大类，需要限制小类的列表
    if (data.registrationType) {
      smRegistrationList = registerPrentMap[data.registrationType] || smRegistrationList;
    }
    this.updateState({
      formParams: data,
      isEditing: Boolean(+isEdit),
      shareholderList: data.customerShareholderInfoList, // 将股东信息单独拿出来，防止重复渲染。
      smIndustryList,
      smRegistrationList,
    });
  },

  // 获取公司基础设置，判断是否开启国票通道 申报通道方式（0税务筹划平台；1国票）
  async $getCompanySetting() {
    const data = await services.getCompanySetting();
    this.updateState({
      isNationalTicket: data.declareWay === 1,
    });
  },
  // 保存
  async updateInfo(noRefresh) {
    const { shareholderList, formParams } = this.getState();
    const { customerId } = router.location().query || {};

    const toNotNil = (v, def) => (isNil(v) ? def : v);

    const params = {
      customerId,
      ...formParams,
      // registrationTypeChild: formParams.registrationTypeChild || '',
      // industryType: formParams.registrationTypeChild || '',
      registeredCapitalUnit: isNil(formParams.registeredCapitalUnit)
        ? 1
        : formParams.registeredCapitalUnit, // 防止后端报错。
      // 防止后端报错。
      customerShareholderInfoList: shareholderList.map((it) => ({
        ...it,
        capitalContributionsAmountUnit: toNotNil(it.capitalContributionsAmountUnit, 1),
        reallyInvestAmountUnit: toNotNil(it.reallyInvestAmountUnit, 1),
        subscriptionAmountUnit: toNotNil(it.subscriptionAmountUnit, 1),
        reallyInvestmentAmountUnit: toNotNil(it.reallyInvestmentAmountUnit, 1),
      })),
    };
    const data = await services.updateInfo(params, {
      loading: '正在保存',
      status: {
        400: () => {
          ShowConfirm({
            type: 'warning',
            content: '亲，检测到您填写的税局登录信息有误，为保证申报功能正常使用，请仔细检查。',
          });
        },
      },
    });
    this.updateState({
      isContChange: false,
    });
    message.success('基本信息保存成功');
    !noRefresh && this.$getBasicInfo();
    // #139501 客户名称是否修改，修改需要弹窗确认是否同步修改账套名称
    if (data && data.changeName) {
      const result = await syncUpdateConfirm();
      if (!result) {
        await services.updateZt({ customerId });
        message.success('同步修改账套成功');
      }
    }
  },

  // 根据名称查找客户
  async searchCustomer(customerName) {
    const data = await services.searchCustomer({
      customerName,
    });
    this.updateState({
      customerOptions: data || [],
    });
  },

  // 获取工商信息
  async getBusinessInfo(form) {
    const { formParams, shareholderList } = this.getState();
    const result = await services.getBusinessInfo(
      { customerName: formParams.customerName },
      {
        status: {
          300: () => {
            message.warn('未获取到该客户的工商信息，请检查客户名称！');
          },
        },
        loading: '正在获取工商信息...',
      },
    );
    // 比较表单是否有差异，有差异询问是否覆盖
    // console.log('相等？', isTianYanChaInfoEqual(formParams, result));
    const toMoment = (date) => {
      if (!date) return null;
      return moment(date).isValid() ? moment(date) : null;
    };

    if (
      !isTianYanChaInfoEqual(formParams, result) ||
      !isShareholderListEqual(shareholderList, result.customerShareholderInfoList)
    ) {
      ShowConfirm({
        title: '获取信息与档案信息存在不一致，是否继续覆盖？',
        okText: '覆盖',
        onOk: async () => {
          const changedField = TIAN_YAN_CHA_FIELDS.reduce((r, k) => ({ ...r, [k]: result[k] }), {});
          changedField.establishmentDate = toMoment(changedField.establishmentDate);
          changedField.registeredCapital = {
            number: result.registeredCapital,
            unit: result.registeredCapitalUnit,
          };
          delete changedField.registeredCapitalUnit;
          // console.log(changedField);
          form.setFieldsValue(changedField);

          this.updateState({
            shareholderList: result.customerShareholderInfoList,
          });
        },
        cancelText: '跳过',
      });
    }
  },

  // 离开的时候
  async onLeave() {
    const { isEditing, isContChange } = this.getState();
    if (!isEditing || !isContChange) {
      return true;
    }
    return new Promise((resolve) => {
      ShowConfirm({
        title: '提示',
        content: '当前页面内容未保存，是否离开？',
        okText: '保存',
        cancelText: '离开',
        onOk: async () => {
          try {
            await this.updateInfo(true);
            resolve(true);
          } catch (error) {
            // nothing
          }
        },
        onCancel() {
          resolve(true);
        },
      });
    });
  },

  // 获取行业类型列表
  async $getIndustryTypeList() {
    const data = await services.getIndustryTypeList();
    const industryPrentMap = {};
    const industryChildMap = {};
    const smIndustryList = [];
    data.forEach((item) => {
      industryPrentMap[item.industryTypeCode] = item.children;
      item.children.forEach((child) => {
        industryChildMap[child.industryTypeCode] = item;
        smIndustryList.push(child);
      });
    });
    this.updateState({
      industryList: data,
      smIndustryList,
      industryPrentMap,
      industryChildMap,
    });
  },

  // 获取登记注册类型列表
  async $getRegisterTypeList() {
    const data = await services.getRegisterTypeList();
    const registerPrentMap = {};
    const registerChildMap = {};
    const smRegistrationList = [];
    data.forEach((item) => {
      registerPrentMap[item.registrationTypeCode] = item.children;
      item.children.forEach((child) => {
        registerChildMap[child.registrationTypeCode] = item;
        smRegistrationList.push(child);
      });
    });
    this.updateState({
      registrationList: data,
      smRegistrationList,
      registerPrentMap,
      registerChildMap,
    });
  },

  async initData(payload) {
    this.updateState({
      key: new Date().getTime(),
    });
    await this.$getCompanySetting();
    await this.$getIndustryTypeList();
    await this.$getRegisterTypeList();
    await this.$getBasicInfo(payload);
  },
};
