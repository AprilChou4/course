// 客户详情 > 基本信息1
import React from 'react';
import effects from './effects';
import Main from './components/Main';

export default {
  id: 'customer_detail_basicInfo',
  state: {
    // 所需form表单参数
    formParams: {},
    // 内容是否改变,用于判断是否弹窗提示
    isContChange: false,
    // 股东信息
    shareholderList: [],
    // 是否处于编辑状态
    isEditing: false,
    // 输入建议：客户下拉列表
    customerOptions: [],
    key: 1,
    // 是否开启国票通道 任务 #138216
    isNationalTicket: false,
    // 行业大类型下拉list
    industryList: [],
    // 行业小类型下拉list
    smIndustryList: [],
    // 行业大类对应的孩子们
    industryPrentMap: {},
    // 行业小类对应的父亲们
    industryChildMap: {},
    // 登记注册类型大
    registrationList: [],
    // 登记注册类型小
    smRegistrationList: [],
    // 登记注册类型大对应的孩子们
    registerPrentMap: {},
    // 登记注册小类型对应的父亲们
    registerChildMap: {},
  },
  effects,
  render() {
    return <Main />;
  },
  onInit() {},
};
