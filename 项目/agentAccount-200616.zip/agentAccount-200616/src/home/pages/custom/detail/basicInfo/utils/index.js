import { ShowConfirm } from '@components';
import { pick, isEqual, isNil } from '@utils';
import moment from 'moment';

/* eslint-disable eqeqeq */

const MAX_NUMBER = 999999999.99;

const MAX_NUMBER_WAN = 999999.99;

// 天眼查同步需要同步/比对的字段
export const TIAN_YAN_CHA_FIELDS = [
  'industryTypeParent',
  'industryType',
  'registrationType',
  'registrationTypeChild',
  'representative',
  'registeredCapital',
  'registeredCapitalUnit',
  'establishmentDate',
  'registrationAuthority',
  'registrationAddress',
  'businessScope',
  'unifiedSocialCreditCode',
  'businessAddress',
  'businessEmail',
  'businessPhone',
  'businessPostalCode',
];

// 校验天眼查工商信息是否相等
export function isTianYanChaInfoEqual(value, other) {
  const a = pick(value, TIAN_YAN_CHA_FIELDS);
  const b = pick(other, TIAN_YAN_CHA_FIELDS);

  // 时间处理
  a.establishmentDate = a.establishmentDate && moment(a.establishmentDate).format('YYYY-MM-DD');
  b.establishmentDate = b.establishmentDate && moment(b.establishmentDate).format('YYYY-MM-DD');

  // 注册资金处理 -1也是空的意思
  a.registeredCapital = a.registeredCapital === -1 ? '' : a.registeredCapital;

  // 等等

  console.log(a, b);
  return TIAN_YAN_CHA_FIELDS.every((key) => {
    // if (a[key] != b[key]) {
    //   console.log('key', key);
    // }
    return a[key] == b[key];
  });

  // return isEqual(a, b)
}

// 校验股东信息列表是否相等
export function isShareholderListEqual(a, b) {
  if (a.length !== b.length) return false;
  const NEED_EQUAL_FIELDS = [
    'capitalContributionsAmount',
    'capitalContributionsAmountUnit',
    'capitalContributionsDate',
    'capitalContributionsType',
    'reallyInvestAmount',
    'reallyInvestAmountUnit',
    'reallyInvestDate',
    'reallyInvestType',
    'shareholder',
  ];

  return a.every((item, idx) => {
    const pickA = pick(item, NEED_EQUAL_FIELDS);
    const pickB = pick(b[idx], NEED_EQUAL_FIELDS);

    pickA.capitalContributionsDate =
      pickA.capitalContributionsDate && moment(pickA.capitalContributionsDate).format('YYYY-MM-DD');
    pickB.capitalContributionsDate =
      pickB.capitalContributionsDate && moment(pickB.capitalContributionsDate).format('YYYY-MM-DD');
    pickA.reallyInvestDate =
      pickA.reallyInvestDate && moment(pickA.reallyInvestDate).format('YYYY-MM-DD');
    pickB.reallyInvestDate =
      pickB.reallyInvestDate && moment(pickB.reallyInvestDate).format('YYYY-MM-DD');

    const toNotNil = (v, def) => (isNil(v) ? def : v);
    pickB.capitalContributionsAmountUnit = toNotNil(pickB.capitalContributionsAmountUnit, 1);
    pickB.reallyInvestAmountUnit = toNotNil(pickB.reallyInvestAmountUnit, 1);

    // console.log(pickA, pickB, isEqual(pickA, pickB));
    return isEqual(pickA, pickB);
  });
}

/**
 * 根据单位获取最大数值
 * @param {Number} unit 单位  0：元  1：万元
 */
export function getMaxByUnit(unit) {
  if (unit === 1) {
    return MAX_NUMBER_WAN;
  }
  return MAX_NUMBER;
}

/**
 * 弹窗确认是否同步修改客户名称
 */
export const syncUpdateConfirm = async () => {
  return new Promise((resolve) => {
    ShowConfirm({
      title: '客户名称发生变更，是否同步修改账套名称？',
      okText: '忽略',
      cancelText: '修改',
      onOk() {
        resolve(true);
      },
      onCancel() {
        resolve(false);
      },
    });
  });
};

export default {};
