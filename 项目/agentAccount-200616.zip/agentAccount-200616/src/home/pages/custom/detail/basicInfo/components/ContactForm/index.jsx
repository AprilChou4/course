import React, { useCallback } from 'react';
import { Form, Input } from 'antd';
import { connect } from 'nuomi';
import { constant } from '@public/script';

import './style.less';

const ContactForm = ({ form, formParams, isEditing }) => {
  const { getFieldDecorator } = form;

  const validatePhone = useCallback((rule, value, callback) => {
    // 座机
    const pattern1 = /^(([0+]\d{2,3}-)?(0\d{2,3})-)?(\d{7,8})(-(\d{3,}))?$/;
    // 手机
    const pattern2 = /^0?1[3-9][0-9]{9}$/;
    if (!value || pattern1.test(value) || pattern2.test(value)) {
      callback();
      return;
    }
    callback('联系电话格式错误');
  }, []);

  return (
    <dl className="form-block" styleName="contact-form-block">
      <p styleName="contact-label">企业联系信息</p>
      <dd>
        <div className="form-row">
          <Form.Item label="企业联系电话">
            {getFieldDecorator('businessPhone', {
              initialValue: formParams.businessPhone,
              rules: [{ validator: validatePhone }],
            })(
              <Input
                maxLength={20}
                placeholder={isEditing ? '企业联系电话' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
          <Form.Item label="电子邮箱">
            {getFieldDecorator('businessEmail', {
              initialValue: formParams.businessEmail,
              rules: [{ pattern: constant.REGEX.email, message: '电子邮箱格式错误' }],
            })(
              <Input
                maxLength={30}
                placeholder={isEditing ? '请输入电子邮箱' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
        </div>
        <div className="form-row">
          <Form.Item label="经营地址">
            {getFieldDecorator('businessAddress', {
              initialValue: formParams.businessAddress,
            })(
              <Input
                maxLength={300}
                placeholder={isEditing ? '请输入经营地址' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
          <Form.Item label="邮政编码">
            {getFieldDecorator('businessPostalCode', {
              initialValue: formParams.businessPostalCode,
            })(
              <Input
                maxLength={10}
                placeholder={isEditing ? '请输入邮政编码' : '-'}
                autoComplete="off"
                disabled={!isEditing}
              />,
            )}
          </Form.Item>
        </div>
      </dd>
    </dl>
  );
};

const mapStateToProps = ({ formParams, isEditing }) => ({
  formParams,
  isEditing,
});

export default connect(mapStateToProps)(Form.create()(ContactForm));
