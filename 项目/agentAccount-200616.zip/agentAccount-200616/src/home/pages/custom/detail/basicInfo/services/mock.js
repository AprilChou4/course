export default {
  // getBasicInfo({ customerId }) {
  //   return {
  //     status: 200,
  //     data: {
  //       // 基本信息 todo：营改增企业
  //       customerId,
  //       customerCode: 'kh202005-0792',
  //       customerName: 'mock客户名称',
  //       unifiedSocialCreditCode: '91310118748097906B',
  //       vatType: 0,
  //       industryTypeParent: '建筑业',
  //       industryType: '水源及供水设施工程建筑',
  //       isProductOil: 0,
  //       isForeignTrade: 1,
  //       // 工商信息
  //       registrationType: 4,
  //       representative: 'mock法人代表',
  //       registeredCapital: 4000,
  //       establishmentDate: 1566355099587,
  //       registrationAuthority: 'mock登记机关',
  //       registrationAddress: 'mock注册地址',
  //       businessScope: 'mock经营范围',
  //       // 股东信息
  //       customerShareholderInfoList: [
  //         {
  //           shareholder: 'mock股东名称',
  //           shareholderType: 1,
  //           shareholderCertificateType: 1,
  //           certificateNum: '230229199609044116',
  //           subscriptionAmount: 15000,
  //           reallyInvestmentAmount: 13000,
  //           capitalContributionsType: '货币',
  //           capitalContributionsAmount: 40000,
  //           capitalContributionsDate: 1566355099587,
  //           reallyInvestType: '土地使用权',
  //           reallyInvestAmount: 70000,
  //           reallyInvestDate: 1566355099587,
  //         },
  //       ],
  //     },
  //   };
  // },
  // updateInfo() {
  //   return {
  //     status: 200,
  //     data: null,
  //   };
  // },
  // searchCustomer() {
  //   return {
  //     status: 200,
  //     data: [
  //       {
  //         customerName: 'mock1号客户',
  //         unifiedSocialCreditCode: '33011111122222021607',
  //       },
  //       {
  //         customerName: 'mock2号客户',
  //         unifiedSocialCreditCode: '330111AE2202SD1607',
  //       },
  //       {
  //         customerName: 'mock3号客户',
  //         unifiedSocialCreditCode: '330AD11111asd122222SE027',
  //       },
  //     ],
  //   };
  // },
  // getIndustryTypeList() {
  //   return {
  //     status: 200,
  //     data: [
  //       {
  //         industryTypeCode: 1,
  //         industryTypeName: '农林牧渔',
  //         children: [
  //           { industryTypeCode: 11, industryTypeName: '稻谷种植' },
  //           { industryTypeCode: 12, industryTypeName: '小麦种植' },
  //         ],
  //       },
  //       {
  //         industryTypeCode: 2,
  //         industryTypeName: '采矿业',
  //         children: [
  //           { industryTypeCode: 21, industryTypeName: '烟煤和无烟煤开采洗选' },
  //           { industryTypeCode: 22, industryTypeName: '其他煤炭采选' },
  //         ],
  //       },
  //     ],
  //   };
  // },
  // getRegisterTypeList() {
  //   return {
  //     status: 200,
  //     data: [
  //       {
  //         registrationTypeCode: 1,
  //         registrationTypeName: '农林牧渔',
  //         children: [
  //           { registrationTypeCode: 11, registrationTypeName: '稻谷种植' },
  //           { registrationTypeCode: 12, registrationTypeName: '小麦种植' },
  //         ],
  //       },
  //       {
  //         registrationTypeCode: 2,
  //         registrationTypeName: '采矿业',
  //         children: [
  //           { registrationTypeCode: 21, registrationTypeName: '烟煤和无烟煤开采洗选' },
  //           { registrationTypeCode: 22, registrationTypeName: '其他煤炭采选' },
  //         ],
  //       },
  //     ],
  //   };
  // },
  getBusinessInfo() {
    return {
      status: 200,
      data: {
        // 行业类型
        industryTypeParent: 'A',
        industryType: '',
        // 注册类型
        registrationType: '140',
        registrationTypeChild: '143',
        // 法人代表
        representative: '123',
        // 注册资金
        registeredCapital: 3434,
        // 注册资金单位
        registeredCapitalUnit: 0,
        // 成立日期
        establishmentDate: '2020-04-22',
        // 登记机关
        registrationAuthority: 'asdkasd',
        // 注册地址
        registrationAddress: 'asdasd',
        // 经营范围
        businessScope: '1231223',
        // 社会统一信用码
        unifiedSocialCreditCode: 'ABCDESDASDA12123FG',
        // 企业信息
        businessAddress: '皇岗村',
        businessEmail: '337901912@qq.com',
        businessPhone: '17100000123',
        businessPostalCode: '164300',
        customerShareholderInfoList: [
          {
            capitalContributionsAmount: 123,
            capitalContributionsAmountUnit: 0,
            capitalContributionsDate: '2020-04-22',
            capitalContributionsType: '土地使用权',
            reallyInvestAmount: 456,
            reallyInvestAmountUnit: 0,
            reallyInvestDate: '2020-04-22',
            reallyInvestType: '知识产权',
            shareholder: '测试股东账号',
          },
        ],
      },
    };
  },
};
