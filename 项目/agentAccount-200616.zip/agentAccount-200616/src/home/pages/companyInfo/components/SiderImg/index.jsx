import React from 'react';
import './style.less';

const SiderImg = () => {
  return <div styleName="m-siderImg" />;
};

export default SiderImg;
