import React, { useState, useEffect, useCallback } from 'react';
// import { useSelector, useDispatch } from 'react-redux';
import { connect } from 'nuomi';
import { Form, Input, Select, Popover, Tag } from 'antd';
import _ from 'lodash';
import { AreaCascader, GenFormItem } from '@components';
import Mark from '../Mark';
import './style.less';

import UploadImg from '../UploadImg';
import ShowImg from '../ShowImg';

const { Option } = Select;
const { Item: FormItem } = Form;

const companyTypeList = [
  {
    title: '企业',
    value: 1,
  },
  {
    title: '个人',
    value: 2,
  },
];

const formItemLayout = {
  labelCol: {
    sm: { span: 4 },
  },
  wrapperCol: {
    sm: { span: 16 },
  },
};
const formItemConfig = {
  autoComplete: 'off',
  allowClear: true,
  style: { width: 460 },
};

const MainForm = ({
  dispatch,
  form,
  formValues,
  certificationStatus,
  editStatus,
  rejectReason,
}) => {
  const { getFieldDecorator, validateFields, getFieldValue } = form;
  const {
    companyName,
    companyType,
    unifiedSocialCreditCode,
    idNumber,
    companyPrincipal,
    unitNumber,
    managePhoneNumber,
    areaCode,
    areaName,
    createTime,
    businessPlace,
    businessScope,
    companyLicenseUrl,
    companyLicenseName,
  } = formValues;

  const [isEnterpriseInfoEdit, setIsEnterpriseInfoEdit] = useState(false);
  const [isOtherInfoEdit, setIsOtherInfoEdit] = useState(false);

  const companynameValidator = (rule, value, callback) => {
    if (!value) {
      callback();
      return;
    }

    const trimedValue = value.trim();
    if (!trimedValue) {
      callback('不能为空');
    } else if (trimedValue.length < 2) {
      callback('最少允许输入2个字');
    } else if (trimedValue.length > 40) {
      callback('最多允许输入40个字');
    } else {
      callback();
    }
  };

  const companyPrincipalValidator = (rule, value, callback) => {
    if (!value) {
      callback();
      return;
    }

    const trimedValue = value.trim();
    if (!trimedValue) {
      callback('不能为空');
    } else if (trimedValue.length < 2) {
      callback('最少允许输入2个字');
    } else if (trimedValue.length > 10) {
      callback('最多允许输入10个字');
    } else {
      callback();
    }
  };

  const texnumValidator = (rule, value, callback) => {
    // 必须总是返回一个 callback，否则 validateFields 无法响应
    if (!value || [15, 18].includes(value.length)) {
      callback();
    } else {
      callback('只允许输入15或18字');
    }
  };

  const changeCompanyType = () => {
    // 更改企业类型后，验证规则变了，要手动更新下验证信息
    setTimeout(() => {
      validateFields();
    }, 0);
  };

  // 是否是企业（要用函数去取，这样才能拿到form里最新的值）
  const isEnterprise = () => (form.getFieldValue('companyType') || companyType) === 1;

  const areaValidator = async (rule, value, callback) => {
    if (!value) {
      callback();
      return;
    }
    const code = _.get(value, 'areaCode');
    if (!code) {
      callback();
    }
  };

  useEffect(() => {
    setIsEnterpriseInfoEdit(editStatus === 2);
    setIsOtherInfoEdit(editStatus !== 0);
  }, [editStatus]);

  useEffect(() => {
    dispatch({
      type: 'updateState',
      payload: {
        formRef: form,
      },
    });
  }, [dispatch, form]);

  return (
    <Form {...formItemLayout} styleName="m-companyForm">
      <div styleName="m-title">
        <span styleName="m-titleName">企业信息</span>
        <Mark form={form} />
      </div>
      <div styleName={`m-enterpriseInfo ${isEnterpriseInfoEdit ? 'm-companyEdit' : ''}`}>
        <GenFormItem
          form={form}
          label="企业名称"
          name="companyName"
          initialValue={companyName || ''}
          rules={[
            {
              required: true,
              message: '请输入企业名称',
            },
            {
              validator: companynameValidator,
            },
          ]}
        >
          {isEnterpriseInfoEdit ? (
            <Input placeholder="2~40个字" {...formItemConfig} />
          ) : (
            <div styleName="formItem-value-text">{companyName}</div>
          )}
        </GenFormItem>
        <GenFormItem
          form={form}
          label="企业类型"
          name="companyType"
          initialValue={_.isNil(companyType) ? undefined : companyType}
          rules={[
            {
              required: true,
              message: '请选择企业类型',
            },
          ]}
        >
          {isEnterpriseInfoEdit ? (
            <Select
              placeholder="请选择企业类型"
              {...formItemConfig}
              allowClear={false}
              disabled={isEnterprise() && [0, 1].includes(certificationStatus)}
              onChange={changeCompanyType}
            >
              {companyTypeList.map((item) => (
                <Option key={item.value} value={item.value} title={item.title}>
                  {item.title}
                </Option>
              ))}
            </Select>
          ) : (
            <div styleName="formItem-value-text">
              {(companyTypeList.find((item) => item.value === companyType) || {}).title}
            </div>
          )}
        </GenFormItem>
        {isEnterprise() && (
          <FormItem label="统一社会信用代码">
            {getFieldDecorator('unifiedSocialCreditCode', {
              initialValue: unifiedSocialCreditCode || '',
              rules: [
                {
                  required: isEnterprise() && [0, 1].includes(certificationStatus),
                  message: '请输入统一社会信用代码',
                },
                {
                  pattern: /^[A-Za-z0-9]+$/,
                  message: '只允许输入数字或字母',
                },
                { min: 15, message: '最少允许输入15个字' },
                { max: 20, message: '最多允许输入20个字' },
              ],
            })(
              isEnterpriseInfoEdit ? (
                <Input
                  placeholder={isEnterprise() ? '15~20个字' : '15或18个字'}
                  {...formItemConfig}
                />
              ) : (
                <p styleName="formItem-value-text">{unifiedSocialCreditCode}</p>
              ),
            )}
          </FormItem>
        )}

        {!isEnterprise() && (
          <FormItem label="身份证">
            {getFieldDecorator('idNumber', {
              initialValue: idNumber || '',
              rules: [
                {
                  required: isEnterprise() && [0, 1].includes(certificationStatus),
                  message: '请输入身份证',
                },
                {
                  pattern: /^[A-Za-z0-9]+$/,
                  message: '只允许输入数字或字母',
                },
                {
                  validator: texnumValidator,
                },
              ],
            })(
              isEnterpriseInfoEdit ? (
                <Input placeholder="15或18个字" {...formItemConfig} />
              ) : (
                <p styleName="formItem-value-text">{idNumber}</p>
              ),
            )}
          </FormItem>
        )}

        <FormItem label={isEnterprise() ? '法定代表人' : '负责人'}>
          {getFieldDecorator('companyPrincipal', {
            initialValue: companyPrincipal || '',
            rules: [
              {
                required: isEnterprise() && [0, 1].includes(certificationStatus),
                message: `请输入${isEnterprise() ? '法定代表人' : '负责人'}`,
              },
              {
                validator: companyPrincipalValidator,
              },
            ],
          })(
            isEnterpriseInfoEdit ? (
              <Input placeholder="2~10个字" {...formItemConfig} />
            ) : (
              <p styleName="formItem-value-text">{companyPrincipal || '-'}</p>
            ),
          )}
        </FormItem>
        {isEnterprise() && (
          <FormItem label="营业执照" className="companyInfo-formItem-companyLicenseUrl">
            {getFieldDecorator('companyLicense', {
              initialValue: { companyLicenseUrl, companyLicenseName },
              rules: [
                {
                  required: [0, 1].includes(certificationStatus),
                  message: '请上传营业执照',
                },
              ],
            })(
              isEnterpriseInfoEdit ? (
                <UploadImg />
              ) : (
                <ShowImg alt="营业执照" src={companyLicenseUrl} fileName={companyLicenseName} />
              ),
            )}
          </FormItem>
        )}
      </div>
      <div styleName="m-title">其他信息</div>
      <div styleName={`${isEnterpriseInfoEdit ? 'm-companyEdit' : ''}`}>
        <FormItem label="单位序列号" styleName="formItem-text">
          {getFieldDecorator('unitNumber', {
            initialValue: unitNumber || '',
          })(
            <>
              <Input type="hidden" />
              <p styleName="formItem-value-text">{unitNumber || '-'}</p>
            </>,
          )}
        </FormItem>
        <FormItem label="管理员手机号" styleName="formItem-text">
          {getFieldDecorator('managePhoneNumber', {
            initialValue: managePhoneNumber || '',
          })(
            <>
              <Input type="hidden" />
              <p styleName="formItem-value-text">{managePhoneNumber || '-'}</p>
            </>,
          )}
        </FormItem>
        <FormItem label="所在地">
          {getFieldDecorator('area', {
            initialValue: { areaCode, areaName },
            rules: [
              {
                validator: areaValidator,
              },
            ],
          })(
            isOtherInfoEdit ? (
              <AreaCascader
                placeholder="请选择完整的所在地"
                {...formItemConfig}
                getPopupContainer={(triggerNode) => triggerNode.parentNode}
              />
            ) : (
              <p styleName="formItem-value-text">{areaName || '-'}</p>
            ),
          )}
        </FormItem>
        <FormItem label="注册日期" styleName="formItem-text">
          {getFieldDecorator('createTime', {
            initialValue: createTime || '',
          })(
            <>
              <Input type="hidden" />
              <p styleName="formItem-value-text">{createTime || '-'}</p>
            </>,
          )}
        </FormItem>
        <FormItem label="经营场所">
          {getFieldDecorator('businessPlace', {
            initialValue: businessPlace || '',
            rules: [{ max: 100, message: '最多允许输入100个字' }],
          })(
            isOtherInfoEdit ? (
              <Input placeholder="100字以内" {...formItemConfig} />
            ) : (
              <p styleName="formItem-value-text">{businessPlace || '-'}</p>
            ),
          )}
        </FormItem>
        <FormItem label="经营范围">
          {getFieldDecorator('businessScope', {
            initialValue: businessScope || '',
            rules: [{ max: 300, message: '最多允许输入300个字' }],
          })(
            isOtherInfoEdit ? (
              <Input placeholder="300字以内" {...formItemConfig} />
            ) : (
              <p styleName="formItem-value-text">{businessScope || '-'}</p>
            ),
          )}
        </FormItem>
      </div>
    </Form>
  );
};

export default connect(({ formValues, certificationStatus, editStatus, rejectReason }) => ({
  formValues,
  certificationStatus,
  editStatus,
  rejectReason,
}))(Form.create()(MainForm));
