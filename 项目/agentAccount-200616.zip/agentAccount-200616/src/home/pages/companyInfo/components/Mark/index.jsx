// 标记 已认证/
import React from 'react';
import { Tag, Popover } from 'antd';
import { connect } from 'nuomi';
import { LinkButton } from '@components';
import './style.less';

const Mark = ({
  dispatch,
  form,
  editStatus,
  certificationOptions,
  certificationStatus,
  rejectReason,
  formValues,
}) => {
  const { companyType } = formValues;
  // 是否是企业（要用函数去取，这样才能拿到form里最新的值）
  const isEnterprise = () => (form.getFieldValue('companyType') || companyType) === 1;

  // 确定编辑企业信息
  const handleConfirmEdit = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 2,
      },
    });
  };
  return (
    isEnterprise() && (
      <>
        {editStatus === 1 && certificationStatus === 0 && (
          <div styleName="m-tagWarn">
            您的企业信息认证中，如有
            <LinkButton onClick={handleConfirmEdit}>修改</LinkButton>
            ，将覆盖原认证中的信息
          </div>
        )}

        {editStatus === 1 && certificationStatus === 1 && (
          <div styleName="m-tagWarn">
            您的企业信息已认证，如需
            <LinkButton onClick={handleConfirmEdit}>变更企业信息</LinkButton>
            ，将重新发起认证
          </div>
        )}

        {(editStatus === 0 || [-1, 2].includes(certificationStatus)) && (
          <>
            <Tag
              color={
                certificationOptions[certificationStatus] &&
                certificationOptions[certificationStatus].color
              }
              styleName="m-tag"
            >
              {certificationOptions[certificationStatus] &&
                certificationOptions[certificationStatus].text}
            </Tag>
            {certificationStatus === 2 && rejectReason && (
              <Popover
                arrowPointAtCenter
                title="失败原因"
                placement="bottomLeft"
                content={rejectReason}
              >
                <i className="iconfont" styleName="m-errorReason">
                  &#xeb10;
                </i>
              </Popover>
            )}
          </>
        )}
      </>
    )
  );
};
export default connect(
  ({ editStatus, certificationOptions, certificationStatus, rejectReason, formValues }) => ({
    editStatus,
    certificationOptions,
    certificationStatus,
    rejectReason,
    formValues,
  }),
)(Mark);
