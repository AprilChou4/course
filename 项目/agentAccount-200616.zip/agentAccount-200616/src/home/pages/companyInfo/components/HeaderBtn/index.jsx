import React from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import pubData from 'data';

const HeaderBtn = ({ dispatch, formRef, editStatus, certificationStatus }) => {
  const handleEdit = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: [-1, 2].includes(certificationStatus) ? 2 : 1,
      },
    });
  };

  const handleCancel = () => {
    dispatch({
      type: 'updateState',
      payload: {
        editStatus: 0,
      },
    });
    formRef.resetFields(); // 重置
  };

  const handleSubmit = () => {
    formRef.validateFields((error) => {
      if (error) return;

      dispatch({
        type: 'updateCompanyInfo',
      });
    });
  };
  const { roleName } = pubData.get('userInfo');
  return (
    <div className="f-tar e-mb20">
      {roleName.includes('管理员') &&
        (editStatus === 0 ? (
          <Button type="primary" onClick={handleEdit}>
            {certificationStatus === -1 ? '完善信息' : '修改信息'}
          </Button>
        ) : (
          <>
            <Button onClick={handleCancel} className="e-mr12">
              取消
            </Button>
            <Button type="primary" onClick={handleSubmit}>
              保存
            </Button>
          </>
        ))}
    </div>
  );
};

export default connect(({ formRef, editStatus, certificationStatus }) => ({
  formRef,
  editStatus,
  certificationStatus,
}))(HeaderBtn);
