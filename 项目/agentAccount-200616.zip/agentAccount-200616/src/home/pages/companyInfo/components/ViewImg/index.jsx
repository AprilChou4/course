// 营业执照预览
import React, { forwardRef, useState, useEffect } from 'react';
import { Modal } from 'antd';
import classnames from 'classnames';
import { Carousel } from '@components';
import './style.less';

const ViewImg = ({ className, src, fileName, visible, onVisibleChange, ...rest }, ref) => {
  const handleCancel = () => {
    onVisibleChange(false);
  };

  return (
    <div className={classnames('components-viewImg', className)}>
      <Modal
        title="营业执照"
        footer={null}
        width={800}
        height={500}
        centered
        visible={visible}
        destroyOnClose
        onCancel={handleCancel}
        className="components-viewImg-modal"
        wrapClassName="components-viewImg attach-viewimg-modal"
      >
        <div className="m-imgWrap">
          {/* <h3>营业执照</h3> */}
          <div className="m-changeImg">
            <Carousel
              imageUrl={src}
              // fileList={fileListImg}
              getContent={({ zoom, rotate, curScale }) => (
                <div className="m-funcBtn">
                  <i className="iconfont" onClick={() => zoom()}>
                    &#xea33;
                  </i>
                  <span>{curScale}%</span>
                  <i className="iconfont" onClick={() => zoom(true)}>
                    &#xea35;
                  </i>
                  <i className="iconfont" title="旋转" onClick={() => rotate()}>
                    &#xea36;
                  </i>
                  <a
                    href={`${serviceUrl}instead/CustomerArchive/downloadAttachment.do?urlString=${src}&fileName=${fileName}`}
                    className="iconfont"
                    title="下载"
                  >
                    &#xea34;
                  </a>
                </div>
              )}
            />
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default forwardRef(ViewImg);
