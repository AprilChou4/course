import { createServices } from '@utils';

export default createServices({
  getCompanyInfo: 'http://192.168.206.92:3000/mock/516/instead/v2/user/company/get::post',
  updateCompanyInfo: 'http://192.168.206.92:3000/mock/516/instead/v2/user/company/update::post',
  checkArea: '/clouduser/isLeafAreaCode.do',
});
