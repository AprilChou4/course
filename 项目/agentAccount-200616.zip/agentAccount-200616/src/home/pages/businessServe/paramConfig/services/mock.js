export default {
  getMenuList() {
    return {
      status: 200,
      data: [
        {
          className: '工商服务',
          serviceClassId: 1,
          serviceTypeVOList: [
            {
              isCycle: true,
              productCode: 123,
              serviceName: '工商注册',
              serviceTypeId: 1,
            },
            {
              isCycle: false,
              productCode: 1234,
              serviceName: '工商变更',
              serviceTypeId: 2,
            },
            {
              isCycle: false,
              productCode: 12344,
              serviceName: '工商注销',
              serviceTypeId: 5,
            },
          ],
        },
        {
          className: '财税服务',
          serviceClassId: 2,
          serviceTypeVOList: [
            {
              isCycle: true,
              productCode: 234,
              serviceName: '财税服务-小类',
              serviceTypeId: 61,
            },
          ],
        },
        {
          className: '其他服务',
          serviceClassId: 3,
          serviceTypeVOList: [
            {
              isCycle: true,
              productCode: 1234354,
              serviceName: '其他服务-小类',
              serviceTypeId: 88,
            },
          ],
        },
      ],
    };
  },
  getServiceList() {
    return {
      status: 200,
      data: [
        {
          isCycle: true,
          productCode: 123,
          serviceName: '工商注册',
          serviceTypeId: 1,
        },
        {
          isCycle: false,
          productCode: 1234,
          serviceName: '工商变更',
          serviceTypeId: 2,
        },
        {
          isCycle: false,
          productCode: 12344,
          serviceName: '工商注销',
          serviceTypeId: 5,
        },
        {
          isCycle: true,
          productCode: 234,
          serviceName: '财税服务-小类',
          serviceTypeId: 61,
        },
        {
          isCycle: true,
          productCode: 1234354,
          serviceName: '其他服务-小类',
          serviceTypeId: 88,
        },
      ],
    };
  },
  getProductList() {
    return {
      status: 200,
      data: [
        {
          isCycle: true,
          processSet: true,
          productCode: 1001,
          serviceName: '工商服务',
          serviceProductName: '有限责任公司注册',
          serviceProductId: 123,
          serviceTypeId: 12,
        },
        {
          isCycle: true,
          processSet: true,
          productCode: 1001,
          serviceName: '工商服务1',
          serviceProductName: '有限责任公司注册43',
          serviceProductId: 234,
          serviceTypeId: 12,
        },
        {
          isCycle: true,
          processSet: true,
          productCode: 1001,
          serviceName: '工商服务2',
          serviceProductName: '有限责任公司注册3',
          serviceProductId: 567,
          serviceTypeId: 12,
        },
      ],
    };
  },
  addServiceType() {
    return {
      status: 200,
      data: null,
    };
  },
  addServiceProduct() {
    return {
      status: 200,
      data: null,
    };
  },
  removeProduct() {
    return {
      status: 200,
      data: null,
    };
  },
  validateProductUsed() {
    return {
      status: 200,
      data: false,
    };
  },
  updateServiceProduct() {
    return {
      status: 200,
      data: null,
    };
  },
  checkSameName() {
    return {
      status: 200,
      data: false,
    };
  },
  checkSameProduct() {
    return {
      status: 200,
      data: false,
    };
  },
  getProductCode() {
    return {
      status: 200,
      data: 123,
    };
  },
};
