import { createServices } from '@utils';
import mock from './mock';

export default createServices({
  getCompanySetting: 'instead/v2/user/basicSetting/company/get.do::post', // 获取公司基础设置
  updateTaskFileUpload: 'instead/v2/user/basicSetting/company/updateTaskFileUpload.do::post', // 是否必须上传附件
  updateTaskRule: 'instead/v2/user/basicSetting/company/updateTaskRule.do::post', // 任务是否严格执行
  // ...mock,
});
