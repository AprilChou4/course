import services from '../services';

export default {
  // 获取公司基础设置
  async $getCompanySetting(payload) {
    const data = await services.getCompanySetting(payload);
    this.updateState({
      companySetData: data,
    });
  },
  // 是否必须上传附件
  async $updateTaskFileUpload(payload) {
    await services.updateTaskFileUpload(payload);
    this.$getCompanySetting();
  },

  // 任务是否严格执行
  async $updateTaskRule(payload) {
    await services.updateTaskRule(payload);
    this.$getCompanySetting();
  },
  $initData() {
    this.$getCompanySetting();
  },
};
