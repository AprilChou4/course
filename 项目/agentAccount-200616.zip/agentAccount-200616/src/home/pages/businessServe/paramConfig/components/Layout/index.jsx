import React from 'react';
import { Checkbox, Row, Col } from 'antd';
import { connect } from 'nuomi';
import pubData from 'data';
import Style from './style.less';

const userAuth = pubData.get('authority');
const Layout = ({ dispatch, companySetData }) => {
  const { taskRule, taskFileUpload } = companySetData;
  const list = [
    {
      title: '任务执行设置',
      desc: '勾选严格按流程执行，在工商任务执行过程中必须严格按步骤先后顺序执行',
      option: '严格按流程执行',
      checked: !!taskRule,
      onChange: (e) => {
        dispatch({
          type: '$updateTaskRule',
          payload: {
            taskRule: e.target.checked,
          },
        });
      },
    },
    {
      title: '上传附件设置',
      desc: '勾选必须上传附件，在步骤完成时，必须上传附件，未上传附件不支持标记步骤完成',
      option: '必须上传附件',
      checked: !!taskFileUpload,
      onChange: (e) => {
        dispatch({
          type: '$updateTaskFileUpload',
          payload: {
            taskFileUpload: e.target.checked,
          },
        });
      },
    },
  ];
  console.log(userAuth[610], !!userAuth[610], '-----!!userAuth[610]');
  return (
    <div className={Style['m-paramConfg']}>
      {list.map(({ title, desc, option, checked, onChange }, index) => (
        <Row key={index}>
          <Col span={4} className={Style['m-title']}>
            {title}
          </Col>
          <Col span={18} className={Style['m-cont']}>
            {' '}
            <p>{desc}</p>
            <Checkbox
              checked={checked}
              disabled={!userAuth[610]}
              {...(onChange ? { onChange } : {})}
            >
              {option}
            </Checkbox>
          </Col>
        </Row>
      ))}
    </div>
  );
};

export default connect(({ companySetData }) => ({
  companySetData,
}))(Layout);
