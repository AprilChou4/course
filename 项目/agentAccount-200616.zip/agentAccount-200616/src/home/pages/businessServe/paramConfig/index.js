import React from 'react';
import { NoAuthPage } from '@components';
import pubData from 'data';
import Layout from './components/Layout';
import effects from './effects';

const userAuth = pubData.get('authority');
export default {
  state: {
    // 公司设置数据
    companySetData: {
      // createTaskType	integer	 任务生成方式（1自定生产，2合同生产，3应收单生成，4合同和应收单）
      // declareWay	integer	 申报通道方式（0税务筹划平台；1国票）
      // taskFileUpload	boolean	 任务是否必须上传附件
      // taskRule	boolean	 任务是否严格执行
    },
  },
  effects,
  render() {
    return userAuth[609] ? <Layout /> : <NoAuthPage />;
  },
  onChange: {
    query() {
      if (userAuth[609]) {
        this.store.dispatch({
          type: '$initData',
        });
      }
    },
  },
  // onInit() {
  //   this.store.dispatch({
  //     type: '$initData',
  //   });
  // },
};
