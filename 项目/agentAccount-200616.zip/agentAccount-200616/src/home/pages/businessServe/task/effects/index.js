import { router } from 'nuomi';
import { message } from 'antd';
import globalServices from '@home/services';
import { STATUS_ENUM, initialForm, getProcessList, genStepValues } from '../utils';
import services from '../services';

export default {
  // 查看任务单
  async $getDetail(taskId) {
    const data = await services.getDetail(
      { taskId },
      {
        loading: '正在获取详情...',
      },
    );
    this.updateState({
      dataSource: data.taskStepVOList || [],
      formValues: {
        ...data,
        area: {
          areaCode: data.areaCode,
          areaName: data.areaName,
        },
      },
    });
    const { status } = this.getState();
    // 如果存在部门id，请求对应的执行人列表
    if (data.executorDeptId) {
      this.$getStaffList(data.executorDeptId);
    }
    // 更新时，任务流程要展示表格，
    if (status === STATUS_ENUM.UPDATE) {
      this.updateState({
        dataSource: data.taskStepVOList || [],
      });
    } else if (status === STATUS_ENUM.CREATED) {
      // 新增页面保存时，显示的还是StepForm
      this.updateState({
        stepValues: genStepValues(data.taskStepVOList, data.assign),
      });
    }
    const { allProcessList } = this.getState();
    if (allProcessList.length) {
      this.$changeProcessList(data.areaCode, data.serviceProductId);
    }
  },

  // 更新任务单
  async $update({ params }) {
    const { formValues, status } = this.getState();
    await services.update(
      { ...params, taskId: formValues.taskId },
      {
        loading: '正在提交...',
      },
    );
    message.success('保存成功');
    this.$initForm();
    await this.$getDetail(formValues.taskId);
    const isViewPage = status === STATUS_ENUM.UPDATE;
    this.updateState({
      status: isViewPage ? STATUS_ENUM.RETRIEVE : STATUS_ENUM.CREATED,
      isEdited: false,
    });
  },

  // 新增任务单
  async $add({ params, isContinue }) {
    const taskId = await services.add(params, {
      loading: '正在提交...',
    });
    // const { formValues } = this.getState();
    message.success('新增成功');
    if (isContinue) {
      this.$continueAdd();
    } else {
      const data = await services.getDetail(
        { taskId },
        {
          loading: '正在获取详情...',
        },
      );
      // console.log(data);
      this.updateState({
        status: STATUS_ENUM.CREATED,
        isEdited: false,
        formValues: {
          ...data,
          area: {
            areaCode: data.areaCode,
            areaName: data.areaName,
          },
        },
        stepValues: genStepValues(data.taskStepVOList, data.assign),
      });
      const { form, stepForm } = this.getState();
      form.resetFields && form.resetFields();
      stepForm.resetFields && stepForm.resetFields();
    }
  },

  async $continueAdd() {
    this.$initForm();
    this.updateState({
      status: STATUS_ENUM.CREATE,
    });
    // 新增任务单，需要获取新的编号
    await this.$getTaskNumber();
    // 获取企业默认所在地
    await this.$getCompanyArea();
  },

  // 新增改变状态
  $initForm() {
    this.updateState({
      stepValues: [],
      formValues: initialForm,
      hasOperator: false,
      isEdited: false,
    });
    setTimeout(() => {
      const { form, stepForm } = this.getState();
      form.resetFields && form.resetFields();
      stepForm.resetFields && stepForm.resetFields();
    });
  },

  // 编辑任务单
  $editTask() {
    const { dataSource, formValues } = this.getState();
    this.updateState({
      status: STATUS_ENUM.UPDATE,
      stepValues: genStepValues(dataSource, formValues.assign),
    });
  },

  // 获取服务流程详情
  async $getProcessDetail({ serviceProcessId, staffId }) {
    const data = await services.getProcessDetail({ serviceProcessId });
    // 如果存在预计耗时，需要推算出完成时间 在第2步请求结束做
    const { expectedCompletionDays } = data;
    const { form } = this.getState();
    // 大于一年不自动带出
    if (expectedCompletionDays && expectedCompletionDays < 366) {
      // 签约时间appointmentTime
      const appointmentTime = form.getFieldValue('appointmentTime');
      // console.log(appointmentTime, expectedCompletionDays);
      const completeTime = appointmentTime.add(expectedCompletionDays, 'days');
      form.setFieldsValue({
        completeTime,
      });
    } else {
      form.setFieldsValue({
        completeTime: undefined,
      });
    }
    const { formValues, stepForm } = this.getState();
    stepForm.resetFields && stepForm.resetFields();
    this.updateState({
      stepValues: genStepValues(data.serviceProcessStepVOList, formValues.assign, staffId),
      hasOperator: false,
    });
  },

  // 获取任务单据编号
  async $getTaskNumber() {
    const code = await services.getTaskNumber();
    const { formValues } = this.getState();
    this.updateState({
      formValues: {
        ...formValues,
        taskNumber: code,
      },
    });
  },

  async $getCompanyArea() {
    const area = await services.getCompanyArea();
    const { formValues } = this.getState();
    this.updateState({
      formValues: {
        ...formValues,
        area,
      },
    });
    const { allProcessList } = this.getState();
    if (allProcessList.length) {
      this.$changeProcessList(area.areaCode, formValues.serviceProductId);
    }
    // console.log('这里处理一下');
  },

  $changeProcessList(areaCode, serviceProductId) {
    const { allProcessList, spareProcessList, productMap, areaCodeMap } = this.getState();
    const processList = getProcessList(
      areaCode,
      serviceProductId,
      allProcessList,
      spareProcessList,
      productMap,
      areaCodeMap,
    );
    this.updateState({
      processList,
    });
  },

  async $getDeptListByStaffId(staffId) {
    const data = await globalServices.getDeptListByStaffId({ staffId });
    const { form } = this.getState();
    if (data && data.length) {
      form.setFieldsValue({
        executorDeptId: data[0].deptId,
      });
    }
  },

  // 初始化
  async $initData() {
    const { id } = router.location().query || {};
    this.$initForm();
    if (id) {
      // 代表是查看收款单
      await this.$getDetail(id);
      this.updateState({
        status: STATUS_ENUM.RETRIEVE,
      });
    } else {
      this.$initForm();
      // 代表是新增任务单，需要获取新的编号
      await this.$getTaskNumber();
      // 获取企业默认所在地
      await this.$getCompanyArea();
    }
  },

  // 初始化各种列表
  async $initList() {
    // 获取业务员列表
    this.$getStaffList();
    // 获取业务员列表树结构
    this.$getOperatorList();
    // 获取客户列表
    this.$getCustomerList();
    // 获取服务产品列表
    this.$getProductList();
  },

  // 根据部门获取业务员
  async $getStaffList(deptId) {
    const data = await globalServices.getStaffList({ deptId });
    this.updateState({
      staffList: data || [],
    });
  },

  // 获取所有业务员树结构
  async $getOperatorList() {
    const data = await services.getOperatorList();
    // const helper = (list) => {
    //   return list.map((item) => {
    //     if (item.isParent) {
    //       return {
    //         title: item.name,
    //         value: item.value,
    //         key: item.value,
    //         code: item.code,
    //         selectable: false,
    //         disabled: !item.children.length,
    //         children: helper(item.children),
    //       };
    //     }
    //     return {
    //       title: item.name,
    //       value: item.value,
    //       key: item.value,
    //       code: item.code,
    //       selectable: true,
    //     };
    //   });
    // };
    this.updateState({
      // operatorList: helper(data),
      operatorList: data,
    });
  },

  // 获取客户列表
  async $getCustomerList() {
    const data = await services.getCustomerList({ isShouldReceiveBill: 0 });
    this.updateState({
      customerList: data || [],
    });
  },

  // 获取服务产品列表
  async $getProductList() {
    const data = await services.getProductList();
    const businessList = (data || []).filter((it) => it.serviceClassId === 2);
    const productList = []; // 服务产品树结构  服务类型0-服务产品
    const productMap = {}; // 可以通过服务产品id找到对应流程列表
    const processMap = {}; // 可以通过流程id找到对应父级服务产品
    const areaCodeMap = {}; // 可以通过地区code找到所适合的服务流程

    const productItemMap = {}; // 通过服务产品id找到本身
    const processItemMap = {}; // 通过流程id找到本身本身

    const allProcessList = []; // 所有列表
    const spareProcessList = []; // 全国流程列表
    businessList.forEach((classType) => {
      classType.serviceTypeVOList.forEach((serviceType) => {
        productList.push(serviceType);
        serviceType.serviceProductVOList.forEach((product) => {
          productMap[product.serviceProductId] = product.serviceProcessBaseInfoVOList.map((it) => ({
            ...it,
            serviceProductName: product.serviceProductName,
          }));
          productItemMap[product.serviceProductId] = {
            ...product,
            splicingName: `${serviceType.serviceName}-${product.serviceProductName}`,
          };
          product.serviceProcessBaseInfoVOList.forEach((process) => {
            const processItem = { ...process, serviceProductName: product.serviceProductName };
            processItemMap[process.serviceProcessId] = processItem;
            allProcessList.push(processItem);
            if (process.areaCode === '100000') {
              spareProcessList.push(processItem);
            }
            processMap[process.serviceProcessId] = product;
            if (areaCodeMap[process.areaCode]) {
              areaCodeMap[process.areaCode].push(processItem);
            } else {
              areaCodeMap[process.areaCode] = [processItem];
            }
          });
        });
      });
    });
    this.updateState({
      processList: allProcessList,
      spareProcessList,
      allProcessList,
      productList,
      productMap,
      processMap,
      productItemMap,
      processItemMap,
      areaCodeMap,
    });
    const { formValues } = this.getState();
    if (formValues.area.areaCode) {
      // console.log('进不来');
      this.$changeProcessList(formValues.area.areaCode, formValues.serviceProductId);
    }
  },

  // 判断执行权限
  async taskCheckAuthority(payload) {
    const data = await globalServices.taskCheckAuthority(payload);
    return data;
  },
};
