import React, { useMemo } from 'react';
import { FormTable, SearchTreeSelect } from '@components';
import { connect } from 'nuomi';
import ToolTip from '../ToolTip';
import { STATUS_ENUM } from '../../utils';
import './style.less';

// 空白只做展示的表单组件
const Blank = React.forwardRef(({ falseyValue }, ref) => {
  return <span ref={ref}>{falseyValue}</span>;
});

const StepFrom = ({ form, stepForm, status, stepValues, operatorList, dispatch }) => {
  // 查看状态下、无权限、更新时不能修改的 需要禁用
  const isEditable = status !== STATUS_ENUM.RETRIEVE;

  // 经办人修改
  const handleOperatorChange = (value, rowIndex) => {
    const list = stepForm.getFieldsValue();
    list[rowIndex].operator = value;

    dispatch({
      type: 'updateState',
      payload: {
        isEdited: true, // 改变按钮状态
        hasOperator: list.some((it) => it.operator), // // 是否存在经办人
      },
    });
  };

  const [treeData, staffMap] = useMemo(() => {
    const map = {};
    const helper = (list) => {
      return list.map((item) => {
        if (item.isParent) {
          return {
            title: item.name,
            value: item.value,
            key: item.value,
            selectable: false,
            disabled: !item.children.length,
            children: helper(item.children),
          };
        }
        map[item.value] = item.name;
        // return true;
        return {
          title: item.name,
          key: item.value,
          value: item.value,
          selectable: true,
        };
      });
    };
    return [helper(operatorList), map];
  }, [operatorList]);

  const columns = [
    {
      title: '步骤',
      dataIndex: 'taskStepId',
      key: 'taskStepId',
      width: 80,
      align: 'center',
      render(text, record, index) {
        return <Blank falseyValue={index + 1} />;
      },
    },
    {
      title: '名称',
      dataIndex: 'stepName',
      key: 'stepName',
      align: 'center',
      render(text) {
        return <div style={{ textAlign: 'left' }}>{text}</div>;
      },
    },
    {
      title: '经办人',
      dataIndex: 'operator',
      key: 'operator',
      align: 'center',
      selectFallback: {
        nameMap: staffMap,
        fallbackName: 'operatorName',
      },
      render(text, record, index) {
        if (!record.stepStatus || record.stepStatus < 2) {
          return (
            <SearchTreeSelect
              placeholder="请选择经办人"
              style={{ width: '100%' }}
              disabled={!isEditable || record.noAssign}
              treeData={treeData}
              treeDefaultExpandAll
              dropdownStyle={{ maxHeight: 300 }}
              onChange={(v) => handleOperatorChange(v, index)}
            />
          );
        }
        return (
          <ToolTip content="步骤已完成">
            <div style={{ textAlign: 'left', paddingLeft: 11 }}>
              {staffMap[text] || record.operatorName}
            </div>
          </ToolTip>
        );
      },
    },
  ];

  let serviceProcessId = '';
  if (form.getFieldValue) {
    serviceProcessId = form.getFieldValue('serviceProcessId');
  }

  return (
    <FormTable
      rowKey="serviceProcessStepId"
      dataSource={stepValues}
      columns={columns}
      showOperateCol={false}
      getForm={(f) => {
        dispatch({
          type: 'updateState',
          payload: {
            stepForm: f,
          },
        });
      }}
      locale={{
        emptyText:
          !serviceProcessId || serviceProcessId === '-' ? '未选择使用流程' : '该服务流程未设置步骤',
      }}
      className="task-process-step-form"
    />
  );
};

export default connect(({ status, form, stepForm, stepValues, operatorList }) => ({
  status,
  form,
  stepForm,
  stepValues,
  operatorList,
}))(StepFrom);
