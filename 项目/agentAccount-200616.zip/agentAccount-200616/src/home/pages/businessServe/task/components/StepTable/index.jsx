import React from 'react';
import { AntdTable } from '@components';
import { connect } from 'nuomi';
import { util } from 'nuijs';
import moment from 'moment';

import './style.less';

const StepStatus = ({ status }) => {
  if (status === 0) {
    return (
      <>
        <i styleName="circle gray-circle" />
        未开始
      </>
    );
  }
  if (status === 1) {
    return (
      <>
        <i styleName="circle blue-circle" />
        进行中
      </>
    );
  }
  return (
    <>
      <i styleName="circle green-circle" />
      已完成
    </>
  );
};

const StepTable = ({ dataSource }) => {
  const downFile = ({ outputName, outputFilePath }) => {
    util.location(
      `${basePath}instead/v2/customer/enclosure/downloadFile.do?enclosurePath=${outputFilePath}&enclosureName=${outputName}`,
    );
  };

  const columns = [
    {
      title: '步骤',
      dataIndex: 'stepOrder',
      key: 'stepOrder',
      width: 80,
      align: 'center',
    },
    {
      title: '名称',
      dataIndex: 'stepName',
      key: 'stepName',
      align: 'center',
      render(text) {
        return <div style={{ textAlign: 'left' }}>{text}</div>;
      },
    },
    {
      title: '步骤',
      dataIndex: 'stepStatus',
      key: 'stepStatus',
      align: 'center',
      render(text) {
        return <StepStatus status={text} />;
      },
    },
    {
      title: '完成时间',
      dataIndex: 'completeTime',
      key: 'completeTime',
      align: 'center',
      render(text) {
        return text ? moment(text).format('YYYY-MM-DD') : '-';
      },
    },
    {
      title: '完成人',
      dataIndex: 'completeUser',
      key: 'completeUser',
      align: 'center',
    },
    {
      title: '完成说明',
      dataIndex: 'completeRemark',
      key: 'completeRemark',
      align: 'center',
      render(text) {
        return <div style={{ textAlign: 'left' }}>{text}</div>;
      },
    },
    {
      title: '附件',
      dataIndex: 'taskOutputVOList',
      key: 'taskOutputVOList',
      align: 'center',
      render(list) {
        return (
          <div style={{ textAlign: 'left' }}>
            {list.map((item) => (
              <span
                styleName="step-output-file"
                key={item.taskStepId}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => downFile(item)}
              >
                <i className="iconfont">&#xe64b;</i>
                {item.outputName}
              </span>
            ))}
          </div>
        );
      },
    },
  ];

  return (
    <AntdTable
      bordered
      dataSource={dataSource}
      rowKey="index"
      columns={columns}
      pagination={false}
    />
  );
};

export default connect(({ dataSource }) => ({ dataSource }))(StepTable);
