export default {
  getProductList() {
    return {
      status: 200,
      data: [
        {
          className: '工商服务',
          serviceClassId: '1',
          serviceTypeVOList: [
            {
              isCycle: true,
              isSystem: true,
              serviceClassId: '1',
              serviceName: '工商注册',
              serviceTypeId: '1-1-123123',
              serviceProductVOList: [
                {
                  isCycle: true,
                  processSet: true,
                  productCode: '001',
                  serviceName: '工商注册',
                  serviceProcessBaseInfoVOList: [
                    {
                      serviceProcessId: '1-1-1-1',
                      serviceProcessName: '全国（通用流程）',
                      serviceProductId: '1-1-1',
                      areaCode: '110100',
                      areaName: '北京-北京市',
                    },
                    {
                      serviceProcessId: '1-1-1-2',
                      serviceProcessName: '山东（通用流程)',
                      serviceProductId: '1-1-1',
                      areaCode: '220023',
                      areaName: '浙江-杭州市',
                    },
                  ],
                  serviceProductId: '1k23lkhads',
                  serviceProductName: '工商注册-产品',
                  serviceTypeId: '1-1',
                },
                {
                  isCycle: true,
                  processSet: true,
                  productCode: '001',
                  serviceName: '工商注册',
                  serviceProcessBaseInfoVOList: [
                    {
                      serviceProcessId: '1-1-2-1',
                      serviceProcessName: '全国（通用流程）',
                      serviceProductId: '1-1-2',
                      areaCode: '110100',
                      areaName: '北京-北京市',
                    },
                  ],
                  serviceProductId: 'kjhadl',
                  serviceProductName: '个体工商户注册',
                  serviceTypeId: '1-1',
                },
              ],
            },
          ],
        },
      ],
    };
  },
  getTaskNumber() {
    return {
      status: 200,
      data: 'rw20200212-001',
    };
  },
  getProcessDetail() {
    return {
      status: 200,
      data: {
        areaCode: '110100',
        areaName: '北京-北京市',
        processDescribe: '通用流程-123',
        serviceProcessId: '1-1-1-1',
        serviceProductId: '1-1-1',
        serviceProcessName: '全国（通用流程）',
        expectedCompletionDays: '5',
        serviceProcessStepVOList: [
          {
            serviceProcessId: '1-1-1-1',
            serviceProcessStepId: 'sc-1',
            expectedCompletionDays: 1,
            stepData: '步骤资料',
            stepDescribe: '步骤描述-111',
            stepName: '步骤名称-111',
            stepOrder: '1',
            stepOutput: '13',
          },
        ],
      },
    };
  },
  getCompanyArea() {
    return {
      status: 200,
      data: { areaCode: '110100', areaName: '北京-北京市' },
    };
  },
  add() {
    return {
      status: 200,
      data: null,
    };
  },
  update() {
    return {
      status: 200,
      data: null,
    };
  },
  getDetail() {
    return {
      status: 200,
      data: {
        taskNumber: 'rw20200212-001',
        sourceType: 1,
        sourceNumber: 'ht2912312301',
        emergencyLevel: 1,
        customerId: 'c32df59ff6e44789a24e666de9e842be',
        areaCode: '110100',
        areaName: '北京-北京市',
        serviceProductId: '1k23lkhads',
        serviceProcessId: '1-1-1-2',
        appointmentTime: 1583078400,
        completeTime: 1583816829,
        executorDeptId: '78df8f2c57674ba4b956838289db2403',
        executor_id: '3fa54aaca72542f495050579c46f284a',
        taskRemark: '这是一条任务说明',
        addTime: 1583078400,
        addUser: '李明',
        updateTime: 1583816829,
        updateUser: '赵四',
        // 派工权限
        assign: true,
        // 是否有编辑权限
        edit: true,
        // 是否可执行步骤
        execute: true,
        // 是否派工状态
        assignStatus: true,
        // 任务状态
        taskStatus: 0,
        taskStepVOList: [
          {
            completeTime: 1583816829,
            completeRemark: '完成说明',
            completeUser: '小花',
            operator: '3fa54aaca72542f495050579c46f284a',
            serviceProcessStepId: 1,
            stepData: 'ha,hei,hehe',
            stepDescribe: '步骤描述',
            stepName: '核名',
            stepOrder: 1,
            stepStatus: 2,
            taskOutputVOList: [
              {
                outputFilePath: 'http://baidu.com',
                outputName: '核名通知',
                taskStepId: 1,
              },
              {
                outputFilePath: 'http://baidu.com',
                outputName: '审核表',
                taskStepId: 2,
              },
            ],
          },
          {
            completeTime: 1583816829,
            completeRemark: '完成说明',
            completeUser: '小李',
            operator: '3fa54aaca72542f495050579c46f284a',
            serviceProcessStepId: 2,
            stepData: 'ha,hei,hehe',
            stepDescribe: '步骤描述',
            stepName: '审核通知书',
            stepOrder: 2,
            stepStatus: 1,
            taskOutputVOList: [
              {
                outputFilePath: 'http://baidu.com',
                outputName: '审核表',
                taskStepId: 2,
              },
            ],
          },
        ],
      },
    };
  },
};
