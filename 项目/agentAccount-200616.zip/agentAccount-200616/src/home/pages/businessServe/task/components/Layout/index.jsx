import React from 'react';
import { Layout, ContentWrapper } from '@components';
import { connect } from 'nuomi';
import Content from '../Content';
import Operate from '../Operate';
import Footer from '../Footer';

import './style.less';

const BusinessServe = ({ formValues }) => {
  // 左侧任务单状态JSX
  const Left = formValues.taskStatus === 2 ? <div styleName="task-symbol" /> : null;

  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title="任务单"
        header={{
          left: Left,
          right: <Operate />,
        }}
        content={<Content />}
        footer={<Footer />}
      />
    </Layout.PageWrapper>
  );
};

export default connect(({ formValues }) => ({
  formValues,
}))(BusinessServe);
