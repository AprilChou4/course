import React from 'react';
import { connect } from 'nuomi';
import { Button, message } from 'antd';
import pubData from 'data';
import { get, validateArrayLength, postMessageRouter } from '@utils';
import { Authority } from '@components';
import { STATUS_ENUM, formatSourceType } from '../../utils';

import './style.less';

// 需要校验客户名称、部门，执行人，没有匹配上需要转成id
const NEED_TO_TRUETH_ID = [
  ['customerId', 'customerName'],
  ['executorDeptId', 'executorDeptName'],
  ['executorId', 'executorName'],
  ['serviceProcessId', 'serviceProcessName'],
  ['serviceProductId', 'serviceProductName'],
];

// 需要将 - / 空值转成空字符
const NEED_TO_NULL = [
  'serviceProcessId',
  'serviceProcessName',
  'executorDeptId',
  'executorDeptName',
  'executorId',
  'executorName',
];

const Operate = ({
  form,
  formValues,
  stepValues,
  stepForm,
  status,
  productItemMap,
  processItemMap,
  isEdited,
  dispatch,
}) => {
  // 新增保存/编辑保存
  const handleSave = (isContinue) => {
    form.validateFields((e, baseValues) => {
      stepForm.validateFields((err, stepFormValues) => {
        if (e || err) return;
        const finalParams = {
          ...baseValues,
          sourceType: formatSourceType(baseValues.sourceType),
          sourceNumber: baseValues.sourceNumber === '-' ? '' : baseValues.ourceNumber,
          areaCode: get(baseValues, ['area', 'areaCode']),
          areaName: get(baseValues, ['area', 'areaName']),
          // serviceProcessId:
          //   baseValues.serviceProcessId === '-' ? undefined : baseValues.serviceProcessId,
          appointmentTime: baseValues.appointmentTime
            ? baseValues.appointmentTime.startOf('day').format('YYYY-MM-DD HH:mm:ss')
            : undefined,
          completeTime: baseValues.completeTime
            ? baseValues.completeTime.startOf('day').format('YYYY-MM-DD HH:mm:ss')
            : undefined,
          taskStepRequestList: stepFormValues.map((it, index) => ({
            ...it,
            // 和名字相等，说明员工没有匹配成功
            operator:
              stepValues[index].operatorName === it.operator
                ? stepValues[index].operator
                : it.operator,
            serviceProcessStepId: stepValues[index].serviceProcessStepId,
          })),
        };
        delete finalParams.area;

        // NEED_TO_SPLIT.forEach((item) => {
        //   const [id, name] = item;
        //   console.log(finalParams[id]);
        //   const combinValues = finalParams[id] || {};
        //   finalParams[id] = combinValues.key || combinValues.value; // 不知道为啥 treeSelect select 不一致。
        //   finalParams[name] = combinValues.label;
        // });

        NEED_TO_TRUETH_ID.forEach((keys) => {
          // 下拉框匹配不成功显示名字
          const [idKey, nameKey] = keys;
          if (finalParams[idKey] === formValues[nameKey]) {
            finalParams[idKey] = formValues[idKey];
          }
        });

        NEED_TO_NULL.forEach((key) => {
          if (finalParams[key] === '-' || !finalParams[key]) {
            finalParams[key] = '';
          }
        });

        // 设置服务内容、使用流程的名称
        finalParams.serviceProductName = get(
          productItemMap[finalParams.serviceProductId],
          'splicingName',
          '',
        );
        finalParams.serviceProcessName = get(
          processItemMap[finalParams.serviceProcessId],
          'serviceProcessName',
          '',
        );

        const type = status === STATUS_ENUM.UPDATE || formValues.taskId ? '$update' : '$add';
        dispatch({
          type,
          payload: {
            params: finalParams,
            isContinue, // 只给新增时候用
          },
        });
      });
    });
  };

  // 新增初始化
  const handleAdd = () => {
    dispatch({
      type: '$continueAdd',
    });
  };

  // 任务单编辑
  const handleEdit = () => {
    dispatch({
      type: '$editTask',
    });
  };

  const handleCancel = () => {
    form.resetFields();
    dispatch({
      type: 'updateState',
      payload: {
        stepValues: [],
        status: STATUS_ENUM.RETRIEVE,
      },
    });
  };

  // 派工
  const assign = () => {
    const { taskId } = formValues;
    dispatch({
      type: 'updateState',
      payload: {
        taskAssignVisible: true,
        // 待填写
        selectedRows: [{ taskId }],
        selectedRowKeys: [taskId],
        isSingleAssign: true,
      },
    });
  };

  // 执行
  const handleExecute = async () => {
    const { taskId } = formValues;

    // 过滤无权限和未派工的任务
    const data = await dispatch({
      type: 'taskCheckAuthority',
      payload: {
        execute: true,
        taskIdList: [taskId],
      },
    });
    if (!data) {
      return;
    }
    const { taskIdList, notAssign, notAuthority } = data || {};
    if (!validateArrayLength(taskIdList)) {
      if (notAssign && notAuthority) {
        message.warning('所选任务未派工或无权限，无法执行');
      } else if (notAssign) {
        message.warning('所选任务未派工，无法执行');
      } else {
        message.warning('您无权限执行该任务');
      }
      return;
    }

    // 由于新项目经过路由跳转时只能把参数附在url上，url长度有限制，所以有的查询参数就放到了pubData
    pubData.set('taskExecution-query', { taskIds: taskIdList });
    postMessageRouter({
      type: 'agentAccount/routerLocation',
      payload: {
        url: '/businessServe/taskExecution',
      },
    });
  };

  const renderBtns = () => {
    if (status === STATUS_ENUM.CREATE) {
      return (
        <>
          <Authority code="602">
            <Button type="primary" onClick={() => handleSave()}>
              保存
            </Button>
            <Button onClick={() => handleSave(true)}>保存并新增</Button>
          </Authority>
        </>
      );
    }
    if (status === STATUS_ENUM.CREATED) {
      return (
        <>
          <Authority code="603">
            <Button type="primary" onClick={() => handleSave(false)} disabled={!isEdited}>
              保存
            </Button>
          </Authority>
          <Authority code="604">
            <Button type="primary" onClick={assign}>
              派工
            </Button>
          </Authority>
          <Authority code="602">
            <Button onClick={handleAdd}>新增</Button>
          </Authority>
        </>
      );
    }
    if (status === STATUS_ENUM.RETRIEVE) {
      return (
        <>
          {formValues.edit && formValues.taskStatus < 2 && (
            <Authority code="603">
              <Button type="primary" onClick={handleEdit}>
                编辑
              </Button>
            </Authority>
          )}
          {formValues.execute && (
            <Authority code="605">
              <Button onClick={handleExecute}>执行</Button>
            </Authority>
          )}
        </>
      );
    }
    return (
      <>
        <Authority code="603">
          <Button onClick={handleCancel}>取消</Button>
          <Button type="primary" onClick={() => handleSave()}>
            保存
          </Button>
        </Authority>
      </>
    );
  };

  return <div styleName="business-stack-operate">{renderBtns()}</div>;
};

export default connect(
  ({
    form,
    stepForm,
    formValues,
    productItemMap,
    processItemMap,
    isEdited,
    status,
    stepValues,
  }) => ({
    form,
    stepForm,
    formValues,
    productItemMap,
    processItemMap,
    status,
    isEdited,
    stepValues,
  }),
)(Operate);
