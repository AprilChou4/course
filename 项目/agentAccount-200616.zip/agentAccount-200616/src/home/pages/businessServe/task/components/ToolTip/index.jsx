import React, { useState, forwardRef, useRef, useEffect } from 'react';
import { useMouse, useWindowSize } from 'react-use';
import useComponentSize from '@rehooks/component-size';

const ToolTip = forwardRef(({ children, content }, ref) => {
  const wrapperRef = useRef(null);
  const popoverRef = useRef(null);

  const popoverSize = useComponentSize(popoverRef);
  const { posX, posY, elX, elY, elW, elH } = useMouse(wrapperRef);
  const { width, height } = useWindowSize();

  const [show, setShow] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (elX > 0 && elY > 0 && elX < elW && elY < elH) {
      setShow(true);
      let x = elX + 10;
      let y = elY + 10;
      if (x + popoverSize.width + posX > width - 16) {
        x -= popoverSize.width;
      }
      if (y + popoverSize.height + posY > height - 16) {
        y -= popoverSize.height;
      }
      setPos({ x, y });
    } else {
      setShow(false);
    }
  }, [elX, elY, elW, elH, posX, posY, width, height, popoverSize]);

  return (
    <div ref={wrapperRef} style={{ position: 'relative' }}>
      {children}
      <div
        ref={popoverRef}
        style={{
          display: show ? 'block' : 'none',
          position: 'absolute',
          left: pos.x,
          top: pos.y,
          background: '#fff',
          padding: '8px',
          zIndex: '999',
          boxShadow: '0 0 4px 0 rgba(0,0,0,0.14)',
          whiteSpace: 'nowrap',
        }}
      >
        {content}
      </div>
    </div>
  );
});

export default ToolTip;
