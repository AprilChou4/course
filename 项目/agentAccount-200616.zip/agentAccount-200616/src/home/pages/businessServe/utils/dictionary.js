/**
 * @func 数据字典
 */

const getData = (data) => {
  const datas = data;
  datas.map = {};
  datas.list.forEach((ele) => {
    datas.map[ele.value] = ele.name;
  });
  return datas;
};

// 任务状态 （-1无状态，0未开始，1进行中/2已完成/3已终止/4移交中/5待处理)
const taskStatus = {
  title: '任务状态',
  list: [
    {
      name: '进行中',
      value: 1,
    },
    {
      name: '已完成',
      value: 2,
    },
    {
      name: '未开始',
      value: 0,
    },
  ],
};

// 派工状态
const assignStatus = {
  title: '派工状态',
  list: [
    {
      name: '已派工',
      value: 1,
    },
    {
      name: '未派工',
      value: 0,
    },
  ],
};

// 步骤状态 步骤进度0未始，1进行中/2已完成
const stepProcess = {
  title: '步骤状态',
  list: [
    {
      name: '进行中',
      value: 1,
    },
    {
      name: '已完成',
      value: 2,
    },
    {
      name: '未开始',
      value: 0,
    },
  ],
};
// 是否加急 急程度（0一般，1加急）
const emergencyLevel = {
  title: '紧急程度',
  list: [
    {
      name: '一般',
      value: 0,
    },
    {
      name: '加急',
      value: 1,
    },
  ],
};
export default {
  taskStatus: getData(taskStatus),
  assignStatus: getData(assignStatus),
  stepProcess: getData(stepProcess),
  emergencyLevel: getData(emergencyLevel),
};
