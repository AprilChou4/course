import pubData from 'data';
import { message } from 'antd';
import dictionary from './dictionary';

export default dictionary;
