import React from 'react';
import { connect } from 'nuomi';
import classnames from 'classnames';
import { If } from '@components';
import { validateArrayLength } from '@utils';
import HasStepsContent from './HasStepsContent';
import NoStepsContent from './NoStepsContent';
import styles from './styles.less';

const Content = ({ taskId, taskStepVOList }) => {
  return (
    <If condition={taskId}>
      <div className={classnames('taskExecution-steps-container', styles.container)}>
        {validateArrayLength(taskStepVOList) ? <HasStepsContent /> : <NoStepsContent />}
      </div>
    </If>
  );
};

export default connect(({ taskInfo: { taskId, taskStepVOList } }) => ({
  taskId,
  taskStepVOList,
}))(Content);
