/**
 * 进行中的步骤内容
 */
import React, { useCallback, useMemo } from 'react';
import { useUpdateEffect } from 'react-use';
import { connect } from 'nuomi';
import moment from 'moment';
import { Form, Row, Col, Button, DatePicker } from 'antd';
import pubData from 'data';
import { If, GenFormItem, LimitInput, SuperSelect } from '@components';
import { get, omitBy, isNil, getSelectOptions, validateArrayLength } from '@utils';
import UploadAttachment from './UploadAttachment';
import styles from './style.less';

const formItemStyle = {
  width: '100%',
};

const ProcessingStepContent = ({
  index,
  form,
  form: { validateFields },
  data,
  completeUserList,
  shouldUploadAttachment,
  dispatch,
}) => {
  const {
    execute,
    taskId,
    taskStepId,
    serviceProcessStepId,
    stepName,
    stepDescribe,
    stepData,
    stepOutput,
    completeRemark,
  } = data;

  // 注册隐藏域
  form.getFieldDecorator('taskId', {
    initialValue: taskId,
  });
  form.getFieldDecorator('taskStepId', {
    initialValue: taskStepId,
  });
  form.getFieldDecorator('serviceProcessStepId', {
    initialValue: serviceProcessStepId,
  });

  // 完成人下拉框列表
  const completeUserListOptions = useMemo(
    () =>
      getSelectOptions(completeUserList, (item) => ({
        value: item.staffId,
        name: item.realName,
      })),
    [completeUserList],
  );

  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault();
      form.validateFields((err, values) => {
        if (err) {
          return;
        }
        const taskOutputRequestList = [];
        if (validateArrayLength(values.taskOutputRequestList) > 0) {
          values.taskOutputRequestList.forEach((item) => {
            if (get(item, 'response.status') === 200) {
              taskOutputRequestList.push({
                ...get(item, 'response.data', {}),
                taskStepId,
              });
            }
          });
        }
        dispatch({
          type: 'taskStepComplete',
          payload: omitBy(
            {
              ...values,
              taskOutputRequestList,
              completeTime: values.completeTime
                ? moment(values.completeTime).format('YYYY-MM-DD HH:mm:ss')
                : undefined,
            },
            (val) => isNil(val, '') || validateArrayLength(val) === 0,
          ),
        });
      });
    },
    [dispatch, form, taskStepId],
  );

  useUpdateEffect(() => {
    // required字段改变后重新校验，必须加force（对已经校验过的表单域是否再次校验），否则还保留了上次的校验信息，提交表单时校验状态也不对
    validateFields(['taskOutputRequestList'], { force: true });
  }, [shouldUploadAttachment, validateFields]);

  return (
    <div className={styles.content}>
      <div className={styles.title}>{`步骤${index + 1}：${stepName}`}</div>
      <Form className={styles.form} onSubmit={handleSubmit}>
        <GenFormItem label="描述" className={styles.plainItem}>
          {stepDescribe || '无'}
        </GenFormItem>
        <GenFormItem label="资料" className={styles.plainItem}>
          {stepData || '无'}
        </GenFormItem>
        <GenFormItem label="交付件" className={styles.plainItem}>
          {stepOutput || '无'}
        </GenFormItem>
        <If condition={stepOutput}>
          <GenFormItem
            form={form}
            label="附件"
            name="taskOutputRequestList"
            className={styles.upload}
            rules={[
              {
                required: shouldUploadAttachment,
                message: '请上传附件',
              },
            ]}
          >
            <UploadAttachment />
          </GenFormItem>
        </If>
        <GenFormItem
          form={form}
          label="完成说明"
          name="completeRemark"
          initialValue={completeRemark}
        >
          <LimitInput
            allowClear
            placeholder="请输入完成说明"
            maxLength={200}
            style={formItemStyle}
          />
        </GenFormItem>
        <Row gutter={22}>
          <Col span={12}>
            <GenFormItem
              form={form}
              label="完成人"
              name="completeUser"
              initialValue={pubData.get('userInfo_staffId')}
              rules={[
                {
                  required: true,
                  message: '请选择完成人',
                },
              ]}
            >
              <SuperSelect placeholder="请选择完成人" style={formItemStyle}>
                {completeUserListOptions}
              </SuperSelect>
            </GenFormItem>
          </Col>
          <Col span={12}>
            <GenFormItem
              form={form}
              label="完成时间"
              name="completeTime"
              initialValue={moment()}
              rules={[
                {
                  required: true,
                  message: '请选择完成时间',
                },
              ]}
            >
              <DatePicker placeholder="请选择完成时间" allowClear={false} style={formItemStyle} />
            </GenFormItem>
          </Col>
        </Row>
        <If condition={execute}>
          <GenFormItem className="f-tac">
            <Button type="primary" htmlType="submit">
              完成
            </Button>
          </GenFormItem>
        </If>
      </Form>
    </div>
  );
};

export default connect(({ completeUserList, shouldUploadAttachment }) => ({
  completeUserList,
  shouldUploadAttachment,
}))(
  Form.create({
    onValuesChange({ dispatch }) {
      dispatch &&
        dispatch({
          type: 'updateTaskInfo',
          payload: {
            data: {
              isFormValuesChange: true,
            },
          },
        });
    },
  })(ProcessingStepContent),
);
