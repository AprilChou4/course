// import mock from './mock';
import { createServices } from '@utils';

export default createServices({
  // ...mock,
  // 查看任务详情-执行时获取任务单详情
  getTaskInfo: 'instead/v2/customer/task/business/getTask::post',
  // 执行任务-完成状态
  taskComplete: 'instead/v2/customer/task/business/complete::post',
  // 执行任务-撤销状态
  taskRevoke: 'instead/v2/customer/task/business/revoke::post',
  // 执行步骤-完成状态
  taskStepComplete: 'instead/v2/customer/task/business/step/complete::postJSON',
  // 执行步骤-撤销状态
  taskStepRevoke: 'instead/v2/customer/task/business/step/revoke::post',
});
