/**
 * 已完成的步骤内容
 */
import React, { useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { util } from 'nuijs';
import Qs from 'qs';
import moment from 'moment';
import { Descriptions, Button, Typography } from 'antd';
import { If, ShowConfirm, LinkButton, Iconfont } from '@components';
import styles from '../style.less';

const { Paragraph } = Typography;
const { Item: DescriptionsItem } = Descriptions;
const dateFormat = 'YYYY-MM-DD';
const handleFileName = (name = '') => {
  let dotIndex = name.lastIndexOf('.');
  dotIndex = dotIndex > 0 ? dotIndex : name.length;
  return (
    <>
      <Paragraph ellipsis title={name}>
        {name.slice(0, dotIndex)}
      </Paragraph>
      {name.slice(dotIndex)}
    </>
  );
};

const CompletedStepContent = ({ index, data, dispatch }) => {
  const {
    execute,
    taskStepId,
    stepName,
    completeTime,
    completeUser,
    completeRemark,
    taskOutputVOList,
  } = data;

  // 撤销完成
  const handleRevoke = useCallback(() => {
    ShowConfirm({
      title: '你确定要撤销该完成的步骤吗？',
      content: '撤销后，需重新进行完成操作',
      onOk() {
        dispatch({
          type: 'taskStepRevoke',
          payload: { taskStepId },
        });
      },
    });
  }, [dispatch, taskStepId]);

  const content = useMemo(() => {
    const downloadFile = ({ outputFilePath, outputName }) =>
      util.location(
        `${basePath}instead/v2/customer/enclosure/downloadFile.do?${Qs.stringify({
          enclosurePath: outputFilePath,
          enclosureName: outputName,
        })}`,
      );
    const datas = [
      {
        key: 'completeTime',
        label: '完成时间',
        className: styles['item-ellipsis'],
        ellipsis: true,
        content: completeTime ? moment(completeTime, 'YYYY-MM-DD HH:mm:ss').format(dateFormat) : '',
      },
      {
        key: 'completeUser',
        label: '完成人',
        className: styles['item-ellipsis'],
        span: 2,
        ellipsis: true,
        content: completeUser,
      },
      {
        key: 'completeRemark',
        label: '完成说明',
        span: 3,
        content: completeRemark,
      },
      {
        key: 'taskOutputVOList',
        label: '交付件',
        span: 3,
        content: taskOutputVOList.map((item) => (
          <LinkButton
            plain
            key={item.outputFilePath}
            className={styles.file}
            onClick={() => downloadFile(item)}
          >
            <Iconfont type="iconfujian" className={styles['icon-file']} />
            {handleFileName(item.outputName)}
          </LinkButton>
        )),
      },
    ];

    return datas.map((item) => (
      <DescriptionsItem
        key={item.key}
        label={item.label}
        span={item.span}
        className={item.className}
      >
        <Paragraph ellipsis={item.ellipsis} title={item.ellipsis ? item.content : undefined}>
          {item.content}
        </Paragraph>
      </DescriptionsItem>
    ));
  }, [completeRemark, completeTime, completeUser, taskOutputVOList]);

  return (
    <Descriptions
      title={
        <div className={styles.title}>
          {`步骤${index + 1}：${stepName}`}
          <If condition={execute}>
            <Button type="highlight" onClick={handleRevoke}>
              撤销完成
            </Button>
          </If>
        </div>
      }
      className={styles.descriptions}
    >
      {content}
    </Descriptions>
  );
};

export default connect()(CompletedStepContent);
