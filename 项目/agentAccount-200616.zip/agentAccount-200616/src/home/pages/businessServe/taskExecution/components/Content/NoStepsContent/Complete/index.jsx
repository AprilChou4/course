/**
 * 无步骤-已完成的内容
 */
import React, { useCallback } from 'react';
import { connect } from 'nuomi';
import { Button } from 'antd';
import { If } from '@components';
import styles from './styles.less';

const Complete = ({ execute, dispatch }) => {
  const handleRevoke = useCallback(() => {
    dispatch({
      type: 'handleTaskRevoke',
    });
  }, [dispatch]);

  return (
    <div className={styles.complete}>
      <div className={styles.placeholder}>任务已完成</div>
      <If condition={execute}>
        <div className={styles.operation}>
          <Button type="highlight" onClick={handleRevoke}>
            撤销完成
          </Button>
        </div>
      </If>
    </div>
  );
};

export default connect(({ taskInfo: { execute } }) => ({ execute }))(Complete);
