/* eslint-disable no-nested-ternary */
/**
 * 任务单有步骤的内容
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { connect } from 'nuomi';
import { Steps, Typography } from 'antd';
import cls from 'classnames';
import { Layout } from '@components';
import { get } from '@utils';
import { dictionary } from '../../../utils';
import CompletedStepContent from './Content/CompletedStepContent';
import NotStartedStepContent from './Content/NotStartedStepContent';
import ProcessingStepContent from './Content/ProcessingStepContent';
import styles from './style.less';

const { Paragraph } = Typography;
const { Step } = Steps;
const { Left, BFCContent } = Layout;

const stepStatusMap = {
  0: 'wait',
  1: 'wait',
  2: 'finish',
};

const Content = ({ taskStepKey, taskStepVOList, selectStepId, shouldOpenStepIds, dispatch }) => {
  // 展示内容的步骤
  const [openStepIds, setOpenStepIds] = useState([]);

  // 选中一个步骤
  const handleStepsChange = useCallback(
    (current) => {
      // 选中后改变selectStepId，根据数据来控制视图变化
      dispatch({
        type: 'updateTaskInfo',
        payload: {
          data: {
            // selectStepOrder: current,
            selectStepId: get(taskStepVOList, `${current}.${taskStepKey}`),
          },
        },
      });
    },
    [dispatch, taskStepKey, taskStepVOList],
  );

  useEffect(() => {
    setOpenStepIds([...shouldOpenStepIds, selectStepId]);
  }, [shouldOpenStepIds, selectStepId]);

  const stepsContent = useMemo(
    () =>
      taskStepVOList.map((item, index) => {
        const status =
          selectStepId === item[taskStepKey] ? 'process' : stepStatusMap[item.stepStatus] || 'wait';
        const isShowContent = openStepIds.includes(item[taskStepKey]);
        return (
          <Step
            key={item[taskStepKey]}
            className={cls(styles.step, { 'taskExecution-steps-item-open': isShowContent })}
            icon={status === 'finish' ? <span className={styles['icon-finish']} /> : undefined}
            disabled={!item[taskStepKey]}
            status={status}
            title={
              <div className={styles.title}>
                <Left>
                  <Paragraph ellipsis title={item.stepName} className={styles.titleName}>
                    {item.stepName}
                  </Paragraph>
                  <span className={styles.titleStatus}>
                    {get(dictionary.taskStepStatus.map, `${item.stepStatus}`)}
                  </span>
                </Left>
                {isShowContent && (
                  <BFCContent>
                    <div className={styles.content} onClick={(e) => e.stopPropagation()}>
                      {item.stepStatus === 2 ? (
                        <CompletedStepContent data={item} index={index} />
                      ) : item.stepStatus === 1 && item.execute ? (
                        <ProcessingStepContent data={item} index={index} />
                      ) : (
                        <NotStartedStepContent data={item} index={index} />
                      )}
                    </div>
                  </BFCContent>
                )}
              </div>
            }
          />
        );
      }),
    [openStepIds, selectStepId, taskStepKey, taskStepVOList],
  );

  // Steps.current属性要设置成null，因为current所在的step无法点击，而current的默认值是0，并且我们只用Step.status来控制当前步骤，所以最终导致第一步始终无法点击
  return (
    <Steps direction="vertical" current={null} onChange={handleStepsChange}>
      {stepsContent}
    </Steps>
  );
};

export default connect(
  ({ taskStepKey, taskInfo: { taskStepVOList, selectStepId, shouldOpenStepIds } }) => ({
    taskStepKey,
    taskStepVOList,
    selectStepId,
    shouldOpenStepIds,
  }),
)(Content);
