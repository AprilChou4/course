import pubData from 'data';
import { ShowConfirm } from '@components';
import { get, isNil, findLast, validateArrayLength } from '@utils';
import globalServices from '@home/services';
import { message } from 'antd';
import services from '../services';

export default {
  // 初始化
  async initData(init) {
    const { taskIds } = pubData.get('taskExecution-query') || {};
    pubData.set('taskExecution-query', undefined);

    if (validateArrayLength(taskIds)) {
      this.updateTaskIds({ taskIds });
    }
    this.query({
      ...(validateArrayLength(taskIds)
        ? {
            taskId: taskIds[0],
          }
        : {}),
    });
  },

  // 查询
  async query(payload) {
    this.getCompanyBasicSetting();
    this.getCompleteUserList();
    await this.$query(payload);
  },

  // 查看任务执行单信息
  async $query(payload = {}) {
    // const { init } = payload;
    const {
      taskStepKey,
      taskInfo: { taskId: currentTaskId },
    } = this.getState();
    const taskId = payload.taskId || currentTaskId;

    if (!taskId) {
      message.warning('请选择要执行的任务！');
      return;
    }

    const data = await services.getTaskInfo({ taskId }, { loading: '正在获取任务单数据...' });

    const taskStatus = get(data, 'taskStatus');
    const selectStepId = get(data, 'selectStepId');
    const taskStepVOList = get(data, 'taskStepVOList', []);
    let selectStepOrder; // 当前选中的步骤序号
    // 如果任务单是已完成状态 默认展开所有步骤内容，否则 默认展开已完成步骤的上一步可撤销的步骤
    const openStepIds = (taskStatus === 2
      ? taskStepVOList.map((item) => item[taskStepKey])
      : [
          get(
            findLast(taskStepVOList, (item, index) => {
              if (item[taskStepKey] === selectStepId) {
                selectStepOrder = index;
              }
              return (
                index < selectStepOrder &&
                item.execute &&
                item.stepStatus === 2 &&
                taskStepVOList[selectStepOrder].stepStatus === 1
              );
            }),
            taskStepKey,
          ),
        ]
    ).filter((val) => !isNil(val, ''));

    this.updateTaskInfo({
      init: true,
      data: {
        ...(data || {}),
        shouldOpenStepIds: [selectStepId, ...openStepIds],
      },
    });

    // 获取完任务单数据后，定位到第一个展示内容的步骤
    this.positionOpenStep();
  },

  // 更新执行单相关状态
  updateTaskInfo(payload = {}) {
    const { init, data } = payload;
    const { taskInfo } = this.getState();
    this.updateState({
      taskInfo: init
        ? data
        : {
            ...taskInfo,
            ...data,
          },
    });
  },

  // 完成任务
  async $taskComplete() {
    const {
      taskInfo: { taskId },
    } = this.getState();
    await services.taskComplete({ taskId }, { loading: '正在保存...' });
    this.updateDatas();
  },

  // 处理撤销任务
  handleTaskRevoke() {
    const that = this;
    ShowConfirm({
      title: '你确定要撤销已完成的任务吗？',
      content: '撤销后，需重新进行完成操作',
      onOk: () => that.$taskRevoke(),
    });
  },

  // 撤销任务
  async $taskRevoke() {
    const {
      taskInfo: { taskId },
    } = this.getState();
    await services.taskRevoke({ taskId }, { loading: '正在保存...' });
    this.updateDatas();
  },

  // 获取公司基础设置
  async getCompanyBasicSetting() {
    const data = await globalServices.getCompanyBasicSetting();
    const shouldUploadAttachment = !!get(data, 'taskFileUpload');
    this.updateState({
      shouldUploadAttachment,
    });
  },

  // 获取完成人列表
  async getCompleteUserList() {
    const data = await globalServices.getStaffList();
    this.updateState({
      completeUserList: data,
    });
  },

  // 判断执行权限
  async taskCheckAuthority(payload = {}) {
    const { taskIds } = this.getState();
    const data = await globalServices.taskCheckAuthority({
      execute: true,
      taskIdList: payload.taskIds || taskIds,
    });
    const taskIdList = get(data, 'taskIdList', []);
    this.updateTaskIds({
      taskIds: taskIdList,
    });
    return taskIdList;
  },

  // 完成步骤
  async taskStepComplete(payload) {
    await services.taskStepComplete(payload, { loading: '正在保存...' });
    this.updateDatas();
  },

  // 撤销步骤
  async taskStepRevoke(payload) {
    await services.taskStepRevoke(payload, { loading: '正在保存...' });
    this.updateDatas();
  },

  // 更新任务单id队列
  updateTaskIds(payload = {}) {
    const { taskIds } = payload;
    this.updateState({
      taskIds,
    });
  },

  // 操作完成后更新相关数据
  updateDatas(payload) {
    this.taskCheckAuthority();
    this.query(payload);
  },

  // 去下一条任务单
  async toNewTask(payload) {
    const {
      taskInfo: { taskId },
    } = this.getState();
    const { status } = payload;
    // 先更新taskIds;
    const currentTaskIds = await this.taskCheckAuthority();
    const currentIndex = currentTaskIds.findIndex((val) => val === taskId);
    const nextIndex = status === 1 ? currentIndex + 1 : currentIndex - 1;
    const nextTaskId = currentTaskIds[nextIndex];
    if (!nextTaskId) {
      message.warning('所选任务未派工或无权限，无法执行');
      return;
    }
    this.query({ taskId: nextTaskId });
  },

  // 切换任务单
  handleSwitchTask(payload) {
    const that = this;
    const {
      taskInfo: { isFormValuesChange },
    } = this.getState();
    if (isFormValuesChange) {
      ShowConfirm({
        title: '当前操作未保存，确定离开？',
        onOk() {
          that.toNewTask(payload);
        },
      });
    } else {
      this.toNewTask(payload);
    }
  },

  // 获取完任务单数据后，定位到第一个展示内容的步骤
  positionOpenStep() {
    setTimeout(() => {
      const $container = document.querySelector('.taskExecution-steps-container');
      const $openStep = document.querySelector('.taskExecution-steps-item-open');
      if ($container && $openStep) {
        $container.scrollTop = $openStep.offsetTop - $container.offsetTop;
      }
    });
  },
};
