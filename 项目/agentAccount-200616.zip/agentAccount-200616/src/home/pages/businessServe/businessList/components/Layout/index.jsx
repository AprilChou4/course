// 布局-管理者
import React, { useMemo, useRef } from 'react';
import { Layout, ContentWrapper, Authority } from '@components';
import { connect } from 'nuomi';
import useComponentSize from '@rehooks/component-size';
import Search from '../Search';
import CollectionTable from '../Table';
import './style.less';
import AddBtn from '../AddBtn';
import ExecuteBtn from '../ExecuteBtn';
import TaskAssign from '../TaskAssign';
import More from '../More';

const Main = () => {
  const containerRef = useRef(null);
  const containerSize = useComponentSize(containerRef);
  const contentHeight = useMemo(() => containerSize.height || 0, [containerSize.height]);
  return (
    <Layout.PageWrapper>
      <ContentWrapper
        title="工商任务单列表"
        header={{
          left: <Search />,
          right: (
            <>
              <Authority code="602">
                <AddBtn />
              </Authority>
              <Authority code="604">
                <TaskAssign />
              </Authority>
              <Authority code="605">
                <ExecuteBtn type="default" />
              </Authority>
              <More />
            </>
          ),
        }}
        content={
          <div ref={containerRef} style={{ height: '100%' }}>
            <CollectionTable tableHeight={contentHeight} />
          </div>
        }
      />
    </Layout.PageWrapper>
  );
};

export default connect(({ key }) => ({
  key,
}))(Main);
