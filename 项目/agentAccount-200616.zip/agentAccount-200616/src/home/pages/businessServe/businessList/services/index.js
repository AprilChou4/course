import { createServices } from '@utils';
import mock from './mock';

export default createServices({
  getRoletypeList: 'instead/v2/user/staff/role/list.do', // 查询派工角色信息(树结构)，包括开票员等

  getTaskList: 'instead/v2/customer/task/business/list.do::postJSON', // 获取工商任务单列表
  getProductList: 'instead/v2/user/basicSetting/service/process/list.do::post', // 获取服务产品/流程列表接口
  deleteBusiness: 'instead/v2/customer/task/business/delete.do::postJSON', // 任务-删除
  assignBusiness: 'instead/v2/customer/task/business/assign.do::postJSON', // 派工
  getTaskAssign: 'instead/v2/customer/task/business/get.do::post', // 派工-查看任务详情

  queryEmpTree: 'instead/v2/user/staff/tree.do', // 执行人--获取公司所有部门员工树

  // queryEmpTree: 'instead/v2/user/staff/role/list.do',
  // ...mock,
});
