// 更多按钮
import React from 'react';
import { connect } from 'nuomi';
import DropDown from '@components/DropDown';
import Authority from '@components/Authority';
import DeleteBtn from './DeleteBtn'; // 删除
import ExportBtn from './ExportBtn'; // 导出
import pubData from 'data';

const userAuth = pubData.get('authority');
const More = () => {
  return (
    <DropDown>
        {userAuth[606] && <DeleteBtn />}
        {userAuth[607] && <ExportBtn />}
    </DropDown>
  );
};

export default connect()(More);
