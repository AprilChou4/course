// 工商任务列表-管理者
import React, { useMemo } from 'react';
import { connect } from 'nuomi';
import SuperTable from '@components/SuperTable';
import { ColumnsManage, ColumnsExecutor, ColumnsAll } from './Columns';

const ManageTable = ({
  tableList,
  total,
  selectedRowKeys,
  pageSizeOptions,
  current,
  pageSize,
  tableLoading,
  taskAuth,
  dispatch,
  ...rest
}) => {
  // 计算table的scroll。为了保证table的scroll.x大于非固定列的宽度，否则会出现 列头与内容不对齐或出现列重复
  const calcScroll = useMemo(() => {
    const columns = [ColumnsManage, ColumnsExecutor, ColumnsAll][taskAuth - 1];
    const scroll = {};
    if (columns && columns.length !== 0) {
      const colWidthArr = columns.map((v) => v.width || 0);
      const sumWidth = colWidthArr.reduce((preValue, curValue) => preValue + curValue);
      scroll.x = sumWidth + 40;
    }
    return scroll;
  }, [taskAuth]);

  // 页码改变
  const handlePageChange = (page) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        current: page,
      },
    });
  };

  // pageSize 变化
  const handlePageSizeChange = (page, size) => {
    dispatch({
      type: 'updateCondition',
      payload: {
        pageSize: size,
      },
    });
  };

  // 改变复选框
  const changeSelection = (selectedRowKeys, selectedRows) => {
    dispatch({
      type: 'updateState',
      payload: {
        selectedRowKeys,
        selectedRows,
      },
    });
  };
  return (
    <SuperTable
      loading={tableLoading}
      rowKey="taskId"
      // className={Style['m-taskListTable']}
      bordered
      rowSelection={{
        columnWidth: '40px',
        selectedRowKeys,
        onChange: changeSelection,
      }}
      locale={{
        emptyText: '暂无数据',
      }}
      pagination={{
        showSizeChanger: true,
        pageSizeOptions,
        current,
        total,
        pageSize,
        showTotal: (count) => `共${count}条`,
        onChange: handlePageChange,
        onShowSizeChange: handlePageSizeChange,
      }}
      scroll={calcScroll}
      dataSource={tableList}
      {...rest}
      columns={[ColumnsManage, ColumnsExecutor, ColumnsAll][taskAuth - 1]}
    />
  );
};

export default connect(
  ({
    tableList,
    total,
    selectedRowKeys,
    pageSizeOptions,
    tableConditions,
    taskAuth,
    loadings,
  }) => ({
    tableList,
    total,
    selectedRowKeys,
    pageSizeOptions,
    current: tableConditions.current,
    pageSize: tableConditions.pageSize,
    taskAuth,
    tableLoading: loadings.$getTaskList,
  }),
)(ManageTable);
